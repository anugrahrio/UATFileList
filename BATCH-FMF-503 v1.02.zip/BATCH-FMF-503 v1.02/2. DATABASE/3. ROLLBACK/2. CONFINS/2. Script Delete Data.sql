-- FMF-4648
IF EXISTS (SELECT '' FROM paymentallocation WHERE paymentallocationID='STMPFEE' )
BEGIN
    DELETE FROM paymentallocation
    WHERE paymentallocationID = 'STMPFEE';
END