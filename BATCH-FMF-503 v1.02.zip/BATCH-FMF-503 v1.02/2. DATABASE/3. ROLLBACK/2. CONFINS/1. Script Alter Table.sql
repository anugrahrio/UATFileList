--Table ProductOffering
IF EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ProductOffering'
                 AND COLUMN_NAME = 'IsCapitalizedFiduciaFee') 
BEGIN
	ALTER TABLE ProductOffering
       DROP COLUMN IsCapitalizedFiduciaFee
END

IF EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ProductOffering'
                 AND COLUMN_NAME = 'IsCapitalizedStampDutyFee') 
BEGIN
	ALTER TABLE ProductOffering
       DROP COLUMN IsCapitalizedStampDutyFee
END

--table Agreement
IF EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'Agreement'
                 AND COLUMN_NAME = 'FiduciaFeeCapitalized') 
BEGIN
	ALTER TABLE Agreement
       DROP COLUMN FiduciaFeeCapitalized numeric(17,2)
END

IF EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'Agreement'
                 AND COLUMN_NAME = 'StampDutyFeeCapitalized') 
BEGIN
	ALTER TABLE Agreement
       DROP COLUMN StampDutyFeeCapitalized
END

IF EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'Agreement'
                 AND COLUMN_NAME = 'StampDutyFee') 
BEGIN
	ALTER TABLE Agreement
       DROP COLUMN StampDutyFee
END



