IF NOT EXISTS (
    SELECT * FROM sys.tables t 
    JOIN sys.schemas s ON (t.schema_id = s.schema_id) 
    WHERE s.name = 'dbo' AND t.name = 'TblKeywordCompanyName') 
BEGIN
CREATE TABLE [dbo].[TblKeywordCompanyName](
	[ID] [varchar](10) NOT NULL,
	[Description] [varchar](100) NOT NULL,
	[UsrUpd] [dbo].[UsrUpd] NOT NULL,
	[DtmUpd] [dbo].[DtmUpd] NOT NULL
);
END

IF NOT EXISTS (
    SELECT * FROM sys.tables t 
    JOIN sys.schemas s ON (t.schema_id = s.schema_id) 
    WHERE s.name = 'dbo' AND t.name = 'APUCompanyNameLog') 
BEGIN
CREATE TABLE [dbo].[APUCompanyNameLog](
	[CustomerID] [char](20) NOT NULL,
	[CustomerName] [varchar](50) NOT NULL,
	[Keyword] [varchar](8000) NOT NULL,
	[UsrUpd] [varchar](20) NOT NULL,
	[DtmUpd] [datetime] NOT NULL
);
END