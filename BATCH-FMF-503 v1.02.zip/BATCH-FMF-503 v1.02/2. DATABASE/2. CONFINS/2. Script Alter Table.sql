--Table ProductOffering
IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ProductOffering'
                 AND COLUMN_NAME = 'IsCapitalizedFiduciaFee') 
BEGIN
	ALTER TABLE ProductOffering
       ADD IsCapitalizedFiduciaFee bit
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ProductOffering'
                 AND COLUMN_NAME = 'IsCapitalizedStampDutyFee') 
BEGIN
	ALTER TABLE ProductOffering
       ADD IsCapitalizedStampDutyFee bit
END

--table Agreement
IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'Agreement'
                 AND COLUMN_NAME = 'FiduciaFeeCapitalized') 
BEGIN
	ALTER TABLE Agreement
       ADD FiduciaFeeCapitalized numeric(17,2)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'Agreement'
                 AND COLUMN_NAME = 'StampDutyFeeCapitalized') 
BEGIN
	ALTER TABLE Agreement
       ADD StampDutyFeeCapitalized numeric(17,2)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'Agreement'
                 AND COLUMN_NAME = 'StampDutyFee') 
BEGIN
	ALTER TABLE Agreement
       ADD StampDutyFee numeric(17,2)
END



