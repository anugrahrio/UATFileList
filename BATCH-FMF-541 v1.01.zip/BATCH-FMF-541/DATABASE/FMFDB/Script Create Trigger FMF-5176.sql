--FMF-5176 License Plate Kosong pada Agreement Asset
--DROP TRIGGER TGR_AGRAsset_LicensePlate

ALTER TRIGGER TGR_AGRAsset_LicensePlate
ON dbo.AgreementAsset
FOR UPDATE
AS
DECLARE @User AS VARCHAR(12),
        @ExecStr VARCHAR(50),
        @Qry NVARCHAR(4000),
        @APPID VARCHAR(20),
        @LicensePlateOld VARCHAR(10),
        @LicensePlateNew VARCHAR(10);

BEGIN
    CREATE TABLE #inputbuffer
    (
        EventType NVARCHAR(MAX),
        Parameters INT,
        EventInfo NVARCHAR(MAX)
    );

    SET @APPID = '';

    SET @APPID =
    (
        SELECT TOP 1
               Inserted.ApplicationID
        FROM inserted
            INNER JOIN dbo.Agreement AGR
                ON AGR.BranchID = Inserted.BranchID
                   AND AGR.ApplicationID = Inserted.ApplicationID
            INNER JOIN Deleted
                ON Deleted.ApplicationID = Inserted.ApplicationID
                   AND Deleted.AssetSeqNo = Inserted.AssetSeqNo
        WHERE (
                  LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(inserted.LicensePlate, CHAR(9), ''), CHAR(10), ''), CHAR(13), ''))) = ''
                  OR LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(inserted.LicensePlate, CHAR(9), ''), CHAR(10), ''), CHAR(13), ''))) = '-'
              )
              AND Deleted.LicensePlate IS NOT NULL
              AND
              (
                  LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(Deleted.LicensePlate, CHAR(9), ''), CHAR(10), ''), CHAR(13), ''))) <> ''
                  OR LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(Deleted.LicensePlate, CHAR(9), ''), CHAR(10), ''), CHAR(13), ''))) <> '-'
              )
    );

    SET @ExecStr = 'DBCC INPUTBUFFER(' + STR(@@SPID) + ')';

    INSERT INTO #inputbuffer
    EXEC (@ExecStr);

    SET @Qry =
    (
        SELECT EventInfo FROM #inputbuffer
    );

    SELECT @LicensePlateOld = Deleted.LicensePlate
    FROM DELETED;

    SELECT @LicensePlateNew = Inserted.LicensePlate
    FROM INSERTED;

    IF @APPID <> '' AND @LicensePlateOld <> '' AND @LicensePlateOld <> '-'
    BEGIN
        INSERT INTO Sys_AuditLogs
        (
            Event,
            LoginID,
            TableName,
            FieldName,
            KeyValue,
            Status,
            OldValue,
            NewValue
        )
        SELECT GETDATE(),
               SYSTEM_USER,
               'AgreementAsset CEK FMF-5176',
               'ApplicationID_' + @APPID,
               @Qry,
               'U',
               CAST(@LicensePlateOld AS VARCHAR(1000)),
               CAST(@LicensePlateNew AS VARCHAR(1000));

    END;

END;