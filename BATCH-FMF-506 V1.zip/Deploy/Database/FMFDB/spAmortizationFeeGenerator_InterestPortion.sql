USE [FMFDB]
GO
/****** Object:  StoredProcedure [dbo].[spAmortizationFeeGenerator_InterestPortion]    Script Date: 1/29/2024 1:19:41 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



/*
=============================================
Author		: Sugiono
Create date	: 24 November 2022
Description	: PI-4397 Effort bulan Desember 2022 - FMF (Sugi) : Tambah exec spAmortizationFeeGenerator_InterestPortion untuk handle tebaran PSAK Plus Minus
=============================================
Modification :
1. Restu 29 Jan 2024 FMF-4862 : Kirim SP ini ke FMF, sebelumnya dicreate atas temuan daily balancing tetapi blm sempat terkirim ke FMF
=============================================
*/

CREATE PROCEDURE [dbo].[spAmortizationFeeGenerator_InterestPortion]
    @BranchId VARCHAR(3) ,
    @ApplicationID VARCHAR(20)
AS
    SET NOCOUNT ON; 

    DECLARE @OSAmountInstallmentSchedule Amount ,
        @FeeAmount Amount ,
        @AmortizationAmountField AS VARCHAR(100) ,
        @RunningAmountField AS VARCHAR(8000) ,
        @OSAmortizationAmountField VARCHAR(100) ,
        @SQLFeeAmount VARCHAR(8000) ,
        @SqlInstallmentSchedule VARCHAR(8000);
		
--=======================================================================
    DECLARE @tblAmortizationMaster TABLE
        (
          seqno INT IDENTITY ,
          amortizationid CHAR(10)
        );

    DECLARE @StartLoop INT ,
        @EndLoop INT ,
        @SeqNo1 INT ,
        @EndInsSeqNo INT ,
        @AmortizationID VARCHAR(10) ,
        @DateAmortization DATETIME;


	----------------------------------------------------------------
    DECLARE @assettypeid VARCHAR(10);
    
	SELECT  @assettypeid = pr.AssetTypeID
    FROM    Agreement ag WITH ( NOLOCK )
            INNER JOIN Product pr WITH ( NOLOCK ) ON pr.ProductID = ag.ProductID
    WHERE   ag.ApplicationID = @ApplicationID
            AND ag.BranchID = @BranchId;
	-------------------------------------------------------

    INSERT  INTO @tblAmortizationMaster
            ( amortizationid
            )
            SELECT  amortizationid
            FROM    AmortizationMaster
			WHERE assettypeid = @assettypeid AND IsActive = 1

    SELECT  @EndLoop = COUNT(seqno)
    FROM    @tblAmortizationMaster;

    SET @StartLoop = 1;
    SET @SeqNo1 = 1;
    SELECT  @EndInsSeqNo = COUNT(InsSeqNo)
    FROM    InstallmentSchedule
    WHERE   ApplicationID = @ApplicationID
            AND BranchId = @BranchId;

    WHILE @SeqNo1 <= @EndInsSeqNo
        BEGIN
            WHILE @StartLoop <= @EndLoop
                BEGIN
                    SELECT  @AmortizationID = amortizationid
                    FROM    @tblAmortizationMaster
                    WHERE   seqno = @StartLoop;
    
	--=======================================================================
                    SELECT  @AmortizationAmountField = AmortizationField ,
                            @RunningAmountField = RunningAmountField_InterestPortion ,
                            @OSAmortizationAmountField = OSAmortizationField ,
                            @SQLFeeAmount = SQLFeeAmount ,
                            @SqlInstallmentSchedule = SQLInstallmentSchedule_InterestPortion
                    FROM    AmortizationMaster
                    WHERE   AmortizationID = @AmortizationID AND AssetTypeID = @assettypeid AND AmortizationField IS NOT NULL; 

					IF @AmortizationID = 'DIFFRATE'
					AND @AssetTypeID = '4'
					AND EXISTS ( SELECT ''
								 FROM   AmortizationMaster WITH ( NOLOCK )
								 WHERE  AssetTypeID = @AssetTypeID
										AND AmortizationID = 'DIFFRATE'
										AND IsActive = 0 )
					BEGIN
						UPDATE  InstallmentSchedule
						SET     DiffRateAmount = 0 ,
								OutStandingDiffRateAmount = 0
						WHERE   BranchId = @BranchId
								AND ApplicationID = @ApplicationID;
					END;

                    SET @SQLFeeAmount = REPLACE(@SQLFeeAmount, '$BranchID', '''' + @BranchId + '''');
                    SET @SQLFeeAmount = REPLACE(@SQLFeeAmount, '$ApplicationID', '''' + @ApplicationID + '''');



                    SET @SqlInstallmentSchedule = REPLACE(@SqlInstallmentSchedule, '$BranchID', '''' + @BranchId + '''');
                    SET @SqlInstallmentSchedule = REPLACE(@SqlInstallmentSchedule, '$ApplicationID', '''' + @ApplicationID + '''');
                    SET @SqlInstallmentSchedule = REPLACE(@SqlInstallmentSchedule,
                                                          '$InsSeqNo', @SeqNo1);
	
                    CREATE TABLE #OSAmountInstallmentSchedule
                        (
                          OSInstallmentScheduleAmount NUMERIC(17, 2)
                        );

                    CREATE TABLE #FeeAmountTbl ( FeeAmount NUMERIC(17, 2) ); 
					

                    EXEC ('Insert Into #FeeAmountTbl ' +  @SQLFeeAmount + '');
	
                    SELECT  @FeeAmount = FeeAmount
                    FROM    #FeeAmountTbl;

                    IF @FeeAmount <> 0
                        BEGIN
                            EXEC ('Insert Into #OSAmountInstallmentSchedule ' +  @SqlInstallmentSchedule);
		
                            SELECT  @OSAmountInstallmentSchedule = OSInstallmentScheduleAmount
                            FROM    #OSAmountInstallmentSchedule;
							
                            IF @OSAmountInstallmentSchedule <> 0
                                BEGIN 
									EXEC ('	Update	InstallmentSchedule
                                    set		' + @AmortizationAmountField + ' = qry1.AmortizationAmount
                                    From
                                    (Select BranchID, ApplicationID, InsSeqNo, 
                                    ((' + @RunningAmountField + ' / ' + @OSAmountInstallmentSchedule + ' ) * ' + @FeeAmount + ' ) as AmortizationAmount
                                    From	InstallmentSchedule
                                    where	BranchID = ''' + @BranchId + ''' and 
                                    applicationid = ''' + @ApplicationID + '''
                                    and InstallmentSchedule.InsSeqNo >= ''' + @SeqNo1 + ''') qry1
                                    Where	InstallmentSchedule.BranchID = Qry1.BranchID 
                                    and InstallmentSchedule.ApplicationID = Qry1.ApplicationID And 
                                    InstallmentSchedule.InsSeqNo = Qry1.Insseqno ');

                                   
                                END;
		--------------------------------------------------------------------------------------------------------------

                            EXEC ('	Update	InstallmentSchedule
									Set		' + @AmortizationAmountField + ' = ' + @AmortizationAmountField + ' + Qry1.RoundedAmount
									From 
									(Select Top 1 
									BranchID, ApplicationID, 
									(Select Max(InsSeqNo) - 2 from InstallmentSchedule Inst2 Where Inst2.BranchID = InstallmentSchedule.BranchID and 
									Inst2.ApplicationID = InstallmentSchedule.ApplicationID) AS InsSeqNo, ' +
									@FeeAmount + '- (	Select Sum(' + @AmortizationAmountField + ') 
									from	InstallmentSchedule Inst1 
									Where	Inst1.BranchID = InstallmentSchedule.BranchID 
									and Inst1.ApplicationID = InstallmentSchedule.ApplicationID
									AND Inst1.InsSeqNo >= '''+@SeqNo1+''') as RoundedAmount
									From	InstallmentSchedule
									where	BranchID = ''' + @BranchId + ''' and 
									applicationid = ''' + @ApplicationID + ''' ) As Qry1
									Where	InstallmentSchedule.BranchId = Qry1.BranchId 
									and InstallmentSchedule.ApplicationID = Qry1.ApplicationID
									and InstallmentSchedule.InsseqNo = Qry1.InsSeqNo ');

                            EXEC ('	Update	InstallmentSchedule
									Set		' + @OSAmortizationAmountField + ' = Qry1.OSAmortizationFee
									From
									(Select BranchID, ApplicationID, InsSeqNo, 
									isnull((Select Sum(' + @AmortizationAmountField + ') 
									From	InstallmentSchedule Inst1 
									Where	Inst1.BranchID = InstallmentSchedule.BranchID 
									AND Inst1.ApplicationID = InstallmentSchedule.ApplicationID 
									AND Inst1.InsSeqNo > InstallmentSchedule.InsSeqNo),0) AS OSAmortizationFee
									From	InstallmentSchedule
									where	BranchID = ''' + @BranchId + ''' and 
									applicationid = ''' + @ApplicationID + ''' 
									and InsSeqNo >= ''' + @SeqNo1 + ''') Qry1
									Where	InstallmentSchedule.BranchId = Qry1.BranchID 
									and InstallmentSchedule.ApplicationID = Qry1.ApplicationID  
									and InstallmentSchedule.InsSeqNo = Qry1.InsSeqNo ');
                        END;

                    DROP TABLE #OSAmountInstallmentSchedule;
                    DROP TABLE #FeeAmountTbl;
	
                    SET @StartLoop = @StartLoop + 1;
                END;
            SET @SeqNo1 = @SeqNo1 + 1;
        END;



    SET ANSI_NULLS ON;
    SET QUOTED_IDENTIFIER ON;

