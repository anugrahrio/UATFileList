---Notes dijalankan per no urut (satu-satu)


----1. ALTER TABLE AmortizationMaster
ALTER TABLE AmortizationMaster
ADD RunningAmountField_InterestPortion VARCHAR(8000)
ALTER TABLE AmortizationMaster
ADD SQLInstallmentSchedule_InterestPortion VARCHAR(8000)

---2. UPDATE TABLE AmortizationMaster
UPDATE	AmortizationMaster
SET		RunningAmountField_InterestPortion ='ISNULL(InterestAmount,0)',
		SQLInstallmentSchedule_InterestPortion = 'SELECT SUM(ISNULL(InterestAmount,0)) FROM dbo.InstallmentSchedule WHERE ApplicationID=$ApplicationID AND BranchID=$BranchID AND InsSeqNo>=$InsSeqNo'

