USE [FMFDB]
GO
/****** Object:  StoredProcedure [dbo].[spGoLiveProcess]    Script Date: 2/27/2024 3:44:34 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- gcp : 17/04/2002: Tambahkan/Update Field SupplierID di table AccountPayable (proses A/P to Supplier)              
-- Fixed In Line 626              
/*Modification :              
1. 3 Maret 2004 jam 19:32 : tetap ALTER  AP INSR walaupun StdPremium=0              
2. 4 Maret 2004 jam 18:33 : AP INSR statusnya N, bukan H              
3. Teddy, 31 May 2004               
   Add Process : ADD  AP for Supplier Incentive Employee               
   ADD  Journal for Supplier Incentive Employee               
4. Teddy, June 6 2004              
   Add Validation If SupplierBranch doesn't have IncentiveCardID yet then SupplierIncentivePerAgreement.IncentiveCardID = 0               
5. Teddy, June 9, 2004              
   Add Process : Update Agreement FundingData              
6. Teddy, June 22 2004              
   Drop Validation If SupplierBranch doesn't have IncentiveCardID yet then SupplierIncentivePerAgreement.IncentiveCardID = 0               
7. Teddy, June 22, 2004              
   Modify Call SPACtivtyLOG              
8. teddy, June 22, 2004              
   Modify Insert into supplierIncentivePerAgreement.TotalIncentive=SupplierIncentiveDailyDCO.IncentiveForRecepient              
9. Teddy, June 25, 2004              
   Modify join from agreementAsset to assetMaster for insert into SupplierIncentivePerAgreement               
10. Teddy, July 20, 2004              
    modify Journal SuplierIncentiveBalance              
11. 23 August 2004 :  INSRCRTEXP terdiri dari   premi standard + AP supplier incentive              
--------------------------------------------------------------------------------------              
Clipan modification :              
Widi 17 Sept 2004              
1. Tidak ada journal BBNADV               
2. Journal INSRCRTEXP = AdminFeetoCust + MateraiFeeToCust              
3. Journal OPINSUR = = AdminFeetoCust + MateraiFeeToCust              
4. Penambahan PDCPromisedDate di agreement              
5. Tidak ada BBNFee              
6. DeliveryOrderDate diambil dari tbl Agreement (yg lama diambil dr AgreementAsset, tidak bisa dilakukan di Clipan karena Multi Asset)              
7. Advance Installment bisa > 1, jadi update Due Date di tbl Installment Schedule = Effective Date, bisa lbh dari 1 Installment juga              
8. Update ContractPrepaidAmount di tbl PurchaseOrder hanya yang IsMainPO = 1              
9. Insert ke tbl Fiducia              
10. Harus looping untuk update field ExpectedReceivedDate di tbl AssetDocumentContent              
11. Tabel InsuranceAsset keynya hanya BranchID dan ApplicationID              
12. Looping untuk update field AccountPayableNo di tbl PO              
13. tabel AccountPayable, untuk AP Supplier, yg main PO = PO Total + ContractPrepaidAmount. lainnya = PO Total saja              
14. Tidak insert ke tbl MailTransaction lagi, karena semua Document diALTER  sewaktu PO              
15. Tidak insert ke SupplierIncentivePerAgreement              
16. AP to InsCo = PremiumAmountToInsCo + AdminFee + MeteraiFee              
17. Jurnal:              
 ARGROSS  : (D) Sum(InstallmentAmount) kecuali yg AdvanceInstallment              
 UCI   : (C) Sum(InterestAmount)              
 ADMINFEE : (C) AdminFee            
 ADMFEEADV : (C) AdminFee in Advance            
 PROVISIFEE : (C) ProvisionFee              
 NOTARYFEE : (C) NotaryFee              
 FIDUADV  : (C) FiduciaFee (jika hendak difiduciakan)              
 FIDUFEE  : (C) FiduciaFee (jika tidak difiduciakan)              
 SURVEYFEE : (C) SurveyFee              
 OTHERFEE : (C) OtherFee              
 INSRCRTEXP : (D) Total Komisi dari Insurance Income + Premium Amount to InsCo + Admin Fee to InsCo + Meterai Fee to InsCo              
  revisi tgl 17 dec:              
     (D) hanya utk At Cost, Premium Amount to InsCo               
 APINSUR  : (C) Premium Amount to InsCo + Admin Fee to InsCo + Meterai Fee to InsCo              
 APINCSPL2 : (C) Total Komisi dari Insurance Income + Upping Bunga + Other Fee untuk Supplier Employee - TaxAmount               APTAXPS : (C) Commision.TaxAmount              
 APINCSPL1 : (C) Total Komisi dari Insurance Income + Upping Bunga + Other Fee untuk Supplier - TaxAmount              
 APTAXCO : (C) Commision.TaxAmount              
              
 APINCSPL3 : (C) Total Komisi dari Insurance Income + Upping Bunga + Other Fee untuk Referantor              
         INSURINC : (C) Jika untung : Premi ke Customer - Premi ke InsCo - komisi yg sudah diberikan (Termasuk Admin dan meterai)              
   : (D) Jika rugi   : Premi ke Customer - Premi ke InsCo - komisi yg sudah diberikan (Termasuk Admin dan meterai)              
 APSUPPLIER : (C) Total PO Amount + Contract Prepaid Amount              
 ECI   : (D) Total Komisi dari Upping Bunga, jika Eff Rate > Supp Rate              
      (C) DiffRateAmount * -1, jika Eff Rate < Supp Rate               
 COMMEXP  : (D) Total Komisi dari Other Fee              
              
u/Payment History, ditambahkan:              
 INSTALLRCV : (C) Sum(InstallmentAmount) yg AdvanceInstallment                   
 diupdate:              
 ARGROSS  : (D) ARGROSS + INSTALLRCV              
              
18. Field FlagInsActivation , FlagInsStatus , FlagInsStatusDate , FlagDocStatus ,FlagRenew  dari tbl Insurance Asset               
    tidak di update krn di New Application Insurance Fiel tsb sudah di update              
              
Clipan Modification : Henry              
1. Floating History: Ditambahkan field OldOsPrincipal, NewOSPrincipal, OldOsInstallmentDue, NewOsInstallmentDue              
              
ratna 17 dec 2004              
1. u/Leasing, tambahkan jurnal berikut, nilai diambil dr tbl Agreement.DownPayment              
     D C              
 RESIDUAL : X -              
 SECDEPOSIT : - X              
               
ratna 11 jan 2005              
1. tidak ada pengecekan apakah supplier punya GM, BM, ADH, karena incentive ke supplier tidak diatur oleh system              
              
 Teddy, April 15th, 2005              
 Modification : add ALTER  AP and Journal for TAX (Supplier Company and Supplier Employee)               
               
ratna 7 mei 2005              
- u/ARGROSS dan UCI, dibulatkan round(0)              
- AP Type Komisi untuk supplier, disamakan dengan SPPL              
- bila AP Type Komisi > 0, baru dibuat record di Account Payable              
              
ratna 10 mei 2005              
- u/ARGROSS dan UCI, dijadikan floor              
              
Johnson 17 Mei 2005  Tambah Proses Insert Ke SMSMessageOut              
Johnson 17 Mei 2005  : Remark Proses ALTER  Apay Supplier n Insert To Jurnal              
Teddy 18 Mei 2005 : Ubah Bagian Menghitung Commision Data untuk supplier Dan Supplier Employee               
Johnson 21 Mei 2005 : Remark --> if  @TotalSupplierIncome > 0  , Karena  commission Supplier               
 Tidak Dimasukkan kedalam Jurnal Lagi (Versi BDF)              
Teddy, 27 May 2005 : Disabled Modification ON ratna 7 May 2005 for rounding ARGross dan UCI              
Henry, 09 Juni 2005: AP Due Date 'INCE' dengan tanggal business date              
              
ratna 13 juni 2005 : MaturityDate untuk yg Step Up Step Down tipe II dan III, diambil dari Due Date Installment yg ke CummulativeTenor,               
untuk Installment Scheme lainnya, diambil dari Due Date Installment yg ke Num of Installment              
Teddy, July 5th, 2005 : add Process Insert Into Sales.ProductType = Agreement.ProductType              
Johnson, 15 juli 2005 : Ubah @ContractPrepaidAmount dengan @TDPAmount, Semua Perubahan ada keterangan : Johnson, 15 juli 2005              
Johnson, 7 September 2005 : Tambah Looping Untuk Other Supplier Ketika masukin ke AccountPayable              
Johnson, 11 Oct 2005 : Convert(Varchar(10),@APDueDate,101)              
Johnson, 6 Des 2005 : Tambah Process Get KPPName From GeneralSetting Dan              
         ApTo Untuk APTAX diganti dengan @KPPName, Account No = '-'              
Johnson, 13 des 2005 : Tambah Param @LastDateOfMonth              
Yovita Des 16 2005 : Di Installment Schedulee, update PaidDate = @EffectiveDate, bukan @BusinessDate              
Yovita 21 Dec 2005 : Tambah Jam pada @BusinessDate, @AgreementDate         
Yovita Jan 25 2006 : Update CurrencyRate Di tblAgreement dari table Currency               
emilia 9/2/06 : menambahkan variable untuk life insurance dan                
Yovita Ap 24 06 : Add Params @EffectiveRateType and change insert for floatinghistory.FloatingNExtReviewDate              
Yovita 27 Aug 2007: Insert data firstinstallment, NextInstallmentNumber, NextInstallmentDate, NextInstallmentDueNumber, NextInstallmentDueDate              
        ke table CollectionAgreement (atas Request jessy)              
Leonita 30 Agustus 2007  :  samakan untuk proses funding dengan kitaf              
Gema 25 September 2007 : Add Net Rate Amortization dari KITAF (Untuk komisi Referantor dan SupplierEmployee)              
Gema, 25 September 2007 :Pemilihan Insco secara Automatis              
Gema, 25 September 2007 : Tambah perhitungan CoyPortion untuk ARGROSS dan UCI              
Gema, 25 September 2007 : Update GLJournalD untuk paymentallocation ARBNK dari FundingCoy              
Gema, 27 September 2007 : Rubah paymentAllocation ECISSIDY menjadi ECISSIDYAR (subsidy) dan ECIRFDN menjadi ECIRFDNAR (Refund)               
Gema, 1 Oktober 2007 : Tambah cek NormalType dari productoffering jika 'LB' maka di isi data dari Customer            
Gema, 2 Oktober 2007 : Tambah other Income untuk journal.             
                       Sewaktu create payment history tidak pakai funding #tempTable dikembalikan ke awal. Untuk Advance             
                       instalmment pertama di ambil dari installment scheme.            
Gema, 8 Oktober 2007 : Tambah parameter @ActivityStartDate untuk Activity Log             
Lisa, 18 Oktober 2007 : Hitung FundingCoyPortion Menggunakan generateFundingCoyPortionJFCHN            
-- Yovita 19 Okt 2007: ubah paymentallocationid dari ECIRFNDAR jadi RATERFND dan ECISSIDYAR jadi RATESSIDY untuk samain dengan KITAF            
Leonita 18 December 2007 perbaikin untuk parameter coa dari varchar(10) menjadi varchar(25)          
Gema, 16 Jan 2008 : Tambah update agreement FlagCs = 'B' (Pledging Before Golive) Flag Cs Dipinda Ke agreement          
Gema, 20 Feb 2008 : Remark FlagCs = B sewaktu get FundingPortion          
LELE 28052008 : subsidy tidak terjurnal jika effrate=supprate          
revised by Andy 29 Mei 2008 : mencegah agar proses insert tetap dapat dijalankan untuk OTHERINC          
MUL 29052008           
Leonita 5 Juni 2008           
untuk argross,Refund  dimasukkan ke temptable jika <> 0          
Leonita 13 Juni 2008 untuk pengecekan exec spUpdateInterestInsSche mengecek effectiverate < = 0 bukan effectiverate < 0          
Andreas 30 Juni 2008 tambah spSelectInscoFromFundingCoyInsurance dari fundingcoyinsurance untuk mengambil insurancecompany          
Leonita menyamakan dengan versi BII -- Lisa 20080703 : Perbaikan utk tipe supplier personal          
Gema, 20081008 : Add Round untuk perhitungan @ARBNK          
Gema, 20081016 : Pindain OTHERINC dibawah 'RATEINEXP'          
Gema, 20081107 : Amortize Additional Admin Fee ke table installmentschedule          
                 dan pindahkan process amortize diffrate dan adminfee setelah update due date, supaya duedatenya tdk NULL            
Amelya , 180309 : ganti Select TopDays di ambil dari table Supplier (TopDays)          
Lisa 20091229 : Remark pengecekan ApDueDate terhadap EffectiveDate, utk handle tgl 28-31 yang jd tgl 1-4          
David 25Jan2010 : pembuatan PSAK          
David 29Jan2010 : memindahkan proses Pemilihan Insco secara Automatis ke step sebelum hitung grossyieldAcct di golive (spSelectInscoAutomatic)          
Rubianto, 20100330 : tambahkan script DELETE dbo.TempIncomeNet          
David 8Juni2010 : pastikan stepnya diperbolehkan utk golive (masih sama dengan yg dipaging golive)          
Arif 7 oktober 2010: pengaturan amortization agar mendukung untuk per asset   
Gema, 20101008 : Pindain cek amortisasinya kedalam if karena ada tambahan cek minimumamount           
arif 30 11 2010 : berikan penambahan validasi untuk @adminfee          
arif 4 januari 2011 : penambahan pejagaan untuk amount minimum          
arif 18 jan 2011 : tambah penjagaan ERROR kalo cost OF survey > 0          
ria 18 jan 2011 : UPDATE Agreement           
SET costofsurvey=costofsurvey*-1           
WHERE ApplicationId = @ApplicationId and BranchId = @BranchID AND costofsurvey>0          
          
UPDATE dbo.InstallmentSchedule          
SET CostOfSurveyFeeAmount=CostOfSurveyFeeAmount*-1          
WHERE ApplicationId = @ApplicationId and BranchId = @BranchID AND CostOfSurveyFeeAmount>0          
          
David 25Jan2011 recheck InsuranceAsset          
Rudi, 05 Dec 2011 : Tambahkan WITH(NOLOCK), pindahkan proses update Agreement punya Arif, hilangkang CURSOR          
Dewi, 22 February 2012 : tambahkan wherecond AND AmortizationID <> 'PROVFEEJF'          
          
Hendrik Wijaya, On 26 June 2012 : - Add Parameter @POSID          
          - Update POSID = @POSID          
          - Update POSID = @POSID          
Dessy Ratih, 31 Agustus 2012 : FMF-1141 ubah cara ambil @TotalOtherFee dan tambah bentuk jurnal untuk APVoucher          
Dessy Ratih, 21 Sept 2012    : FMF CR IJON, jika SupplierEmployee nya adalah IJON, maka update SupplierEmployee.OSIJONAmount dan RequestIJON.AmountRealized          
          
Johan, 2 Oct 2012 : Perubahan sewaktu pecah AP jika isAPToInscoAnually = 1 dan CoverPeriod = FT          
Dessy Ratih, 16 Oct 2012 : CR IJON tambah penjagaan jika SupplierEmployee nya IJON tapi belum request IJON sama sekali          
Dessy, 29Jan2013 (FMF-1272) : tambah set @AdditionalAdminFee = 0 buat default value biar ga dapet null          
Dewi, 16 Okt 2013 : tambah set @TotalOtherFee = 0 untuk VoucherMethod = C, sehingga apabila C tidak bentuk APVOUCHER          
Dessy, 12 Des 2013 : (FMF-1326) karena ada issue anomali FMF-1215 (licenseplate ada di agreementasset tapi tidak ada di assetattributecontent), maka tambah proses INSERT licenseplate di assetattributecontent          
Johan, 12 Mar 2014 : CR OJK          
Dea, 3/17/2015 FMF-1413 Tanggal Golive beda -> @BusinessDate dari BDCurrent SystemControlCoy          
Albert, 06-07-2015 FMF-1427, Add Checking if the agreement is A/P Disburse to Customer          
Anita, 20150709 FMF-1422 tambahan (@IsAssetInsured = 0 AND @LifeInsuranceIncome <> 0)  supaya dapat handle Life Insurance electronic           
Anita, 20150710 FMF-1427 rubah APAmount dan APTo untuk APType INCS          
Fuji, 20151124 FMF-1454 Tambah Pengecekan Way OF Financing dan Purpose OF Financing          
arinta, 20151228, FMF-1465 CR Sales and Lease Back          
arinta, 20160127, FMF1465 CR Sales And Lease Back (Remark WayOfFinacing dan Purpose Of Financing karna bentrok POJK)          
Lingga,25 Mei 2016 (FMF-1496)           
 INSERT data ke agreement asset value          
Novia, 17 Juni 2016 : FMF-1515          
Albert Ricia, 16 Agustus 2016 : FMF-1515          
inggrid, 17 feb 2017 FMF-1576 OJK pembatasan insentive          
Inggrid 27 feb 2018 FMF-1594          
Aditia FMF-1640 12032018 Tambah provisionfee          
Eka, 09 Januari 2019 FMF-1761 Tambah 'RATEINEXP' POST C untuk handle yang @InterestExpenseAmount minus (effectiverate = 0)          
Eka, 09 Januari 2019 FMF-1763 Ubah COAID untuk APLFINSUR diambil dari LifeinsuranceCoyBranch          
Fuji,11 Des 2019 (FMF-1819) : Tambah Journal Credit Insurance,Kemudian Pada saat Journal DEFINSUR/INSREXPDEF di tambah dengan @CreditInsuranceAmount ,supaya amount nya tidak ngaco karena untuk Credit Insurance Journal nya sendiri sedangkan Amortisasinya 
  
     
      
       
di set off dengan DEFINSINC          
Adhitya 11 Maret 2020 (FMF-1819): Merubah Journal Credit Insurance yang awalnya menggunakan DEFINSUR/INSREXPDEF dipindahkan ke INSREXPDEF / INSRCRTEXP          
Adhitya 11 Juni 2020(FMF-2220): Melakukan Update COA dari CreditInsuranceCoyBranch untuk PaymentAllocation CINSEXPDEF dan APCRDINS          
      
Felix Y FMF-2233 7-Sep-2020 penambahan marketing program        
Candra 9 Nov 2020 [FMF-2451] : jika provision fee di amortisasi maka totalotherfee nya akan ditambah dengan nilai refund provision fee   
Felix Y 13-November 2020 [FMF-2273] memasukan customer KreditMu   
Vincenza FMF-2420 18112020 : InterestRate save ke ContractPrepaidAmount  
Ria 24 Nov 2020 REMARK SEMENTARA PEKERJAAN FELIX (KARENA INI TIDAK MASUK DI BATCH-4) [FMF-2273] memasukan customer KreditMu   
Ria 1 Dec 2020 restore collection agreement yang "hilang"  
Ria 6 Jan 2021 restore PEKERJAAN FELIX [FMF-2273] memasukan customer KreditMu   
Candra, 29 April 2021 [FMF-2748] : Ubah pengambilan COA untuk INSREXPDEF semua asset, ambil dari Journal Scheme saja, karena pas accrued juga pakai COA dari Journal Scheme  
Vincenza FMF-2705 22032022 : Supplier IJON  
Vincenza FMF-2737 09062022 : Agreement Allocation  
Vincenza FMF-3854 19102022 : Penjagaan Allocation hanya lebih besar  
Jason [FMF-3934], 18 November 2022 : Penambahan case when untuk variabel @CommisionMainSuppEmp Dimana ada case gross (SupplierEmployeeUppingBunga) dan net (SupplierEmployeeUppingBunga-SupplierEmployeeTaxAmount) *Dikurangin pajak karena nett  
Fuji,07 Des 2022 : (FMF-3885) Deposit Amount dialokasikan ke titipan customer (Agreement.ContractPrepaidAmount) dan akan terbentuk journal prepaid di posisi Credit  
Fuji,09 Des 2022 : Perbaiki Bugs CR (FMF-3546) Split Tax Amount SupplierEmployee antara Personal dan Company (Journal dan Pembentukan Account Payable) - Temuan Internal ,Instruksi dari Pak Joko tanpa tiket JIRA titip di tiket fmf-3885 saja  
Fuji,18 Jan 2023 : (FMF-4114) Perbaiki  journal prepaid di posisi credit tidak terbentuk karena belum handle untuk keadaan kontrak factoring yang memiliki Interest Rate Amount namun tidak memiliki Deposit Amount  
Victor, 25 Jan 2023 : (FMF-4071) sesuai permintaan client untuk AP to Supplier Employee & Referantor hanya bisa dibayarkan di HO, sehingga paymentLocation dihardcode ke HO  
Fuji,27 Jan 2023 : (FMF-4017) Ubah perhitungan SeubsidyCommision jika ada VAT/PPN  
Vincent , 7 Feb 2023 : (FMF-3862) Penambahan Kondisi Untuk CR KMB dan Exec SP baru dibuat   
Fuji,08 Maret 2023 : (FMF-4127) Add Take Over Amount menggunakan PaymentAllocation = TAOVERAMT  
Victor 19 Okt 2023 - FMF-4676 - penambahan kondisi untuk paymentAllocation insurance income jika insurance asset tidak ada tapi life insurance ada     
Fajar 11 Nov 2023 : (FMF-4301) Auto Disburse non SPPL dan pengacualian kontrak PSA
Restu, 29 Jan 2024 : (FMF-4862) Tambah generator interest portion untuk handle psak plus minus
*/              
              
ALTER PROCEDURE [dbo].[spGoLiveProcess]          
    @BranchID CHAR(3) ,          
    @ApplicationID CHAR(20) ,          
    @EffectiveDate DATETIME ,          
    @AgreementDate DATETIME ,          
    @BusinessDate DATETIME ,          
    @AppID VARCHAR(10) ,          
    @Notes TEXT = NULL ,          
    @FundingCoyID CHAR(20) ,          
    @FundingContractNO CHAR(20) ,          
    @FundingBatchNO CHAR(20) ,          
    @PDCPromisedDate DATETIME ,          
    @ActivityStartDate DATETIME ,          
    @POSID VARCHAR(50)-- = NULL -- Hendrik Wijaya, On 26 June 2012 --DESSY SEMENTARA KASIH DEFAULT NULL          
AS          
              
          
    
    
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
SET NOCOUNT ON              
  SET XACT_ABORT ON;  
  --SELECT * FROM ABC
 --Vincenza FMF-2705 22032022  
 Declare @PrpHoldStatusIJON varchar(20), @AgrNoIJON varchar(20), @FlagIjon bit, @AppIDIjon varchar(20),  
 @IJONAllocationID Bigint  
 if exists (select '' from AgreementIJONAllocation where ApplicationID = @ApplicationID)  
 begin  
  set @FlagIjon = 1  
    
  select @IJONAllocationID = IJONAllocationID from AgreementIJONAllocation with (nolock)  
  where ApplicationID = @ApplicationID   
  
  if exists (select '' from Agreement agr with (nolock)  
  inner join (  
  select ijon.IJONAllocationID, ijd.ApplicationIDIJON, ijd.BranchIDIJON from AgreementIJONAllocation ijon with (nolock)   
  inner join AgreementIJONAllocationDetail ijd with (nolock)  on ijon.IJONAllocationID = ijd.IJONAllocationID   
  where IJON.IJONAllocationID = @IJONAllocationID   
  )IJON on IJON.BranchIDIJON  = agr.BranchID and IJON.ApplicationIDIJON = agr.ApplicationID  
  where (agr.DefaultStatus not in ('NM','NA') or agr.ContractStatus not in ('LIV','ICP') or agr.PrepaidHoldStatus not in ('NM','NA') )  
  )  
  begin  
  
   select top 1 @PrpHoldStatusIJON = PrepaidHoldStatus, @AgrNoIJON = AgreementNo from Agreement agr with (nolock)  
   inner join AgreementIJONAllocationDetail ijon with (nolock) on agr.BranchID = ijon.BranchIDIJON and agr.ApplicationID = ijon.ApplicationIDIJON   
   where Ijon.IJONAllocationID = @IJONAllocationID and ( agr.DefaultStatus not in ('NM','NA') or agr.ContractStatus not in ('LIV','ICP') or agr.PrepaidHoldStatus <> 'NM' )  
  
   set @PrpHoldStatusIJON =   
   case @PrpHoldStatusIJON when 'PP' then 'Prepayment'  
   when 'PP' then 'Prepayment'  
   when 'RS' then 'Rescheduling'  
   when 'RF' then 'Refund To Customer'  
   when 'AR' then 'Asset Replacement'  
   when 'WT' then 'Waive Transaction'  
   when 'DC' then 'Due Date Change'  
   when 'AT' then 'Agreement Transfer'  
   when 'AP' then 'Asset Prepayment'  
   END  
  
   RAISERROR ('Agreement No %s %s Must be Solved First!', 16, 1,  @AgrNoIJON, @PrpHoldStatusIJON  )          
            GOTO ExitSP  
  end  
  
    
  
  if exists ( select '' from AgreementIJONAllocation with (nolock) where IJONAllocationID > @IJONAllocationID  )  
  begin  
   Raiserror('Another IJON Agreement Go Live, Please Recalculate for IJON Allocation!',16,1)  
   GOTO ExitSP  
  end  
  
 end  
 --end   
  
 --Vincenza FMF-2737 09062022  
 declare @BranchIDAlloc varchar(3), @AppIDAlloc varchar(20), @PaymentType varchar(2), @PrepaymentNo varchar(20), @FlagAlloc bit, @TotalAmountToBeAllocated numeric(17,2), @PoAlloc numeric(17,2)  
  select @PoAlloc =  POTotal from PurchaseOrder  with (nolock) where branchID = @BranchID and ApplicationID = @ApplicationID  
  
  if exists( select '' from AgreementDisbAllocation  with (nolock) where branchID = @BranchID and ApplicationID = @ApplicationID)  
  begin  
   select @BranchIDAlloc = BranchIDAllocation , @AppIDAlloc = ApplicationIDAllocation, @PaymentType = PaymentType, @PrepaymentNo = ISNULL(PrepaymentNo,''), @TotalAmountToBeAllocated = TotalAmountToBeAllocated from AgreementDisbAllocation with (nolock) 
   where branchID = @BranchID and ApplicationID = @ApplicationID  
   --Vincenza FMF-3854 19102022  
   --if  @PoAlloc <=  @TotalAmountToBeAllocated  
   if  @PoAlloc <  @TotalAmountToBeAllocated  
   begin  
    RAISERROR('Alokasi PO harus lebih besar daripada Alokasi Agreement!',16,1)  
    goto exitSP  
   end  
  
   if exists (select '' from agreement agr with (nolock)   
   inner join AgreementAsset aga with (nolock) on agr.branchID = aga.branchID and agr.ApplicationID = aga.ApplicationID   
   where agr.BranchID = @BranchIDAlloc and agr.ApplicationID = @AppIDAlloc and agr.ContractStatus in ('LIV','ICP') and DefaultStatus  in ('NM','NA') and aga.AssetStatus = 'NOR' and agr.prepaidHoldStatus in ('NM','NA','PP') and agr.WayOfPayment <> 'IJ' )  
   begin  
    if exists (select '' from agreement agr with (nolock)  
     left join Prepayment pp with (nolock) on agr.branchID = pp.branchID and agr.ApplicationID = pp.ApplicationID   
     left join NonAccrual na with (nolock) on agr.branchID = na.branchID and agr.ApplicationID = na.ApplicationID   
     where agr.BranchID = @BranchIDAlloc and agr.ApplicationID = @AppIDAlloc   
     and (( ISNULL(na.ProcessID,'') = 'M' and ISNULL(na.ApprovalStatus,'') = 'R') or ISNULL(pp.PrepaymentStatus,'') = 'R' ) )  
    begin  
     RAISERROR('Status Requesting Non Accrual Manual atau Prepayment harus di Reject/Accept!',16,1)  
     goto exitSP  
    end  
  
    if @PaymentType = 'ET'  
    begin  
     if @PrepaymentNo <> ''  
     begin  
      set @FlagAlloc = 1  
     end  
     else   
     begin  
      RAISERROR('Harus Proses Amendment Prepayment dan Sudah di Approve!',16,1)  
      goto exitSP  
     end  
    end  
    else if @PaymentType = 'NM'  
    begin  
     set @FlagAlloc = 1  
    end  
   end  
   else  
   begin  
    RAISERROR('Contract Status harus LIV/ICP, Default Status NM/NA, WOP bukan IJON, Requesting Process Status NM/NA/PP dan Asset Status Normal!',16,1)  
    goto exitSP  
   end  
  end  
 --end   
  
 --David 8Juni2010 : pastikan stepnya diperbolehkan utk golive          
    IF NOT EXISTS ( SELECT  ''          
                    FROM    Agreement WITH ( NOLOCK )          
                            INNER JOIN ProductOffering po WITH ( NOLOCK ) ON Agreement.BranchID = po.BranchID          
                                                              AND Agreement.ProductOfferingID = po.ProductOfferingID          
                                                              AND Agreement.ProductID = po.ProductID          
         WHERE   Agreement.applicationID = @ApplicationID          
                            AND Agreement.BranchID = @BranchID          
                            AND ( ( ApplicationStep = 'DLO'          
                                    AND po.AssetTypeID <> 10          
                                    AND Agreement.ApplicationId IN (          
                                    SELECT  applicationid          
                                    FROM    InvoiceAgreement WITH ( NOLOCK ) )          
                                  )          
                                  OR ( ApprovalDate IS  NULL          
                                       AND po.AssetTypeID = 10          
                                     )          
                                )          
                            AND IsRejected = 0          
                            AND IsCancelled = 0          
                            AND ContractStatus = 'PRP'          
                            AND GoLiveDate IS NULL )          
        BEGIN          
            RAISERROR ( 'This agreement''s status has been updated by other user',          
                16, 1 )          
            GOTO ExitSP          
        END          
--David 8juni2010 selesai          
--remark arinta di karenaka bentrok POJK,FMF-1465 Sales And Lease Back           
-------------add fuji ,24 Nov 2015 (fmf-1454)---------------          
 --DECLARE @PurposeOfFinancingID VARCHAR(10),          
 --@WayOfFinancing VARCHAR(10)          
          
 --SELECT @PurposeOfFinancingID=PurposeofFinancingID,@WayOfFinancing=WayofFinancingID          
 --FROM dbo.Agreement           
 --WHERE BranchID=@BranchID           
 --AND ApplicationID=@ApplicationID          
          
 --IF (@PurposeOfFinancingID IS NULL OR @PurposeOfFinancingID='' OR @WayOfFinancing IS NULL OR @PurposeOfFinancingID='')          
 --       BEGIN          
 --           RAISERROR('You can  golive ! Because PurposeOfFinancing or WayOfFinancing Is Null !', 16,1)            
 --           GOTO exitsp           
 --       END           
          
-------------end fuji------------------          
          
          
    DECLARE              
 -- Variable Storage for Agreement --              
        @AgreementNo CHAR(20) ,          
        @ProductID CHAR(10) ,          
        @ProductOfferingID CHAR(10) ,          
        @CustomerID CHAR(20) ,          
        @CustomerName VARCHAR(50) ,          
        @DefaultStatus CHAR(3) ,          
        @NewApplicationDate DATETIME ,          
        @NextInstallmentDate DATETIME ,          
        @NextInstallmentDueDate DATETIME ,          
        @NextInstallmentNumber SMALLINT ,          
        @NextInstallmentDueNumber SMALLINT ,          
        @MaturityDate DATETIME ,          
        @FloatingPeriod VARCHAR(2) ,          
        @FloatingNextReviewDate DATETIME ,          
        @InsAssetReceivedInAdv NUMERIC(17, 2) ,          
        @InsAssetCapitalized NUMERIC(17, 2) ,          
   @InsAssetInsuredBy VARCHAR(10) ,          
        @InsAssetPaidBy VARCHAR(10) ,          
        @InsAssetPeriod CHAR(1) ,          
        @TotalOTR NUMERIC(17, 2) ,          
        @DownPayment NUMERIC(17, 2) ,          
        @NTF NUMERIC(17, 2) ,          
        @EffectiveRate NUMERIC(9, 6) ,       
        @FlatRate NUMERIC(9, 6) ,          
        @SupplierRate NUMERIC(9, 6) ,          
        @PaymentFrequency CHAR(1) ,          
        @FirstInstallment CHAR(2) ,          
        @InstallmentScheme CHAR(2) ,          
        @InterestType CHAR(2) ,          
        @NumOfInstallment SMALLINT ,          
        @Tenor SMALLINT ,          
        @CummulativeTenor SMALLINT ,          
        @InstallmentAmount NUMERIC(17, 2) ,          
        @AdminFee NUMERIC(12, 2) ,          
        @FiduciaFee NUMERIC(12, 2) ,          
        @ProvisionFee NUMERIC(12, 2) ,          
        @NotaryFee NUMERIC(12, 2) ,          
        @SurveyFee NUMERIC(12, 2) ,          
        @CostofSurvey NUMERIC(12, 2) ,          
        @OtherFee NUMERIC(12, 2) ,          
        @CancellationFee NUMERIC(12, 2) ,          
        @OutstandingPrincipal NUMERIC(17, 2) ,          
        @OutstandingInterest NUMERIC(17, 2) ,          
        @OutstandingPrincipalUnDue NUMERIC(17, 2) ,          
        @OutstandingInterestUnDue NUMERIC(17, 2) ,          
        @TDPAmount NUMERIC(17, 2) ,          
        @ContractPrepaidAmount NUMERIC(17, 2) ,          
        @AmountTolerance NUMERIC(17, 2) ,          
        @PercentagePenalty NUMERIC(9, 6) ,          
        @DiffRateAmount NUMERIC(17, 2) ,          
        @InstallmentDue NUMERIC(17, 2) ,          
        @InstallmentDuePaid NUMERIC(17, 2) ,          
        @InsuranceDue NUMERIC(17, 2) ,          
        @DeliveryOrderDate DATETIME ,          
        @AOID CHAR(10) ,          
        @AOSupervisorID CHAR(10) ,          
        @GMID CHAR(10) ,          
        @BMID CHAR(10) ,          
        @ADHID CHAR(10) ,          
        @WayOfPayment CHAR(2) ,          
        @NumofAdvanceInstallment SMALLINT ,          
        @NumOfAssetUnit SMALLINT ,          
        @IsFiduciaCovered BIT ,      
  --Vincenza FMF-2420 18112020  
  @IsFactoring BIT,  
  @InterestRate Amount,  
  @CreditInsuranceBy char(1),  
  @AgentFee Amount,  
  --End   
  @DepositAmount Amount, --Add fuji,07122022 (fmf-3885)     
  @TakeOverAmount Amount, --Add fuji,08032023 (fmf-4127)      
              
 -- Variable Storage for InstallmentSchedule --              
        @DueDate DATETIME ,              
              
 -- Variable Storage for AgreementAsset --              
        @DPAmount NUMERIC(17, 2) ,              
              
 -- Variable Storage for AccountPayable --              
        @AccountPayableNo VARCHAR(50) ,          
        @APSequenceNo INT ,          
        @PONo VARCHAR(50) ,          
        @POInstallment NUMERIC(17, 2) ,          
        @TOPDays INT ,          
        @SupplierID CHAR(10) ,          
        @SupplierIDPO CHAR(10) ,          
        @APDueDate DATETIME ,          
        @PaymentLocation CHAR(3) ,          
        @BankName VARCHAR(50) ,          
        @BankBranch VARCHAR(50) ,          
        @AccountName VARCHAR(50) ,          
        @AccountNo VARCHAR(25) ,          
        @APTo VARCHAR(200) ,          
        @APStatus CHAR(1) ,          
        @KodeHO CHAR(3) ,          
        @InvoiceNo CHAR(20) ,          
        @InvoiceDate DATETIME ,              
               
 -- Variable Storage for InsuranceAsset --              
        @AssetSeqNo SMALLINT ,          
        @InsSequenceNo SMALLINT ,          
        @InsuranceCoyID CHAR(10) ,          
        @InsuranceCoyBranchID CHAR(10) ,          
        @AdminFeeToCust NUMERIC(17, 2) ,          
        @MeteraiFeeToCust NUMERIC(17, 2) ,          
        @PolicyReceiveDate DATETIME ,          
        @InsuranceType CHAR(2) ,          
        @StartDate DATETIME ,          
        @EndDate DATETIME ,          
        @YearNum INT ,          
        @FlagRenew CHAR(1) ,          
        @InsLength SMALLINT ,          
        @PremiumAmountByCust NUMERIC(17, 2) ,          
        @PremiumAmountToInsCo NUMERIC(17, 2) ,          
        @AdminFeeToInsCo NUMERIC(17, 2) ,          
        @MeteraiFeeToInsCo NUMERIC(17, 2) ,         
              
 -- Variable Storage for ProductBranch --              
        @LengthMainDocProcess SMALLINT ,              
        
 -- Variable Storage for AssetDocumentContent --              
        @ExpectedReceivedDate DATETIME ,              
              
 -- Variable Storage for NotaryCharge --              
        @NotaryID CHAR(10) ,          
        @OTRFrom NUMERIC(17, 2) ,          
        @OTRUntil NUMERIC(17, 2) ,          
        @NotaryChg NUMERIC(17, 2) ,          
        @DepKehChg NUMERIC(17, 2) ,          
        @RoyaChg NUMERIC(17, 2) ,          
        @RoyaChg2Cust NUMERIC(17, 2) ,              
              
 -- Variable Storage for PaymentHistoryHeader --              
        @HistorySequenceNo SMALLINT ,          
        @Tr_Nomor VARCHAR(50) ,          
        @Tr_Desc VARCHAR(80) ,              
              
 -- Variable Storage for Customer --              
        @FirstAgreementDate DATETIME ,              
              
 -- Variable Storage for SalesReport --              
 -- ratna 02/09 --              
        @ReportID INT ,          
        @1From NUMERIC(17, 2) ,          
        @1To NUMERIC(17, 2) ,          
        @1Text VARCHAR(50) ,          
        @2From NUMERIC(17, 2) ,          
        @2To NUMERIC(17, 2) ,          
        @2Text VARCHAR(50) ,          
        @3From NUMERIC(17, 2) ,          
        @3To NUMERIC(17, 2) ,          
        @3Text VARCHAR(50) ,          
        @4From NUMERIC(17, 2) ,          
        @4To NUMERIC(17, 2) ,          
        @4Text VARCHAR(50) ,          
        @5From NUMERIC(17, 2) ,          
        @5To NUMERIC(17, 2) ,          
        @5Text VARCHAR(50) ,          
        @6From NUMERIC(17, 2) ,          
        @6To NUMERIC(17, 2) ,          
        @6Text VARCHAR(50) ,          
        @7From NUMERIC(17, 2) ,          
        @7To NUMERIC(17, 2) ,          
        @7Text VARCHAR(50) ,          
        @8From NUMERIC(17, 2) ,          
        @8To NUMERIC(17, 2) ,          
        @8Text VARCHAR(50) ,          
        @9From NUMERIC(17, 2) ,          
        @9To NUMERIC(17, 2) ,          
        @9Text VARCHAR(50) ,          
        @10From NUMERIC(17, 2) ,          
        @10To NUMERIC(17, 2) ,          
        @10Text VARCHAR(50) ,          
        @Text VARCHAR(50) ,          
        @PercentDP NUMERIC(9, 6) ,              
              
 -- Variable Storage for Journal --              
        @ARGross NUMERIC(17, 2) ,          
        @TotalInterest NUMERIC(17, 2) ,          
        @FirstInstallmentAmount NUMERIC(17, 2) ,          
        @APSupplier NUMERIC(17, 2) ,          
        @CompanyID CHAR(3) ,              
              
 -- Variable Storage for MailTransaction --              
        @UserCreate VARCHAR(20) ,              
              
 -- Variable Storage for Account GL untuk InsuranceCoyBranch --              
 -- ratna 22/12/2004              
        @AccountGL ShortDescription ,              
              
 -- Variable Storage for Product Type (Consumer Finance / Finance Lease) --              
 -- ratna 17 dec               
        @ProductType CHAR(2) ,          
        @NormalType VARCHAR(20) , --arinta, 28 des 2015, fmf-1465                 
             
 -- Variable Storage for Processing --              
        @CtrNo INT ,          
        @Description VARCHAR(100) ,          
        @JournalDate DATETIME ,          
        @FloatingUntilDate DATETIME ,          
        @SelisihPHDebitCredit DECIMAL(18, 6) ,          
        @TotalPHDebit DECIMAL(18, 6) ,          
        @TotalPHCredit DECIMAL(18, 6) ,          
        @return_status INT ,          
        @Result VARCHAR(1000) ,          
        @ReceiptNo CHAR(20) ,          
        @Error INT ,          
        @CurrencyID CHAR(3) ,          
        @CurrencyRate NUMERIC(17, 2) ,          
        @IsMainPO SMALLINT ,          
        @CtrSeqNo SMALLINT ,          
        @CustomerType CHAR(1) ,              
               
 --ratna 13 juni 2005              
 --buat deklarasi untuk simpan variabel StepUpStepDownType              
        @StepUpStepDownType CHAR(2) ,              
               
 ---Teddy Sept 13 05              
 --Variabel To Funding Batch              
        @FundingBankID CHAR(5) ,          
        @LastDateOfMonth DATETIME ,              
              
              
 -- Variable Storage for LifeInsurance --              
 -- Emilia 9/2/2006              
 -- @AssetSeqNo    smallint,              
        @InsSeqNo SMALLINT ,          
        @LifeInsuranceCoyID CHAR(10) ,          
        @LifeInsuranceCoyBranchID CHAR(10) ,          
        @LifeAdminFee NUMERIC(17, 2) ,          
        @LifeStampDutyFee NUMERIC(17, 2) ,          
        @PolicyDate DATETIME ,          
        @BankID VARCHAR(5) ,          
        @InsuredBy CHAR(10) ,          
        @PaidBy CHAR(2) ,              
 --@YearNum    int,              
 --@FlagRenew    char(1),              
 --@InsLength    smallint,              
        @Premium NUMERIC(17, 2) ,          
        @PremiumToInsCo NUMERIC(17, 2) ,          
        @EffectiveRateType CHAR(1) ,          
        @PledgeStatus VARCHAR(10) ,          
--mul variable baru untuk meniympan interest yang minus          
        @InterestExpenseAmount NUMERIC(17, 2) ,          
        @strTemp VARCHAR(50) ,          
        @PaymentAllocID VARCHAR(20) ,--David 25Jan2010,           
        @IsAssetInsured BIT --anita, 20150709          
           
 --variable storage buat amortizationmaster          
    DECLARE @assettypeid AS VARCHAR(10)          
               
  --Add fuji,12 Des 2019 (fmf-1819)          
  DECLARE @PremiumCreditIns NUMERIC(17, 2) ,          
        @AdminFeeCreditIns NUMERIC(17, 2) ,          
        @StampFeeCreditIns NUMERIC(17, 2),           
  @CreditInsAmountTotal Numeric (17,2)          
  --end fuji 
             
    SET NoCount ON              
              
--------------------------              
-- Initialize Variables --              
--------------------------              
          
               
    SET @NextInstallmentNumber = 0              
    SET @NextInstallmentDueNumber = 0              
    SET @InsAssetReceivedInAdv = 0              
    SET @InsAssetCapitalized = 0              
    SET @TotalOTR = 0              
    SET @DownPayment = 0              
    SET @NTF = 0              
    SET @EffectiveRate = 0              
    SET @FlatRate = 0              
    SET @SupplierRate = 0              
    SET @NumOfInstallment = 0              
    SET @Tenor = 0              
    SET @CummulativeTenor = 0              
    SET @InstallmentAmount = 0              
    SET @FirstInstallmentAmount = 0              
    SET @AdminFee = 0              
    SET @FiduciaFee = 0              
    SET @ProvisionFee = 0              
    SET @NotaryFee = 0              
    SET @SurveyFee = 0          
    SET @CostofSurvey = 0              
    SET @OtherFee = 0              
    SET @CancellationFee = 0              
    SET @TDPAmount = 0              
    SET @AdminFeeToCust = 0              
    SET @MeteraiFeeToCust = 0              
    SET @ContractPrepaidAmount = 0              
    SET @AmountTolerance = 0              
    SET @PercentagePenalty = 0              
    SET @DiffRateAmount = 0              
    SET @InstallmentDue = 0              
    SET @InstallmentDuePaid = 0              
    SET @InsuranceDue = 0              
    SET @DPAmount = 0              
    SET @AccountPayableNo = 0              
    SET @POInstallment = 0              
    SET @TOPDays = 0              
    SET @PremiumAmountByCust = 0              
    SET @AssetSeqNo = 0              
    SET @InsSequenceNo = 0              
    SET @OTRFrom = 0              
    SET @OTRUntil = 0              
    SET @NotaryChg = 0              
    SET @DepKehChg = 0              
    SET @RoyaChg = 0              
    SET @RoyaChg2Cust = 0              
    SET @HistorySequenceNo = 0              
    SET @CtrNo = 0              
    SET @TotalInterest = 0              
    SET @APSupplier = 0              
    SET @OutstandingPrincipalUndue = 0              
    SET @OutstandingInterestUndue = 0              
    SET @AOSupervisorID = NULL              
    SET @GMID = NULL              
    SET @BMID = NULL              
    SET @ADHID = NULL              
 --Vincenza FMF-2420 18112020  
 SET @InterestRate  = 0  
 SET @IsFactoring = 0  
 SET @CreditInsuranceBy = ''  
 SET @AgentFee = 0  
 --end   
 SET @DepositAmount =0 --add fuji,07122022 (fmf-3885)  
    SET @TakeOverAmount  = 0 --Add fuji,08032023 (fmf-4127)
         
    SET @BusinessDate = ( SELECT    BDCurrent          
                          FROM      systemcontrolcoy          
                        ) --Add Dea 3/17/2015 FMF-1413 Tanggal Golive beda          
          
    IF @PDCPromisedDate = '19000101'          
        SET @PDCPromisedDate = NULL              
              
    SELECT  @LastDateOfMonth = dbo.LastFullDateOfMonth(LTRIM(RTRIM(STR(MONTH(@BusinessDate)))),          
                                                       LTRIM(RTRIM(STR(YEAR(@BusinessDate)))))              
  --arif 7 okt 2010          
    SELECT  @assettypeid = pr.assettypeid          
    FROM    Agreement ag WITH ( NOLOCK )          
            INNER JOIN Product pr WITH ( NOLOCK ) ON pr.ProductID = ag.ProductID          
    WHERE   ag.ApplicationID = @applicationID          
            AND ag.BranchID = @branchID          
 --end arif          
          
   --inggrid 17 feb 2017 FMF-1576          
    DECLARE @MaxRefundAmount Amount ,          
        @InterestAmountMaxRefund Amount ,          
        @InsuranceIncomeMaxRefund Amount ,          
        @AdminFeeMaxRefund Amount ,          
        @ProvisionFeeMaxRefund Amount ,          
        @MaxIncentiveOJK NUMERIC(9,6) ,          
        @MaxRefundAmountNew Amount ,          
        @LifeInsAmtMaxRefund Amount ,          
        @SurveyFeeMaxRefund Amount ,          
        @OtherFeeMaxRefund Amount ,          
        @AddAdminFeeMaxRefund Amount ,          
        @TotalRefund Amount,          
        @AssetType CHAR(10)             
            
    EXEC GetIncentiveOJKInfo @ApplicationID, @BranchID,          
        @MaxRefundAmountNew OUTPUT            
               
    SET @MaxRefundAmount = ( SELECT ISNULL(MaxRefundAmount, 0)          
                         FROM   dbo.Agreement          
                             WHERE  BranchID = @BranchID          
                                    AND ApplicationID = @ApplicationID          
                           )             
    SET @MaxIncentiveOJK = ( SELECT GSValue          
                             FROM   dbo.GeneralSetting          
                             WHERE  GSID = 'MAXINCENTIVEOJK'          
                           )          
    SET @MaxRefundAmountNew = ( @MaxIncentiveOJK / 100.00 )          
        * ISNULL(@MaxRefundAmountNew, 0)          
          
    SET @TotalRefund = ( SELECT SUM(SupplierInsuranceIncome          
                                    + SupplierEmployeeInsuranceIncome          
                                    + ReferenceNameInsuranceIncome          
                                    + SupplierUppingBunga          
                                    + SupplierEmployeeUppingBunga          
                                    + ReferenceNameUppingBunga          
                                    + SupplierOtherFee          
                                    + SupplierEmployeeOtherFee          
                                    + ReferenceNameOtherFee          
         --Aditia FMF-1640 09032018          
         + ISNULL(SupplierProvisionFee,0)          
                                    + ISNULL(SupplierEmployeeProvisionFee,0)          
                                    + ISNULL(ReferenceNameProvisionFee,0)          
         --END Aditia          
      )          
                         FROM   dbo.Commision          
                         WHERE  BranchID = @BranchID          
                                AND ApplicationID = @ApplicationID          
                       )          
          
 SET @AssetType = ( SELECT   AssetTypeID          
                       FROM     dbo.Agreement WITH ( NOLOCK )          
                                INNER JOIN dbo.ProductOffering WITH ( NOLOCK ) ON dbo.ProductOffering.BranchID = dbo.Agreement.BranchID          
                                                              AND dbo.ProductOffering.ProductID = dbo.Agreement.ProductID          
                                                              AND dbo.ProductOffering.ProductOfferingID = dbo.Agreement.ProductOfferingID          
                       WHERE    dbo.Agreement.BranchID = @BranchId          
                                AND ApplicationID = @ApplicationID          
                     )          
  --IF ( (@MaxRefundAmount <> @MaxRefundAmountNew AND @AssetType <> '4')          
  --       OR (@TotalRefund > @MaxRefundAmountNew AND @AssetType <> '4')          
  --     )          
  --      BEGIN          
             
  --          RAISERROR('Maximum Refund Has Changed, Please Review Commission Data !', 16,1)          
  --        IF @@error > 0          
  --              BEGIN            
  --                  GOTO exitsp             
  --              END                 
  --      END             
  --end inggrid             
-----------------------              
-- Begin Transaction --              
-----------------------              
    BEGIN TRANSACTION tranGoLive              
--select '' from abc      --debug     
--SELECT * FROM abcded --test jason  
          
  
------------------------              
-- Get Data Agreement --              
------------------------              
            
    SELECT  @AgreementNo = AgreementNo ,          
            @ProductID = ProductID ,          
            @ProductOfferingID = ProductOfferingID ,          
            @CustomerID = CustomerID ,          
            @CurrencyID = CurrencyID ,          
            @TotalOTR = TotalOTR ,          
            @DownPayment = DownPayment ,          
            @NTF = NTF ,          
            @EffectiveRate = EffectiveRate ,          
            @FlatRate = FlatRate ,          
            @SupplierRate = SupplierRate ,          
            @PaymentFrequency = PaymentFrequency ,          
            @FirstInstallment = FirstInstallment ,          
            @InstallmentScheme = InstallmentScheme ,          
            @InterestType = InterestType ,          
            @NumOfInstallment = NumOfInstallment ,          
            @Tenor = Tenor ,          
            @CummulativeTenor = CummulativeTenor ,          
            @InstallmentAmount = InstallmentAmount ,          
            @AdminFee = AdminFee ,          
            @FiduciaFee = FiduciaFee ,          
            @ProvisionFee = ProvisionFee ,          
            @NotaryFee = NotaryFee ,          
            @SurveyFee = SurveyFee ,          
            @CostofSurvey = costofsurvey ,          
            @OtherFee = OtherFee ,          
            @InsAssetCapitalized = InsAssetCapitalized ,          
            @InsAssetInsuredBy = InsAssetInsuredBy ,          
            @InsAssetPaidBy = InsAssetPaidBy ,          
            @InsAssetPeriod = InsAssetPeriod ,          
            @NewApplicationDate = NewApplicationDate ,          
            @TDPAmount = TDPAmount ,          
            @FloatingPeriod = FloatingPeriod ,          
            @DeliveryOrderDate = DeliveryOrderDate ,          
            @DiffRateAmount = DiffRateAmount ,          
            @AOID = AOID ,          
            @WayOfPayment = WayOfPayment ,          
            @SupplierID = SupplierID ,          
            @ContractPrepaidAmount = ContractPrepaidAmount ,          
            @NumofAdvanceInstallment = NumofAdvanceInstallment ,          
            @NumOfAssetUnit = NumOfAssetUnit ,          
            @IsFiduciaCovered = IsFiduciaCovered ,              
 --ratna 13 juni 2005              
 --ambil data StepUpStepDownType dan masukkan ke variabel              
            @StepUpStepDownType = StepUpStepDownType ,              
 -- Yovita Ap 24 06 : Add Params @EffectiveRateType              
            @EffectiveRateType = ISNULL(EffectiveRateType, 'S') ,          
 -- MUL May 13 08 : Add Params @EffectiveRateType           
            @InterestExpenseAmount = InterestExpenseAmount ,          
   --Vincenza FMF-2420 18112020  
   @InterestRate = ISNULL(InterestRate,0),   
   @CreditInsuranceBy = ISNULL(CreditInsuranceBy,''),  
   @AgentFee = ISNULL(AgentFee,0),  
   --end Vincenza  
            @IsAssetInsured = IsAssetInsured , --Anita, 20150709    
   @DepositAmount=ISNULL(DepositAmt,0),  --add fuji,07122022 (fmf-3885)   
   @TakeOverAmount = ISNULL(TakeOverAmt,0) --Add fuji,08032023 (fmf-4127)  
    FROM    Agreement WITH ( NOLOCK )          
    WHERE   ( Agreement.BranchID = @BranchID )          
            AND ( Agreement.ApplicationID = @ApplicationID )               
    IF @@error <> 0          
        GOTO ExitSP              
    --Vincenza FMF-2420 18112020  
   
 select @IsFactoring = ISNULL(AT.isFactoring,0)  from Agreement agr with (nolock)  
 inner join ProductOffering PO with (nolock) on agr.ProductID = PO.ProductID and agr.ProductOfferingID = PO.ProductOfferingID  
 inner join AssetType AT with (nolock) on AT.AssetTypeID = PO.AssetTypeID   
 where agr.ApplicationID = @ApplicationID and agr.BranchID = @BranchID   
  
 if @IsFactoring = 1 and @InterestRate > 0  
 begin  
  set @ContractPrepaidAmount += @InterestRate   
 end  
 --end Vincenza  
  
-- ratna 17 dec 2004              
-- get currency rate, untuk diinsert ke tabel account payable              
    SELECT  @CurrencyRate = DailyExchangeRate          
    FROM    currency WITH ( NOLOCK )          
    WHERE   CurrencyID = @CurrencyID              
          
 --Inggrid 27 feb 2018 FMF-1594          
    IF EXISTS ( SELECT  ''          
                    FROM    dbo.Product          
                    WHERE   ProductID = @ProductId          
                            AND ISNULL(FlagSimpleDoc, 0) = 1 )          
        BEGIN           
            UPDATE  dbo.Customer          
            SET     FlagSimpleDoc = 1          
            WHERE   CustomerID = @CustomerID          
        END          
    --end inggrid          
---------------------------------------------              
-- Dessy add 12 Des 2013 (FMF-1326), tambah insert licenseplate          
---------------------------------------------              
    IF EXISTS ( SELECT  ''          
                FROM    agreementasset WITH ( NOLOCK )          
                WHERE   branchid = @branchid          
                        AND applicationid = @applicationid          
                        AND licenseplate <> ''          
AND NOT EXISTS ( SELECT ''          
                                         FROM   AssetAttributeContent          
                                         WHERE  branchid = agreementasset.branchid          
                                                AND applicationid = agreementasset.applicationid          
                                                AND assetseqno = agreementasset.assetseqno          
                                                AND AttributeID = 'LICPLATE' ) )          
        BEGIN          
            INSERT  INTO AssetAttributeContent          
                    ( branchid ,          
                      applicationid ,          
                      assetseqno ,          
                      attributeid ,          
                      assettypeid ,          
                      attributecontent ,          
                      usrupd ,          
                      dtmupd          
                    )          
                    SELECT  branchid ,          
                            applicationid ,          
                            assetseqno ,          
                            'LICPLATE' ,          
                            assettypeid ,          
               LicensePlate ,          
                            SYSTEM_USER ,          
                            GETDATE()          
                    FROM    agreementasset WITH ( NOLOCK )          
                    WHERE   branchid = @branchid          
                            AND applicationid = @applicationid          
                            AND licenseplate <> ''          
                            AND  EXISTS ( SELECT ''          
                                             FROM   AssetAttributeContent          
                                             WHERE  branchid = agreementasset.branchid          
                                                    AND applicationid = agreementasset.applicationid          
                                                    AND assetseqno = agreementasset.assetseqno          
                                                    AND AttributeID = 'LICPLATE' )          
            IF @@error <> 0          
                GOTO ExitSP                  
        END          
---------------------------------------------              
              
---------------------------------------------              
-- update ke table Purchase Order di field ContractPrepaidAmount              
-- untuk keperluan View AP Detail di APDisbursement              
---------------------------------------------              
    UPDATE  PurchaseOrder -- By Johnson, 15 juli 2005 , Update Dengan Nilai TDPAmount              
    SET     ContractPrepaidAmount = @TDPAmount -- @ContractPrepaidAmount              
    WHERE  BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND IsMainPO = 1              
    IF @@error <> 0          
        GOTO ExitSP              
              
---------------------------------------------              
-- Get Kode HO dr tbl Branch --              
-- ratna 02/09 --               
---------------------------------------------              
    SELECT  @KodeHO = BranchID          
    FROM    Branch WITH ( NOLOCK )          
    WHERE   ( IsHeadOffice = 1 )              
    IF @@error <> 0          
        GOTO ExitSP              
    IF ( @KodeHO IS NULL )          
        BEGIN              
            RAISERROR ( 'Head Office Branch  Exists', 16, 1 )              
            SET @Error = 1               
            IF @Error > 0          
                GOTO ExitSp              
        END              
              
---------------------------------------------              
-- Get AO Supervisor dr tbl BranchEmployee --              
-- ratna 02/09 --               
---------------------------------------------              
    SELECT  @AOSupervisorID = AOSupervisor          
    FROM    BranchEmployee WITH ( NOLOCK )          
    WHERE   ( BranchID = @BranchID )          
            AND ( EmployeeID = @AOID )              
    IF @@error <> 0          
        GOTO ExitSP              
    IF ( @AOSupervisorID IS NULL )          
        BEGIN              
            RAISERROR ( 'AO Supervisor  Exists', 16, 1 )              
            RETURN               
        END              
              
---------------------------------------------              
-- Get GM for Supplier --              
-- ratna 02/09 --               
---------------------------------------------              
    SELECT  @GMID = SupplierEmployeeID          
    FROM    SupplierEmployee WITH ( NOLOCK )          
    WHERE   ( SupplierID = @SupplierID )          
 AND ( SupplierEmployeePosition = 'GM' )              
    IF @@error <> 0          
        GOTO ExitSP              
              
              
---------------------------------------------              
-- Get BM for Supplier --              
-- ratna 02/09 --               
---------------------------------------------              
    SELECT  @BMID = SupplierEmployeeID          
    FROM    SupplierEmployee WITH ( NOLOCK )          
    WHERE   ( SupplierID = @SupplierID )          
            AND ( SupplierEmployeePosition = 'BM' )              
    IF @@error <> 0          
        GOTO ExitSP              
              
---------------------------------------------              
-- Get ADH for Supplier --              
-- ratna 02/09 --               
---------------------------------------------              
    SELECT  @ADHID = SupplierEmployeeID          
    FROM    SupplierEmployee WITH ( NOLOCK )          
    WHERE   ( SupplierID = @SupplierID )          
            AND ( SupplierEmployeePosition = 'AH' )              
    IF @@error <> 0          
        GOTO ExitSP              
              
-------------------------------------------------------------------------------              
-- Get CompanyID for Branch --              
-- ratna 05/09              
-------------------------------------------------------------------------------              
    SELECT  @CompanyID = CompanyID          
    FROM    Branch WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID              
    IF @@error <> 0          
        GOTO ExitSP              
    IF ( @CompanyID IS NULL )          
        BEGIN              
            RAISERROR ( 'Company ID On This Branch  Exists', 16, 1 )              
            SET @Error = 1               
            IF @Error > 0          
                GOTO ExitSp              
        END              
          
--Novia add, 17062016 : FMF-1515          
    DECLARE @CalculateTaxMethodSupllier CHAR(2)          
    DECLARE @CalculateTaxMethodSupllierEmp CHAR(2)          
             
    SELECT TOP 1          
            @CalculateTaxMethodSupllier = ISNULL(dbo.Commision.CalculateTaxMethodSupplier,          
                                                 'NE') , --Novia modify, 03033014 : Tmabah isnull          
            @CalculateTaxMethodSupllierEmp = ISNULL(dbo.Commision.CalculateTaxMethodSupplierEmployee,          
                                                    'NE') --Novia modify, 03033014 : Tmabah isnull          
    FROM    dbo.Commision          
    WHERE   BranchId = @BranchID          
            AND ApplicationID = @ApplicationId          
    ORDER BY SeqNo           
--Eo Novia          
          
              
--------------------------------------------------------------------------------------------              
-- Update DueDate pada table InstallmentSchedule based on EffectiveDate, PaymentFrequency --              
-- ratna 02/09 : tambah key BranchID pada searching              
--------------------------------------------------------------------------------------------              
    SELECT  @DueDate = @EffectiveDate              
              
    IF @FirstInstallment = 'AD'          
        BEGIN              
            SELECT  @CtrNo = 1               
            WHILE @CtrNo <= @NumofAdvanceInstallment          
                BEGIN              
                    EXEC @Error = spGetNoTransaction @BranchID, @BusinessDate,          
                        'TTU', @ReceiptNo OUTPUT              
                    IF @Error > 0          
                        GOTO ExitSp              
              
                    UPDATE  InstallmentSchedule          
                    SET     DueDate = @DueDate ,          
                            ReceiptNo = @ReceiptNo          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )          
                            AND ( InsSeqNo = @CtrNo )              
                    IF @@error <> 0          
                        GOTO ExitSP                
              
                    SET @CtrNo = @CtrNo + 1               
                END            
 --290520008 MUL BEGIN            
  --SET @FirstInstallmentAmount = @InstallmentAmount              
            SET @FirstInstallmentAmount = ( SELECT  SUM(PrincipalAmount)          
                                            FROM    installmentSchedule WITH ( NOLOCK )          
                                            WHERE   applicationid = @ApplicationID          
                                                    AND BranchID = @BranchID          
                                                    AND InsSeqNo <= @NumofAdvanceInstallment          
                                       )               
  --290520008 MUL END            
            SELECT  @CtrSeqNo = 1              
            WHILE ( @CtrNo > @NumofAdvanceInstallment )          
                AND ( @CtrNo <= @NumOfInstallment )          
    BEGIN              
   -----------------------------------------              
   -- Get Next DueDate for Monthly period --              
   -----------------------------------------              
                    IF @PaymentFrequency = '1'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrSeqNo,          
                                                       @EffectiveDate)              
                        END              
   -------------------------------------------              
   -- Get Next DueDate for Bimonthly period --              
   -------------------------------------------              
                    IF @PaymentFrequency = '2'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrSeqNo * 2,          
                                                       @EffectiveDate)              
                        END              
   -------------------------------------------              
   -- Get Next DueDate for Quarterly period --              
   -------------------------------------------              
                    IF @PaymentFrequency = '3'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrSeqNo * 3,          
                                                       @EffectiveDate)              
                        END              
   ----------------------------------------------              
   -- Get Next DueDate for Semi Annualy period --              
   ----------------------------------------------              
                    IF @PaymentFrequency = '6'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrSeqNo * 6,          
                                                       @EffectiveDate)              
                        END              
           
                    EXEC @Error = spGetNoTransaction @BranchID, @BusinessDate,          
                        'TTU', @ReceiptNo OUTPUT              
              IF @Error > 0          
                        GOTO ExitSp              
              
                    UPDATE  InstallmentSchedule          
                    SET     DueDate = @DueDate ,          
                            ReceiptNo = @ReceiptNo          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )          
                            AND ( InsSeqNo = @CtrNo )              
                    IF @@error <> 0          
                        GOTO ExitSP                
              
                    SET @CtrNo = @CtrNo + 1               
                    SET @CtrSeqNo = @CtrSeqNo + 1               
                END               
        END              
    ELSE          
        BEGIN              
            SELECT  @CtrNo = 1              
              
            WHILE @CtrNo <= @NumOfInstallment          
                BEGIN              
   -----------------------------------------              
   -- Get Next DueDate for Monthly period --              
   -----------------------------------------              
                    IF @PaymentFrequency = '1'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrNo,          
       @EffectiveDate)              
                        END              
   -------------------------------------------              
   -- Get Next DueDate for Bimonthly period --              
   -------------------------------------------              
                    IF @PaymentFrequency = '2'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrNo * 2,          
                                                       @EffectiveDate)              
                        END              
   -------------------------------------------              
   -- Get Next DueDate for Quarterly period --              
   -------------------------------------------              
                    IF @PaymentFrequency = '3'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrNo * 3,          
                                                       @EffectiveDate)              
                        END              
   ----------------------------------------------              
   -- Get Next DueDate for Semi Annualy period --              
   ----------------------------------------------              
                    IF @PaymentFrequency = '6'          
                        BEGIN              
                            SELECT  @DueDate = DATEADD(month, @CtrNo * 6,          
                                                       @EffectiveDate)              
                        END              
                
                    EXEC @Error = spGetNoTransaction @BranchID, @BusinessDate,          
                        'TTU', @ReceiptNo OUTPUT              
                    IF @Error > 0          
                        GOTO ExitSp              
              
                    UPDATE  InstallmentSchedule          
                    SET     DueDate = @DueDate ,          
                            ReceiptNo = @ReceiptNo          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )          
                            AND ( InsSeqNo = @CtrNo )              
                    IF @@error <> 0          
                        GOTO ExitSP                
              
                    SET @CtrNo = @CtrNo + 1               
                END               
              
            SET @FirstInstallmentAmount = 0              
        END              
              
 select * from InstallmentSchedule where applicationid=@ApplicationID          
---------------------------------------------------------------------------------------------------------              
-- Update PaidAmount & PaidDate pada table InstallmentSchedule untuk pembayaran Installment In Advance --              
-- ratna 02/09 : tambah key BranchID waktu Update              
---------------------------------------------------------------------------------------------------------              
    SET @CtrNo = 1               
    IF @FirstInstallment = 'AD'          
        BEGIN              
            WHILE @CtrNo < = @NumofAdvanceInstallment          
                BEGIN              
                    UPDATE  InstallmentSchedule          
                    SET     PaidAmount = @FirstInstallmentAmount ,          
                            PaidDate = @EffectiveDate     --@installmentamount diganti jadi @FirstInstallmentAmount 29052008 MUL          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )          
                            AND ( InsSeqNo = @CtrNo )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                    SET @CtrNo = @CtrNo + 1               
                END              
        END           
          
          
--13052008 MUL BEGIN          
--============Add Net Rate Amortization pindahan dari bawah============================================          
/*Di remark David 25Jan2010          
Declare @StartLoop Int,               
 @AmortizationID varchar(10),               
 @DateAmortization DateTime              
Set @DateAmortization = dateadd(month, -1, @EffectiveDate)              
 set @AmortizationID = 'DIFFRATE'             
 Exec @Error = spAmortizationFeeGenerator @BranchID, @ApplicationID, @DateAmortization, @AmortizationID              
 If @Error > 0              
  Goto ExitSp                
*/          
--David 25Jan2010 : Bagian Gema yang di pindahkan          
--Gema, 20081107 : Amortize Additional Admin Fee ke table installmentschedule =============================          
    DECLARE @AdditionalAdminFee NUMERIC(17, 2)          
           
    SET @AdditionalAdminFee = 0 --Dessy Add 29Jan2013 (FMF-1272)          
           
    SELECT  @AdditionalAdminFee = ISNULL(AdditionalAdminFee, 0)          
    FROM    AdminFeeforProductperTenor WITH ( NOLOCK )          
    WHERE   ProductID = @ProductID          
            AND Tenor = @Tenor          
           
    IF @AdditionalAdminFee <> 0          
        BEGIN          
               
            UPDATE  agreement          
            SET     AdditionalAdminFee = @AdditionalAdminFee          
            WHERE   Agreement.BranchID = @BranchID          
                    AND Agreement.ApplicationID = @ApplicationID          
            IF @@error <> 0          
                GOTO ExitSP            
        END          
--End Gema, 20081107 =======================================================================================          
/*David 25jan2010 : ganti kembali dengan cara biasa : */          
/*Arif 7 Oktober 2010 : penambahan assettypeid */          
    DECLARE @tblAmortizationMaster TABLE          
        (          
          seqno INT IDENTITY ,          
          amortizationid CHAR(10)          
        )          
          
    DECLARE @StartLoop INT ,          
        @EndLoop INT ,          
        @AmortizationID VARCHAR(10) ,          
        @DateAmortization DATETIME          
                     
          
    INSERT  INTO @tblAmortizationMaster          
            ( amortizationid          
            )          
            SELECT  amortizationid          
            FROM    amortizationmaster WITH ( NOLOCK )          
            WHERE   isactive = 1          
                    AND assettypeid = @assettypeid          
     -- Dewi 22022012 added begin          
                    AND AmortizationID <> 'PROVFEEJF'          
     -- Dewi 22022012 added end          
    SELECT  @EndLoop = COUNT(seqno)          
    FROM    @tblAmortizationMaster          
         
    SET @DateAmortization = DATEADD(MONTH, -1, @EffectiveDate)          
    SET @StartLoop = 1          
          
    WHILE @StartLoop <= @EndLoop          
        BEGIN          
            SELECT  @AmortizationID = amortizationid          
            FROM    @tblAmortizationMaster          
            WHERE   seqno = @StartLoop          
          
            EXEC @Error = spamortizationfeegenerator @BranchID, @ApplicationID,          
                @DateAmortization, @AmortizationID          
                
          
            IF @Error > 0          
                GOTO exitsp          
          
            SET @StartLoop = @StartLoop + 1          
        END         
		 
---Restu, 29 Januari 2024 [FMF-4862] : Tambah Pengecekan PSAK Plus Minus, lalu jalankan spAmortizationFeeGenerator_InterestPortion jika ada plus minus
 IF EXISTS (select '' from InstallmentSchedule i WITH(NOLOCK) WHERE i.ApplicationID = @ApplicationID AND i.BranchID = @BranchID    
			GROUP BY i.BranchId, i.ApplicationID    
			HAVING    
			SUM(CASE WHEN ISNULL(i.DiffRateAmount, 0) < 0 THEN i.DiffRateAmount*(-1) END) <> ABS(SUM(ISNULL(i.DiffRateAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.Incentive, 0) < 0 THEN i.Incentive*(-1) END) <> ABS(SUM(ISNULL(i.Incentive, 0)))    
			OR SUM(CASE WHEN ISNULL(i.InsuranceIncomeAmount, 0) < 0 THEN i.InsuranceIncomeAmount*(-1) END) <> ABS(SUM(ISNULL(i.InsuranceIncomeAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.Provision, 0) < 0 THEN i.Provision*(-1) END) <> ABS(SUM(ISNULL(i.Provision, 0)))    
			OR SUM(CASE WHEN ISNULL(i.AdminFee, 0) < 0 THEN i.AdminFee*(-1) END) <> ABS(SUM(ISNULL(i.AdminFee, 0)))    
			OR SUM(CASE WHEN ISNULL(i.OtherRefundAmount, 0) < 0 THEN i.OtherRefundAmount*(-1) END) <> ABS(SUM(ISNULL(i.OtherRefundAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.AdmFeeAmount, 0) < 0 THEN i.AdmFeeAmount*(-1) END) <> ABS(SUM(ISNULL(i.AdmFeeAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.ProvisionFeeAmount, 0) < 0 THEN i.ProvisionFeeAmount*(-1) END) <> ABS(SUM(ISNULL(i.ProvisionFeeAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.OtherFeeAmount, 0) < 0 THEN i.OtherFeeAmount*(-1) END) <> ABS(SUM(ISNULL(i.OtherFeeAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.SurveyFeeAmount, 0) < 0 THEN i.SurveyFeeAmount*(-1) END) <> ABS(SUM(ISNULL(i.SurveyFeeAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.DeferredInsurIncAmount, 0) < 0 THEN i.DeferredInsurIncAmount*(-1) END) <> ABS(SUM(ISNULL(i.DeferredInsurIncAmount, 0)))    
			OR SUM(CASE WHEN ISNULL(i.CostOfSurveyFeeAmount, 0) < 0 THEN i.CostOfSurveyFeeAmount*(-1) END) <> ABS(SUM(ISNULL(i.CostOfSurveyFeeAmount, 0)))    
		)    
    BEGIN    
		EXEC spAmortizationFeeGenerator_InterestPortion @BranchID, @ApplicationID    
    END    
---End Restu, 29 Januari 2024 [FMF-4862]	
  
--============Adjust Installment Schedule yang interset<0===============================================          
    IF ( SELECT effectiverate          
         FROM   agreement WITH ( NOLOCK )          
         WHERE  branchid = @BranchID          
                AND applicationid = @Applicationid          
       ) <= 0          
        BEGIN          
            EXEC @Error = spUpdateInterestInsSche @BranchID, @Applicationid              
            IF @Error > 0          
                GOTO ExitSp            
        END          
--13052008 MUL END           
/*Di remark David 25Jan2010 karena di pindahkan keatas bagian sebelum spamortizationfeegenerator          
--Gema, 20081107 : Amortize Additional Admin Fee ke table installmentschedule =============================          
 Declare @AdditionalAdminFee numeric(17,2)          
          
 select @AdditionalAdminFee = isnull(AdditionalAdminFee,0)          
 from AdminFeeforProductperTenor with(nolock)          
 where ProductID = @ProductID and Tenor = @Tenor          
           
 if @AdditionalAdminFee <> 0          
 Begin          
               
     update agreement          
     set  AdditionalAdminFee = @AdditionalAdminFee          
     where Agreement.BranchID = @BranchID AND Agreement.ApplicationID = @ApplicationID          
     if @@error <> 0               
       goto ExitSP            
          
  Set @DateAmortization = dateadd(month, -1, @EffectiveDate)              
  set @AmortizationID = 'ADMINFEE'             
  Exec @Error = spAmortizationFeeGenerator @BranchID, @ApplicationID, @DateAmortization, @AmortizationID              
  If @Error > 0              
   Goto ExitSp            
          
 End          
--End Gema, 20081107 =======================================================================================          
*/          
              
------------------------              
-- Get Data Customer  --              
------------------------              
    SELECT  @CustomerName = Customer.Name ,          
            @CustomerType = CustomerType          
    FROM    Customer WITH ( NOLOCK )          
    WHERE   Customer.CustomerID = @CustomerID           
        
------------------------------------------------------------------------------------------------------------------------------              
-- Get NextInstallmentNumber, NextInstallmentDate, OutstandingPrincipal, OutstandingInterest from table InstallmentSchedule --              
------------------------------------------------------------------------------------------------------------------------------              
-- Revisi BY Henry. Untuk Mengambil nilai nextInstallmentNumber, NextInstallmentDate, OutStandingPrincipal(Cash Bases),               
-- OutStandingInterest (CashBases), OutStandingPrincipalUndue (Accrued Bases), OutStandingInterest Undue (Accrued Bases),               
-- NextInstallmentDueNumber, NextInstallmentDueDate, InstallmentDue sama Tidak membedakan firstinsallment di arrear atau advance              
          SELECT TOP 1          
            @NextInstallmentNumber = InsSeqNo ,          
            @NextInstallmentDate = DueDate          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   ( InstallmentSchedule.BranchID = @BranchID )          
            AND ( InstallmentSchedule.ApplicationID = @ApplicationID )          
            AND ( InstallmentSchedule.InstallmentAmount          
                  - InstallmentSchedule.PaidAmount          
                  - InstallmentSchedule.WaivedAmount ) > 0          
    ORDER BY InsSeqNo               
              
  SELECT TOP 1          
            @NextInstallmentDueNumber = InsSeqNo ,          
            @NextInstallmentDueDate = DueDate          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   ( InstallmentSchedule.BranchID = @BranchID )          
            AND ( InstallmentSchedule.ApplicationID = @ApplicationID )          
            AND ( InstallmentSchedule.DueDate > @BusinessDate )          
    ORDER BY InsSeqNo               
              
    SELECT  @OutstandingPrincipal = ISNULL(SUM(PrincipalAmount), '0') ,          
            @OutstandingInterest = ISNULL(SUM(InterestAmount), '0')          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   ( InstallmentSchedule.BranchID = @BranchID )          
            AND ( InstallmentSchedule.ApplicationID = @ApplicationID )          
            AND InstallmentSchedule.PaidAmount = 0               
              
    SELECT  @OutstandingPrincipalUnDue = ISNULL(SUM(PrincipalAmount), '0') ,          
            @OutstandingInterestUnDue = ISNULL(SUM(InterestAmount), '0')          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   ( InstallmentSchedule.BranchID = @BranchID )          
            AND ( InstallmentSchedule.ApplicationID = @ApplicationID )          
            AND ( DueDate > @BusinessDate )               
              
    SET @InstallmentDue = 0              
    SET @InstallmentDuePaid = 0              
    SELECT  @InstallmentDue = ISNULL(SUM(InstallmentAmount), 0)          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )          
            AND ( DueDate <= @BusinessDate )              
              
    SELECT  @InstallmentDuePaid = ISNULL(SUM(PaidAmount), 0)          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )               
              
              
---------------------------------------------------------------------              
-- Get MaturityDate from the Last Due Date of Installment Schedule --              
-- ratna 02/09 : tambah key BranchID waktu Select              
-- ratna 13 juni 2005              
-- untuk StepUpStepDown tipe II dan III (split), MaturityDate diambil dari DueDate untuk InsSeqNo = CummulativeTenor              
-- lainnya, diambil dari DueDate untuk InsSeqNo = NumOfInstallment              
---------------------------------------------------------------------              
    IF @InstallmentScheme = 'ST'          
        AND @StepUpStepDownType IN ( 'RL', 'LS' )          
        BEGIN              
            SELECT  @MaturityDate = DueDate          
            FROM    InstallmentSchedule WITH ( NOLOCK )          
            WHERE   ( InstallmentSchedule.BranchID = @BranchID )          
                    AND ( InstallmentSchedule.ApplicationID = @ApplicationID )          
                    AND ( InstallmentSchedule.InsSeqNo = @CummulativeTenor )              
        END              
    ELSE          
        BEGIN              
            SELECT  @MaturityDate = DueDate          
            FROM    InstallmentSchedule WITH ( NOLOCK )          
            WHERE   ( InstallmentSchedule.BranchID = @BranchID )          
                    AND ( InstallmentSchedule.ApplicationID = @ApplicationID )          
                    AND ( InstallmentSchedule.InsSeqNo = @NumOfInstallment )              
        END              
               
--------------------------------------------------------              
-- Get FloatingNextReviewDate based on FloatingPeriod --              
--------------------------------------------------------              
-------------------------------              
-- FloatingPeriod: Quarterly --              
-------------------------------              
-- ReviewDate Tidak Diisi Karena berkaitan supaya tidak diProcess Flaoting tapi hanya di-extend Secara Otomatis di Program EOD              
-- Base On Effective Date Untuk menghandle Advance, Arrear              
              
-- Add Condtion jika @EffectiveRateType = 'S', maka FloatingNextReviewDate menggunakan EffectiveDate, sedangkan jika               
-- @EffectiveRateType = 'B', maka menggunakan NextInstallemntDueDate              
              
    IF @InterestType = 'FL'          
        BEGIN                 
            IF @EffectiveRateType = 'S'          
                BEGIN              
 -----------------------------              
 -- FloatingPeriod: Monthly --              
 -----------------------------              
                    IF ( RTRIM(@FloatingPeriod) ) = 'M'          
                        BEGIN              
                            SELECT  @FloatingUntilDate = DATEADD(month, 0,          
                                                              @NextInstallmentDueDate)              
                            SELECT  @FloatingNextReviewDate = DATEADD(month, 0,          
                              @NextInstallmentDueDate)              
                        END              
                    ELSE              
 -------------------------------              
 -- FloatingPeriod: Quarterly --              
 -------------------------------              
                        IF ( RTRIM(@FloatingPeriod) ) = 'Q'          
                            BEGIN              
                                SELECT  @FloatingUntilDate = DATEADD(month, 2,          
                                                              @NextInstallmentDueDate)              
                                SELECT  @FloatingNextReviewDate = DATEADD(month,          
                                                              2,          
                                                              @NextInstallmentDueDate)              
                            END              
                        ELSE              
 -----------------------------------              
 -- FloatingPeriod: Semi Annually --              
 -----------------------------------              
                            IF ( RTRIM(@FloatingPeriod) ) = 'S'          
                                BEGIN              
                                    SELECT  @FloatingUntilDate = DATEADD(month,          
                                                              5,          
                                                              @NextInstallmentDueDate)              
                                    SELECT  @FloatingNextReviewDate = DATEADD(month,          
                                                              5,          
                                                              @NextInstallmentDueDate)              
                                END              
                            ELSE              
 ------------------------------              
 -- FloatingPeriod: Annually --              
 ------------------------------              
                                IF ( RTRIM(@FloatingPeriod) ) = 'A'          
                      BEGIN              
                                        SELECT  @FloatingUntilDate = DATEADD(month,          
                                                              11,          
                                                              @NextInstallmentDueDate)              
                                        SELECT  @FloatingNextReviewDate = DATEADD(month,          
                                                              11,          
                                                              @NextInstallmentDueDate)              
                                    END              
                END              
            ELSE          
                IF @EffectiveRateType = 'B'          
                    BEGIN              
 -----------------------------              
 -- FloatingPeriod: Monthly --              
 -----------------------------              
                        IF ( RTRIM(@FloatingPeriod) ) = 'M'          
                            BEGIN              
                                SELECT  @FloatingUntilDate = DATEADD(month, 1,          
 @NextInstallmentDueDate)              
                                SELECT  @FloatingNextReviewDate = DATEADD(month,          
                                                              1,          
                                                              @NextInstallmentDueDate)              
                            END           
                        ELSE              
 -------------------------------              
 -- FloatingPeriod: Quarterly --              
 -------------------------------              
                            IF ( RTRIM(@FloatingPeriod) ) = 'Q'          
                                BEGIN              
                                    SELECT  @FloatingUntilDate = DATEADD(month,          
                                                              3,          
                                                @NextInstallmentDueDate)              
                                    SELECT  @FloatingNextReviewDate = DATEADD(month,          
                                                              3,          
                                                              @NextInstallmentDueDate)              
                                END              
                            ELSE              
 -----------------------------------              
 -- FloatingPeriod: Semi Annually --              
 -----------------------------------              
                                IF ( RTRIM(@FloatingPeriod) ) = 'S'          
                                    BEGIN              
                                        SELECT  @FloatingUntilDate = DATEADD(month,          
                                                              6,          
                                                              @NextInstallmentDueDate)              
                                        SELECT  @FloatingNextReviewDate = DATEADD(month,          
                                                              6,          
                                                              @NextInstallmentDueDate)              
                                    END              
                                ELSE              
 ------------------------------              
 -- FloatingPeriod: Annually --              
 ------------------------------              
                                    IF ( RTRIM(@FloatingPeriod) ) = 'A'          
                                        BEGIN              
                                            SELECT  @FloatingUntilDate = DATEADD(month,          
                                                              12,          
                                                              @NextInstallmentDueDate)              
                                            SELECT  @FloatingNextReviewDate = DATEADD(month,          
                                                              12,          
                                                              @NextInstallmentDueDate)              
  END              
                    END              
 -----------------------------              
 -- Insert Floating History --              
 -- ratna 02/09 : tambah key BranchID waktu Insert              
 -----------------------------              
            INSERT  INTO FloatingHistory          
                    ( BranchID ,          
                      ApplicationID ,          
                      FloatingSeqNo ,          
                      OldEffectiveRate ,          
                      OldFlatRate ,          
                      NewEffectiveRate ,          
                      NewFlatRate ,          
                      OldOSInterest ,          
                      NewOSInterest ,          
                      OldARGross ,          
                      NewARGross ,          
                      OldOsPrincipal ,          
                      NewOsPrincipal ,          
                      OldOsInstallmentDue ,          
                      NewOsInstallmentDue ,          
                      InstallmentAmount ,          
                      EffectiveDateFrom ,      
                      EffectiveDateTo ,          
                      FloatingPeriod ,          
                      FloatingNextReviewDate ,          
                      FloatingStatus ,          
                      FloatingStatusDate              
                    )          
            VALUES  ( @BranchID ,          
                      @ApplicationID ,          
                      1 ,          
                      @EffectiveRate ,          
                      @FlatRate ,          
                      @EffectiveRate ,          
                      @FlatRate ,          
                      @OutstandingInterest ,          
                      @OutstandingInterest ,          
                      @OutstandingInterest + @OutstandingPrincipal ,          
          @OutstandingInterest + @OutstandingPrincipal ,          
                      @OutStandingPrincipal ,          
                      @OutStandingPrincipal ,          
                      @InstallmentDue ,          
                      @InstallmentDue ,          
                      @InstallmentAmount ,          
                      @EffectiveDate ,          
                      @FloatingUntilDate ,          
                      @FloatingPeriod ,          
                      @FloatingNextReviewDate ,          
                      'R' ,          
                      @BusinessDate              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
              
 ------------------------------------------              
 -- Insert Installment Schedule Floating --              
 -- ratna 02/09 : tambah key BranchID waktu Insert              
              
 ------------------------------------------              
            INSERT  INTO InstallmentScheduleFloating          
                    ( BranchID ,          
                      ApplicationID ,          
                      FloatingSeqNo ,          
                      InsSeqNo ,          
                      DueDate ,          
                      InstallmentAmount ,          
                      PrincipalAmount ,          
                      InterestAmount ,          
                      OutstandingPrincipal ,          
                      OutstandingInterest           
                    )          
                    SELECT  BranchID ,          
                            ApplicationID ,          
                            1 ,          
                            InsSeqNo ,          
                            DueDate ,          
                            InstallmentAmount ,          
                            PrincipalAmount ,          
                            InterestAmount ,          
                            OutstandingPrincipal ,          
                            OutstandingInterest          
                    FROM    InstallmentSchedule WITH ( NOLOCK )          
                    WHERE   BranchID = @BranchID          
                            AND ApplicationID = @ApplicationID              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
              
              
              
--------------------------------              
-- Insert CollectionAgreement --              
-- ratna 02/09 : tambah key BranchID waktu Insert              
--------------------------------       
 --Ria 1 Dec 2020         
    --IF  EXISTS ( SELECT  ''       
  IF  NOT EXISTS ( SELECT  ''         
                    FROM    CollectionAgreement WITH ( NOLOCK )          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID ) )          
        BEGIN              
            INSERT  INTO CollectionAgreement          
                    ( BranchID ,          
                      ApplicationID ,          
                      AgreementNo ,          
                      CurrencyID ,          
                      Collecting ,          
                      Repossess ,          
                      FixedAssign ,              
  -- Yovita 27 Aug 2007: Insert data firstinstallment, NextInstallmentNumber, NextInstallmentDate, NextInstallmentDueNumber, NextInstallmentDueDate              
  --        ke table CollectionAgreement (atas Request jessy)              
                      FirstInstallment ,          
                      NextInstallmentNumber ,          
                      NextInstallmentDate ,          
                      NextInstallmentDueNumber ,          
                      NextInstallmentDueDate              
                    )          
            VALUES  ( @BranchID ,      
                      @ApplicationID ,          
                      @AgreementNo ,          
                      @CurrencyID ,          
                      'N' ,          
                      'N' ,          
                      'N' ,          
                      @FirstInstallment ,              
  -- Yovita 27 Aug 2007: Insert data firstinstallment, NextInstallmentNumber, NextInstallmentDate, NextInstallmentDueNumber, NextInstallmentDueDate              
  --        ke table CollectionAgreement (atas Request jessy)              
                      @NextInstallmentNumber ,          
                      @NextInstallmentDate ,          
                      @NextInstallmentDueNumber ,          
                      @NextInstallmentDueDate              
                
                    )              
            IF @@error <> 0          
                GOTO ExitSP            
        END              
              
    DECLARE @cBusinessDate AS VARCHAR(50)              
    DECLARE @cAgreementDate AS VARCHAR(50)              
              
    SET @cAgreementDate = CONVERT(VARCHAR(10), @AgreementDate, 101)              
    SET @cAgreementDate = LEFT(@cAgreementDate, 10) + ' '          
        + LTRIM(STR(DATEPART(hh, GETDATE()))) + ':' + LTRIM(STR(DATEPART(n,          
                                                              GETDATE())))          
        + ':' + LTRIM(STR(DATEPART(ss, GETDATE())))                  
    SET @cAgreementDate = CONVERT(DATETIME, @cAgreementDate)              
              
    SET @cBusinessDate = CONVERT(VARCHAR(10), @BusinessDate, 101)              
    SET @cBusinessDate = LEFT(@cBusinessDate, 10) + ' '          
        + LTRIM(STR(DATEPART(hh, GETDATE()))) + ':' + LTRIM(STR(DATEPART(n,          
                                                              GETDATE())))          
        + ':' + LTRIM(STR(DATEPART(ss, GETDATE())))                  
    SET @cBusinessDate = CONVERT(DATETIME, @cBusinessDate)              
              
----------------------              
-- Update Agreement --              
-- ratna 02/09 : tambah key BranchID waktu Update              
-- Johnson, 15 Juli 2005 : Update ContractPrepaidAmount = @ContractPrepaidAmount - @TDPAmount              
----------------------              
              
    SELECT  @PledgeStatus = FundingPledgeStatus          
    FROM    Agreement WITH ( NOLOCK )          
    WHERE   ApplicationID = @ApplicationID              
              
    IF @PledgeStatus = ''          
        OR @PledgeStatus = ' '          
        OR @PledgeStatus IS NULL              
--if @FundingCoyID = '' or @FundingCoyID = ' ' or @FundingCoyID = '0' or @FundingCoyID = 'All'              
--Remark By Gema, 25 September 2007 : Ambil dari KITAF              
        BEGIN              
            UPDATE  Agreement          
            SET     EffectiveDate = @EffectiveDate ,          
                    AgreementDate = @cAgreementDate ,          
                    GoLiveDate = @cBusinessDate ,          
                    DefaultStatus = 'NM' ,          
                    PrepaidHoldStatus = 'NM' ,          
                    ContractStatus = 'LIV' ,          
                    ApplicationStep = 'GLV' ,          
                    NextInstallmentDate = @NextInstallmentDate ,          
                    NextInstallmentDueDate = @NextInstallmentDueDate ,          
                    NextInstallmentNumber = @NextInstallmentNumber ,          
                    NextInstallmentDueNumber = @NextInstallmentDueNumber ,          
                    MaturityDate = @MaturityDate ,          
                    FloatingNextReviewDate = @FloatingNextReviewDate ,          
                    TDPAmount = @TDPAmount ,          
                    ContractPrepaidAmount = @ContractPrepaidAmount          
                    - @TDPAmount ,              
      --ContractPrepaidAmount = 0,               
                    InstallmentDue = @InstallmentDue ,          
    InstallmentDuePaid = @InstallmentDuePaid ,          
                    OutstandingPrincipal = @OutstandingPrincipal ,          
                    OutstandingInterest = @OutstandingInterest ,          
                    OutstandingPrincipalUndue = @OutstandingPrincipalUndue ,          
                    OutstandingInterestUndue = @OutstandingInterestUndue ,          
                    Notes = @Notes ,          
                    FundingPledgeStatus = NULL ,          
                    FundingBankID = NULL ,          
                    FundingCoyID = NULL ,          
                    FundingContractID = '-' ,          
                    FundingBatchID = '-' ,          
                    FundingBatchDate = NULL ,          
                    PDCPromisedDate = @PDCPromisedDate          
                    --Added by Rudi, 05 Dec 2011          
                    ,          
                    CostOfSurvey = CASE WHEN CostOfSurvey > 0          
                                        THEN CostOfSurvey * -1          
                                        ELSE CostOfSurvey          
                                   END ,          
                    POSID = @POSID -- Hendrik Wijaya, On 26 June 2012          
                    --End Rudi          
            WHERE   ( Agreement.BranchID = @BranchID )          
                    AND ( Agreement.ApplicationID = @ApplicationID )              
            IF @@error <> 0          
                GOTO ExitSP              
        END                
    ELSE          
        BEGIN               
    --Leonita 30 Sept 2007 tidak insert ke fundingagreement               
--    --============================Add By Teddy ===============================================              
--    Select @FundingBankID = BankID               
--     from FundingBatch with (nolock)               
--     Where  FundingCoyID = @FundingCoyID AND              
--      FundingContractNO = @FundingContractNO AND              
--      FundingBatchNO = @FundingBatchNO              
--     If @@error > 0               
--       Begin              
--        Goto ExitSP              
--       End              
--     Insert Into FundingAgreement              
--     (  BranchID ,              
--       ApplicationID ,              
--       BankID,              
--       FundingCoyID ,              
--       FundingContractNo,              
--       FundingBatchNo,              
--       EffectiveDate,              
--       Tenor,              
--       ARAmount,              
--       PrincipalAmount,              
--       OSARAmount,              
--       OSPrincipalAmount,              
--       InstallmentPaidAmount              
--     )              
--     Select              
--       BranchID ,              
--       ApplicationID ,              
--       FundingBankID,              
--       FundingCoyID ,              
--       FundingContractID,              
--       FundingBatchID,              
--       EffectiveDate,              
--       Tenor,              
--       OutstandingPrincipal+OutStandingInterest,              
--       OutStandingPrincipal,              
--       OutstandingPrincipal+OutStandingInterest,              
--       OutStandingPrincipal,              
--       0              
--            
--     From Agreement with (nolock)               
--     WHERE              
--      (Agreement.BranchID = @BranchID) AND               
--      (Agreement.ApplicationID = @ApplicationID)              
--     If @@error > 0               
--       Begin              
--        Goto ExitSP              
--       End              
--     Update FundingBatch              
--     Set AccRealizedNum = AccRealizedNum + 1              
--     Where  FundingCoyID = @FundingCoyID AND              
--      FundingContractNO = @FundingContractNO AND              
--      FundingBatchNO = @FundingBatchNO              
--     If @@error > 0               
--       Begin              
--        Goto ExitSP              
--       End         
     --==================================================================================              
            UPDATE  Agreement          
            SET     EffectiveDate = @EffectiveDate ,          
                    AgreementDate = @cAgreementDate ,          
                    GoLiveDate = @cBusinessDate ,          
                    DefaultStatus = 'NM' ,          
                    PrepaidHoldStatus = 'NM' ,          
                    ContractStatus = 'LIV' ,          
                    ApplicationStep = 'GLV' ,          
                    NextInstallmentDate = @NextInstallmentDate ,          
                    NextInstallmentDueDate = @NextInstallmentDueDate ,          
                    NextInstallmentNumber = @NextInstallmentNumber ,          
                    NextInstallmentDueNumber = @NextInstallmentDueNumber ,          
                    MaturityDate = @MaturityDate ,          
                    FloatingNextReviewDate = @FloatingNextReviewDate ,          
                    TDPAmount = @TDPAmount ,          
                    ContractPrepaidAmount = @ContractPrepaidAmount          
                    - @TDPAmount ,              
      --ContractPrepaidAmount = 0,               
                    InstallmentDue = @InstallmentDue ,          
                    InstallmentDuePaid = @InstallmentDuePaid ,          
                    OutstandingPrincipal = @OutstandingPrincipal ,          
                    OutstandingInterest = @OutstandingInterest ,          
                    OutstandingPrincipalUndue = @OutstandingPrincipalUndue ,          
                    OutstandingInterestUndue = @OutstandingInterestUndue ,          
                    Notes = @Notes ,          
                    FundingPledgeStatus = 'S' ,          
                    FlagCs = 'B' , --Add By Gema 16 Jan 2008, Pledging Before Golive              
                    --Added by Rudi, 05 Dec 2011          
                    CostOfSurvey = CASE WHEN CostOfSurvey > 0          
                                        THEN CostOfSurvey * -1          
                                        ELSE CostOfSurvey          
                                   END ,          
                    --End Rudi          
--      FundingBankID = @FundingCoyID,              
--      FundingBankID = @FundingBankID,              
--      FundingCoyID = @FundingCoyID,              
--      FundingContractID = @FundingContractNO,              
--      FundingBatchID = @FundingBatchNO,              
--      FundingBatchDate = @BusinessDate,              
                    PDCPromisedDate = @PDCPromisedDate ,          
                    POSID = @POSID -- Hendrik Wijaya, On 26 June 2012          
            WHERE   ( Agreement.BranchID = @BranchID )          
                    AND ( Agreement.ApplicationID = @ApplicationID )              
            IF @@error > 0          
                BEGIN              
                    GOTO ExitSP              
                END              
        
        END              
              
---------------------------------------------------              
-- Update First Agreement Date at table Customer --              
---------------------------------------------------              
    SELECT  @FirstAgreementDate = FirstAgreementDate          
    FROM    Customer WITH ( NOLOCK )          
    WHERE   ( CustomerID = @CustomerID )              
    IF ISDATE(@FirstAgreementDate) = 0          
        BEGIN              
            UPDATE  Customer          
            SET     FirstAgreementDate = @AgreementDate          
            WHERE   ( CustomerID = @CustomerID )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
              
-------------------------------------------------------------------              
-- Update AssetDocStatus and AssetStatus at table AgreementAsset --              
-- ratna 02/09 : tambah key BranchID waktu Update     
-------------------------------------------------------------------              
    UPDATE  AgreementAsset          
    SET     AssetDocStatus = 'W'          
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )          
            AND ( AssetDocStatus = 'P' )              
    IF @@error <> 0          
        GOTO ExitSP              
    UPDATE  AgreementAsset          
    SET     AssetStatus = 'NOR'          
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )              
    IF @@error <> 0          
        GOTO ExitSP              
              
---------------------------------------------------------              
-- Update AssetDocStatus at table AssetDocumentContent --              
-- ratna 02/09 : tambah key BranchID waktu Update              
---------------------------------------------------------              
    UPDATE  AssetDocumentContent          
    SET     AssetDocStatus = 'W'          
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )          
            AND ( AssetDocStatus = 'P' )              
    IF @@error <> 0          
        GOTO ExitSP              
              
---------------------------------------------------------------              
-- Update ExpectedReceivedDate at table AssetDocumentContent --              
-- ratna 02/09 : AssetUsedNew diambil dr tbl ProductOffering              
-- ratna 17/09/2004 : AssetUsedNew diambil dr tbl AgreementAsset              
---------------------------------------------------------------              
    SELECT  @CtrNo = 1              
    WHILE @CtrNo <= @NumOfAssetUnit          
        BEGIN              
            IF ( SELECT UsedNew          
                 FROM   AgreementAsset WITH ( NOLOCK )          
                 WHERE  BranchID = @BranchID          
                        AND ApplicationID = @ApplicationID          
                        AND AssetSeqNo = @CtrNo          
               ) = 'N'          
                BEGIN              
                    SELECT  @LengthMainDocProcess = LengthMainDocProcess          
                    FROM    ProductOffering WITH ( NOLOCK )          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ProductID = @ProductID )          
                            AND ( ProductOfferingID = @ProductOfferingID )              
                    SELECT  @ExpectedReceivedDate = DATEADD(day,          
                                                            @LengthMainDocProcess,          
                                                            @BusinessDate)              
                END              
            ELSE          
                BEGIN              
                    SELECT  @ExpectedReceivedDate = @BusinessDate              
                END                
              
            UPDATE  AssetDocumentContent          
            SET     ExpectedReceivedDate = @ExpectedReceivedDate          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID          
                    AND AssetDocStatus = 'W'          
                    AND AssetSeqNo = @CtrNo              
            IF @@error <> 0          
                GOTO ExitSP              
              
            SET @CtrNo = @CtrNo + 1                
        END              
          
          
/*Diremark David 29Jan2010 karena proses ini dipindah ke spSelectInscoAutomatic yang dijalankan sebelum perhitungan grossyieldAcct untuk PSAK (di proses save golive jg)              
--===================================================================================================              
-- Created By Gema, 25 September 2007                 
-- Pemilihan Insco secara Automatis              
-- Date Modified : Andreas 30 Juni 2008 tambah spSelectInscoFromFundingCoyInsurance              
--===================================================================================================              
              
If exists(               
    select '' from InsuranceAsset            
    where InsuranceAsset.FlagInsStatus = 'A' and                  
    InsuranceAsset.BranchID = @BranchID and               
    InsuranceAsset.ApplicationID = @ApplicationID              
)              
Begin              
          
          
          
  exec spSelectInscoFromFundingCoyInsurance @BranchID,@ApplicationID,@InsuranceCoyBranchID out          
          
  if @@error <> 0 goto ExitSP           
           
  if @InsuranceCoyBranchID = ''          
   begin          
    select @InsuranceCoyBranchID              
    exec @error = spSelectInscoToInsuranceAsset @BranchID,@ApplicationID,@InsuranceCoyBranchID out              
    if @error <> 0 goto ExitSP              
   end          
                      
  declare @ApplicationType varchar(5),              
  @MaxInsSeq int               
              
  select @MaxInsSeq = max(inssequenceno) from InsuranceAsset with(nolock)              
  where BranchID=@BranchID And ApplicationID=@ApplicationID              
              
  select @ApplicationType = ApplicationType from InsuranceAsset with(nolock)              
  WHERE BranchID = @BranchID AND ApplicationID = @ApplicationID and InsSequenceNo = @MaxInsSeq              
              
  exec @error = spSaveRateInscoToInsuranceAssetDetail @BranchID,@ApplicationID,@InsuranceCoyBranchID,@ApplicationType              
  if @error <> 0 goto ExitSP              
End              
              
--===================================================================================================              
*/          
------------------------------------            
-- Insert to agreement asset value --            
-- lingga 17/5/2016 (IAF 1065) : insert data aset ke table agreement aset value          
------------------------------------          
          
    INSERT  INTO AgreementAssetValue          
            ( BranchID ,          
              ApplicationID ,          
              AssetSeqNo ,          
              LastReviewDate ,          
              AssetValue ,          
              CurrentAssetValue          
  --UsrUpd,          
  --DtmUpd          
      )          
            SELECT  aga.BranchID ,          
                    aga.ApplicationID ,          
                    aga.AssetSeqNo ,          
                    @BusinessDate ,          
                    aga.OTRPrice ,          
                    aga.OTRPrice          
  --SYSTEM_USER,          
  --GETDATE()          
            FROM    dbo.AgreementAsset aga WITH ( NOLOCK )          
                    INNER JOIN dbo.Agreement agr WITH ( NOLOCK ) ON aga.BranchID = agr.BranchID          
                                                              AND aga.ApplicationID = agr.ApplicationID          
            WHERE   agr.ApplicationID = @ApplicationID          
                    AND agr.BranchID = @BranchID          
    IF @@ERROR <> 0          
        GOTO exitsp          
          
--------------------------------              
-- Asset Insurance Activation --              
-- ratna 02/09 : tambah key BranchID waktu Select              
--------------------------------              
    SELECT  @InsuranceCoyID = InsuranceAsset.InsuranceCoyID ,          
            @InsuranceCoyBranchID = InsuranceAsset.InsuranceCoyBranchID ,               
  --@InsuranceType = InsuranceAsset.InsuranceType,              
            @PremiumAmountByCust = InsuranceAsset.PremiumAmountByCust ,          
            @InsLength = InsuranceAsset.InsLength ,          
            @AdminFeeToCust = AdminFeeToCust ,          
            @MeteraiFeeToCust = MeteraiFeeToCust          
    FROM    InsuranceAsset WITH ( NOLOCK )          
    WHERE   ( InsuranceAsset.BranchID = @BranchID )          
            AND ( InsuranceAsset.ApplicationID = @ApplicationID )          
            AND flaginsstatus = 'A'              
              
 -----------------------              
 -- Update Flag Renew --              
 -----------------------              
    SET @FlagRenew = 'N'              
    IF ( @InsAssetPeriod = 'AN' )          
        AND ( @Tenor > 12 )          
        BEGIN               
            SET @FlagRenew = 'Y'              
        END               
              
    UPDATE  InsuranceAsset          
    SET     RequestDate = @BusinessDate ,          
            InsActivateDate = @BusinessDate ,          
            PaidAmountByCust = ISNULL(@PremiumAmountByCust, 0)          
            + @AdminFeeToCust + @MeteraiFeeToCust ,          
            PaidDate = @BusinessDate          
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )               
    IF @@error <> 0          
        GOTO ExitSP              
               
              
              
--------------------------------              
-- Life Insurance Activation --              
-- Emilia 9/2/06               
--------------------------------              
--Remark By : Benny, 15juni2015 fmf-1422 : Dipindahkan kebagian create AP Life Insurance            
 /*          
    SELECT  @LifeInsuranceCoyID = LifeInsuranceAgreement.LifeInsuranceCoyID,          
            @LifeInsuranceCoyBranchID = LifeInsuranceAgreement.LifeInsuranceCoyBranchID,          
            @PAidBy = LifeInsuranceAgreement.paidby,          
            @Premium = LifeInsuranceAgreement.Premium,          
            @PremiumToInsCo = LifeInsuranceAgreement.PremiumToInsCo,          
            @Insuredby = LifeInsuranceAgreement.insuredby,          
            @LifeAdminFee = LifeInsuranceAgreement.AdminFee,          
            @LifeStampDutyFee = LifeInsuranceAgreement.StampDutyFee          
    FROM    LifeInsuranceAgreement WITH ( NOLOCK )          
    WHERE   ( LifeInsuranceAgreement.BranchID = @BranchID )          
            AND ( LifeInsuranceAgreement.ApplicationID = @ApplicationID )          
            AND LifeInsuranceAgreement.flaginsstatus = 'A'              
              
    IF @@error <> 0           
        GOTO ExitSP              
    */          
              
------------------              
-- Create Sales --              
-- ratna 02/09 : Tbl Sales field2nya sudah berubah              
------------------              
    INSERT  INTO Sales          
            ( Sales.BranchID ,          
              Sales.ApplicationID ,          
              Sales.AgreementNo ,          
              Sales.SalesDate ,          
              Sales.SupplierID ,          
              Sales.AOID ,          
              Sales.AOSupervisorID ,          
              Sales.CAID ,          
              Sales.GMID ,          
              Sales.BMID ,          
              Sales.ADHID ,          
              Sales.SalesmanID ,          
              Sales.SalesSupervisorID ,          
              Sales.SupplierAdminID ,          
              Sales.TotalOTR ,          
              Sales.DownPayment ,          
              Sales.NTF ,          
              Sales.FinanceType ,          
              Sales.NumOfAssetUnit ,          
              Sales.WayOfPayment ,          
              Sales.FloatingPeriod ,          
              Sales.InsAssetPremium ,          
              Sales.InsAssetReceivedInAdv ,          
              Sales.InsAssetCapitalized ,          
              Sales.InsAssetInsuredBy ,          
              Sales.InsAssetPaidBy ,          
              Sales.InsAssetPeriod ,          
              Sales.EffectiveRate ,          
              Sales.FlatRate ,          
              Sales.SupplierRate ,          
              Sales.PaymentFrequency ,          
              Sales.FirstInstallment ,          
              Sales.InstallmentScheme ,          
              Sales.InterestType ,          
              Sales.NumOfInstallment ,          
              Sales.Tenor ,          
              Sales.CummulativeTenor ,          
              Sales.InstallmentAmount ,          
         Sales.GracePeriod ,          
              Sales.GracePeriodType ,          
              Sales.GrossYield ,          
              Sales.OutstandingPrincipal ,          
              Sales.OutstandingInterest ,          
              Sales.TDPAmount ,          
              Sales.DiffRateAmount ,          
              Sales.IsAvalist ,          
              Sales.IsNST ,          
              Sales.IsIncentiveSupplier ,          
              Sales.MaturityDate ,          
              Sales.Notes ,          
              Sales.ProductType              
            )          
            SELECT  Agreement.BranchID ,          
       Agreement.ApplicationID ,          
      Agreement.AgreementNo ,          
                    @BusinessDate ,          
                    Agreement.SupplierID ,          
                    @AOID ,          
                    @AOSupervisorID ,          
                    ISNULL(Agreement.CAID, '-') ,          
                    @GMID ,          
                    @BMID ,          
                    @ADHID ,          
                    Agreement.SalesmanID ,          
                    ISNULL(Agreement.SalesSupervisorID, '') ,          
                    ISNULL(Agreement.SupplierAdminID, '') ,          
                    Agreement.TotalOTR ,          
                    Agreement.DownPayment ,          
                    Agreement.NTF ,          
                    Agreement.FinanceType ,          
                    Agreement.NumOfAssetUnit ,          
                    Agreement.WayOfPayment ,          
                    Agreement.FloatingPeriod ,          
                    Agreement.InsAssetPremium ,          
                    Agreement.InsAssetReceivedInAdv ,          
                    Agreement.InsAssetCapitalized ,          
                    Agreement.InsAssetInsuredBy ,          
                    Agreement.InsAssetPaidBy ,          
                    Agreement.InsAssetPeriod ,          
                    Agreement.EffectiveRate ,          
                    Agreement.FlatRate ,          
                    Agreement.SupplierRate ,          
                    Agreement.PaymentFrequency ,          
                    Agreement.FirstInstallment ,          
                    Agreement.InstallmentScheme ,          
                    Agreement.InterestType ,          
                    Agreement.NumOfInstallment ,          
                    Agreement.Tenor ,          
                    Agreement.CummulativeTenor ,          
                    Agreement.InstallmentAmount ,          
                    Agreement.GracePeriod ,          
                    Agreement.GracePeriodType ,          
                    Agreement.GrossYield ,          
                    Agreement.OutstandingPrincipal ,          
                    Agreement.OutstandingInterest ,          
                    Agreement.TDPAmount ,          
                    Agreement.DiffRateAmount ,          
                    Agreement.IsAvalist ,          
                    Agreement.IsNST ,          
                    ISNULL(Agreement.IsIncentiveSupplier, 0) ,          
                    Agreement.MaturityDate ,          
                    Agreement.Notes ,          
                    Agreement.ProductType          
            FROM    AGREEMENT WITH ( NOLOCK )          
            WHERE   ( Agreement.BranchID = @BranchID )          
                    AND ( Agreement.ApplicationID = @ApplicationID )              
    IF @@error <> 0          
        GOTO ExitSP              
              
-------------------------------------------------              
-- Create tbl SalesReport u/AmountFinance              
-- ratna 02/09 --              
-------------------------------------------------              
-------------------------------------------------              
-- Range for ReportAmountFinance and ReportInstallmentAmount is @ntf>=@N and @ntf<=@N for n = 1,2,3,...,10              
-- ratna 02/09 --              
-------------------------------------------------              
    /*Remark by Rudi, 05 Dec 2011          
    DECLARE cur_SalesReport CURSOR          
    FOR          
        SELECT  ReportID ,          
                AmountFinance1From ,          
                AmountFinance1To ,          
                AmountFinance1Text ,          
                AmountFinance2From ,          
                AmountFinance2To ,          
                AmountFinance2Text ,          
                AmountFinance3From ,          
                AmountFinance3To ,          
                AmountFinance3Text ,          
                AmountFinance4From ,      
                AmountFinance4To ,          
                AmountFinance4Text ,          
                AmountFinance5From ,          
                AmountFinance5To ,          
                AmountFinance5Text ,          
                AmountFinance6From ,          
                AmountFinance6To ,         
                AmountFinance6Text ,          
                AmountFinance7From ,          
                AmountFinance7To ,          
                AmountFinance7Text ,          
                AmountFinance8From ,          
            AmountFinance8To ,          
                AmountFinance8Text ,          
                AmountFinance9From ,          
       AmountFinance9To ,          
                AmountFinance9Text ,          
                AmountFinance10From ,          
                AmountFinance10To ,          
                AmountFinance10Text          
        FROM    ReportAmountFinance              
    OPEN cur_SalesReport              
    FETCH NEXT FROM cur_SalesReport INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From, @5To, @5Text,          
        @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
    WHILE @@FETCH_STATUS = 0           
        BEGIN              
            SET @Text = CASE WHEN ( @NTF >= @1From          
                                    AND @NTF <= @1To          
                                  ) THEN @1Text          
                             WHEN ( @NTF >= @2From          
                                    AND @NTF <= @2To          
                                  ) THEN @2Text          
                             WHEN ( @NTF >= @3From          
                                    AND @NTF <= @3To          
                                  ) THEN @3Text          
                             WHEN ( @NTF >= @4From          
                                    AND @NTF <= @4To          
                                  ) THEN @4Text          
                             WHEN ( @NTF >= @5From          
                                    AND @NTF <= @5To          
                                  ) THEN @5Text          
                             WHEN ( @NTF >= @6From          
                                    AND @NTF <= @6To          
                                  ) THEN @6Text          
                             WHEN ( @NTF >= @7From          
                                    AND @NTF <= @7To          
                                  ) THEN @7Text          
                             WHEN ( @NTF >= @8From          
                                    AND @NTF <= @8To          
                                  ) THEN @8Text          
                             WHEN ( @NTF >= @9From          
                                    AND @NTF <= @9To          
                                  ) THEN @9Text          
                             WHEN ( @NTF >= @10From          
                                    AND @NTF <= @10To          
                                  ) THEN @10Text          
                        END              
              
            INSERT  INTO SalesReport          
                    ( BranchID ,          
                      ApplicationID ,   
                      ReportID ,          
                      AmountFinanceText          
                    )          
            VALUES  ( @BranchID ,          
                      @ApplicationID ,          
                      @ReportID ,          
                      @Text          
                    )              
            IF @@error <> 0           
                GOTO ExitSP              
              
            FETCH NEXT FROM cur_SalesReport INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From, @5To,          
                @5Text, @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
        END              
              
    CLOSE cur_SalesReport                DEALLOCATE cur_SalesReport              
    End Rudi*/          
              
    --Added by Rudi, 05 Dec 2011          
    /*SELECT  @ReportID = ReportID,          
            @1From = AmountFinance1From,          
   @1To = AmountFinance1To,          
            @1Text = AmountFinance1Text,          
            @2From = AmountFinance2From,          
            @2To = AmountFinance2To,          
            @2Text = AmountFinance2Text,          
            @3From = AmountFinance3From,          
            @3To = AmountFinance3To,          
            @3Text = AmountFinance3Text,          
            @4From = AmountFinance4From,          
            @4To = AmountFinance4To,          
            @4Text = AmountFinance4Text,          
            @5From = AmountFinance5From,          
            @5To = AmountFinance5To,          
            @5Text = AmountFinance5Text,          
 @6From = AmountFinance6From,          
            @6To = AmountFinance6To,          
            @6Text = AmountFinance6Text,          
            @7From = AmountFinance7From,          
            @7To = AmountFinance7To,          
            @7Text = AmountFinance7Text,          
            @8From = AmountFinance8From,          
         @8To = AmountFinance8To,          
            @8Text = AmountFinance8Text,          
            @9From = AmountFinance9From,          
            @9To = AmountFinance9To,          
            @9Text = AmountFinance9Text,          
            @10From = AmountFinance10From,          
            @10To = AmountFinance10To,          
            @10Text = AmountFinance10Text          
 FROM dbo.ReportAmountFinance WITH(NOLOCK)*/          
           
    SELECT  @ReportID = ReportID ,          
            @Text = CASE WHEN ( @NTF >= AmountFinance1From          
                                AND @NTF <= AmountFinance1To          
                              ) THEN AmountFinance1Text          
                         WHEN ( @NTF >= AmountFinance2From          
                                AND @NTF <= AmountFinance2To          
                              ) THEN AmountFinance2Text          
                         WHEN ( @NTF >= AmountFinance3From          
                                AND @NTF <= AmountFinance3To          
                              ) THEN AmountFinance3Text          
                         WHEN ( @NTF >= AmountFinance4From          
                                AND @NTF <= AmountFinance4To          
                              ) THEN AmountFinance4Text          
                         WHEN ( @NTF >= AmountFinance5From          
                                AND @NTF <= AmountFinance5To          
                              ) THEN AmountFinance5Text          
                         WHEN ( @NTF >= AmountFinance6From          
                                AND @NTF <= AmountFinance6To          
                              ) THEN AmountFinance6Text          
                         WHEN ( @NTF >= AmountFinance7From          
                                AND @NTF <= AmountFinance7To          
                              ) THEN AmountFinance7Text          
                         WHEN ( @NTF >= AmountFinance8From          
                                AND @NTF <= AmountFinance8To          
                              ) THEN AmountFinance8Text          
                         WHEN ( @NTF >= AmountFinance9From          
                                AND @NTF <= AmountFinance9To          
                              ) THEN AmountFinance9Text          
                         WHEN ( @NTF >= AmountFinance10From          
                                AND @NTF <= AmountFinance10To          
                              ) THEN AmountFinance10Text          
                    END          
    FROM    dbo.ReportAmountFinance WITH ( NOLOCK )          
           
    INSERT  INTO dbo.SalesReport          
            ( BranchID ,          
              ApplicationID ,          
              ReportID ,          
              AmountFinanceText          
            )          
    VALUES  ( @BranchID ,          
              @ApplicationID ,          
   @ReportID ,          
              @Text          
            )          
              
    IF @@ERROR <> 0          
        GOTO ExitSP          
    --End Rudi          
              
-------------------------------------------------              
-- Update tbl SalesReport u/InstallmentAmount              
-- ratna 02/09 --              
-------------------------------------------------              
    /*Remark by Rudi, 05 Dec 2011          
    DECLARE cur_SalesReportIA CURSOR          
    FOR          
        SELECT  ReportID ,          
                AmountInstallment1From ,          
                AmountInstallment1To ,          
                AmountInstallment1Text ,          
                AmountInstallment2From ,          
                AmountInstallment2To ,          
                AmountInstallment2Text ,          
                AmountInstallment3From ,          
                AmountInstallment3To ,          
                AmountInstallment3Text ,          
                AmountInstallment4From ,          
                AmountInstallment4To ,          
                AmountInstallment4Text ,          
                AmountInstallment5From ,          
                AmountInstallment5To ,          
                AmountInstallment5Text ,          
                AmountInstallment6From ,          
                AmountInstallment6To ,          
                AmountInstallment6Text ,          
                AmountInstallment7From ,          
                AmountInstallment7To ,          
                AmountInstallment7Text ,          
                AmountInstallment8From ,          
                AmountInstallment8To ,          
                AmountInstallment8Text ,          
                AmountInstallment9From ,          
                AmountInstallment9To ,          
                AmountInstallment9Text ,          
                AmountInstallment10From ,          
                AmountInstallment10To ,          
                AmountInstallment10Text          
        FROM    ReportInstallmentAmount              
    OPEN cur_SalesReportIA              
    FETCH NEXT FROM cur_SalesReportIA INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From, @5To,          
        @5Text, @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
    WHILE @@FETCH_STATUS = 0           
        BEGIN              
            SET @Text = CASE WHEN ( @InstallmentAmount >= @1From          
                                    AND @InstallmentAmount <= @1To          
                                  ) THEN @1Text          
                             WHEN ( @InstallmentAmount >= @2From          
                                    AND @InstallmentAmount <= @2To          
                                  ) THEN @2Text          
                             WHEN ( @InstallmentAmount >= @3From          
                                    AND @InstallmentAmount <= @3To          
                                  ) THEN @3Text          
                             WHEN ( @InstallmentAmount >= @4From          
                                    AND @InstallmentAmount <= @4To          
                                  ) THEN @4Text          
                             WHEN ( @InstallmentAmount >= @5From          
                                    AND @InstallmentAmount <= @5To          
                                  ) THEN @5Text          
                             WHEN ( @InstallmentAmount >= @6From          
                                    AND @InstallmentAmount <= @6To          
                                  ) THEN @6Text          
                             WHEN ( @InstallmentAmount >= @7From          
                                    AND @InstallmentAmount <= @7To          
                                  ) THEN @7Text          
                             WHEN ( @InstallmentAmount >= @8From          
                                    AND @InstallmentAmount <= @8To          
                                  ) THEN @8Text          
                       WHEN ( @InstallmentAmount >= @9From          
                                    AND @InstallmentAmount <= @9To          
                                  ) THEN @9Text          
                             WHEN ( @InstallmentAmount >= @10From          
                                    AND @InstallmentAmount <= @10To          
                                  ) THEN @10Text          
                        END              
              
            UPDATE  SalesReport          
            SET     AmountInstallmentText = @Text          
            WHERE   ( BranchID = @BranchID )          
                    AND ( ApplicationID = @ApplicationID )          
                    AND ( ReportID = @ReportID )              
            IF @@error <> 0           
                GOTO ExitSP              
              
            FETCH NEXT FROM cur_SalesReportIA INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From,          
                @5To, @5Text, @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
              
        END              
    CLOSE cur_SalesReportIA              
    DEALLOCATE cur_SalesReportIA              
    End Rudi*/          
              
    --Added by Rudi, 05 Dec 2011          
    SELECT  @ReportID = ReportID ,          
            @Text = CASE WHEN ( @InstallmentAmount >= AmountInstallment1From          
                                AND @InstallmentAmount <= AmountInstallment1To          
                              ) THEN AmountInstallment1Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment2From          
                                AND @InstallmentAmount <= AmountInstallment2To          
                              ) THEN AmountInstallment2Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment3From          
                                AND @InstallmentAmount <= AmountInstallment3To          
                              ) THEN AmountInstallment3Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment4From          
                                AND @InstallmentAmount <= AmountInstallment4To          
                              ) THEN AmountInstallment4Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment5From          
                                AND @InstallmentAmount <= AmountInstallment5To          
                              ) THEN AmountInstallment5Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment6From          
                                AND @InstallmentAmount <= AmountInstallment6To          
                              ) THEN AmountInstallment6Text          
         WHEN ( @InstallmentAmount >= AmountInstallment7From          
                                AND @InstallmentAmount <= AmountInstallment7To          
                              ) THEN AmountInstallment7Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment8From          
                                AND @InstallmentAmount <= AmountInstallment8To          
                              ) THEN AmountInstallment8Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment9From          
                                AND @InstallmentAmount <= AmountInstallment9To          
                              ) THEN AmountInstallment9Text          
                         WHEN ( @InstallmentAmount >= AmountInstallment10From          
                                AND @InstallmentAmount <= AmountInstallment10To          
                              ) THEN AmountInstallment10Text          
                    END          
    FROM    dbo.ReportInstallmentAmount WITH ( NOLOCK )          
           
    UPDATE  dbo.SalesReport          
    SET     AmountInstallmentText = @Text          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND ReportID = @ReportID          
           
    IF @@ERROR <> 0          
        GOTO ExitSP          
 --End Rudi          
-------------------------------------------------              
-- Update tbl SalesReport u/%DP              
-- ratna 02/09 --              
-------------------------------------------------              
    SET @PercentDP = @DownPayment / @TotalOTR * 100              
              
    /*Remark by Rudi, 05 Dec 2011          
    DECLARE cur_SalesReportDP CURSOR          
    FOR          
        SELECT  ReportID ,          
                PercentDP1From ,          
                PercentDP1To ,          
                PercentDP1Text ,          
                PercentDP2From ,          
                PercentDP2To ,          
                PercentDP2Text ,          
                PercentDP3From ,          
                PercentDP3To ,          
                PercentDP3Text ,          
                PercentDP4From ,          
                PercentDP4To ,          
                PercentDP4Text ,          
                PercentDP5From ,          
                PercentDP5To ,          
                PercentDP5Text ,          
                PercentDP6From ,          
                PercentDP6To ,          
                PercentDP6Text ,          
                PercentDP7From ,          
                PercentDP7To ,          
                PercentDP7Text ,          
                PercentDP8From ,          
                PercentDP8To ,          
                PercentDP8Text ,          
                PercentDP9From ,          
                PercentDP9To ,          
                PercentDP9Text ,          
                PercentDP10From ,          
                PercentDP10To ,          
                PercentDP10Text          
        FROM    ReportPercentDP              
    OPEN cur_SalesReportDP              
    FETCH NEXT FROM cur_SalesReportDP INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From, @5To,          
        @5Text, @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
    WHILE @@FETCH_STATUS = 0           
        BEGIN              
            SET @Text = CASE WHEN ( @PercentDP >= @1From          
                                    AND @PercentDP < @1To          
                                  ) THEN @1Text          
                             WHEN ( @PercentDP >= @2From          
                                    AND @PercentDP < @2To          
                                  ) THEN @2Text          
                             WHEN ( @PercentDP >= @3From          
                                    AND @PercentDP < @3To                                    ) THEN @3Text          
                             WHEN ( @PercentDP >= @4From          
                                    AND @PercentDP < @4To          
                                  ) THEN @4Text          
                             WHEN ( @PercentDP >= @5From          
                                    AND @PercentDP < @5To          
                                  ) THEN @5Text          
                             WHEN ( @PercentDP >= @6From          
                                    AND @PercentDP < @6To          
                                  ) THEN @6Text          
                             WHEN ( @PercentDP >= @7From          
                                    AND @PercentDP < @7To          
                                  ) THEN @7Text          
                             WHEN ( @PercentDP >= @8From          
                                    AND @PercentDP < @8To          
                                  ) THEN @8Text          
                             WHEN ( @PercentDP >= @9From          
                                    AND @PercentDP < @9To          
                                  ) THEN @9Text          
                             WHEN ( @PercentDP >= @10From          
                                    AND @PercentDP < @10To          
                                  ) THEN @10Text          
                        END              
              
            UPDATE  SalesReport          
            SET     PercentDPText = @Text          
            WHERE   ( BranchID = @BranchID )          
                    AND ( ApplicationID = @ApplicationID )          
                    AND ( ReportID = @ReportID )              
            IF @@error <> 0           
                GOTO ExitSP              
              
            FETCH NEXT FROM cur_SalesReportDP INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From,          
                @5To, @5Text, @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
        END              
    CLOSE cur_SalesReportDP              
    DEALLOCATE cur_SalesReportDP              
    End Rudi*/          
              
    --Added by Rudi, 05 Dec 2011          
    SELECT  @ReportID = ReportID ,          
            @Text = CASE WHEN ( @PercentDP >= PercentDP1From          
                                AND @PercentDP <= PercentDP1To          
                              ) THEN PercentDP1Text          
                         WHEN ( @PercentDP >= PercentDP2From          
                                AND @PercentDP <= PercentDP2To          
                              ) THEN PercentDP2Text          
                         WHEN ( @PercentDP >= PercentDP3From          
                                AND @PercentDP <= PercentDP3To          
                              ) THEN PercentDP3Text          
                         WHEN ( @PercentDP >= PercentDP4From          
                                AND @PercentDP <= PercentDP4To          
                              ) THEN PercentDP4Text          
                         WHEN ( @PercentDP >= PercentDP5From          
                                AND @PercentDP <= PercentDP5To          
                              ) THEN PercentDP5Text          
                         WHEN ( @PercentDP >= PercentDP6From          
                                AND @PercentDP <= PercentDP6To          
                              ) THEN PercentDP6Text          
                         WHEN ( @PercentDP >= PercentDP7From          
                                AND @PercentDP <= PercentDP7To          
                              ) THEN PercentDP7Text          
                         WHEN ( @PercentDP >= PercentDP8From          
                                AND @PercentDP <= PercentDP8To          
                              ) THEN PercentDP8Text          
                         WHEN ( @PercentDP >= PercentDP9From          
                                AND @PercentDP <= PercentDP9To          
                              ) THEN PercentDP9Text          
                         WHEN ( @PercentDP >= PercentDP10From          
                                AND @PercentDP <= PercentDP10To          
                              ) THEN PercentDP10Text          
                    END          
    FROM    dbo.ReportPercentDP WITH ( NOLOCK )          
           
    UPDATE  dbo.SalesReport          
    SET     PercentDPText = @Text          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND ReportID = @ReportID          
           
    IF @@ERROR <> 0          
        GOTO ExitSP          
 --End Rudi          
              
-------------------------------------------------              
-- Update tbl SalesReport u/%EffectiveRate              
-- ratna 02/09 --              
-------------------------------------------------              
    /*Remark by Rudi, 05 Dec 2011          
    DECLARE cur_SalesReportEff CURSOR          
    FOR          
        SELECT  ReportID ,          
                PercentEffective1From ,          
                PercentEffective1To ,          
                PercentEffective1Text ,          
                PercentEffective2From ,          
                PercentEffective2To ,          
                PercentEffective2Text ,          
                PercentEffective3From ,          
          PercentEffective3To ,          
                PercentEffective3Text ,          
                PercentEffective4From ,          
                PercentEffective4To ,          
                PercentEffective4Text ,          
                PercentEffective5From ,          
                PercentEffective5To ,          
                PercentEffective5Text ,          
                PercentEffective6From ,          
                PercentEffective6To ,          
                PercentEffective6Text ,          
                PercentEffective7From ,          
                PercentEffective7To ,          
                PercentEffective7Text ,          
                PercentEffective8From ,          
                PercentEffective8To ,          
                PercentEffective8Text ,          
                PercentEffective9From ,          
                PercentEffective9To ,          
                PercentEffective9Text ,          
                PercentEffective10From ,          
                PercentEffective10To ,          
                PercentEffective10Text          
        FROM    ReportPercentEffective              
    OPEN cur_SalesReportEff              
              
    FETCH NEXT FROM cur_SalesReportEff INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From, @5To,          
        @5Text, @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
    WHILE @@FETCH_STATUS = 0           
        BEGIN              
            SET @Text = CASE WHEN ( @EffectiveRate >= @1From          
                                    AND @EffectiveRate < @1To          
                                  ) THEN @1Text          
                             WHEN ( @EffectiveRate >= @2From          
                                    AND @EffectiveRate < @2To          
                                  ) THEN @2Text          
                             WHEN ( @EffectiveRate >= @3From          
                                    AND @EffectiveRate < @3To          
                                  ) THEN @3Text          
                             WHEN ( @EffectiveRate >= @4From          
                                    AND @EffectiveRate < @4To          
                                  ) THEN @4Text          
                             WHEN ( @EffectiveRate >= @5From          
                             AND @EffectiveRate < @5To          
                  ) THEN @5Text          
                             WHEN ( @EffectiveRate >= @6From          
                                    AND @EffectiveRate < @6To          
                                  ) THEN @6Text          
                             WHEN ( @EffectiveRate >= @7From          
                                    AND @EffectiveRate < @7To          
                                  ) THEN @7Text          
                             WHEN ( @EffectiveRate >= @8From          
                                    AND @EffectiveRate < @8To          
                                  ) THEN @8Text          
                             WHEN ( @EffectiveRate >= @9From          
                                    AND @EffectiveRate < @9To          
                                  ) THEN @9Text          
                             WHEN ( @EffectiveRate >= @10From          
                                    AND @EffectiveRate < @10To          
                                  ) THEN @10Text          
                        END              
              
            UPDATE  SalesReport          
            SET     PercentEffectiveText = @Text          
            WHERE   ( BranchID = @BranchID )                      AND ( ApplicationID = @ApplicationID )          
                    AND ( ReportID = @ReportID )              
            IF @@error <> 0           
                GOTO ExitSP              
              
            FETCH NEXT FROM cur_SalesReportEff INTO @ReportID, @1From, @1To, @1Text, @2From, @2To, @2Text, @3From, @3To, @3Text, @4From, @4To, @4Text, @5From,       
                @5To, @5Text, @6From, @6To, @6Text, @7From, @7To, @7Text, @8From, @8To, @8Text, @9From, @9To, @9Text, @10From, @10To, @10Text              
        END              
    CLOSE cur_SalesReportEff              
    DEALLOCATE cur_SalesReportEff              
    End Rudi*/          
              
    --Added by Rudi, 05 Dec 2011          
    SELECT  @ReportID = ReportID ,          
            @Text = CASE WHEN ( @EffectiveRate >= PercentEffective1From          
                                AND @EffectiveRate <= PercentEffective1To          
                              ) THEN PercentEffective1Text          
                         WHEN ( @EffectiveRate >= PercentEffective2From          
                                AND @EffectiveRate <= PercentEffective2To          
                              ) THEN PercentEffective2Text          
                         WHEN ( @EffectiveRate >= PercentEffective3From          
                                AND @EffectiveRate <= PercentEffective3To          
                              ) THEN PercentEffective3Text          
                         WHEN ( @EffectiveRate >= PercentEffective4From          
                                AND @EffectiveRate <= PercentEffective4To          
                              ) THEN PercentEffective4Text          
                         WHEN ( @EffectiveRate >= PercentEffective5From          
                        AND @EffectiveRate <= PercentEffective5To          
                              ) THEN PercentEffective5Text          
                         WHEN ( @EffectiveRate >= PercentEffective6From          
                                AND @EffectiveRate <= PercentEffective6To          
                              ) THEN PercentEffective6Text          
                         WHEN ( @EffectiveRate >= PercentEffective7From          
                                AND @EffectiveRate <= PercentEffective7To          
                              ) THEN PercentEffective7Text          
                         WHEN ( @EffectiveRate >= PercentEffective8From          
                                AND @EffectiveRate <= PercentEffective8To          
                              ) THEN PercentEffective8Text          
                         WHEN ( @EffectiveRate >= PercentEffective9From         
                                AND @EffectiveRate <= PercentEffective9To          
                              ) THEN PercentEffective9Text          
                         WHEN ( @EffectiveRate >= PercentEffective10From          
                                AND @EffectiveRate <= PercentEffective10To          
                              ) THEN PercentEffective10Text          
                    END          
    FROM    dbo.ReportPercentEffective WITH ( NOLOCK )          
           
    UPDATE  dbo.SalesReport          
    SET     PercentEffectiveText = @Text          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND ReportID = @ReportID          
           
    IF @@ERROR <> 0          
        GOTO ExitSP          
 --End Rudi          
          
--Amelya 180309 Ganti TopDays di ambil dari table Supplier             
-------------------------------------------------              
-- Get TOPDays for Supplier from GeneralSetting              
-- ratna 02/09 --              
-------------------------------------------------              
--SELECT @TOPDays = GSValue              
--FROM GeneralSetting with (nolock)               
--WHERE GSID = 'SUPPTOPDAYS'            
            
    SELECT  @TOPDays = TopDays          
    FROM    Supplier WITH ( NOLOCK )          
    WHERE   SupplierID = @SupplierID             
--Amelya 180309 end           
           
-------------------------------------------------              
-- Cek apakah sudah pernah ada Invoice u/Agreement tsb              
-- kalau sudah, baru isi ke field InvoiceNo, InvoiceDate, dan DueDate di AccountPayable              
-- ratna 02/09 --              
-------------------------------------------------             
          
    IF EXISTS ( SELECT  InvoiceNo          
         FROM    InvoiceAgreement WITH ( NOLOCK )          
                WHERE   ( BranchID = @BranchID )          
                        AND ( ApplicationID = @ApplicationID ) )          
        BEGIN              
            SELECT  @InvoiceNo = InvoiceNo          
            FROM    InvoiceAgreement WITH ( NOLOCK )          
            WHERE   ( BranchID = @BranchID )          
                    AND ( ApplicationID = @ApplicationID )              
            SELECT  @InvoiceDate = InvoiceDate          
            FROM    Invoice WITH ( NOLOCK )          
            WHERE   ( BranchID = @BranchID )          
                    AND ( InvoiceNo = @InvoiceNo )              
              
      --Amelya 190309 begin          
 --  SET @APDueDate = DATEADD(day, @TOPDays, @DeliveryOrderDate)           
            SET @APDueDate = DATEADD(day, @TOPDays, @cBusinessdate)           
 --Amleya 190309 end          
          
  -- Lisa 20091229 : Remark pengecekan ApDueDate terhadap EffectiveDate, utk handle tgl 28-31 yang jd tgl 1-4          
  --IF @APDueDate < @EffectiveDate              
  -- BEGIN              
  --  Set @APDueDate =  @EffectiveDate              
  -- END            
  -- End Lisa 20091229            
        END              
    ELSE          
        BEGIN              
            SET @InvoiceNo = '-'              
            SET @InvoiceDate = NULL              
        END              
              
-----------------------------              
-- Process A/P to Supplier --              
-- ratna 02/09 : PO sekarang hanya 1 record krn 1 agreement hanya 1 supplier         
-- widi 17/09/2004 : PO multi              
-----------------------------              
              
----------------------------------------------              
-- Calculate A/P Due Date based on TOP days --              
-- ratna 02/09 : tdk cek IsHold              
----------------------------------------------              
    SELECT  @APStatus = 'N'              
              
------------------------------------------------------------------              
-- Update tbl Account Payable --               
-- widi 17/09/2004 : looping karena 1 Agreement bisa multi PO   
------------------------------------------------------------------              
    SELECT  @PaymentLocation = @BranchID              
              
    /*Remark by Rudi, 05 Dec 2011          
    DECLARE cur_PO CURSOR          
    FOR          
        SELECT  PONo ,          
                POTotal ,          
                BankName ,          
                BankBranch ,          
                AccountNo ,          
                AccountName ,          
                SupplierID          
        FROM    PurchaseOrder WITH(NOLOCK)          
        WHERE   BranchID = @BranchID          
                AND ApplicationID = @ApplicationID              
    OPEN cur_PO              
              
    FETCH NEXT FROM cur_PO INTO @PONo, @POInstallment, @BankName, @BankBranch, @AccountNo, @AccountName, @SupplierIDPO              
    WHILE @@FETCH_STATUS = 0           
        BEGIN              
    End Rudi*/          
              
    --Added by Rudi, 05 Dec 2011          
    DECLARE @i SMALLINT ,          
        @CountPO SMALLINT          
             
 SET @i = 1          
              
    CREATE TABLE #TempPO          
        (          
          RowNum INT IDENTITY ,          
          PONo VARCHAR(50) ,          
          POTotal NUMERIC(17, 2) ,          
          BankName VARCHAR(50) ,          
          BankBranch VARCHAR(50) ,          
          AccountNo VARCHAR(25) ,          
          AccountName VARCHAR(50) ,          
          SupplierID CHAR(10)          
        )          
              
    INSERT  INTO #TempPO          
            ( PONo ,          
              POTotal ,          
              BankName ,          
              BankBranch ,          
              AccountNo ,          
              AccountName ,          
              SupplierID          
            )          
            SELECT  PONo ,          
                    POTotal ,          
                    BankName ,          
                    BankBranch ,          
                    AccountNo ,          
              AccountName ,          
                    SupplierID          
            FROM    dbo.PurchaseOrder WITH ( NOLOCK )          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID          
              
    SELECT  @CountPO = COUNT('')          
    FROM    #TempPO          
              
    WHILE @i <= @CountPO          
        BEGIN          
            SELECT  @PONo = PONo ,          
                    @POInstallment = POTotal ,          
                    @BankName = BankName ,          
                    @BankBranch = BankBranch ,          
                    @AccountNo = AccountNo ,          
                    @AccountName = AccountName ,          
                    @SupplierIDPO = SupplierID          
            FROM    #TempPO          
 WHERE   RowNum = @i          
    --End Rudi          
                  
  ------------------------------------------------              
  -- Get SequenceNo from MasterSequence for A/P --              
  -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction              
  ------------------------------------------------              
            EXEC @error= spGetNoTransaction @BranchID, @BusinessDate, 'ACCPAY',          
                @AccountPayableNo OUTPUT              
            IF @error <> 0          
                GOTO ExitSP              
                
  ------------------------------------------------------------------              
  -- Check A/P Limit for Branch based on setting at ProductBranch --               
  -- ratna 02/09 : cek dr tbl ProductOffering              
  ------------------------------------------------------------------              
            IF @POInstallment > ( SELECT    LimitAPCash          
                                  FROM      ProductOffering WITH ( NOLOCK )          
                                  WHERE     ProductOffering.BranchID = @BranchID          
    AND ProductOffering.ProductID = @ProductID          
                                            AND ProductOffering.ProductOfferingID = @ProductOfferingID          
                                )          
                BEGIN              
                    SELECT  @PaymentLocation = @KodeHO              
                END              
                
  ---------------------------              
  -- Get the Supplier Name --               
  -- ratna 02/09 : field di Supplier : SupplierName              
  ---------------------------              
            SELECT  @APTo = Supplier.SupplierName          
            FROM    Supplier WITH ( NOLOCK )          
            WHERE   ( SupplierID = @SupplierIDPO )              
              
  -----------------------------------------              
  -- Insert data to table AccountPayable --              
  -- ratna 02/09 : field2 disesuaikan dgn tbl AP di TFS              
  -----------------------------------------              
            SELECT  @Description = LTRIM(RTRIM(@AgreementNo)) + ' - '          
                    + @CustomerName              
                
                 
            SELECT  @IsMainPO = IsMainPO          
            FROM    PurchaseOrder WITH ( NOLOCK )          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID          
                    AND PONo = @PoNo              
          
-------------------Arinta, 28 des 2015, fmf-1465----------------------------          
----------------------------------------------------------------------------          
          
            DECLARE @BAName VARCHAR(50) ,          
                @AccountNameB VARCHAR(50) ,          
                @AccountNoB VARCHAR(50) ,          
                @BankBranchB VARCHAR(50) ,          
                @CountBA INT ,          
                @AddOtherFee NUMERIC(17, 2)          
          
            SELECT  @CountBA = COUNT(IsMainBankAccount)          
            FROM    BankAccount          
            WHERE   BranchID = @BranchID          
                    AND IsMainBankAccount = 1          
          
            SELECT  @AddOtherFee = AdditionalOtherFee          
            FROM    Agreement          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID          
          
            IF ( @CountBA <= 0 )          
                BEGIN          
                    RAISERROR ( 'Please Setting Main Bank Account!', 16, 1 )              
                    SET @Error = 1               
                    IF @Error > 0          
                        GOTO ExitSp           
                END          
            ELSE          
                IF ( @CountBA = 1 )          
                    BEGIN           
      --edit by Cevin (Compared)          
                        --SELECT  @BAName = BankAccountName ,          
      SELECT  @BAName = BankMaster.BankName,          
      --end Cevin          
                                @AccountNameB = AccountName ,          
                                @AccountNoB = AccountNo ,          
                                @BankBranchB = BankBranch          
                        FROM    BankAccount          
      --add by Cevin (Compared)          
      INNER JOIN BankMaster WITH (NOLOCK) ON BankAccount.BankID=BankMaster.BankID          
      --end Cevin          
                        WHERE   BranchID = @BranchID          
                                AND IsMainBankAccount = 1          
   END          
------------------end arinta--------------------------------------------------          
------------------------------------------------------------------------------          
            
          
  --Anita, 20150710 remark supaya tidak saling bentrok dengan transferAPDisb          
  --Gema, 1 Oktober 2007 : Tambah cek NormalType dari productoffering            
  --          IF ( SELECT NormalType          
  --               FROM   ProductOffering WITH ( NOLOCK )          
  --               WHERE  productID = @ProductId          
  --                      AND ProductOfferingID = @ProductOfferingID          
  --                      AND BranchID = @BranchID          
  --             ) = 'LB'           
  --              BEGIN              
  --------------------------            
  ---- Get Data Customer  --            
  --------------------------            
  --                  SELECT  @APTo = Customer.Name,          
  --                          @CustomerType = CustomerType,          
  --                          @AccountName = ( CASE WHEN customerType = 'P'          
  --                                                THEN PC.AccountName          
  --                                                ELSE CC.AccountName          
  --                                           END ),          
  --                          @AccountNo = ( CASE WHEN customerType = 'P'          
  --                                              THEN PC.AccountNo          
  --                                              ELSE CC.AccountNo          
  --                                         END ),          
  --                          @BankName = ( CASE WHEN customerType = 'P'          
  --                                             THEN PC.BankID          
  --                                             ELSE CC.BankID          
  --                                        END ),          
  --                          @BankBranch = ( CASE WHEN customerType = 'P'          
  --                                               THEN PC.BankBranch          
  --                                               ELSE CC.BankBranch          
  --                                          END )          
  --                  FROM    Customer WITH ( NOLOCK )          
  --                          LEFT JOIN PersonalCustomer PC WITH ( NOLOCK ) ON PC.CustomerID = Customer.CustomerID          
  --                          LEFT JOIN CompanyCustomer CC WITH ( NOLOCK ) ON CC.CustomerID = Customer.CustomerID          
  --                  WHERE   Customer.CustomerID = @CustomerID            
                    
  --                  IF ( @AccountNo IS NULL )           
  --                      BEGIN            
  --                          RAISERROR ( 'Customer Account is  Exists', 16,          
  --                              1 )            
  --                          SET @error = 1            
  --                          GOTO ExitSP            
  --                      END            
            
  --              END           
  --End Anita          
              
                
            INSERT  INTO AccountPayable          
                    ( BranchID ,          
                      AccountPayableNo ,          
                      ApplicationID ,          
                      APDate ,          
                      ReferenceNo ,          
                      Description ,          
                      DueDate ,          
                      APAmount ,          
                      APAmountInProcess ,          
                      PaidAmount ,          
                      APType ,          
                      APTo ,          
                      AccountNameTo ,          
                      AccountNoTo ,          
                      BankNameTo ,          
                      BankBranchTo ,          
                      SupplierID ,          
                      PaymentLocation ,          
                      InvoiceNo ,          
                      InvoiceDate ,          
                      Status ,          
                      APStatusDate ,          
                      CurrencyID ,          
                      CurrencyRate               
                    )          
            VALUES  ( @BranchID ,          
                      @AccountPayableNo ,          
                      @ApplicationID ,          
                      @BusinessDate ,          
         @AgreementNo ,          
                      @Description ,          
                      CONVERT(VARCHAR(10), @APDueDate, 101) ,  -- By Johnson, 15 juli 2005  TDPAmount Sudah Termasuk Dalam @POInstallment             
                      ( CASE WHEN @IsMainPO = 1 THEN @POInstallment --+ @ContractPrepaidAmount              
                             ELSE @POInstallment          
                        END ) ,          
                      0 ,          
                   0 ,          
                      'SPPL' ,          
                      @APTo ,          
                      ISNULL(@AccountName, '-') ,          
                      ISNULL(@AccountNo, '-') ,          
                      ISNULL(@BankName, '-') ,          
                      ISNULL(@BankBranch, '') ,          
                      @SupplierIDPO ,          
                      @PaymentLocation ,          
                      @InvoiceNo ,          
                      @InvoiceDate ,          
                      @APStatus ,          
                      @BusinessDate ,          
                      @CurrencyID ,          
                      @CurrencyRate               
                    )              
                
            IF @@error <> 0          
                BEGIN              
                
                    GOTO ExitSP              
                END              
          
          
------------------------------------------------------------------          
-- Added by arinta          
--on 28 des 2015 : Add AP To Branch          
------------------------------------------------------------------          
          
          
            IF @AddOtherFee > 0          
                BEGIN              
          
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO ExitSP           
          
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                              APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
      APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
          )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description + ' - AP to Branch' ,          
                              CONVERT(VARCHAR(10), @APDueDate, 101) ,          
                              @AddOtherFee ,          
                              0 ,          
                              0 ,          
                              'SPPL' ,          
                              'To Branch' ,          
                      ISNULL(@AccountNameB, '-') ,          
                              ISNULL(@AccountNoB, '-') ,          
                              ISNULL(@BAName, '-') ,          
                              ISNULL(@BankBranchB, '') ,          
                              '-' ,          
                              @KodeHO ,          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              @APStatus ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
          )              
                END          
          
            IF @@error <> 0          
                BEGIN              
                
                    GOTO ExitSP              
                END             
--end arinta          
------------------------------------------------------------------------------------------------------------------------------------------------------------------          
          
-- ---------------------------------------------------------------           
-- Added by Albert Ricia,           
-- on 3-7-2015 : Checked if the agreement is A/P Disburse to Customer          
-- ---------------------------------------------------------------           
            DECLARE @TransferApDisb CHAR(1)          
            DECLARE @AccountNameINCS VARCHAR(100) ,          
                @AccountNoINCS VARCHAR(100) ,          
                @BankNameINCS VARCHAR(100) ,          
                @BankBranchINCS VARCHAR(100) ,          
                @SubsidyCommission NUMERIC(17, 2)          
          
            SELECT  @TransferApDisb = ISNULL(TransferApDisb, 'D')          
            FROM    agreement          
            WHERE   applicationID = @ApplicationID          
          
            IF ( @TransferApDisb = 'C' )          
                BEGIN          
  -- Take Account Name, Account No, Bank Name, and Bank Branch from Suplier          
                    SELECT  @AccountNameINCS = SupplierAccountName ,          
                            @AccountNoINCS = SupplierAccountNo ,          
                            @BankNameINCS = SupplierBankID ,          
                            @BankBranchINCS = SupplierBankBranch          
                    FROM    SupplierAccount          
                    WHERE   SupplierID = @SupplierIDPO          
          
  --Anita, 201507010          
                    SELECT  @APTo = Supplier.SupplierName          
                    FROM    Supplier WITH ( NOLOCK )          
                    WHERE   ( SupplierID = @SupplierIDPO )              
       
     --edit fuji,27012023 (fmf-4017) ubah cara ambil @SubsidyCommission  
                    SELECT  @SubsidyCommission = CASE WHEN SUM(ISNULL(SupplierPPNAmount,0)) > 0   
     THEN SUM(ISNULL(SupplierDPPAmount,0))+  
     SUM(ISNULL(SupplierPPNAmount,0))-SUM(SupplierTaxAmount)  
     ELSE  
        SUM(SupplierInsuranceIncome)          
                            + SUM(SupplierUppingBunga) + SUM(SupplierOtherFee) + ISNULL(SUM(SupplierProvisionFee),0) --Aditia FMF-1640 09032018 Tambah SupplierProvisionFee          
                            - SUM(SupplierTaxAmount)    
     END        
                    FROM    dbo.Commision WITH ( NOLOCK )          
                    WHERE   BranchId = @BranchID          
                     AND ApplicationId = @ApplicationID          
                    GROUP BY BranchId ,          
                            ApplicationId ,          
                            SupplierID          
     --end edit fuji  
  
                    IF @SubsidyCommission <> 0          
                        BEGIN           
    -- Generate ApNo          
                            EXEC @error= spGetNoTransaction @BranchID,          
                                @BusinessDate, 'ACCPAY',          
                                @AccountPayableNo OUTPUT              
                            IF @error <> 0          
                                GOTO exitSP           
          
    -- Insert into account payable with APType INCS          
                            INSERT  INTO AccountPayable          
                                    ( BranchID ,          
                                      AccountPayableNo ,          
                                      ApplicationID ,          
                                      APDate ,          
                                      ReferenceNo ,          
                                      Description ,          
                                      DueDate ,          
                                      APAmount ,          
                                      APAmountInProcess ,          
                                      PaidAmount ,          
                                      APType ,          
                                      APTo ,          
                                      AccountNameTo ,          
                                      AccountNoTo ,          
                                      BankNameTo ,          
                                      BankBranchTo ,          
                                      SupplierID ,          
                                      PaymentLocation ,          
      InvoiceNo ,          
                                      InvoiceDate ,          
                                      Status ,          
                                      APStatusDate ,          
                                      CurrencyID ,          
                                      CurrencyRate               
                     )          
                            VALUES  ( @BranchID ,          
                                      @AccountPayableNo ,          
       @ApplicationID ,          
                                      @BusinessDate ,          
                                      @AgreementNo ,          
                                      @Description ,          
                                      CONVERT(VARCHAR(10), @APDueDate, 101) ,  -- By Johnson, 15 juli 2005  TDPAmount Sudah Termasuk Dalam @POInstallment             
      --Anita, 20150710           
      --( CASE WHEN @IsMainPO = 1 THEN @POInstallment --+ @ContractPrepaidAmount              
      --   ELSE @POInstallment          
      --  END ),          
                                      @SubsidyCommission ,          
      --End Anita          
                                      0 ,          
                                      0 ,          
                                      'INCS' ,          
                                      @APTo ,          
                                      ISNULL(@AccountNameINCS, '-') ,          
                                      ISNULL(@AccountNoINCS, '-') ,          
                                      ISNULL(@BankNameINCS, '-') ,          
                                      ISNULL(@BankBranchINCS, '') ,          
                              @SupplierIDPO ,          
                                      @PaymentLocation ,          
                                      @InvoiceNo ,          
                                      @InvoiceDate ,          
                                      @APStatus ,          
                                      @BusinessDate ,          
                                      @CurrencyID ,          
                                      @CurrencyRate               
                     )              
                        END          
  --End Anita          
                   
            
                END          
-- End Added By Albert Ricia          
                
  ---------------------------------------------------------------              
  -- Update AccountPayableNo at table PurchaseOrder --              
  -- ratna 02/09 : APNo ada di PO              
  ---------------------------------------------------------------              
            UPDATE  PurchaseOrder          
            SET     AccountPayableNo = @AccountPayableNo          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID          
                    AND PONo = @PoNo              
            IF @@error <> 0          
                GOTO ExitSP              
              
            --FETCH NEXT FROM cur_PO INTO @PONo, @POInstallment, @BankName, @BankBranch, @AccountNo, @AccountName, @SupplierIDPO              
            SET @i = @i + 1          
        END              
    /*Remark by Rudi, 05 Dec 2011          
    CLOSE cur_PO              
    DEALLOCATE cur_PO              
    End Rudi*/          
              
-------------------------------------------              
-- Process A/P Refund to Supplier if any --              
-- ratna 02/09 : perubahan disesuaikan dgn tbl AP sekarang              
-- widi 22/09/2004 :               
-- 1. AP Status diset 'N' tidak usah ambil dari tbl AccountPayable              
-- 2. Bank Name, dst, ambil dr tbl Commision              
-------------------------------------------              
    DECLARE @MainSupplier amount ,          
        @MainSupplierEmployee amount ,          
        @MainReferantor amount ,          
        @SupplierIncentive amount ,          
        @SupplierEmployeeIncentive amount ,          
        @SupplierBankName VARCHAR(50) ,          
        @SupplierEmployeeBankName VARCHAR(50) ,          
        @ReferantorBankName VARCHAR(50) ,          
        @SupplierIncentiveBankName VARCHAR(50) ,          
        @SupplierIncentiveEmployeeBankName VARCHAR(50) ,          
        @ReferantorIncentiveBankName VARCHAR(50) ,          
        @SupplierCommisionBankName VARCHAR(50) ,          
        @SupplierCommisionEmployeeBankName VARCHAR(50) ,          
        @ReferantorCommisionBankName VARCHAR(50) ,          
        @SupplierEmployeeIncentiveBankBranch VARCHAR(50) ,          
        @SupplierEmployeeIncentiveAccountNo VARCHAR(50) ,          
        @SupplierEmployeeIncentiveAccountName VARCHAR(50) ,          
        @SupplierBankBranch VARCHAR(50) ,          
        @SupplierAccountNo VARCHAR(50) ,          
        @SupplierAccountName VARCHAR(50) ,          
        @SupplierEmployeeBankBranch VARCHAR(50) ,          
        @SupplierEmployeeAccountNo VARCHAR(50) ,          
        @SupplierEmployeeAccountName VARCHAR(50) ,          
        @ReferenceBankBranch VARCHAR(50) ,          
        @ReferenceAccountNo VARCHAR(50) ,          
        @ReferenceAccountName VARCHAR(50) ,          
        @SupplierIncentiveBankBranch VARCHAR(50) ,          
        @SupplierIncentiveAccountNo VARCHAR(50) ,          
        @SupplierIncentiveAccountName VARCHAR(50) ,          
        @MainSupplierName VARCHAR(200) ,          
        @MainSupplierEmployeeName VARCHAR(50) ,          
        @MainReferenceName VARCHAR(50) ,          
        @SupplierIncentiveName VARCHAR(50) ,          
        @SupplierEmployeeIncentiveName VARCHAR(50) ,          
        @MainSupplierID VARCHAR(20) ,          
        @MainSupplierEmployeeID VARCHAR(20) ,          
        @SupplierEmployeeIncentiveID VARCHAR(20) ,          
        @SupplierIncentiveID VARCHAR(20) ,          
        @TaxAmountMainSupplierCompany NUMERIC(17, 2) ,   
  --edit fuji,09122022 perbaiki Bugs CR FMF-3546 Tax Main SupplierEmployee Personal dan Company dipisah        
        @TaxAmountMainSupplierEmployeePersonal NUMERIC(17, 2) ,   
  @TaxAmountMainSupplierEmployeeCompany NUMERIC(17, 2) ,   
  --End Fuji         
        @TaxAmountOtherSupplierCompany NUMERIC(17, 2) ,   
  --edit fuji,09122022 perbaiki Bugs CR FMF-3546 Tax Other SupplierEmployee Personal dan Company dipisah           
        @TaxAmountOtherSupplierEmployeePersonal NUMERIC(17, 2) ,    
  @TaxAmountOtherSupplierEmployeeCompany NUMERIC(17, 2) ,   
  --end fuji       
        @TaxAmountReferantor NUMERIC(17, 2) ,          
        @ReferenceType CHAR(1) ,          
 @APTAXTYPE VARCHAR(10) ,          
        @KppName VARCHAR(50) ,          
        @CommisionMainSuppEmp NUMERIC(17, 2), --Add by Dessy 21092012 : FMF CR IJON          
        @SupplierEmployeeIncentiveVAT Amount = 0 --add fuji,27012023 (fmf-4017)       
--------------------------------------------------------------------------------------------              
-- Get KPPName From GeneralSetting              
-- Johnson, 6 Des 2005              
--------------------------------------------------------------------------------------------              
--Novia modiy, 17062016 : FMF-1515          
    --IF EXISTS ( SELECT  ''          
    --            FROM    GeneralSetting WITH ( NOLOCK )          
    --            WHERE   GSID = 'KPPNAME' )          
    --    BEGIN              
    --        SELECT  @KppName = GSValue          
    -- FROM    GeneralSetting WITH ( NOLOCK )          
    --        WHERE   GSID = 'KPPNAME'              
    --    END              
    --ELSE          
    --    BEGIN              
    --        SET @KppName = 'KPP'              
    --    END              
          
    SELECT  @KppName = TblNPWPBranch.Description          
    FROM    dbo.Branch WITH ( NOLOCK )          
            INNER JOIN dbo.TblNPWPBranch WITH ( NOLOCK ) ON dbo.Branch.NPWPBranch = dbo.TblNPWPBranch.ID          
           
    SET @KppName = ISNULL(@KppName, 'KPP')          
          
              
 --Eo Novia, 17062016          
              
--------------------------------------------------------------------------------------------              
              
                 
--------------------------------------------------------------------------------------------              
-- Mengambil TotalSupplier, TotalSupplierEmployee, TotalReferantor      --              
-- Bank Name  BankBranch ,AccoountNo, AccountName  -> Supplier,SupplierEmployee,Referantor--              
-- widi 22/09 : ambil data dr tbl Commision           --              
--------------------------------------------------------------------------------------------              
    SET @TaxAmountMainSupplierCompany = 0    
 --Edit fuji,Perbaiki Bugs CR (FMF-3546)  Pisahin Tax Supplier               
    SET @TaxAmountMainSupplierEmployeePersonal = 0   
   SET @TaxAmountMainSupplierEmployeeCompany = 0                
    SET @TaxAmountOtherSupplierCompany = 0              
    SET @TaxAmountOtherSupplierEmployeePersonal = 0   
 SET @TaxAmountMainSupplierEmployeeCompany = 0    
 --end fuji         
    SET @TaxAmountReferantor = 0               
      
 --edit fuji,27012023 (fmf-4017),jika ada VAT cara perhitungan berubah  
    SELECT  @MainSupplier = CASE WHEN ISNULL(SupplierPPNAmount,0) > 0   
     THEN ISNULL(SupplierDPPAmount,0)+  
     ISNULL(SupplierPPNAmount,0)-SupplierTaxAmount  
   else  
   SupplierInsuranceIncome + SupplierUppingBunga          
   + SupplierOtherFee + ISNULL(SupplierProvisionFee,0) --Aditia FMF-1640 09032018 Tambah SupplierProvisionFee          
            - -- Added by Albert Ricia on 16 Agustus 2016 (FMF-1515)          
   ( CASE @CalculateTaxMethodSupllier          
                WHEN 'GR' THEN 0          
                WHEN 'NE' THEN SupplierTaxAmount          
                ELSE SupplierTaxAmount          
              END ) end,    
 --end edit fuji        
   -- End Added          
   --Novia modify, 17062016 : FMF-1515          
            --@MainSupplierEmployee = SupplierEmployeeInsuranceIncome          
            --+ SupplierEmployeeUppingBunga + SupplierEmployeeOtherFee          
            --- SupplierEmployeeTaxAmount ,          
            --@MainReferantor = dbo.Commision.ReferenceNameInsuranceIncome          
            --+ dbo.Commision.ReferenceNameUppingBunga          
            --+ dbo.Commision.ReferenceNameOtherFee          
            --- dbo.Commision.ReferenceNameTaxAmount ,   
   --edit fuji,27012023 (fmf-4017),jika ada VAT cara perhitungan @MainSupplierEmployee berubah         
            @MainSupplierEmployee = case when ISNULL(SupplierEmployeePPnAmount,0) > 0 then  ISNULL(SupplierEmployeeDPPAmount,0) + ISNULL(SupplierEmployeePPnAmount,0) - SupplierEmployeeTaxAmount  
     else   
     SupplierEmployeeInsuranceIncome          
    + SupplierEmployeeUppingBunga + SupplierEmployeeOtherFee + ISNULL(SupplierEmployeeProvisionFee,0) --Aditia FMF-1640 09032018 Tambah SupplierProvisionFee          
    - ( CASE @CalculateTaxMethodSupllierEmp          
                  WHEN 'GR' THEN 0          
      WHEN 'NE' THEN SupplierEmployeeTaxAmount          
                  ELSE SupplierEmployeeTaxAmount          
    END ) end ,      
    --end fuji      
            @MainReferantor = dbo.Commision.ReferenceNameInsuranceIncome          
            + dbo.Commision.ReferenceNameUppingBunga          
            + dbo.Commision.ReferenceNameOtherFee          
      + ISNULL(dbo.Commision.ReferenceNameProvisionFee,0) --Aditia FMF-1640 09032018 Tambah SupplierProvisionFee          
            - ( CASE @CalculateTaxMethodSupllierEmp          
                  WHEN 'GR' THEN 0          
                  WHEN 'NE' THEN dbo.Commision.ReferenceNameTaxAmount          
                  ELSE dbo.Commision.ReferenceNameTaxAmount          
                END ) ,          
   --Eo Novia, 17062016          
            @SupplierBankName = BM.BankName ,          
            @SupplierEmployeeBankName = BMEmployee.BankName ,          
            @ReferantorBankName = BMReferantor.BankName ,          
            @SupplierBankBranch = SupplierBankBranch ,          
            @SupplierAccountNo = SupplierAccountNo ,          
            @SupplierAccountName = SupplierAccountName ,          
            @SupplierEmployeeBankBranch = Commision.SupplierEmployeeBankBranch ,          
            @SupplierEmployeeAccountNo = Commision.SupplierEmployeeAccountNo ,          
            @SupplierEmployeeAccountName = Commision.SupplierEmployeeAccountName ,          
            @ReferenceBankBranch = dbo.Commision.ReferenceBankBranch ,          
            @ReferenceAccountNo = dbo.Commision.ReferenceAccountNo ,          
            @ReferenceAccountName = dbo.Commision.ReferenceAccountName ,          
            @MainSupplierName = SupplierName ,          
            @MainSupplierEmployeeName = SupplierEmployeeName ,          
            @MainReferenceName = dbo.Commision.ReferenceName ,          
            @MainSupplierID = Commision.SupplierID ,          
            @MainSupplierEmployeeID = Commision.SupplierEmployeeID ,          
            @TaxAmountMainSupplierCompany = Commision.SupplierTaxAmount ,          
            --edit fuji,09122022 : perbaiki Bugs CR FMF-3546  
   @TaxAmountMainSupplierEmployeePersonal =   
   (CASE  WHEN ISNULL(SupplierEmployee.SupplierEmployeeType,'P') = 'P'   
   THEN Commision.SupplierEmployeeTaxAmount  
   ELSE  0  
   END) ,   
   @TaxAmountMainSupplierEmployeeCompany =   
   (CASE  WHEN ISNULL(SupplierEmployee.SupplierEmployeeType,'P') = 'C'   
   THEN Commision.SupplierEmployeeTaxAmount  
   ELSE  0  
   END) ,          
            --end edit fuji  
   @TaxAmountReferantor = Commision.ReferenceNameTaxAmount ,          
            @ReferenceType = ISNULL(Agreement.ReferenceType, '-') ,    
   --Edit Jason, 18 November 2022 [FMF-3934]        
            --@CommisionMainSuppEmp = SupplierEmployeeUppingBunga  --Add by Dessy 21092012 : FMF CR IJON    
   @CommisionMainSuppEmp = SupplierEmployeeUppingBunga -   
   ( CASE @CalculateTaxMethodSupllierEmp          
                  WHEN 'GR' THEN 0   
      WHEN 'NE' THEN SupplierEmployeeTaxAmount        
                  ELSE SupplierEmployeeTaxAmount      
                END )  
   --End Jason          
    FROM    dbo.Commision WITH ( NOLOCK )          
            LEFT JOIN BankMaster BM WITH ( NOLOCK ) ON Commision.SupplierBankID = BM.BankID          
            LEFT JOIN BankMaster BMEmployee WITH ( NOLOCK ) ON Commision.SupplierEmployeeBankID = BMEmployee.BankID          
            LEFT JOIN BankMaster BMReferantor WITH ( NOLOCK ) ON Commision.ReferenceBankID = BMReferantor.BankID          
            LEFT JOIN dbo.Supplier WITH ( NOLOCK ) ON dbo.Commision.SupplierID = dbo.Supplier.SupplierID          
            LEFT JOIN dbo.SupplierEmployee WITH ( NOLOCK ) ON dbo.Commision.SupplierID = dbo.SupplierEmployee.SupplierID          
                                                              AND dbo.Commision.SupplierEmployeeID = dbo.SupplierEmployee.SupplierEmployeeID          
            INNER JOIN dbo.Agreement WITH ( NOLOCK ) ON dbo.Commision.BranchID = dbo.Agreement.BranchID          
                                                        AND dbo.Commision.ApplicationID = dbo.Agreement.ApplicationID          
    WHERE   dbo.Commision.BranchID = @BranchID          
            AND dbo.Commision.ApplicationID = @ApplicationID          
            AND SeqNo = 1               
             
---------------------------------------------------------------------------------------------                
-- Dessy Add 21092012 : FMF CR IJON -> tambah proses Update Data jika SupplierEmployee nya IJON          
---------------------------------------------------------------------------------------------          
    DECLARE @IsIJON BIT          
    SET @IsIJON = 0          
    SELECT  @IsIJON = IsIJON          
    FROM    SupplierEmployee WITH ( NOLOCK )          
    WHERE   SupplierID = @MainSupplierID          
            AND SupplierEmployeeID = @MainSupplierEmployeeID          

    IF ( @IsIJON = 1 )          
        BEGIN           
 --Dessy Add 16 Oct 2012          
            IF  EXISTS ( SELECT  ''          
                            FROM    RequestIJON          
                            WHERE   SupplierID = @MainSupplierID          
                                    AND SupplierEmployeeID = @MainSupplierEmployeeID )          
                BEGIN          
                    RAISERROR('Supplier Employee has no IJON. Please request IJON first',16,1)          
                    GOTO ExitSP           
                END          
 --end dessy 16 Oct 2012          
           
            UPDATE  SupplierEmployee          
            SET     OSIJONAmount = ISNULL(OSIJONAmount, 0)          
                    - @CommisionMainSuppEmp          
            WHERE   SupplierID = @MainSupplierID          
                    AND SupplierEmployeeID = @MainSupplierEmployeeID          
           
            IF EXISTS ( SELECT  ''          
                        FROM    RequestIJON          
                        WHERE   SupplierID = @MainSupplierID          
                                AND SupplierEmployeeID = @MainSupplierEmployeeID          
                                AND Status = 'OPN' )          
                BEGIN          
                    UPDATE  RequestIJON          
                    SET     AmountRealized = ISNULL(AmountRealized, 0)          
                            + @CommisionMainSuppEmp          
                    WHERE   SupplierID = @MainSupplierID          
                            AND SupplierEmployeeID = @MainSupplierEmployeeID          
                            AND Status = 'OPN'          
                END          
            ELSE          
                BEGIN          
                    UPDATE  RequestIJON          
                    SET     AmountRealized = ISNULL(AmountRealized, 0)          
                            + @CommisionMainSuppEmp          
                    WHERE   SupplierID = @MainSupplierID          
                            AND SupplierEmployeeID = @MainSupplierEmployeeID          
                            AND Status = 'NEW'          
                            AND OldIJONAmount > 0          
                END           
        END          
---------------------------------END DESSY 21092012-------------------------------------           
              
              
-- untuk main supplier              
    IF @MainSupplier > 0          
        BEGIN              
            SELECT  @PaymentLocation = @BranchID              
              
 ------------------------------------------------------------------              
 -- Check A/P Limit for Branch based on setting at ProductOffering --              
 -- ratna 02/09 : ambil data dr tbl ProductOffering --              
 ------------------------------------------------------------------              
            IF @MainSupplier > ( SELECT LimitAPCash          
                                 FROM   ProductOffering WITH ( NOLOCK )          
                                 WHERE  ( ProductOffering.BranchID = @BranchID )          
                                        AND ( ProductOffering.ProductID = @ProductID )          
                                        AND ( ProductOffering.ProductOfferingID = @ProductOfferingID )          
                               )          
                BEGIN               
                    SELECT  @PaymentLocation = @KodeHO              
                END              
              
/* By Johnson 17 Mei 2005               
 ------------------------------------------------              
 -- Get SequenceNo from MasterSequence for A/P --              
 -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction              
 ------------------------------------------------              
 EXEC @error=spGetNoTransaction @BranchID, @BusinessDate, 'ACCPAY', @AccountPayableNo OUTPUT              
 if @error <> 0               
  goto exitSP              
           
 -----------------------------------------              
 -- Insert data to table AccountPayable --              
 -- ratna 02/09 : sesuaikan field2 dengan tbl AP sekarang              
 -----------------------------------------              
 SELECT @Description = 'Incentive Supplier ' + Ltrim(Rtrim(@AgreementNo)) + ' - ' + @CustomerName              
 INSERT INTO AccountPayable (              
  BranchID,              
  AccountPayableNo,              
  ApplicationID,              
  APDate,              
  ReferenceNo,              
  Description,              
  DueDate,              
  APAmount,              
  APAmountInProcess,              
  PaidAmount,              
  APType,              
  APTo,              
  AccountNameTo,              
  AccountNoTo,              
  BankNameTo,              
  BankBranchTo,              
  SupplierID,              
  PaymentLocation,              
  InvoiceNo,              
  InvoiceDate,              
  Status,              
  APStatusDate,              
  CurrencyID,              
  CurrencyRate               
 )              
 VALUES (              
  @BranchID,              
  @AccountPayableNo,              
  @ApplicationID,              
  @BusinessDate,              
  @AgreementNo,              
  @Description,              
  @APDueDate,              
  @MainSupplier,              
  0,              
  0,              
  'SPPL',              
  @MainSupplierName,              
  @SupplierAccountName,              
  @SupplierAccountNo,              
  @SupplierBankName,              
  @SupplierBankBranch,              
  @MainSupplierID,              
  @PaymentLocation,              
  @InvoiceNo,              
  @InvoiceDate,              
  'N',              
  @BusinessDate,              
  @CurrencyID,              
  @CurrencyRate               
 )              
 if @@error <> 0 goto ExitSP              
              
*/              
 --===== Start Process Create AccountPayable Supplier AP tax =======--              
 --ratna 7 mei 2005              
               
            IF @TaxAmountMainSupplierCompany > 0          
                BEGIN              
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
        IF @error <> 0          
                        GOTO exitSP              
                
                    SELECT  @Description = 'APTAX Supplier '          
                            + LTRIM(RTRIM(@MainSupplierName)) + '('          
                            + LTRIM(RTRIM(@AgreementNo)) + ')'              
                
              
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                              APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
               @AgreementNo ,          
                              @Description ,          
                              CONVERT(VARCHAR(10), @LastDateOfMonth, 101) , --@BusinessDate,              
                              @TaxAmountMainSupplierCompany ,          
                              0 ,          
                              0 ,          
                              'TXCO' ,          
                              @KppName ,          
                              '-' , --@SupplierAccountName,              
                              '-' , --@SupplierAccountNo,              
                              '-' , --@SupplierBankName,              
                              '-' , --@SupplierBankBranch,              
                              @MainSupplierID ,          
                              @PaymentLocation ,          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END              
        END              
              
    /*Dessy 21092012 : FMF CR IJON , beri kondisi IF @IsIJON = 0, bahwa jika SupplierEmployee nya bukan IJON maka boleh membentuk AP INCENTIVE,           
       jika IJON maka tidak boleh membentuk AP INCENTIVE*/            
    IF @IsIJON = 0          
        BEGIN             
            IF @MainSupplierEmployee > 0          
                BEGIN                   
                    SELECT  @PaymentLocation = @BranchID              
              
 ------------------------------------------------------------------              
 -- Check A/P Limit for Branch based on setting at ProductOffering --              
 -- ratna 02/09 : ambil data dr tbl ProductOffering --              
 ------------------------------------------------------------------              
              
                    IF @MainSupplierEmployee > ( SELECT LimitAPCash          
                                                 FROM   ProductOffering WITH ( NOLOCK )          
                    WHERE  ( ProductOffering.BranchID = @BranchID )          
                                                        AND ( ProductOffering.ProductID = @ProductID )          
                                                        AND ( ProductOffering.ProductOfferingID = @ProductOfferingID )          
                                               )          
                        BEGIN              
                            SELECT  @PaymentLocation = @KodeHO              
                        END              
              
 ------------------------------------------------              
 -- Get SequenceNo from MasterSequence for A/P --              
 -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction              
 ------------------------------------------------              
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO exitSP          
              
 -----------------------------------------              
 -- Insert data to table AccountPayable --              
 -- ratna 02/09 : sesuaikan field2 dengan tbl AP sekarang               
 -----------------------------------------              
                    SELECT  @Description = 'Incentive Supplier Employee '          
                            + LTRIM(RTRIM(@AgreementNo)) + ' - '          
                            + @CustomerName              
                
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                  APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              SupplierEmployeeId ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              @BusinessDate ,          
                              @MainSupplierEmployee ,          
                              0 ,          
                              0 ,          
                              'INCE' ,          
                              ISNULL(@MainSupplierEmployeeName,'-') ,          
                              ISNULL(@SupplierEmployeeAccountName,'-') ,          
                              ISNULL(@SupplierEmployeeAccountNo,'-') ,          
                         ISNULL(@SupplierEmployeeBankName,'-') ,          
                              ISNULL(@SupplierEmployeeBankBranch,'-') ,          
                              @MainSupplierID ,          
            @MainSupplierEmployeeID ,          
                              @KodeHO,--@PaymentLocation , --Victor, 25 Jan 2023 : (FMF-4071)   
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
              
--===== Start Process Create AccountPayable Supplier Employee AP tax =======--              
          -------------Tax Supplier Employee Personal-------------------  
   IF @TaxAmountMainSupplierEmployeePersonal > 0  
   BEGIN    
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO exitSP              
              
                    SELECT  @Description = 'APTAX PS Suppl Emp '          
                            + LTRIM(RTRIM(@MainSupplierEmployeeName)) + '('          
                            + LTRIM(RTRIM(@AgreementNo)) + ')'              
               
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                  APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
               BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              SupplierEmployeeId ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              CONVERT(VARCHAR(10), @LastDateOfMonth, 101) , --@BusinessDate,              
                              @TaxAmountMainSupplierEmployeePersonal ,          
                              0 ,          
                              0 ,          
                              'TXPS' ,          
                              @KppName ,          
                              '-' , --@SupplierEmployeeAccountName,              
                              '-' , --@SupplierEmployeeAccountNo,              
                              '-' , --@SupplierEmployeeBankName ,              
                              '-' , --@SupplierEmployeeBankBranch,              
                              @MainSupplierID ,          
                              @MainSupplierEmployeeID ,          
                              @PaymentLocation ,          
                              @InvoiceNo ,          
                       @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
     END  
   ------------TAX SUPPLIER EMPLOYEE COMPANY-----------  
   --Add fuji,09122022 Perbaikan Bugs CR FMF-3546  
   IF @TaxAmountMainSupplierEmployeeCompany > 0  
   BEGIN    
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO exitSP              
              
                    SELECT  @Description = 'APTAX CO Suppl Emp '          
                            + LTRIM(RTRIM(@MainSupplierEmployeeName)) + '('          
                            + LTRIM(RTRIM(@AgreementNo)) + ')'              
               
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                  APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
               BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              SupplierEmployeeId ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              CONVERT(VARCHAR(10), @LastDateOfMonth, 101) , --@BusinessDate,              
                              @TaxAmountMainSupplierEmployeeCompany ,          
                              0 ,          
                              0 ,          
                              'TXCO' ,          
                              @KppName ,          
                              '-' , --@SupplierEmployeeAccountName,              
                              '-' , --@SupplierEmployeeAccountNo,              
                              '-' , --@SupplierEmployeeBankName ,              
                              '-' , --@SupplierEmployeeBankBranch,              
                              @MainSupplierID ,          
                              @MainSupplierEmployeeID ,          
                              @PaymentLocation ,          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                    )              
                    IF @@error <> 0          
                        GOTO ExitSP              
    END  
    --END FUJI  
          END                     
        END --dessy 21092012 : FMF CR IJON          
              
    IF @MainReferantor > 0          
        BEGIN              
            SELECT  @PaymentLocation = @BranchID              
              
 ------------------------------------------------------------------              
 -- Check A/P Limit for Branch based on setting at ProductOffering --              
 -- ratna 02/09 : ambil data dr tbl ProductOffering --              
 ------------------------------------------------------------------              
            IF @MainReferantor > ( SELECT   LimitAPCash          
                                   FROM     ProductOffering WITH ( NOLOCK )          
                                   WHERE    ( ProductOffering.BranchID = @BranchID )          
                                            AND ( ProductOffering.ProductID = @ProductID )          
             AND ( ProductOffering.ProductOfferingID = @ProductOfferingID )          
                                 )          
                BEGIN              
                    SELECT  @PaymentLocation = @KodeHO              
                END              
              
 ------------------------------------------------              
 -- Get SequenceNo from MasterSequence for A/P --              
 -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction              
 ------------------------------------------------              
            EXEC @error= spGetNoTransaction @BranchID, @BusinessDate, 'ACCPAY',          
                @AccountPayableNo OUTPUT              
            IF @error <> 0          
                GOTO exitSP              
              
 -----------------------------------------               
 -- Insert data to table AccountPayable --              
 -- ratna 02/09 : sesuaikan field2 dengan tbl AP sekarang               
 -----------------------------------------              
            SELECT  @Description = 'Incentive Referantor '          
                    + LTRIM(RTRIM(@AgreementNo)) + ' - ' + @CustomerName              
            INSERT  INTO AccountPayable          
                    ( BranchID ,          
                      AccountPayableNo ,          
                      ApplicationID ,          
                      APDate ,          
                      ReferenceNo ,          
                      Description ,          
                      DueDate ,          
                      APAmount ,          
                      APAmountInProcess ,          
                      PaidAmount ,          
                      APType ,          
                      APTo ,          
                      AccountNameTo ,          
                      AccountNoTo ,          
                      BankNameTo ,          
                      BankBranchTo ,          
                      PaymentLocation ,          
                      InvoiceNo ,          
                      InvoiceDate ,          
                      Status ,          
                      APStatusDate ,          
                      CurrencyID ,          
                      CurrencyRate               
                    )          
            VALUES  ( @BranchID ,          
                      @AccountPayableNo ,          
                      @ApplicationID ,          
                      @BusinessDate ,          
                      @AgreementNo ,          
                      @Description ,          
                      @BusinessDate ,          
                      @MainReferantor ,          
                      0 ,          
                      0 ,          
                      'INCE' ,          
                      ISNULL(@MainReferenceName,'-') ,          
                      ISNULL(@ReferenceAccountName,'-') ,          
                      ISNULL(@ReferenceAccountNo,'-') ,         
                      ISNULL(@ReferantorBankName,'-') ,          
                      ISNULL(@ReferenceBankBranch,'-') ,          
                      @KodeHO, --@PaymentLocation , --Victor, 25 Jan 2023 : (FMF-4071)        
                      @InvoiceNo ,          
                      @InvoiceDate ,          
                      'N' ,          
                      @BusinessDate ,          
                      @CurrencyID ,          
                      @CurrencyRate               
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
              
--===== Start Process Create AccountPayable Supplier Employee AP tax =======--              
              
            IF @TaxAmountReferantor > 0          
                BEGIN              
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO exitSP              
              
                    SELECT  @Description = 'APTAX Referantor '          
                            + LTRIM(RTRIM(@MainReferenceName)) + '('          
                            + LTRIM(RTRIM(@AgreementNo)) + ')'              
                    IF @ReferenceType = 'P'          
                        BEGIN               
                            SET @APTAXTYPE = 'TXPS'              
                        END              
                    IF @ReferenceType = 'C'          
                        BEGIN               
                            SET @APTAXTYPE = 'TXCO'              
                        END            
              
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                              APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,        
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              CONVERT(VARCHAR(10), @LastDateOfMonth, 101) , --@BusinessDate,              
                              @TaxAmountReferantor ,          
                              0 ,          
                              0 ,          
                              @APTAXTYPE ,          
                              @KppName ,          
                              '-' , --@SupplierAccountName,              
                              '-' , --@SupplierAccountNo,              
                              '-' , --@SupplierBankName,              
           '-' , --@SupplierBankBranch,              
                              @MainSupplierID ,          
                              @PaymentLocation ,          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END              
        END              
              
-- Johnson, 7 September 2005              
-- ambil data commision for another supplier              
    DECLARE @MinSeqNoOtherSup AS INT ,          
        @MaxSeqNoOtherSup AS INT              
              
    SELECT  @MinSeqNoOtherSup = MIN(SeqNo) ,          
            @MaxSeqNoOtherSup = MAX(SeqNo)          
    FROM    dbo.Commision WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND SeqNo > 1          
            AND ISNULL(Commision.SupplierEmployeeID, '') = ''               
              
              
    WHILE @MinSeqNoOtherSup < = @MaxSeqNoOtherSup          
        BEGIN              
    --edit fuji 27 jan 2023 (fmf-4017)  
            SELECT  @SupplierIncentive = CASE WHEN ISNULL(SupplierPPNAmount,0) > 0   
     THEN ISNULL(SupplierDPPAmount,0)+  
     ISNULL(SupplierPPNAmount,0)- SupplierTaxAmount else  
     SupplierInsuranceIncome          
                    + SupplierUppingBunga + SupplierOtherFee          
     + ISNULL(SupplierProvisionFee,0) --Aditia FMF-1640 12032018          
                    - SupplierTaxAmount end ,     
    --end fuji        
                    @SupplierIncentiveBankName = BM.BankName ,          
                    @SupplierIncentiveBankBranch = Commision.SupplierBankBranch ,          
                    @SupplierIncentiveAccountNo = Commision.SupplierAccountNo ,          
                 @SupplierIncentiveAccountName = Commision.SupplierAccountName ,          
                    @SupplierIncentiveName = SupplierName ,          
                    @SupplierIncentiveID = Commision.SupplierID ,          
                    @TaxAmountOtherSupplierCompany = SupplierTaxAmount          
            FROM    dbo.Commision WITH ( NOLOCK )          
                    INNER JOIN BankMaster BM WITH ( NOLOCK ) ON Commision.SupplierBankID = BM.BankID          
                 LEFT JOIN dbo.Supplier WITH ( NOLOCK ) ON dbo.Commision.SupplierID = dbo.Supplier.SupplierID          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID          
                    AND SeqNo = @MinSeqNoOtherSup          
                    AND ISNULL(Commision.SupplierEmployeeID, '') = ''               
                
                
            IF @SupplierIncentive > 0          
                BEGIN              
                    SELECT  @PaymentLocation = @BranchID              
                
   ------------------------------------------------------------------              
   -- Check A/P Limit for Branch based on setting at ProductOffering --              
   -- ratna 02/09 : ambil data dr tbl ProductOffering --              
   ------------------------------------------------------------------              
                    IF @SupplierIncentive > ( SELECT    LimitAPCash          
                                              FROM      ProductOffering WITH ( NOLOCK )          
                                              WHERE     ( ProductOffering.BranchID = @BranchID )          
                                                        AND ( ProductOffering.ProductID = @ProductID )          
                                                        AND ( ProductOffering.ProductOfferingID = @ProductOfferingID )          
                                            )          
                        BEGIN              
                            SELECT  @PaymentLocation = @KodeHO              
                        END              
                
  /* By Johnson 17 Mei 2005                
   ------------------------------------------------              
   -- Get SequenceNo from MasterSequence for A/P --              
   -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction              
   ------------------------------------------------              
   EXEC @error=spGetNoTransaction @BranchID, @BusinessDate, 'ACCPAY', @AccountPayableNo OUTPUT              
   if @error <> 0              
    goto exitSP              
                
   -----------------------------------------              
   -- Insert data to table AccountPayable --              
   -- ratna 02/09 : sesuaikan field2 dengan tbl AP sekarang              
   -----------------------------------------              
   SELECT @Description = 'Incentive Supplier ' + Ltrim(Rtrim(@AgreementNo)) + ' - ' + @CustomerName              
   INSERT INTO AccountPayable (              
    BranchID,              
    AccountPayableNo,              
    ApplicationID,              
    APDate,              
    ReferenceNo,              
    Description,              
    DueDate,              
    APAmount,              
    APAmountInProcess,              
    PaidAmount,              
    APType,              
    APTo,              
    AccountNameTo,              
    AccountNoTo,              
    BankNameTo,              
    BankBranchTo,              
    SupplierID,              
    PaymentLocation,              
    InvoiceNo,              
    InvoiceDate,              
    Status,              
    APStatusDate,              
    CurrencyID,              
    CurrencyRate               
   )              
   VALUES (              
    @BranchID,              
    @AccountPayableNo,              
    @ApplicationID,              
    @BusinessDate,              
    @AgreementNo,              
    @Description,              
    @APDueDate,              
    @SupplierIncentive,              
    0,              
    0,              
    'SPPL',              
    @SupplierIncentiveName,              
    @SupplierIncentiveAccountName,              
    @SupplierIncentiveAccountNo,              
    @SupplierIncentiveBankName,              
    @SupplierIncentiveBankBranch,              
    @SupplierID,              
    @PaymentLocation,              
    @InvoiceNo,              
    @InvoiceDate,              
    'N',              
    @BusinessDate,              
    @CurrencyID,              
    @CurrencyRate               
   )              
   if @@error <> 0 goto ExitSP              
  */              
                
  --===== Start Process Create AccountPayable Supplier AP tax =======--              
                
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
         'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO exitSP              
                
                    SELECT  @Description = 'AP TAX Supplier '          
                            + LTRIM(RTRIM(@AgreementNo)) + ' - '          
                            + @CustomerName              
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                              APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              @BusinessDate ,          
                              @TaxAmountOTHERSupplierCompany ,          
                              0 ,          
                              0 ,          
                              'TXCO' ,          
                              @SupplierIncentiveName ,          
                              @SupplierIncentiveAccountName ,          
                              @SupplierIncentiveAccountNo ,          
                              @SupplierIncentiveBankName ,          
                              @SupplierIncentiveBankBranch ,          
                              @SupplierIncentiveID , --@SupplierID,              
                              @PaymentLocation ,          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END              
            SET @MinSeqNoOtherSup = @MinSeqNoOtherSup + 1              
        END              
              
-- Johnson, 7 September 2005              
-- ambil data commision for another salesman              
    DECLARE @MinSeqNoOtherSupEmp AS INT ,          
        @MaxSeqNoOtherSupEmp AS INT              
              
    SELECT  @MinSeqNoOtherSupEmp = MIN(SeqNo) ,          
            @MaxSeqNoOtherSupEmp = MAX(SeqNo)          
    FROM    dbo.Commision WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND SeqNo > 1          
            AND ISNULL(Commision.SupplierEmployeeID, '') <> ''               
              
    WHILE @MinSeqNoOtherSupEmp < = @MaxSeqNoOtherSupEmp          
        BEGIN              
               
               
              
            SELECT  --Novia modify, 17062016 : FMF-1515          
     --@SupplierEmployeeIncentive = SupplierEmployeeInsuranceIncome          
     --               + SupplierEmployeeUppingBunga + SupplierEmployeeOtherFee          
     --               - SupplierEmployeeTaxAmount ,   
     --Edit fuji,jika ada VAT (fmf-4017)         
                    @SupplierEmployeeIncentive = case when ISNULL(SupplierEmployeePPnAmount,0) > 0 then  ISNULL(SupplierEmployeeDPPAmount,0) + ISNULL(SupplierEmployeePPnAmount,0) - SupplierEmployeeTaxAmount  
     else  
     SupplierEmployeeInsuranceIncome          
                    + SupplierEmployeeUppingBunga + SupplierEmployeeOtherFee          
      + ISNULL(SupplierEmployeeProvisionFee,0) --Aditia FMF-1640 12032018          
                    - ( CASE @CalculateTaxMethodSupllierEmp          
                          WHEN 'GR' THEN 0          
         WHEN 'NE' THEN SupplierEmployeeTaxAmount          
                          ELSE SupplierEmployeeTaxAmount          
                        END ) end ,          
     --Eo Novia, 17062016          
                    @SupplierCommisionEmployeeBankName = BMEmployee.BankName ,          
                    @SupplierEmployeeIncentiveBankBranch = Commision.SupplierEmployeeBankBranch ,          
                    @SupplierEmployeeIncentiveAccountNo = Commision.SupplierEmployeeAccountNo ,          
                    @SupplierEmployeeIncentiveAccountName = Commision.SupplierEmployeeAccountName ,          
                    @SupplierEmployeeIncentiveName = SupplierEmployeeName ,          
                    @SupplierEmployeeIncentiveID = Commision.SupplierEmployeeID ,          
                    @SupplierIncentiveID = Commision.SupplierID ,   
     --edit fuji,09122022 : Perbaiki Bugs CR FMF-3546         
                    @TaxAmountOtherSupplierEmployeePersonal =   
     (case when isnull(SupplierEmployee.SupplierEmployeeType,'P') ='P'  
      then SupplierEmployeeTaxAmount  
      else 0 end),  
      @TaxAmountOtherSupplierEmployeeCompany =   
     (case when isnull(SupplierEmployee.SupplierEmployeeType,'P') ='C'  
      then SupplierEmployeeTaxAmount  
      else 0 end)  
      --end edit fuji  
            FROM    dbo.Commision WITH ( NOLOCK )          
                    INNER JOIN BankMaster BMEmployee WITH ( NOLOCK ) ON Commision.SupplierEmployeeBankID = BMEmployee.BankID          
                    LEFT JOIN dbo.SupplierEmployee WITH ( NOLOCK ) ON dbo.Commision.SupplierID = dbo.SupplierEmployee.SupplierID          
                                                              AND dbo.Commision.SupplierEmployeeID = dbo.SupplierEmployee.SupplierEmployeeID          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID          
                    AND SeqNo = @MinSeqNoOtherSupEmp          
                    AND ISNULL(Commision.SupplierEmployeeID, '') <> ''    
        
                
  -- Untuk Other SupplierEmployee              
            IF @SupplierEmployeeIncentive > 0          
                BEGIN                   
                    SELECT  @PaymentLocation = @BranchID              
                
   ------------------------------------------------------------------              
   -- Check A/P Limit for Branch based on setting at ProductOffering --              
   -- ratna 02/09 : ambil data dr tbl ProductOffering --              
   ------------------------------------------------------------------              
                    IF @SupplierEmployeeIncentive > ( SELECT  LimitAPCash          
                                                      FROM    ProductOffering          
                                                              WITH ( NOLOCK )          
                                                      WHERE   ( ProductOffering.BranchID = @BranchID )          
                                                              AND ( ProductOffering.ProductID = @ProductID )          
                                                              AND ( ProductOffering.ProductOfferingID = @ProductOfferingID )          
                                                    )          
                        BEGIN              
                            SELECT  @PaymentLocation = @KodeHO              
                        END              
                
   ------------------------------------------------              
   -- Get SequenceNo from MasterSequence for A/P --              
   -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction              
   ------------------------------------------------              
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO exitSP     
   -----------------------------------------              
   -- Insert data to table AccountPayable --          
   -- ratna 02/09 : sesuaikan field2 dengan tbl AP sekarang               
   -----------------------------------------              
                    SELECT  @Description = 'Incentive Supplier Employee '          
                            + LTRIM(RTRIM(@AgreementNo)) + ' - '          
                            + @CustomerName              
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
           APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              SupplierEmployeeID ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              @BusinessDate ,          
                              @SupplierEmployeeIncentive ,          
                              0 ,          
                              0 ,          
                              'INCE' ,          
                              @SupplierEmployeeIncentiveName ,          
                              @SupplierEmployeeIncentiveAccountName ,          
                              @SupplierEmployeeIncentiveAccountNo ,          
                              @SupplierCommisionEmployeeBankName ,          
                              @SupplierEmployeeIncentiveBankBranch ,          
                              @SupplierIncentiveID , --@SupplierID,              
                              @SupplierEmployeeIncentiveID ,          
                              @KodeHO,--@PaymentLocation , --Victor, 25 Jan 2023 : (FMF-4071)          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
  --===== Start Process Create AccountPayable Supplier Employee AP tax =======--              
         ----------Other Supplier Employee AP Tax Personal-------------------  
    IF @TaxAmountOtherSupplierEmployeePersonal > 0  
    BEGIN      
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
 GOTO exitSP               
                
                    SELECT  @Description = 'APTAX P Suppl Emp '          
                            + LTRIM(RTRIM(@SupplierEmployeeIncentiveName))          
                            + '(' + LTRIM(RTRIM(@AgreementNo)) + ')'              
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                              APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              SupplierEmployeeId ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              CONVERT(VARCHAR(10), @LastDateOfMonth, 101) , -- @BusinessDate,              
                              @TaxAmountOtherSupplierEmployeePersonal ,          
                              0 ,          
                              0 ,          
                              'TXPS' ,          
                              @KppName ,          
                              '-' , --@SupplierEmployeeIncentiveAccountName,              
                              '-' , --@SupplierEmployeeIncentiveAccountNo,              
                              '-' , --@SupplierCommisionEmployeeBankName,              
                              '-' , --@SupplierEmployeeIncentiveBankBranch,              
                              @SupplierIncentiveID , --@SupplierID,              
                              @SupplierEmployeeIncentiveID ,          
                              @PaymentLocation ,          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
      IF @@error <> 0          
       GOTO ExitSP   
     END             
    --add fuji,09122022 Perbaiki Bugs CR fmf-3546  
   ----------Other Supplier Employee AP Tax Company-------------------  
    IF @TaxAmountOtherSupplierEmployeeCompany > 0  
    BEGIN      
                    EXEC @error= spGetNoTransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT              
                    IF @error <> 0          
                        GOTO exitSP               
                
                    SELECT  @Description = 'APTAX CO Suppl Emp '          
                            + LTRIM(RTRIM(@SupplierEmployeeIncentiveName))          
                            + '(' + LTRIM(RTRIM(@AgreementNo)) + ')'              
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                              APDate ,          
                              ReferenceNo ,          
                              Description ,          
                              DueDate ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              SupplierID ,          
                              SupplierEmployeeId ,          
                              PaymentLocation ,          
                              InvoiceNo ,          
                              InvoiceDate ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              CONVERT(VARCHAR(10), @LastDateOfMonth, 101) , -- @BusinessDate,              
                              @TaxAmountOtherSupplierEmployeeCompany ,          
                              0 ,          
                              0 ,          
                              'TXCO' ,          
                              @KppName ,          
                              '-' , --@SupplierEmployeeIncentiveAccountName,              
                              '-' , --@SupplierEmployeeIncentiveAccountNo,              
                              '-' , --@SupplierCommisionEmployeeBankName,              
                              '-' , --@SupplierEmployeeIncentiveBankBranch,              
                              @SupplierIncentiveID , --@SupplierID,              
                              @SupplierEmployeeIncentiveID ,          
                              @PaymentLocation ,          
                              @InvoiceNo ,          
                              @InvoiceDate ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
                            )              
      IF @@error <> 0          
       GOTO ExitSP   
     END             
    --end fuji  
                END               
            SET @MinSeqNoOtherSupEmp = @MinSeqNoOtherSupEmp + 1              
        END               
              
------------------------------------------------------------------------------------------------              
-- Process A/P to Insurance Company  --              
-- ratna 02/09 : hanya u/Asset Insurance              
-- Nilai AP diambil dr StdPremium + AdminFeeToCust + MeteraiFeeToCust              
------------------------------------------------------------------------------------------------           
          
    DECLARE @CoverPeriod CHAR(2) --Johan 2 Oct 2012          
           
 --Johan 2 Oct 2012, Add          
    DECLARE @AcquisitionCost NUMERIC(17, 2) ,          
        @SingleInsuranceRate CHAR(1)          
           
    SET @AcquisitionCost = 0           
          
    SELECT  @SingleInsuranceRate = SingleInsuranceRate          
    FROM    dbo.AgreementAsset WITH ( NOLOCK )          
            INNER JOIN dbo.AssetType WITH ( NOLOCK ) ON dbo.AgreementAsset.AssetTypeID = dbo.AssetType.AssetTypeID          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
 --End Johan 2 Oct 2012          
             
    IF EXISTS ( SELECT  InsuranceAsset.BranchID          
                FROM    InsuranceAsset WITH ( NOLOCK )          
                WHERE   ( InsuranceAsset.FlagInsStatus = 'A' )          
                        AND ( InsuranceAsset.PremiumAmountToInsCo          
                              + InsuranceAsset.AdminFee          
                              + InsuranceAsset.MeteraiFee > 0 )          
                        AND ( InsuranceAsset.BranchID = @BranchID )          
                        AND ( InsuranceAsset.ApplicationID = @ApplicationID ) )          
        BEGIN              
            SELECT  @InsuranceCoyID = InsuranceAsset.InsuranceCoyID ,          
                    @InsuranceCoyBranchID = InsuranceAsset.InsuranceCoyBranchID ,          
                    @PremiumAmountToInsCo = InsuranceAsset.PremiumAmountToInsCo ,          
                    @AdminFeeToInsCo = InsuranceAsset.AdminFee ,          
                   @MeteraiFeeToInsCo = InsuranceAsset.MeteraiFee ,          
                    @BankName = ISNULL(InsuranceCoyBranch.BankName, '-') ,          
                    @BankBranch = ISNULL(InsuranceCoyBranch.BankBranch, '-') ,          
                    @AccountName = ISNULL(InsuranceCoyBranch.AccountName, '-') ,          
                    @AccountNo = ISNULL(InsuranceCoyBranch.AccountNo, '-') ,          
                    @APTo = ISNULL(InsuranceCoyBranch.InsuranceCoyBranchName,          
                                   '-') ,          
       @AccountGL = ISNULL(InsuranceCoyBranch.AccountGL, '-') ,          
                    @CoverPeriod = InsuranceAsset.CoverPeriod , --Johan 2 Oct 2012          
                    @AcquisitionCost = ISNULL(InsuranceAsset.AcquisitionCost,          
                                              0)  --Johan 2 Oct 2012          
            FROM    InsuranceAsset WITH ( NOLOCK )          
                    LEFT JOIN InsuranceCoyBranch WITH ( NOLOCK ) ON ( InsuranceAsset.InsuranceCoyId = InsuranceCoyBranch.InsuranceCoyID )          
                                                              AND ( InsuranceAsset.InsuranceCoyBranchID = InsuranceCoyBranch.InsuranceCoyBranchID )          
                                                              AND ( InsuranceAsset.BranchId = InsuranceCoyBranch.BranchID )          
            WHERE   ( InsuranceAsset.FlagInsStatus = 'A' )          
                    AND ( InsuranceAsset.PremiumAmountToInsCo          
                          + InsuranceAsset.AdminFee          
                          + InsuranceAsset.MeteraiFee > 0 )          
                    AND ( InsuranceAsset.BranchID = @BranchID )          
                    AND ( InsuranceAsset.ApplicationID = @ApplicationID )              
              
 ------------------------------------------------              
 -- Get SequenceNo from MasterSequence for A/P --              
 -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction     ------------------------------------------------              
            EXEC @error = spGetNoTransaction @BranchID, @BusinessDate,          
                'ACCPAY', @AccountPayableNo OUTPUT              
            IF @error <> 0          
                GOTO exitsp              
              
 -----------------------------------------              
 -- Insert data to table AccountPayable --              
 -- ratna 02/09 : tbl AccountPayable disesuaikan dgn TFS              
 -----------------------------------------              
              
    --added by Johan 12 Mar 2014          
          IF @SingleInsuranceRate <> '1'          
                BEGIN          
  SET @AcquisitionCost = 0          
                END            
   --End Johan          
              
    --Johan 2 Oct 2012 Pecah AP saat GoLive          
            DECLARE @IsAPToInscoAnually BIT          
            SET @IsAPToInscoAnually = ( SELECT  IsAPToInscoAnually          
                                        FROM    InsuranceCoyHo          
                                        WHERE   InsuranceCoyId = @InsuranceCoyID          
                                      )          
          
            IF ( @IsAPToInscoAnually = 1          
                 AND @CoverPeriod = 'FT'          
               )          
                BEGIN          
                    EXEC spCalculateInsuranceAsset @BranchID, @ApplicationID          
          
    --Remark by Johan 28 May 2014          
    --IF @SingleInsuranceRate = 0          
    --BEGIN          
     --EXEC spCalculateInsuranceAsset @BranchID, @ApplicationID          
    --END          
              
    --ELSE          
    --BEGIN          
    --  CREATE TABLE #TempIAD          
    --  (          
    --    SeqNo INT IDENTITY ,          
    --    YearNum INT ,          
    --    PremiumToInscoAmount NUMERIC(17, 2),          
                   
    --  )          
          
    --  INSERT INTO #TempIAD          
    --   ( YearNum ,          
    --     PremiumToInscoAmount          
    --   )          
    --   SELECT  YearNum ,          
    --     SUM(PremiumToInscoAmount)          
    --   FROM    InsuranceAssetDetail          
    --   WHERE   BranchID = @BranchID          
    --     AND ApplicationID = @ApplicationID          
    --   GROUP BY YearNum          
          
    --  DECLARE          
    --  @PremiumToInscoAmount NUMERIC(17, 2) ,          
    --  @z INT ,          
    --  @APToInscoAmount NUMERIC(17, 2),          
    --  @APDate DATETIME,          
    --  @InsSeqNoBilling INT          
                
    --  SET @InsSeqNoBilling = (SELECT MAX(InsSequenceNo) FROM dbo.InsuranceAsset WHERE ApplicationID = @ApplicationID AND BranchID = @BranchID)          
    --  SET @APDate = @BusinessDate          
    --  SET @z = 1          
          
    --  WHILE @z <= ( SELECT   COUNT(1)          
    --       FROM     #TempIAD          
    --     )           
    --  BEGIN          
          
    --   SET @YearNum = 0          
    --   SET @APToInscoAmount = 0          
          
    --   SELECT  @YearNum = YearNum ,          
    --     @PremiumToInscoAmount = PremiumToInscoAmount          
    --   FROM    #TempIAD          
    --   WHERE   SeqNo = @z          
          
    --   SELECT  @YearNum AS YearNum ,          
    --     @PremiumToInscoAmount AS PremiumToInscoAmount          
          
    --   IF @YearNum = 1           
    --    BEGIN          
    --     SET @APToInscoAmount = @PremiumToInscoAmount          
    --      + @AdminFeeToInsCo + @MeteraiFeeToInsCo          
    --      - @AcquisitionCost --johan 14 mar          
    --    END          
    --   ELSE           
    --    BEGIN          
    --     SET @APDate = DATEADD(YEAR, 1, @APDate)          
    --     SET @APToInscoAmount = @PremiumToInscoAmount           
    --    END          
          
    --   IF @APToInscoAmount > 0           
    --    BEGIN          
          
    --       ------------------------------------------------              
    --       -- Get SequenceNo from MasterSequence for A/P --              
    --       -- Toby, 20100408: Generate APNo skrg pakai spGetNoTransaction     ------------------------------------------------              
    --     EXEC @error = spGetNoTransaction @BranchID, @BusinessDate,          
    --      'ACCPAY', @AccountPayableNo OUTPUT              
    --     IF @error <> 0           
    --      GOTO exitsp              
                     
    --       --Novia add, 18022014          
    --     IF @SingleInsuranceRate <> '1' --@AssetTypeID <> '1'  --Novia modify,22022014          
    --      BEGIN          
    --       SET @AcquisitionCost = 0          
    --      END            
    --       --Eo Novia          
          
    --       -----------------------------------------              
    --       -- Insert data to table AccountPayable --              
    --       -----------------------------------------              
    --     SELECT  @Description = 'AP To Insurance Co '          
    --       + LTRIM(RTRIM(@AgreementNo)) + ' - '          
    --       + @CustomerName + ' - YearNum '          
    --       + CONVERT(VARCHAR(2), @YearNum)          
    --     INSERT  INTO AccountPayable          
    --       ( BranchID ,          
    --         AccountPayableNo ,          
    --         ApplicationID ,          
    --         APDate ,          
    --         ReferenceNo ,          
    --         Description ,          
    --         APAmount ,          
    --         APAmountInProcess ,          
    --         PaidAmount ,          
    --         APType ,          
    --         APTo ,          
    --         AccountNameTo ,          
    --         AccountNoTo ,          
    --         BankNameTo ,          
    --         BankBranchTo ,          
    --         InsuranceBranchID ,          
    --         PaymentLocation ,          
    --         Status ,          
    --         APStatusDate ,          
    --         CurrencyID ,          
    --         CurrencyRate            
                     
    --       )          
    --     VALUES  ( @BranchID ,          
    --         @AccountPayableNo ,          
    --         @ApplicationID ,          
    --         @APDate ,          
    --         @AgreementNo ,          
    --         @Description ,          
    --         @APToInscoAmount , --Novia modify 18022014, AP dikurangi dengan @AcquisitionCost --johan 14 Mar          
    --         0 ,          
    --         0 ,          
    --         'INSR' ,          
    --         @APTo ,          
    --         @AccountName ,          
    --         @AccountNo ,          
    --         @BankName ,          
    --         @BankBranch ,          
    --         @InsuranceCoyBranchID ,          
    --         @KodeHO ,          
    --         'N' ,          
    --         @BusinessDate ,          
    --         @CurrencyID ,          
    --         @CurrencyRate               
                     
    --       )              
    --     IF @@error <> 0           
    --      GOTO ExitSP              
          
    --     --modified by Johan 14 Mar 2014          
    --     INSERT INTO dbo.InsuranceAssetBilling          
    --     (          
    --      BranchID ,          
    --      ApplicationID ,          
    --      InsSequenceNo ,          
    --      YearNum ,          
    --      AccountPayableNo ,          
    --      StartDate ,          
    --      EndDate ,          
    --      UsrUpd ,          
    --      DtmUpd          
    --     )          
    --     VALUES          
    --     (          
    --      @BranchID,          
    --      @ApplicationID,          
    --      @InsSeqNoBilling,          
    --      @z ,          
    --      @AccountPayableNo ,          
    --      NULL,          
    --      NULL,          
    --      SYSTEM_USER,          
    --      GETDATE()          
    --     )          
                   
    --     --UPDATE  dbo.InsuranceAssetBilling          
    --     --SET     AccountPayableNo = @AccountPayableNo          
    --     --WHERE   BranchID = @BranchID          
    --     --  AND ApplicationID = @ApplicationID          
    --     --  AND YearNum = @YearNum              
    --     --IF @@error <> 0           
    --     -- GOTO ExitSP          
    --     --End Johan          
          
    --    END          
          
    --   SET @z = @z + 1          
    --  END          
          
    --  DROP TABLE #TempIAD             
    --END          
    --End Remark          
                END          
             
            ELSE          
                BEGIN          
                    SELECT  @Description = 'AP To Insurance Co '          
                            + LTRIM(RTRIM(@AgreementNo)) + ' - '          
                            + @CustomerName              
                    INSERT  INTO AccountPayable          
                            ( BranchID ,          
                              AccountPayableNo ,          
                              ApplicationID ,          
                              APDate ,          
                              ReferenceNo ,          
                 Description ,          
                              APAmount ,          
                              APAmountInProcess ,          
                              PaidAmount ,          
                              APType ,          
                              APTo ,          
                              AccountNameTo ,          
                              AccountNoTo ,          
                              BankNameTo ,          
                              BankBranchTo ,          
                              InsuranceBranchID ,          
                              PaymentLocation ,          
                              Status ,          
                              APStatusDate ,          
                              CurrencyID ,          
                              CurrencyRate               
          )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              @PremiumAmountToInsCo + @AdminFeeToInsCo          
                              + @MeteraiFeeToInsCo - @AcquisitionCost , --modified by Johan 12 Mar 2014          
                              0 ,          
                              0 ,          
                              'INSR' ,          
                              @APTo ,          
                              @AccountName ,          
                              @AccountNo ,          
                              @BankName ,          
                              @BankBranch ,          
                              @InsuranceCoyBranchID ,          
                              @KodeHO ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate               
          )              
                    IF @@error <> 0          
                        GOTO ExitSP          
               
   -----------------------------------------------------              
   -- Update AccountPayableNo at table InsuranceAsset --              
   -- ratna 02/09 : tambah key BranchID waktu Update              
   -----------------------------------------------------              
                    UPDATE  InsuranceAsset          
                    SET     AccountPayableNo = @AccountPayableNo          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )              
                    IF @@error <> 0          
                        GOTO ExitSP             
               
                END             
        END              
              
              
              
------------------------------------------------------------------------------------------------              
-- Process A/P to Life Insurance Company  --              
-- Emilia  9/2/'06 : hanya u/Life Insurance              
-- Nilai AP diambil dr StdPremium + AdminFeeToCust + MeteraiFeeToCust              
------------------------------------------------------------------------------------------------              
    --Benny Remark 15 juni 2015, FMF-1422 Life Insurace          
 /*          
 IF EXISTS ( SELECT  LifeInsuranceAgreement.BranchID          
                FROM    LifeInsuranceAgreement WITH ( NOLOCK )          
                WHERE   ( LifeInsuranceAgreement.FlagInsStatus = 'A' )          
                        AND ( LifeInsuranceAgreement.PremiumToInsCo          
                              + LifeInsuranceAgreement.AdminFee          
                              + LifeInsuranceAgreement.StampDutyFee > 0 )          
                        AND ( LifeInsuranceAgreement.BranchID = @BranchID )          
                        AND ( LifeInsuranceAgreement.ApplicationID = @ApplicationID ) )           
        BEGIN              
            SELECT  @LifeInsuranceCoyID = LifeInsuranceAgreement.LifeInsuranceCoyID,          
                    @InsuranceCoyBranchID = LifeInsuranceAgreement.LifeInsuranceCoyBranchID,          
                    @PremiumAmountToInsCo = LifeInsuranceAgreement.PremiumToInsCo,          
                    @LifeAdminFee = LifeInsuranceAgreement.AdminFee,          
                    @LifeStampDutyFee = LifeInsuranceAgreement.StampDutyFee,          
                    @BankID = ISNULL(LifeInsuranceCoyBranch.BankID, '-'),          
                    @BankBranch = ISNULL(LifeInsuranceCoyBranch.BankBranch,          
                                         '-'),          
                    @AccountName = ISNULL(LifeInsuranceCoyBranch.AccountName,          
                                          '-'),          
                    @AccountNo = ISNULL(LifeInsuranceCoyBranch.AccountNo, '-'),          
                    @APTo = ISNULL(LifeInsuranceCoyBranch.LifeInsuranceCoyBranchName,          
                                   '-'),          
                    @AccountGL = ISNULL(LifeInsuranceCoyBranch.AccountGL, '-')          
            FROM    LifeInsuranceAgreement WITH ( NOLOCK )          
                    LEFT JOIN LifeInsuranceCoyBranch WITH ( NOLOCK ) ON ( LifeInsuranceAgreement.LifeInsuranceCoyId = LifeInsuranceCoyBranch.LifeInsuranceCoyId )          
                                                                        AND ( LifeInsuranceAgreement.LifeInsuranceCoyBranchID = LifeInsuranceCoyBranch.LifeInsuranceCoyBranchID )          
                                                                        AND ( LifeInsuranceAgreement.BranchId = LifeInsuranceCoyBranch.BranchID )          
            WHERE   ( LifeInsuranceAgreement.FlagInsStatus = 'A' )          
                    AND ( LifeInsuranceAgreement.PremiumToInsCo          
                          + LifeInsuranceAgreement.AdminFee          
                          + LifeInsuranceAgreement.StampDutyFee > 0 )          
                    AND ( LifeInsuranceAgreement.BranchID = @BranchID )          
                    AND ( LifeInsuranceAgreement.ApplicationID = @ApplicationID )              
              
 ------------------------------------------------              
 -- Get SequenceNo from MasterSequence for A/P --              
 -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction              
 ------------------------------------------------              
            EXEC @error = spGetNoTransaction @BranchID, @BusinessDate,          
                'ACCPAY', @AccountPayableNo OUTPUT              
            IF @error <> 0           
                BEGIN              
                
                    GOTO exitsp              
                END              
               
 -----------------------------------------              
 -- Insert data to table AccountPayable --              
 -- ratna 02/09 : tbl AccountPayable disesuaikan dgn TFS              
 -----------------------------------------              
            SELECT  @Description = 'AP To Life Insurance Co '          
                    + LTRIM(RTRIM(@AgreementNo)) + ' - ' + @CustomerName              
              
            INSERT  INTO AccountPayable          
                    (          
                      BranchID,          
                      AccountPayableNo,                                ApplicationID,          
                      APDate,          
                      ReferenceNo,          
                      Description,          
                      APAmount,          
                      APAmountInProcess,          
                      PaidAmount,          
                      APType,          
                      APTo,          
                      AccountNameTo,          
                      AccountNoTo,          
                      BankNameTo,          
                      BankBranchTo,          
                      InsuranceBranchID,          
                      PaymentLocation,          
                      Status,          
                      APStatusDate,          
                      CurrencyID,          
                      CurrencyRate               
                    )          
            VALUES  (          
                      @BranchID,          
                      @AccountPayableNo,          
                      @ApplicationID,          
            @BusinessDate,          
                      @AgreementNo,          
                      @Description,          
                      @PremiumToInsCo + @LifeAdminFee + @LifeStampDutyfee,          
                      0,          
                      0,          
                      'LIFE',          
                      @APTo,          
                      @AccountName,          
                      @AccountNo,          
                      @BankName,          
                      @BankBranch,          
                      @InsuranceCoyBranchID,          
                      @KodeHO,          
                      'N',          
                      @BusinessDate,          
                      @CurrencyID,          
                      @CurrencyRate               
                    )              
              
               
            IF @@error <> 0           
                GOTO ExitSP              
               
 -----------------------------------------------------              
 -- Update AccountPayableNo at table InsuranceAsset --              
 -- ratna 02/09 : tambah key BranchID waktu Update              
 -----------------------------------------------------              
            UPDATE  LifeInsuranceAgreement          
            SET     AccountPayableNo = @AccountPayableNo          
            WHERE   ( BranchID = @BranchID )          
                AND ( ApplicationID = @ApplicationID )              
            IF @@error <> 0           
                GOTO ExitSP              
        END              
   */ -- End Benny - Remark          
   ---Add Benny 15 juni 2015 - FMF-1422 LifeInsurance          
    DECLARE @isLifeInsurance VARCHAR(3) ,          
        @AccountGLLifeIns ShortDescription ,          
        @BankNameLIFEINS Name          
          
    SELECT  @isLifeInsurance = IsLifeInsurance          
    FROM    dbo.Agreement WITH ( NOLOCK )          
    WHERE   branchid = @BranchID          
            AND applicationid = @ApplicationID                  
          
    IF @isLifeInsurance = 1          
        BEGIN                          
 --Benny, 15 Juni 2015  : Pindahan dari Atas                      
            SELECT  @LifeInsuranceCoyID = LifeInsuranceHeader.LifeInsuranceCoyID ,          
                    @LifeInsuranceCoyBranchID = LifeInsuranceHeader.LifeInsuranceCoyBranchID ,          
                    @PAidBy = LifeInsuranceHeader.InsurancePaidBy ,          
                    @Premium = LifeInsuranceHeader.PremiumAmountToCust ,          
     --@AdjustedPremi = isnull(LifeInsuranceHeader.AdjustedPremi,0), --Erik S, Apr 3 2014          
                    @LifeAdminFee = 0 ,          
                    @LifeStampDutyFee = 0 ,          
                    @Insuredby = LifeInsuranceHeader.InsuredBy ,          
                    @PremiumToInsCo = LifeInsuranceHeader.MainPremiumToInsCo ,          
                    @BankID = ISNULL(lifeinsurancecoybranch.bankid, '-') ,          
                    @BankBranch = ISNULL(lifeinsurancecoybranch.bankbranch,          
                                         '-') ,          
                    @AccountName = ISNULL(lifeinsurancecoybranch.accountname,          
                                          '-') ,          
                    @AccountNo = ISNULL(lifeinsurancecoybranch.accountno, '-') ,          
                    @APTo = ISNULL(lifeinsurancecoybranch.lifeinsurancecoybranchname,          
                                   '-') ,          
                    @AccountGLLifeIns = ISNULL(lifeinsurancecoybranch.accountgl,          
                                               '-') ,          
                    @BankNameLIFEINS = ISNULL(bankmaster.BankName, '-')          
            FROM    LifeInsuranceHeader WITH ( NOLOCK )          
                    LEFT JOIN lifeinsurancecoybranch WITH ( NOLOCK ) ON ( LifeInsuranceHeader.lifeinsurancecoyid = lifeinsurancecoybranch.lifeinsurancecoyid )          
                                                              AND ( LifeInsuranceHeader.lifeinsurancecoybranchid = lifeinsurancecoybranch.lifeinsurancecoybranchid )          
                                                              AND ( LifeInsuranceHeader.branchid = lifeinsurancecoybranch.branchid )          
                    LEFT JOIN bankmaster WITH ( NOLOCK ) ON lifeinsurancecoybranch.BankID = bankmaster.BankID          
            WHERE   ( LifeInsuranceHeader.branchid = @BranchID )          
                    AND ( LifeInsuranceHeader.applicationid = @ApplicationID )          
                    AND LifeInsuranceHeader.flaginsstatus = 'N'                         
             
   --Benny add, 15062015 fmf-1422          
            DECLARE @LifeInsuranceIncome NUMERIC(17, 2)          
            SET @LifeInsuranceIncome = 0          
                  
            SELECT  @isLifeInsurance = IsLifeInsurance          
            FROM    dbo.Agreement WITH ( NOLOCK )          
            WHERE   branchid = @BranchID          
                    AND applicationid = @ApplicationID                  
                  
            IF @PaidBy = 'CU'          
                AND @InsuredBy = 'CO'          
                BEGIN          
                    SET @LifeInsuranceIncome = ( @Premium + @LifeAdminFee          
                                                 + @LifeStampDutyFee )          
                        - ( @PremiumToInsCo + @LifeAdminFee          
                            + @LifeStampDutyFee )          
                END             
             
     --Eo Benny, 15062015          
          
          
            IF ISNULL(@PremiumToInsCo, 0) <> 0          
                BEGIN                      
          
   ------------------------------------------------                          
      -- Get SequenceNo from MasterSequence for A/P --                          
      -- ratna 02/09 : Generate APNo skrg pakai spGetNoTransaction                          
      ------------------------------------------------                      
                    EXEC @error = spgetnotransaction @BranchID, @BusinessDate,          
                        'ACCPAY', @AccountPayableNo OUTPUT                      
          
                    IF @error <> 0          
                        BEGIN                      
                            GOTO exitsp                      
                        END                      
          
      -----------------------------------------                          
      -- Insert data to table AccountPayable --                          
      -- ratna 02/09 : tbl AccountPayable disesuaikan dgn TFS                          
      -----------------------------------------                      
                    SELECT  @Description = 'AP To Life Insurance Co '          
                            + LTRIM(RTRIM(@AgreementNo)) + ' - '          
                            + @CustomerName          
          
                    INSERT  INTO accountpayable          
                            ( branchid ,          
                              accountpayableno ,          
                              applicationid ,          
                              apdate ,          
                              referenceno ,          
                              description ,          
                              apamount ,          
                              apamountinprocess ,          
        paidamount ,          
                              aptype ,          
                              apto ,          
                              accountnameto ,          
                              accountnoto ,          
                              banknameto ,          
                              bankbranchto ,          
                              insurancebranchid ,          
                              paymentlocation ,          
                              status ,          
                              apstatusdate ,          
              currencyid ,          
                              currencyrate                      
                            )          
                    VALUES  ( @BranchID ,          
                              @AccountPayableNo ,          
                              @ApplicationID ,          
                              @BusinessDate ,          
                              @AgreementNo ,          
                              @Description ,          
                              @PremiumToInsCo + @LifeAdminFee          
                              + @LifeStampDutyfee , --@PremiumToInsCo ,          
                              0 ,          
                              0 ,          
                              'LIFE' ,          
                              @APTo ,          
                              @AccountName ,          
                              @AccountNo ,          
                              @BankNameLIFEINS ,          
                              @BankBranch ,          
                              @LifeInsuranceCoyBranchID , --@InsuranceCoyBranchID ,          
                              @KodeHO ,          
                              'N' ,          
                              @BusinessDate ,          
                              @CurrencyID ,          
                              @CurrencyRate                      
                            )                      
                    IF @@ERROR <> 0          
                        GOTO exitsp                              
      -----------------------------------------------------                          
      -- Update AccountPayableNo at table InsuranceAsset --                          
      -- ratna 02/09 : tambah key BranchID waktu Update                          
      -----------------------------------------------------                      
                    UPDATE  LifeInsuranceHeader          
            SET     AccountPayableNo = @AccountPayableNo          
                    WHERE   branchid = @BranchID          
                            AND applicationid = @ApplicationID                      
          
                    IF @@ERROR <> 0          
                        GOTO exitsp                      
          
          
                END --End IF ISNULL(@PremiumToInsCo, 0) <> 0                      
        END                 
 --End Benny, 15 juni 2015                            
              
              
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : Create Temp Table              
-------------------------------------------------------------------------------              
    CREATE TABLE #TempTable          
        (          
          SeqNo INT IDENTITY(1, 1)          
                    PRIMARY KEY ,          
          PaymentAllocationID CHAR(20) ,          
          Post CHAR(1) ,          
          Amount NUMERIC(17, 2) ,          
          RefDesc VARCHAR(50) ,          
          DepartementID VARCHAR(3) ,          
          VoucherDesc VARCHAR(50)          
        )              
              
    SELECT  @CtrNo = 1              
              
-------------------------------------------------------------------------------              
-- Journal --              
-- u/Leasing              
-- ratna 17/12 : RESIDUAL dan SECDEPOSIT              
-- nilai diambil dari tbl Agreement.DownPayment              
-------------------------------------------------------------------------------              
    SELECT  @ProductType = ProductType ,          
            @NormalType = NormalType          
    FROM    ProductOffering WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ProductID = @ProductID          
            AND ProductOfferingID = @ProductOfferingID              
               
    IF @ProductType = 'LS'          
        BEGIN              
       IF @DownPayment > 0          
                BEGIN              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
        Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'RESIDUAL' ,          
                              'D' ,          
                              @DownPayment ,          
                              @AgreementNo ,          
                              '-'              
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'SECDEPOSIT' ,          
                              'C' ,          
                              @DownPayment ,          
                              @AgreementNo ,          
                              '-'              
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END              
        END           
            
--arinta, 28 des 2015, fmf-1465          
    IF @ProductType = 'LS'          
        AND @NormalType = 'LB'          
        BEGIN              
            IF @TotalOTR > 0          
                BEGIN              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                         VoucherDesc               
                            )          
                    VALUES  ( 'FIXASSETB' ,          
                              'D' ,          
                              @TotalOTR ,          
                @AgreementNo ,          
                              '-'              
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'FIXASSETS' ,          
                   'C' ,          
                              @TotalOTR ,          
                              @AgreementNo ,          
                              '-'              
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END              
        END                 
 --end arinta          
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : PREPAID              
-------------------------------------------------------------------------------              
--Johnson, 15 Juli 2005 nilai Yang Di Update Dari @TDPAmount              
--IF @ContractPrepaidAmount > 0              
    IF @TDPAmount > 0          
        BEGIN              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'PREPAID' ,          
                      'D' ,          
                      @TDPAmount  ,            
  --@ContractPrepaidAmount,              
                      @AgreementNo ,          
                      '-'          
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END     
  
--edit fuji,07122022 (fmf-3885)  
IF @DepositAmount > 0  
BEGIN  
  --Vincenza FMF-2420 18112020    
  IF @InterestRate > 0 and @IsFactoring = 1    
  BEGIN              
    INSERT  INTO #TempTable          
      ( PaymentAllocationID ,          
        Post ,          
        Amount ,          
        RefDesc ,          
        VoucherDesc               
      )          
    VALUES  ( 'PREPAID' ,          
        'C' ,          
        @InterestRate + @DepositAmount  ,      
        @AgreementNo ,          
        '-'          
      )              
    IF @@error <> 0          
     GOTO ExitSP              
  END     
 --end Vincenza  
 --Add fuji,07122022 (fmf-3885)  
   ELSE   
  BEGIN  
   INSERT  INTO #TempTable          
      ( PaymentAllocationID ,          
        Post ,          
        Amount ,          
        RefDesc ,          
        VoucherDesc               
      )          
    VALUES  ( 'PREPAID' ,          
        'C' ,          
        @DepositAmount  ,      
        @AgreementNo ,          
        '-'          
      )              
    IF @@error <> 0          
     GOTO ExitSP          
  END     
 --END FUJI         
END  
--Add Fuji,18012023 (FMF-4114)  
ELSE IF @DepositAmount <= 0  
BEGIN  
  --Vincenza FMF-2420 18112020    
  IF @InterestRate > 0 and @IsFactoring = 1    
  BEGIN              
    INSERT  INTO #TempTable          
      ( PaymentAllocationID ,          
        Post ,          
        Amount ,          
        RefDesc ,          
        VoucherDesc               
      )          
    VALUES  ( 'PREPAID' ,          
        'C' ,          
        @InterestRate,      
        @AgreementNo ,          
        '-'          
      )              
    IF @@error <> 0          
     GOTO ExitSP              
  END     
 --end Vincenza  
END  
--end fuji,18012023 (FMF-4114)          
  
-------------------------------------------------------------------------------              
-- Journal Take Over Amount--              
-- Fuji,08032023 : TAOVERAMT (FMF-4127)             
-------------------------------------------------------------------------------   
IF @TakeOverAmount > 0  
BEGIN  
 INSERT  INTO #TempTable          
    ( PaymentAllocationID ,          
     Post ,          
     Amount ,          
     RefDesc ,          
     VoucherDesc               
    )          
  VALUES  ( 'TAOVERAMT' ,          
     'C' ,          
     @TakeOverAmount ,      
     @AgreementNo ,          
     '-'          
    )              
  IF @@error <> 0          
   GOTO ExitSP          
END     
  
--end fuji,08032023 (fmf-4127)  
  
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : ARGROSS              
-------------------------------------------------------------------------------              
-------------------------------------------------------------------------------              
-- Hitung Total Interest dr tbl Installment Schedule --              
-- ratna 05/09 : ARGROSS              
-- widi 22/09/2004 : didapat dari total Installment Amount dikurangi Advance Installment              
--Leonita 30 Agustus 2007 update funding coy portion untuk table installmentschedule              
-------------------------------------------------------------------------------              
            
---------------------------------------------------------------------------------------------------------------------------              
-- remark by Lisa 20071018 : Adjust dengan KITAF : Hitung FundingCoyPortion Menggunakan generateFundingCoyPortionJFCHN            
---------------------------------------------------------------------------------------------------------------------------            
--declare @CoyPortion rate,               
--  @IsInsAssetCapitalized int,              
--  @TotPrincipal numeric (17,2),              
--  @FirstAmount numeric              
--              
--set @CoyPortion = 0               
--              
--              
--SELECT @CoyPortion = FundingCoyPortion,               
--  @IsInsAssetCapitalized = FundingContract.IsInsAssetCapitalized              
--from agreement with(nolock)              
--JOIN FundingContract with(nolock) ON agreement.FundingCoyID = FundingContract.FundingCoyID  and               
--      agreement.FundingContractID = FundingContract.FundingContractNo              
--WHERE FundingContract.FacilityKind IN ('CHANN','JFINC') and               
--  FundingContract.FlagCS = 'B' and              
--  FundingContract.BalanceSheetStatus = 'F' and              
--  Agreement.BranchID = @BranchID and              
--  Agreement.ApplicationID = @applicationID              
--              
--if @IsInsAssetCapitalized = 0              
--BEGIN              
-- select @TotPrincipal=sum(PrincipalAmount) FROM InstallmentSchedule with(nolock) where BranchID=@BranchID and ApplicationID=@applicationID              
--              
-- declare @CoyPortionOld rate,              
--   @a numeric (17,2),              
--   @b numeric (17,2)              
-- set @CoyPortionOld = @CoyPortion              
--               
-- if @FirstInstallment = 'AD'              
-- BEGIN              
--  SELECT @FirstAmount = PrincipalAmount FROM InstallmentSchedule with(nolock) where BranchID=@BranchID and ApplicationID=@applicationID and InsSeqNo = 1              
--  set @a = (@TotPrincipal-@insassetcapitalized-@FirstAmount) * @CoyPortionOld/100              
--  SET @CoyPortion = @a/(@TotPrincipal-@FirstAmount)*100              
-- END              
-- ELSE              
-- BEGIN              
--  set @a = (@TotPrincipal-@insassetcapitalized) * @CoyPortionOld/100              
--  SET @CoyPortion = @a/@TotPrincipal*100              
-- END              
--END              
-- print  @CoyPortion            
            
            
    DECLARE @CoyPortion rate            
    SET @CoyPortion = 0            
            
    IF EXISTS ( SELECT  ''          
                FROM    agreement WITH ( NOLOCK )          
                        JOIN FundingContract WITH ( NOLOCK ) ON agreement.FundingCoyID = FundingContract.FundingCoyID          
                                                              AND agreement.FundingContractID = FundingContract.FundingContractNo          
                WHERE   FundingContract.FacilityKind IN ( 'CHANN', 'JFINC' )          
                        AND             
   --FundingContract.FlagCS = 'B' and            
                        FundingContract.BalanceSheetStatus = 'F'          
          AND Agreement.BranchID = @BranchID                                AND Agreement.ApplicationID = @applicationID )          
        BEGIN            
            
            EXECUTE @Error = generateFundingCoyPortionJFCHN @BranchId,          
                @ApplicationId, '-', '-', '-', @CoyPortion OUTPUT          
            --PRINT @CoyPortion          
            IF @Error <> 0          
                GOTO ExitSP            
            
        END            
            
--End Lisa 20071018 : Hitung FundingCoyPortion Menggunakan generateFundingCoyPortionJFCHN            
--------------------------------------------------------------------------------------------------------------------            
            
            
--End leonita 30 Agustus 2007              
              
-------------------------------------------------------------------------------              
-- ADD By Gema, 25 September 2007 : Tambah perhitungan CoyPortion untuk ARGROSS (dari Tendi)              
-- Hitung Total Interest dr tbl Installment Schedule --              
-- ARGROSS              
-- didapat dari total Installment Amount dikurangi Advance Installment              
-------------------------------------------------------------------------------              
    SELECT  @ARGross = SUM(InstallmentAmount)          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND InsSeqNo > @NumofAdvanceInstallment              
      
    --PRINT @ARGross          
          
--SELECT @ARGross = FLOOR(@ARGross)              
--========Tendi 18 June 2007================================================              
--select @ARGross as ARGROSS              
    SET @ARGross = @ARGross * ( 100 - @CoyPortion ) / 100            
          
--==========================================================================              
             
    IF @@error <> 0          
        GOTO ExitSP              
          
    IF @ARGross <> 0          
        BEGIN          
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                 )          
            VALUES  ( 'ARGROSS' ,           
  --15052008 MUL BEGIN             
                      CASE WHEN @ARGross < 0 THEN 'C'          
                           ELSE 'D'          
                      END ,          
                      CASE WHEN @ARGross < 0 THEN @ARGross * -1          
                           ELSE @ARGross          
                      END ,             
  --15052008 MUL END           
                      @AgreementNo ,          
                      '-'              
                 )            
        END            
    IF @@error <> 0          
        GOTO ExitSP              
             
             
-------------------------------------------------------------------------------              
-- Hitung Total Principle dr tbl Installment Schedule --              
-- Tendi 06/18 : ARBNK              
-------------------------------------------------------------------------------              
    DECLARE @ARBNK Amount              
              
    SELECT  @ARBNK = SUM(PrincipalAmount)          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
            AND InsSeqNo > @NumofAdvanceInstallment              
--============================================              
--select @ARBNK as ARBNK              
--Gema, 20081008 : Add Round          
    SET @ARBNK = ROUND(@ARBNK * @CoyPortion / 100, 0)              
--=========================================              
    IF @@error <> 0          
        GOTO ExitSP              
              
    IF @ARBNK > 0          
        BEGIN              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'ARBNK' ,          
                      'D' ,          
                      @ARBNK ,          
                      @AgreementNo ,          
                      '-'              
                    )              
        END              
    IF @@error <> 0          
        GOTO ExitSP              
              
              
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : UCI              
-------------------------------------------------------------------------------              
    SELECT  @TotalInterest = SUM(InterestAmount)          
    FROM    InstallmentSchedule WITH ( NOLOCK )          
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )              
              
--SELECT @TotalInterest = FLOOR(@TotalInterest)              
--========Tendi 18 June 2007================================================              
--select @TotalInterest as TotalInterest              
    SET @TotalInterest = @TotalInterest * ( 100 - @CoyPortion ) / 100              
--==========================================================================              
              
-- Henry, 9 April 2007              
-- SELECT @TotalInterest = FLOOR(@TotalInterest)              
    IF @TotalInterest > 0          
        BEGIN              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'UCI' ,          
                      'C' ,          
                      @TotalInterest ,          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END               
    SELECT  @CtrNo = @CtrNo + 1              
          
          
--Add fuji,12 Des 2019 (FMF-1819)          
-------------------------------------------------------------------------------              
-- Journal Credit Insurance--              
-- Fuji,12122019:   CINSEXPDEF,APCRDINS            
-------------------------------------------------------------------------------          
 /*Remarked by Adhitya 11/03/2020 FMF-1819          
 --SET @PremiumCreditIns=0           
 --SET @AdminFeeCreditIns =0          
 --SET @StampFeeCreditIns=0          
 Remarked by Adhitya 11/03/2020 FMF-1819*/          
 SET @CreditInsAmountTotal=0          
           
 /*Remarked by Adhitya 11/03/2020 FMF-1819          
   --Select @PremiumCreditIns=ISNULL(Premium,0),          
   --@AdminFeeCreditIns=ISNULL(AdminFee,0),          
   --@StampFeeCreditIns=ISNULL(StampDutyFee,0)          
   --from CreditInsuranceData            
   --WHERE   BranchID = @BranchID          
   --AND ApplicationID = @ApplicationID           
          
   --SET @CreditInsAmountTotal =@PremiumCreditIns + @AdminFeeCreditIns + @StampFeeCreditIns          
   Remarked by Adhitya 11/03/2020 FMF-1819*/          
             
   --Add Adhitya FMF-1819 11/03/2020          
   SET @CreditInsAmountTotal = -1* dbo.FnGetCreditInsuranceExp(@BranchID, @ApplicationId)           
 IF ( SELECT IsActive          
  FROM   AmortizationMaster WITH ( NOLOCK )          
  WHERE  AmortizationID = 'CRTINSEXP'          
   AND assettypeid = @assettypeid          
 ) = 1          
 AND ( SELECT    amountminimum          
   FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
   WHERE     AmortizationID = 'CRTINSEXP'          
     AND assettypeid = @assettypeid          
  ) <= ABS(@CreditInsAmountTotal) --jika CRTINSEXP  diamortize          
 BEGIN          
  SET @PaymentAllocID = 'INSREXPDEF'          
 END          
 ELSE --jika DEFINSINC  tidak diamortize          
 BEGIN          
  SET @PaymentAllocID = 'INSRCRTEXP'          
 END          
 --END Adhitya FMF-1819 11/03/2020          
          
          
   IF @CreditInsAmountTotal > 0          
   BEGIN          
  INSERT  INTO #temptable          
                    ( paymentallocationid ,          
                        post ,          
                        amount ,          
                        refdesc ,          
                        voucherdesc          
                    )          
            VALUES  ( @PaymentAllocID , -- edit ubah CINSEXPDEF menjadi @PaymentAllocID Adhitya FMF-1819 11/03/2020           
                        'D' ,          
                        @CreditInsAmountTotal ,          
                        @AgreementNo ,          
                        '-'          
                    )          
          
            IF @@ERROR <> 0          
                GOTO exitsp          
       
  if (@CreditInsuranceBy <> 'A') --Vincenza FMF-2420 19112020  
  begin     
   INSERT  INTO #temptable          
                    ( paymentallocationid ,          
                        post ,          
                        amount ,          
                        refdesc ,          
                        voucherdesc          
                    )          
            VALUES  ( 'APCRDINS' ,          
                        'C' ,         
                        @CreditInsAmountTotal ,          
                        @AgreementNo ,          
                        '-'          
                    )          
          
            IF @@ERROR <> 0          
                GOTO exitsp    
 end        
   END          
   --Vincenza FMF-2420 19112020  
        IF @AgentFee > 0 and @IsFactoring = 1     
   BEGIN   
 IF ( SELECT IsActive          
  FROM   AmortizationMaster WITH ( NOLOCK )          
  WHERE  AmortizationID = 'AGENTFEE'          
   AND assettypeid = @assettypeid          
 ) = 1          
 AND ( SELECT    amountminimum          
   FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
   WHERE     AmortizationID = 'AGENTFEE'          
     AND assettypeid = @assettypeid          
  ) <= ABS(@AgentFee) --jika AGENTFEE  diamortize          
 BEGIN          
  SET @PaymentAllocID = 'RATERFND'          
 END          
 ELSE --jika AGENTFEE  tidak diamortize          
 BEGIN          
  SET @PaymentAllocID = 'RFNDEXP'          
 END          
     
          
          
            
  INSERT  INTO #temptable          
                    ( paymentallocationid ,          
                        post ,          
                        amount ,          
                        refdesc ,          
                        voucherdesc          
                    )          
            VALUES  ( @PaymentAllocID ,      
                        'D' ,          
                        @AgentFee ,          
                        @AgreementNo ,          
                        '-'          
                    )          
          
            IF @@ERROR <> 0          
                GOTO exitsp       
 END     
   --end Vincenza  
--end fuji (FMF-1819)              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : ADMINFEE              
-------------------------------------------------------------------------------           
/*Diremark David 25Jan2010             
IF @AdminFee > 0              
BEGIN              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'ADMINFEE',              
  'C',              
  @AdminFee + @AdditionalAdminFee,              
  @AgreementNo,               
  '-'              
 )              
 if @@error <> 0 goto ExitSP              
END    */          
          
/*David 25Jan2010 : Tambah pengecekan jika admfee diamortize atau tidak          
 Arif 7 okt 2010 : tambah pengecekan amortize atau tidak          
          
*/          
    IF @AdminFee + @AdditionalAdminFee > 0          
        BEGIN          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'ADMFEE'          
                        AND assettypeid = @assettypeid          
               ) = 1          
                AND ( SELECT    amountminimum          
                      FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'ADMFEE'          
    AND assettypeid = @assettypeid          
                    ) <= @adminFee + @AdditionalAdminFee --jika AdmFee diamortize          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'ADMFEEDEF' ,          
                              'C' ,          
                              @AdminFee + @AdditionalAdminFee ,          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
            ELSE --jika AdminFee tidak diamortize          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
       refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'ADMINFEE' ,          
                              'C' ,          
                              @AdminFee + @AdditionalAdminFee ,          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
        END          
/*David 25Jan2010 selesai*/          
-------------------------------------------------------------------------------              
-- Journal --              
-- Gema, 20081107  : ADMFEEADV              
-------------------------------------------------------------------------------              
    IF @AdditionalAdminFee <> 0          
        BEGIN              
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'ADMINFEE'          
                        AND assettypeid = @assettypeid          
               ) = 1          
                AND ( SELECT    amountminimum          
                      FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'ADMINFEE'          
                                AND assettypeid = @assettypeid          
                    ) <= ABS(@AdditionalAdminFee) --jika Additional ADMINFEE  diamortize          
                BEGIN          
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
           RefDesc ,          
                              VoucherDesc               
                      )          
                 VALUES  ( 'ADMFEEADV' ,          
                              CASE WHEN @AdditionalAdminFee > 0 THEN 'D'          
                                   ELSE 'C'          
                              END ,          
                              ABS(@AdditionalAdminFee) ,          
                              @AgreementNo ,          
                              '-'              
                      )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END          
            ELSE --jika tidak diamortize          
                BEGIN          
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                      )          
                    VALUES  ( 'ADDADMFEE' ,          
                              CASE WHEN @AdditionalAdminFee > 0 THEN 'D'          
                                   ELSE 'C'          
                              END ,          
                              ABS(@AdditionalAdminFee) ,          
                              @AgreementNo ,          
                              '-'              
                      )              
                    IF @@error <> 0          
                        GOTO ExitSP             
                END          
        END              
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : PROVISIFEE              
-------------------------------------------------------------------------------              
/*Diremark David 25Jan2010           
IF @ProvisionFee > 0              
BEGIN              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'PROVISIFEE',              
  'C',              
  @ProvisionFee,              
  @AgreementNo,               
  '-'              
 )           
 if @@error <> 0 goto ExitSP              
END    */          
           
/*David 25Jan2010 : Tambah pengecekan jika PROVFEE diamortize atau tidak*/          
    IF @ProvisionFee > 0          
        BEGIN          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'PROVFEE'          
                        AND assettypeid = @assettypeid          
               ) = 1          
                AND ( SELECT    amountminimum          
                      FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'PROVFEE'          
                                AND assettypeid = @assettypeid          
                    ) <= ABS(@ProvisionFee) --jika PROVFEE diamortize          
                BEGIN          
                    INSERT  INTO #temptable          
         ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'PRVFEEDEF' ,          
                              'C' ,          
                              @ProvisionFee ,          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
            ELSE --jika PROVFEE tidak diamortize          
                BEGIN          
     SET @ProvisionFee = @ProvisionFee - dbo.FnGetProvisionFeeToAmortize(@BranchID, @ApplicationID) --Aditia FMF-1640 12032018          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'PROVISIFEE' ,          
                              'C' ,          
                              @ProvisionFee ,          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
        END          
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : NOTARYFEE              
-------------------------------------------------------------------------------              
    IF @NotaryFee > 0          
        BEGIN              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'NOTARYFEE' ,          
  'C' ,          
                      @NotaryFee ,          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : FIDUCIAFEE              
-- Modification : Widi              
-- 1. Bila hendak di Fiducia kan masuk ke FIDUADV jika tidak masuk ke FIDUFEE              
-------------------------------------------------------------------------------              
    IF @FiduciaFee > 0          
        BEGIN              
            IF @IsFiduciaCovered = 1          
                BEGIN              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'FIDUADV' ,          
                              'C' ,          
                              @FiduciaFee ,          
                              @AgreementNo ,          
                              '-'              
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END                
            ELSE          
                BEGIN              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'FIDUFEE' ,          
                              'C' ,          
                              @FiduciaFee ,          
                              @AgreementNo ,          
                              '-'              
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END                
        END              

-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : SURVEYFEE              
-------------------------------------------------------------------------------              
/*Diremark David 25Jan2010           
IF @SurveyFee > 0              
BEGIN              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'SURVEYFEE',              
  'C',              
              
  @SurveyFee,              
  @AgreementNo,               
  '-'              
 )              
 if @@error <> 0 goto ExitSP              
END    */          
          
/*David 25Jan2010 : Tambah pengecekan jika SURVEYFEE diamortize atau tidak*/          
    IF @SurveyFee > 0          
        BEGIN          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'SURVEYFEE'          
                        AND assettypeid = @assettypeid          
               ) = 1          
                AND ( SELECT    amountminimum          
                      FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'SURVEYFEE'          
                                AND assettypeid = @assettypeid          
                    ) <= ABS(@SurveyFee)  --jika SURVEYFEE diamortize          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'SVYFEEDEF' ,          
                              'C' ,          
                              ABS(@SurveyFee) ,          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
            ELSE          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                            voucherdesc          
                            )          
                    VALUES  ( 'SURVEYFEE' ,          
                              'C' ,          
                              ABS(@SurveyFee) ,          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
        END          
            
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : OTHERFEE              
-------------------------------------------------------------------------------              
/*Diremark David 25Jan2010           
IF @OtherFee > 0              
BEGIN              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'OTHERFEE',              
  'C',               
  @OtherFee,              
  @AgreementNo,               
  '-'              
 )              
 if @@error <> 0 goto ExitSP              
END    */          
          
/*David 25Jan2010 : Tambah pengecekan jika OTHERFEE diamortize atau tidak*/          
    IF @OtherFee <> 0          
        BEGIN          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'OTHERFEE'          
                        AND assettypeid = @assettypeid          
               ) = 1          
                AND ( SELECT    amountminimum          
                      FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'OTHERFEE'          
                                AND assettypeid = @assettypeid          
                    ) <= ABS(@OtherFee) --jika OTHERFEE diamortize          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
     refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'OTHFEEDEF' ,          
                              CASE WHEN @OtherFee > 0 THEN 'C'          
                                   ELSE 'D'          
                              END ,          
                              ABS(@OtherFee) ,          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
            ELSE --jika OTHERFEE tidak diamortize          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'OTHERFEE' ,          
                              CASE WHEN @OtherFee > 0 THEN 'C'          
                                   ELSE 'D'          
                              END ,          
                              ABS(@OtherFee) ,          
                              @AgreementNo ,          
               '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
        END          
/*Diremark David 25Jan2010           
-------------------------------------------------------------------------------              
-- Journal --              
-- Start jomin 14/May/09 : OTHERFEE < 0             
-------------------------------------------------------------------------------           
IF @OtherFee < 0              
BEGIN              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'OTHERFEE',              
  'D',               
  abs(@OtherFee),              
  @AgreementNo,               
  '-'              
 )              
 if @@error <> 0 goto ExitSP              
END          
                  
-------------------------------------------------------------------------------              
-- Journal --              
-- End jomin 14/May/09 : OTHERFEE < 0             
-------------------------------------------------------------------------------             
End David*/          
          
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 17/12 : INSRCRTEXP              
-- hanya u/At Cost              
-- nilai diambil dari Premi ke InsCo               
-------------------------------------------------------------------------------              
    SELECT  @PremiumAmountToInsCo = InsuranceAsset.PremiumAmountToInsCo ,          
 @AdminFeeToInsCo = InsuranceAsset.AdminFee ,          
            @MeteraiFeeToInsCo = InsuranceAsset.MeteraiFee ,          
            @PremiumAmountByCust = PremiumamountByCust ,          
            @AdminFeeToCust = AdminFeeToCust ,          
            @MeteraiFeeToCust = MeteraiFeeToCust ,          
            @AcquisitionCost = ISNULL(AcquisitionCost, 0) --added by Johan 12 Mar 2014          
    FROM    InsuranceAsset WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID          
          
 --added by Johan 12 Mar 2014          
    IF @SingleInsuranceRate <> '1'          
        BEGIN          
            SET @AcquisitionCost = 0          
        END                  
    --End Johan          
               
    IF @InsAssetPaidBy = 'AC'             
/*Diremark David 25Jan2010             
BEGIN              
 IF @PremiumAmountToInsCo > 0              
 BEGIN              
  INSERT INTO #TempTable(              
   PaymentAllocationID,              
   Post,              
   Amount,              
   RefDesc,               
   VoucherDesc               
  ) VALUES (              
   'INSURINC',              
   'D',              
   @PremiumAmountToInsCo + @AdminFeeToInsCo + @MeteraiFeeToInsCo,              
   @AgreementNo,               
   '-'              
  )              
  if @@error <> 0 goto ExitSP              
 END              
END   */          
--David 25Jan2010 : Bagian yang diremark diatas diganti dengan ini:           
        BEGIN          
            IF @PremiumAmountToInsCo > 0          
                BEGIN          
          
                    IF ( SELECT IsActive          
                         FROM   AmortizationMaster WITH ( NOLOCK )          
                         WHERE  AmortizationID = 'DEFINSINC'          
                                AND assettypeid = @assettypeid          
                       ) = 1          
                        AND ( SELECT    amountminimum          
                              FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                              WHERE     AmortizationID = 'DEFINSINC'          
                                        AND assettypeid = @assettypeid          
                            ) <= ABS(@PremiumAmountToInsCo) --jika DEFINSINC  diamortize          
           BEGIN          
                            SET @PaymentAllocID = 'INSREXPDEF'          
                        END          
                    ELSE --jika DEFINSINC  tidak diamortize          
                        BEGIN          
                            SET @PaymentAllocID = 'INSRCRTEXP'          
                        END          
              
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc     
                            )          
                    VALUES  ( @PaymentAllocID ,          
                              'D' ,          
                              @PremiumAmountToInsCo + @AdminFeeToInsCo          
                              + @MeteraiFeeToInsCo - @AcquisitionCost , --- @LifeInsuranceIncome, --modified by Johan 12 Mar 2014, Modified by Benny 15juni2015 fmf-1422 @lifeinsuranceincome          
                              @AgreementNo ,          
                              '-'          
                            )          
          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
        END          
          
          
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : OPINSUR              
-------------------------------------------------------------------------------              
    DECLARE @SupplierInsuranceIncome amount ,          
        @SupplierEmployeeInsuranceIncome amount ,          
        @SupplierInsuranceIncome1 amount ,          
        @SupplierInsuranceIncome2 amount ,          
        @SupplierInsuranceIncome3 amount ,          
        @SupplierEmployeeInsuranceIncome1 amount ,          
        @SupplierEmployeeInsuranceIncome2 amount ,          
        @SupplierEmployeeInsuranceIncome3 amount ,          
        @ReferenceNameInsuranceIncome1 amount ,          
        @ReferenceNameInsuranceIncome2 amount ,          
        @ReferenceNameInsuranceIncome3 amount ,          
        @TotalCommision amount ,          
        @SupplierUppingBungaIncome1 amount ,          
        @SupplierUppingBungaIncome2 amount ,          
        @SupplierUppingBungaIncome3 amount ,          
        @SupplierOtherFeeIncome1 amount ,          
        @SupplierOtherFeeIncome2 amount ,          
        @SupplierOtherFeeIncome3 amount ,          
        @SupplierEmployeeUppingBungaIncome1 amount ,          
        @SupplierEmployeeUppingBungaIncome2 amount ,          
        @SupplierEmployeeUppingBungaIncome3 amount ,          
        @SupplierEmployeeOtherFeeIncome1 amount ,          
        @SupplierEmployeeOtherFeeIncome2 amount ,          
        @SupplierEmployeeOtherFeeIncome3 amount ,          
        @ReferenceNameInsuranceIncome amount ,          
        @ReferenceUppingBungaInsuranceIncome amount ,          
        @ReferenceOtherFeeInsuranceIncome amount ,          
        @SupplierTaxAmount1 amount ,          
        @SupplierTaxAmount2 amount ,          
        @SupplierTaxAmount3 amount ,          
        @SupplierEmployeeTaxAmount1 amount ,          
        @SupplierEmployeeTaxAmount2 amount ,          
        @SupplierEmployeeTaxAmount3 amount ,          
        @ReferenceNameTaxAmount1 amount          
  --Aditia FMF-1640 12032018          
  ,@SupplierProvisionFee1 NUMERIC(17,2)          
        ,@SupplierProvisionFee2 NUMERIC(17,2)          
        ,@SupplierProvisionFee3 NUMERIC(17,2)          
  ,@SupplierEmployeeProvisionFee1 NUMERIC(17,2)          
        ,@SupplierEmployeeProvisionFee2 NUMERIC(17,2)          
        ,@SupplierEmployeeProvisionFee3 NUMERIC(17,2)          
  ,@ReferenceNameProvisionFee NUMERIC(17,2)          
  --END Aditia          
------------------------------------------------Supplier Income------------------------------------------              
--Teddy 18 Mei 2005              
-- Select @SupplierInsuranceIncome1=Commision.SupplierInsuranceIncome,              
--  @SupplierInsuranceIncome2=Qry1.SupplierInsuranceIncome,                      
--  @SupplierInsuranceIncome3=Qry2.SupplierInsuranceIncome,              
--                     
--  @SupplierUppingBungaIncome1=Commision.SupplierUppingBunga,              
--  @SupplierUppingBungaIncome2=Qry1.SupplierUppingBunga,              
--  @SupplierUppingBungaIncome3=Qry2.SupplierUppingBunga,              
--               
--  @SupplierOtherFeeIncome1=Commision.SupplierOtherFee,       
--  @SupplierOtherFeeIncome2=Qry1.SupplierOtherFee,              
--  @SupplierOtherFeeIncome3=Qry2.SupplierOtherFee,           
--               
--  @SupplierTaxAmount1=Commision.SupplierTaxAmount,              
--  @SupplierTaxAmount2=Qry1.SupplierTaxAmount,              
--  @SupplierTaxAmount3=Qry2.SupplierTaxAmount              
--               
-- FROM   dbo.Commision Left Join (              
--  Select BranchID,ApplicationID, SupplierInsuranceIncome,              
--         SupplierEmployeeInsuranceIncome,               
--         ReferenceNameInsuranceIncome,              
--  SupplierUppingBunga,SupplierEmployeeUppingBunga,ReferenceNameUppingBunga,              
--  SupplierOtherFee,SupplierEmployeeOtherFee,ReferenceNameOtherFee ,              
--  SupplierTaxAmount              
-- FROM   dbo.Commision              
-- Where BranchID = @BranchID And ApplicationID = @ApplicationID And SeqNo > 1 And isnull(SupplierEmployeeID,'') = ''              
-- ) Qry1 on Commision.BranchID = Qry1.BranchID And  Commision.ApplicationID = Qry1.ApplicationID               
-- left Join (              
-- Select BranchID,ApplicationID,SupplierInsuranceIncome,              
--        SupplierEmployeeInsuranceIncome,               
--         ReferenceNameInsuranceIncome,              
--  SupplierUppingBunga,SupplierEmployeeUppingBunga,ReferenceNameUppingBunga,              
--  SupplierOtherFee,SupplierEmployeeOtherFee,ReferenceNameOtherFee,              
--  SupplierTaxAmount              
-- FROM   dbo.Commision              
-- Where BranchID = @BranchID And ApplicationID = @ApplicationID And SeqNo > 1 And isnull(SupplierEmployeeID,'') <> ''              
-- )Qry2 on Commision.BranchID = Qry2.BranchID And  Commision.ApplicationID = Qry2.ApplicationID               
-- Where Commision.BranchID = @BranchID And Commision.ApplicationID = @ApplicationID And SeqNo =1             
          
    DECLARE @TotalOtherSupplier Amount --Novia add, 17062016 : FMF-1515          
              
    SELECT  @SupplierInsuranceIncome1 = 0 , --QryCommision.SumSupplierInsuranceIncome , --Novia modify, 17062016 : FMF-1515          
            @SupplierInsuranceIncome2 = 0 ,          
            @SupplierInsuranceIncome3 = 0 ,          
            @SupplierUppingBungaIncome1 = 0 , --QryCommision.SumSupplierUppingBunga , --Novia modify, 17062016 : FMF-1515          
            @SupplierUppingBungaIncome2 = 0 ,          
            @SupplierUppingBungaIncome3 = 0 ,          
            @SupplierOtherFeeIncome1 = 0 , --QryCommision.SumSupplierOtherFee ,--Novia modify, 17062016 : FMF-1515          
            @SupplierOtherFeeIncome2 = 0 ,          
            @SupplierOtherFeeIncome3 = 0 ,          
            @SupplierTaxAmount1 = 0 , --QryCommision.SumSupplierTaxAmount , --Novia modify, 17062016 : FMF-1515          
            @SupplierTaxAmount2 = 0 ,          
            @SupplierTaxAmount3 = 0 ,          
   --Aditia FMF-1640 12032018          
   @SupplierProvisionFee1 = 0          
   ,@SupplierProvisionFee2 = 0          
   ,@SupplierProvisionFee3 = 0,          
   --END Aditia          
            @TotalOtherSupplier = SUM(QryCommision2.totalothersupplier) --Novia add, 17062016 : FMF-1515          
    FROM    dbo.Commision WITH ( NOLOCK ) --Novia modify, 17062016 : FMF-1515          
            --INNER JOIN ( SELECT BranchID ,          
            --                    ApplicationID ,          
            --                    SUM(SupplierInsuranceIncome) AS SumSupplierInsuranceIncome ,          
            --                    SUM(SupplierUppingBunga) AS SumSupplierUppingBunga ,          
            --                    SUM(SupplierOtherFee) AS SumSupplierOtherFee ,          
            --                    SUM(SupplierTaxAmount) AS SumSupplierTaxAmount          
            --             FROM   dbo.Commision WITH ( NOLOCK )          
            --             WHERE  BranchID = @BranchID          
            --                    AND ApplicationID = @ApplicationID --And isnull(SupplierEmployeeID,'') = ''              
            --             GROUP BY BranchID ,          
            --                    ApplicationID          
            --  ) QryCommision ON Commision.BranchID = QryCommision.BranchID                --                             AND Commision.ApplicationID = QryCommision.ApplicationID          
            --                             AND Commision.BranchID = @BranchID          
            --                             AND Commision.ApplicationID = @ApplicationID              
            INNER JOIN ( SELECT BranchID ,          
                                ApplicationID ,          
                                --SUM(SupplierInsuranceIncome) AS SumSupplierInsuranceIncome ,          
                                --SUM(SupplierUppingBunga) AS SumSupplierUppingBunga ,          
                                --SUM(SupplierOtherFee) AS SumSupplierOtherFee ,          
                                --SUM(SupplierTaxAmount) AS SumSupplierTaxAmount ,   
           --edit fuji,27012023(fmf-4017)  
           CASE WHEN SUM(ISNULL(SupplierPPNAmount,0)) > 0   
          THEN SUM(ISNULL(SupplierDPPAmount,0))+  
          SUM(ISNULL(SupplierPPNAmount,0))-SUM(SupplierTaxAmount)      
         else CASE c.CalculateTaxMethodSupplier          
           WHEN 'NE'          
           THEN ISNULL(( SUM(SupplierInsuranceIncome)          
             + SUM(SupplierUppingBunga)          
             + SUM(SupplierOtherFee)          
             + ISNULL(SUM(SupplierProvisionFee),0) --Aditia FMF-1640 12032018          
             - -- Added by Albert Ricia on 16 Agustus 2016 (FMF-1515)          
              ( CASE @CalculateTaxMethodSupllier          
              WHEN 'GR' THEN 0          
              WHEN 'NE'          
              THEN SupplierTaxAmount          
              ELSE SupplierTaxAmount          
               END )           
    -- End Added                     
             ), 0)          
           WHEN 'GR'          
           THEN ISNULL(( SUM(SupplierInsuranceIncome)          
             + SUM(SupplierUppingBunga)          
             + SUM(SupplierOtherFee)           
             + ISNULL(SUM(SupplierProvisionFee),0) --Aditia FMF-1640 12032018          
             ), 0)          
           ELSE 0          
         END   
        END  
        --END EDIT FUJI  
        AS totalothersupplier ,          
                                SeqNo ,          
                                c.CalculateTaxMethodSupplier          
                         FROM   dbo.Commision c WITH ( NOLOCK )          
                               -- INNER JOIN dbo.Supplier s ON c.SupplierID = s.SupplierID          
                         WHERE  BranchID = @BranchID          
                                AND ApplicationID = @ApplicationID          
                                AND SeqNo <> 1          
                         GROUP BY BranchID ,          
                                ApplicationID ,          
                                c.CalculateTaxMethodSupplier ,          
                                SeqNo ,          
        -- Added by Albert Ricia on 16 Agustus 2016 (FMF-1515)          
                                SupplierTaxAmount          
        -- End Added          
                       ) QryCommision2 ON Commision.BranchID = QryCommision2.BranchID          
                                          AND dbo.Commision.SeqNo = QryCommision2.SeqNo          
                                          AND Commision.ApplicationID = QryCommision2.ApplicationID          
                                          AND Commision.BranchID = @BranchID          
                                          AND Commision.ApplicationID = @ApplicationID          
   --eo Novia,           
              
----------------------------------------------Supplier Employee Income -------------------------------------------              
--Teddy 18 Mei 2005              
-- Select  @SupplierEmployeeInsuranceIncome1=Commision.SupplierEmployeeInsuranceIncome,        
--  @SupplierEmployeeInsuranceIncome2=Qry1.SupplierEmployeeInsuranceIncome,                      
--  @SupplierEmployeeInsuranceIncome3=Qry2.SupplierEmployeeInsuranceIncome,              
--                
--  @SupplierEmployeeUppingBungaIncome1=Commision.SupplierEmployeeUppingBunga,              
--  @SupplierEmployeeUppingBungaIncome2=Qry1.SupplierEmployeeUppingBunga,                      
--  @SupplierEmployeeUppingBungaIncome3=Qry2.SupplierEmployeeUppingBunga,              
--               
--  @SupplierEmployeeOtherFeeIncome1=Commision.SupplierEmployeeOtherFee,              
--  @SupplierEmployeeOtherFeeIncome2=Qry1.SupplierEmployeeOtherFee,                      
--  @SupplierEmployeeOtherFeeIncome3=Qry2.SupplierEmployeeOtherFee,              
--               
--  @SupplierEmployeeTaxAmount1=Commision.SupplierEmployeeTaxAmount,              
--  @SupplierEmployeeTaxAmount2=Qry1.SupplierEmployeeTaxAmount,          
--  @SupplierEmployeeTaxAmount3=qry2.SupplierEmployeeTaxAmount              
--                    
-- FROM   dbo.Commision Left Join (              
--  Select BranchID,ApplicationID, SupplierInsuranceIncome,              
--         SupplierEmployeeInsuranceIncome,               
--         ReferenceNameInsuranceIncome,              
--  SupplierUppingBunga,SupplierEmployeeUppingBunga,ReferenceNameUppingBunga,              
--  SupplierOtherFee,SupplierEmployeeOtherFee,ReferenceNameOtherFee,              
--  SupplierEmployeeTaxAmount               
-- FROM   dbo.Commision              
-- Where BranchID = @BranchID And ApplicationID = @ApplicationID And SeqNo > 1 And isnull(SupplierEmployeeID,'') = ''              
-- ) Qry1 on Commision.BranchID = Qry1.BranchID And  Commision.ApplicationID = Qry1.ApplicationID               
-- left Join (              
-- Select BranchID,ApplicationID,SupplierInsuranceIncome,              
--        SupplierEmployeeInsuranceIncome,               
--         ReferenceNameInsuranceIncome,              
--  SupplierUppingBunga,SupplierEmployeeUppingBunga,ReferenceNameUppingBunga,              
--  SupplierOtherFee,SupplierEmployeeOtherFee,ReferenceNameOtherFee,              
--  SupplierEmployeeTaxAmount              
-- FROM   dbo.Commision              
-- Where BranchID = @BranchID And ApplicationID = @ApplicationID And SeqNo > 1 And isnull(SupplierEmployeeID,'') <> ''              
-- )Qry2 on Commision.BranchID = Qry2.BranchID And  Commision.ApplicationID = Qry2.ApplicationID               
-- Where Commision.BranchID = @BranchID And Commision.ApplicationID = @ApplicationID And SeqNo =1               
    DECLARE @TotalSupplierEmployeeIncome amount, --Novia add, 17062016 : FMF-1515  
 @TotalSupplierEmployeeIncomeWithVAT AMOUNT   
   
       
          
    SELECT  @SupplierEmployeeInsuranceIncome1 = 0 , --QryCommision.SumSupplierEmployeeInsuranceIncome , --Novia modify, 17062016 : FMF-1515          
            @SupplierEmployeeInsuranceIncome2 = 0 ,          
            @SupplierEmployeeInsuranceIncome3 = 0 ,          
            @SupplierEmployeeUppingBungaIncome1 = 0 , --QryCommision.SumSupplierEmployeeUppingBunga , --Novia modify, 17062016 : FMF-1515          
            @SupplierEmployeeUppingBungaIncome2 = 0 ,          
            @SupplierEmployeeUppingBungaIncome3 = 0 ,          
            @SupplierEmployeeOtherFeeIncome1 = 0 , --QryCommision.SumSupplierEmployeeOtherFee , --Novia modify, 17062016 : FMF-1515          
            @SupplierEmployeeOtherFeeIncome2 = 0 ,          
            @SupplierEmployeeOtherFeeIncome3 = 0 ,          
            @SupplierEmployeeTaxAmount1 = 0 , --QryCommision.sumSupplierEmployeeTaxAmount , --Novia modify, 17062016 : FMF-1515          
            @SupplierEmployeeTaxAmount2 = 0 ,          
            @SupplierEmployeeTaxAmount3 = 0 ,          
     --Aditia FMF-1640 12032018          
     @SupplierEmployeeProvisionFee1 = 0           
     ,@SupplierEmployeeProvisionFee2 = 0           
     ,@SupplierEmployeeProvisionFee3 = 0,          
     --END Aditia          
            @TotalSupplierEmployeeIncome = QryCommision.TotalSupplierEmployeeIncome --Novia add, 17062016 : FMF-1515          
    FROM    dbo.Commision WITH ( NOLOCK )       
            INNER JOIN ( SELECT BranchID ,          
                                ApplicationID ,          
        --Novia modify, 17062016 : FMF-1515          
                                --SUM(SupplierEmployeeInsuranceIncome) AS SumSupplierEmployeeInsuranceIncome ,          
                                --SUM(SupplierEmployeeUppingBunga) AS sumSupplierEmployeeUppingBunga ,          
          --SUM(SupplierEmployeeOtherFee) AS sumSupplierEmployeeOtherFee ,          
                                --SUM(SupplierEmployeeTaxAmount) AS sumSupplierEmployeeTaxAmount          
                                SUM(CASE ISNULL(dbo.Commision.CalculateTaxMethodSupplierEmployee,          
                                                'NE')      
                                      WHEN 'NE'          
                                      THEN ( SupplierEmployeeInsuranceIncome          
                                             + SupplierEmployeeUppingBunga          
                                             + SupplierEmployeeOtherFee          
            + ISNULL(SupplierEmployeeProvisionFee,0) --Aditia FMF-1640 12032018          
                                             - SupplierEmployeeTaxAmount )          
                                      WHEN 'GR'          
                                      THEN ( SupplierEmployeeInsuranceIncome          
                                             + SupplierEmployeeUppingBunga          
                                             + SupplierEmployeeOtherFee          
            + ISNULL(SupplierEmployeeProvisionFee,0) --Aditia FMF-1640 12032018          
            )          
                                    END) AS TotalSupplierEmployeeIncome          
        --Eo Novia, 17062016          
                         FROM   dbo.Commision WITH ( NOLOCK )          
                         WHERE  BranchID = @BranchID          
                                AND ApplicationID = @ApplicationID --and isnull(SupplierEmployeeID,'') <> ''  
        AND isnull(SupplierEmployeePPnAmount,0) <=0   --Add fuji,27012023 (fmf-4017)           
                         GROUP BY BranchID ,          
                                ApplicationID          
                       ) QryCommision ON Commision.BranchID = QryCommision.BranchID          
                                         AND Commision.ApplicationID = QryCommision.ApplicationID          
                                         AND Commision.BranchID = @BranchID          
                                         AND Commision.ApplicationID = @ApplicationID  
  
     
 ----Add fuji,27012023 (fmf-4017) @TotalSupplierEmployeeIncome Jika Ada VAT  
    SELECT         
            @TotalSupplierEmployeeIncomeWithVAT =  QryCommision.TotalSupplierEmployeeIncome --Novia add, 17062016 : FMF-1515          
    FROM    dbo.Commision WITH ( NOLOCK )       
            INNER JOIN ( SELECT BranchID ,          
                                ApplicationID ,          
                                SUM(isnull(SupplierEmployeePPnAmount,0) + isnull(SupplierEmployeeDPPAmount,0) - SupplierEmployeeTaxAmount ) AS TotalSupplierEmployeeIncome          
        
                         FROM   dbo.Commision WITH ( NOLOCK )          
                         WHERE  BranchID = @BranchID          
                                AND ApplicationID = @ApplicationID --and isnull(SupplierEmployeeID,'') <> ''  
        AND isnull(SupplierEmployeePPnAmount,0)  > 0              
                         GROUP BY BranchID ,          
                                ApplicationID          
                       ) QryCommision ON Commision.BranchID = QryCommision.BranchID          
                                         AND Commision.ApplicationID = QryCommision.ApplicationID          
                                         AND Commision.BranchID = @BranchID          
                                         AND Commision.ApplicationID = @ApplicationID  
 ----end fuji  
   
 set @TotalSupplierEmployeeIncome = isnull(@TotalSupplierEmployeeIncome,0) + isnull(@TotalSupplierEmployeeIncomeWithVAT,0)                        
   
---------------------------------------------Referantor -------------------------------------------------------------              
    SELECT  @ReferenceNameInsuranceIncome = Commision.ReferenceNameInsuranceIncome ,          
            @ReferenceUppingBungaInsuranceIncome = Commision.ReferenceNameUppingBunga ,          
            @ReferenceOtherFeeInsuranceIncome = Commision.ReferenceNameOtherFee ,          
            @ReferenceNameTaxAmount1 = Commision.ReferenceNameTaxAmount          
   ,@ReferenceNameProvisionFee = ISNULL(Commision.ReferenceNameProvisionFee,0) --Aditia FMF-1640 12032018          
    FROM    dbo.Commision WITH ( NOLOCK )          
    WHERE   Commision.BranchID = @BranchID          
            AND Commision.ApplicationID = @ApplicationID          
            AND SeqNo = 1               
              
-------------------------------------------Total Supplier,SupplierEmployee,Referantor---------------------------------              
    SELECT  @TotalCommision = SUM(SupplierInsuranceIncome)          
            + SUM(SupplierEmployeeInsuranceIncome)          
            + SUM(ReferenceNameInsuranceIncome)          
    FROM    dbo.Commision WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID              
              
    DECLARE @TotalInsuranceIncome amount ,          
        @TotalSupplierIncome amount ,          
        --@TotalSupplierEmployeeIncome amount , --Novia remark, 17062016 : FMF-1515          
        @TotalUppingBungaFee amount ,          
        @TotalOtherFee Amount ,          
        @TotalSupplierTaxAmount Amount ,          
        @TotalSupplierEmployeeTaxAmount Amount ,              
  --Novia add, 17062016 : FMF-1515            
        @TotalOtherSupplierTaxAmount Amount ,          
        @TotalSupplierTax amount          
          
  --Eo Novia, 17062016          
              
              
------------------------------------------------------------END-----------------------------------------------------              
              
    SET @TotalInsuranceIncome = ISNULL(@SupplierInsuranceIncome1, 0)          
        + ISNULL(@SupplierInsuranceIncome2, 0)          
        + ISNULL(@SupplierInsuranceIncome3, 0)          
        + ISNULL(@SupplierEmployeeInsuranceIncome1, 0)          
        + ISNULL(@SupplierEmployeeInsuranceIncome2, 0)          
        + ISNULL(@SupplierEmployeeInsuranceIncome3, 0)          
        + ISNULL(@ReferenceNameInsuranceIncome, 0)              
  --Aditia FMF-1640 120332018          
  + ISNULL(@SupplierEmployeeProvisionFee1, 0)          
        + ISNULL(@SupplierEmployeeProvisionFee2, 0)          
        + ISNULL(@SupplierEmployeeProvisionFee3, 0)          
  --END Aditia          
              
    SET @TotalSupplierIncome = ISNULL(@SupplierInsuranceIncome1, 0)          
        + ISNULL(@SupplierInsuranceIncome2, 0)          
        + ISNULL(@SupplierInsuranceIncome3, 0)          
        + ISNULL(@SupplierUppingBungaIncome1, 0)          
        + ISNULL(@SupplierUppingBungaIncome2, 0)          
        + ISNULL(@SupplierUppingBungaIncome3, 0)          
        + ISNULL(@SupplierOtherFeeIncome1, 0)          
        + ISNULL(@SupplierOtherFeeIncome2, 0)          
        + ISNULL(@SupplierOtherFeeIncome3, 0)               
  --Aditia FMF-1640 12032018          
  + ISNULL(@SupplierProvisionFee1, 0)          
        + ISNULL(@SupplierProvisionFee2, 0)          
        + ISNULL(@SupplierProvisionFee3, 0)           
  --END Aditia          
               
 --Novia remark, 17062016 : FMF-1515          
    --SET @TotalSupplierEmployeeIncome = ISNULL(@SupplierEmployeeInsuranceIncome1,          
    --                                          0)          
    --    + ISNULL(@SupplierEmployeeInsuranceIncome2, 0)          
    --    + ISNULL(@SupplierEmployeeInsuranceIncome3, 0)          
    --    + ISNULL(@SupplierEmployeeUppingBungaIncome1, 0)          
    --    + ISNULL(@SupplierEmployeeUppingBungaIncome2, 0)          
    --    + ISNULL(@SupplierEmployeeUppingBungaIncome3, 0)          
    --    + ISNULL(@SupplierEmployeeOtherFeeIncome1, 0)          
    --    + ISNULL(@SupplierEmployeeOtherFeeIncome2, 0)          
    --    + ISNULL(@SupplierEmployeeOtherFeeIncome3, 0)              
 --Eo Novia, 17062016          
              
--David 25Jan2010: Ganti cara mendapatkan @TotalUppingBungaFee          
--Set @TotalUppingBungaFee = isnull(@SupplierUppingBungaIncome1, 0)          
--    + isnull(@SupplierUppingBungaIncome2, 0)          
--    + isnull(@SupplierUppingBungaIncome3, 0)          
--    + isnull(@SupplierEmployeeUppingBungaIncome1, 0)          
--    + isnull(@SupplierEmployeeUppingBungaIncome2, 0)          
--    + isnull(@SupplierEmployeeUppingBungaIncome3, 0)          
--    + isnull(@ReferenceUppingBungaInsuranceIncome, 0)              
    SELECT  @TotalUppingBungaFee = dbo.FnGetUppingBungaToAmortize(@BranchID,          
                                                              @ApplicationID)           
              
--David 25Jan2010 : Ganti cara mendapatkan @TotalUppingBungaFee          
--Set @TotalOtherFee = isnull(@SupplierOtherFeeIncome1, 0)          
--    + isnull(@SupplierOtherFeeIncome2, 0) + isnull(@SupplierOtherFeeIncome3, 0)          
--    + isnull(@SupplierEmployeeOtherFeeIncome1, 0)          
--    + isnull(@SupplierEmployeeOtherFeeIncome2, 0)          
--    + isnull(@SupplierEmployeeOtherFeeIncome3, 0)          
--    + isnull(@ReferenceOtherFeeInsuranceIncome, 0)            
           
 --Dessy 31082012 modify  : ubah cara ambil @TotalOtherFee          
    /*SELECT  @TotalOtherFee = dbo.FnGetOtherFeeToAmortize(@BranchID,          
                                                         @ApplicationID) */          
                                   
    -- Dewi 16102013 added @VoucherMethod          
    DECLARE @VoucherMethod VARCHAR(1)          
                                              
    SELECT  @TotalOtherFee = VoucherExpense ,          
            @VoucherMethod = ISNULL(VoucherMethod, '') -- Dewi 16102013 added          
    FROM    Agreement          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID            
           
 -- Dewi 16102013 : tambah set @TotalOtherFee = 0 untuk VoucherMethod = C          
    IF @VoucherMethod = 'C'          
        BEGIN          
            SET @TotalOtherFee = 0          
        END          
                                                         
    --End Dessy 31082012 modify          
          
    --Novia modify. 17062016 : FMF-1515          
    --SET @TotalSupplierTaxAmount = ISNULL(@SupplierTaxAmount1, 0)          
    --    + ISNULL(@SupplierTaxAmount2, 0) + ISNULL(@SupplierTaxAmount3, 0)              
    SET @TotalSupplierTaxAmount = ISNULL(@TaxAmountMainSupplierCompany, 0) --ISNULL(@SupplierTaxAmount1, 0) + ISNULL(@SupplierTaxAmount2, 0)  + ISNULL(@SupplierTaxAmount3, 0)               
    SET @TotalOtherSupplierTaxAmount = ISNULL(@SupplierTaxAmount2, 0)          
        + ISNULL(@SupplierTaxAmount3, 0)            
    SET @TotalSupplierTax = @TotalSupplierTaxAmount          
        + @TotalOtherSupplierTaxAmount            
 --Eo Novia, 17062016            
    SET @TotalSupplierEmployeeTaxAmount = ISNULL(@SupplierEmployeeTaxAmount1,          
                                                 0)          
        + ISNULL(@SupplierEmployeeTaxAmount2, 0)          
        + ISNULL(@SupplierEmployeeTaxAmount3, 0)               
              
    IF @PremiumAmountToInsCo + @AdminFeeToInsCo + @MeteraiFeeToInsCo > 0          
        BEGIN              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'APINSUR' ,          
                      'C' ,          
                      @PremiumAmountToInsCo + @AdminFeeToInsCo          
                      + @MeteraiFeeToInsCo - @AcquisitionCost , --added by Johan 12 Mar 2014          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
               
              
 --untuk life insurance              
 -- by : emilia 9/02/'06              
    IF @PremiumToInsCo + @LifeAdminFee + @LifeStampDutyFee > 0          
        BEGIN              
            INSERT  INTO #TempTable          
            ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'APLFINSUR' ,          
                      'C' ,          
                      @PremiumToInsCo + @LifeAdminFee + @LifeStampDutyFee ,          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
              
-- By Johnson 21 Mei 2005             
-- Uncomment And Added TransferApDisb by Albert Ricia on 03-07-2015              
    --IF @TotalSupplierIncome > 0          
    IF ( ISNULL(@MainSupplier, 0) + ISNULL(@TotalOtherSupplier, 0) ) > 0 -- Edit by Albert Ricia on 16 Agustus 2016 (FMF-1515)          
        AND @TransferApDisb = 'C'          
        BEGIN                
  -- By Johnson 17 Mei 2005                 
           
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'APINCSPL1' ,          
                      'C' ,          
       -- Edit by Albert Ricia on 16 Agustus 2016 (FMF-1515)          
                      --@TotalSupplierIncome - @TotalSupplierTaxAmount ,          
                      ( ISNULL(@MainSupplier, 0) + ISNULL(@TotalOtherSupplier,          
                                                          0) ) ,          
       -- End Edit          
                      @AgreementNo ,          
                      '-'              
                    )             
          
            IF @@error <> 0          
                GOTO ExitSP              
   END          
          
       
              
--Menyamakan dengan versi BII Lisa 20080703 : Perbaikan utk tipe supplier personal          
--Novia add, 17062016 : FMF-1515          
    DECLARE @SumTaxCompany AS Amount ,          
        @SumTaxPersonal AS Amount ,          
        @SumTaxSuppEmployeeForCompany AS Amount,  
  @SumTaxSuppEmployeeForPersonal As Amount --Add fuji,09122022 Perbaikan Bugs CR FMF-3546        
           
                  
    SELECT  @SumTaxCompany = SUM(SupplierTaxAmount)          
    FROM    dbo.Commision WITH ( NOLOCK )          
            INNER JOIN supplier WITH ( NOLOCK ) ON commision.supplierid = supplier.supplierid          
    WHERE   ApplicationId = @ApplicationID          
    AND BranchId = @BranchID          
            AND SupplierType = 'C'             
                     
    --edit fuji,09122022 : Perbaiki Bugs CR (fmf-3546) Tax SupplierEmployee dipisah berdasarkan SupplierEmployeeType nya Company atau Personal               
    SELECT  @SumTaxSuppEmployeeForCompany = SUM(SupplierEmployeeTaxAmount)          
    FROM    dbo.Commision WITH ( NOLOCK )          
            INNER JOIN supplier WITH ( NOLOCK ) ON commision.supplierid = supplier.supplierid   
   INNER JOIN dbo.SupplierEmployee WITH ( NOLOCK )  
    ON dbo.Commision.SupplierID = dbo.SupplierEmployee.SupplierID          
              AND dbo.Commision.SupplierEmployeeID = dbo.SupplierEmployee.SupplierEmployeeID          
    WHERE   ApplicationId = @ApplicationID          
            AND BranchId = @BranchID          
            --AND SupplierType = 'C'   
   AND SupplierEmployeeType = 'C'    
     
  
 SELECT  @SumTaxSuppEmployeeForPersonal = SUM(SupplierEmployeeTaxAmount)          
    FROM    dbo.Commision WITH ( NOLOCK )          
            INNER JOIN supplier WITH ( NOLOCK ) ON commision.supplierid = supplier.supplierid   
   INNER JOIN dbo.SupplierEmployee WITH ( NOLOCK )  
    ON dbo.Commision.SupplierID = dbo.SupplierEmployee.SupplierID          
              AND dbo.Commision.SupplierEmployeeID = dbo.SupplierEmployee.SupplierEmployeeID          
    WHERE   ApplicationId = @ApplicationID          
            AND BranchId = @BranchID          
   AND SupplierEmployeeType = 'P'    
    
    
    SELECT  @SumTaxPersonal = SUM(SupplierTaxAmount)          
           -- + SUM(SupplierEmployeeTaxAmount)          
    FROM    dbo.Commision WITH ( NOLOCK )          
            INNER JOIN supplier WITH ( NOLOCK ) ON commision.supplierid = supplier.supplierid          
    WHERE   ApplicationId = @ApplicationID          
            AND BranchId = @BranchID          
            AND SupplierType = 'P'           
   --end edit fuji    
      --select 'test',  @SumTaxSuppEmployeeForCompany as SumTaxSuppEmployeeForCompany, @SumTaxCompany as SumTaxCompany ,@SumTaxSuppEmployeeForPersonal as SumTaxSuppEmployeeForPersonal,@SumTaxPersonal as SumTaxPersonal  
--EO NOvia          
          
    DECLARE @SupplierType CHAR(1)          
    DECLARE @TotalSupplierTaxAmountPersonal Amount          
    SET @TotalSupplierTaxAmountPersonal = 0    
 --add fuji,12 Des 2022 perbaiki Bugs CR (FMF-3546)  
 DECLARE @TotalSupplierTaxAmountCompany Amount          
    SET @TotalSupplierTaxAmountCompany = 0    
 --end edit fuji       
    SELECT  @SupplierType = suppliertype          
    FROM    supplier WITH ( NOLOCK )          
    WHERE   supplierid = @SupplierID          
          
 --Novia remark, 17062016 : FMF-1515          
    --IF @SupplierType = 'C'          
        --BEGIN          
 --Eo Novia, 17062016    
  
    --Add fuji,12 Des 2022 Perbaiki Bugs CR (FMF-3546) : Karena adanya penambahan SupplierEmployeeType maka tax SupplierEmp yang dulunya hanya personal,sekarang di split antara personal dan company        
  IF ISNULL(@SumTaxCompany, 0) > 0 ----Novia modify, 17062016          
        BEGIN          
            SET @TotalSupplierTaxAmountCompany = @SumTaxCompany  
        END          
               
    SET @SumTaxSuppEmployeeForCompany = ISNULL(@SumTaxSuppEmployeeForCompany,0)          
    SET @SumTaxCompany = ISNULL(@SumTaxCompany, 0)    
         
    IF ISNULL(@SumTaxSuppEmployeeForCompany, 0) > 0          
        BEGIN          
            SET @TotalSupplierTaxAmountCompany = @SumTaxCompany          
                + @SumTaxSuppEmployeeForCompany          
        END     
      
 --end fuji    
   
     
    IF ISNULL(@TotalSupplierTaxAmountCompany, 0) > 0--ISNULL(@SumTaxCompany, 0) > 0  --IF @TotalSupplierTaxAmount > 0  --Novia modify, 17062016          
        BEGIN              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                 )          
            VALUES  ( 'APTAXCO' ,          
                      'C' ,          
                      @TotalSupplierTaxAmountCompany,--@SumTaxCompany , --@TotalSupplierTaxAmount ,--Novia modify, 17062016 --edit fuji,12122022 edit cara ambil taxco         
                      @AgreementNo ,          
                      '-'              
                 )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
        --END --Novia remark, 17062016 : FMF-1515          
    --ELSE          
    IF ISNULL(@SumTaxPersonal, 0) > 0 ----Novia modify, 17062016          
        BEGIN          
            SET @TotalSupplierTaxAmountPersonal = @SumTaxPersonal --@TotalSupplierTaxAmountPersonal + @TotalSupplierTaxAmount --Novia modify, 17062016          
        END          
          
 --Novia add, 17062016 : FMF-1515          
    --SET @SumTaxSuppEmployeeForCompany = ISNULL(@SumTaxSuppEmployeeForCompany, 0) --Remark Fuji,12122022 perbaikan bugs cr fmf-3546   
 SET @SumTaxSuppEmployeeForPersonal = ISNULL(@SumTaxSuppEmployeeForPersonal,0)  --add fuji,12122022 perbaikan bugs cr fmf-3546  
    SET @SumTaxPersonal = ISNULL(@SumTaxPersonal, 0)    
         
    IF ISNULL(@SumTaxSuppEmployeeForPersonal,0)>0--ISNULL(@SumTaxSuppEmployeeForCompany, 0) > 0  --edit fuji,12122022 perbaiki bugs cr (fmf-3546)         
        BEGIN          
            SET @TotalSupplierTaxAmountPersonal = @SumTaxPersonal          
                + @SumTaxSuppEmployeeForPersonal --+ @SumTaxSuppEmployeeForCompany  --edit fuji,12122022 perbaiki Bugs CR (fmf-3546)       
        END            
 --Eo Novia          
          
 /*-------Dessy 26092012 : FMF CR IJON, jika SupplierEmployee nya bukan IJON, bentuk jurnal APINCSPL2--------------          
        jika SupplierEmployee nya adalah IJON, maka bentuk jurnal PREPAIDKMB*/    
  SELECT @IsIJON '@IsIJON'        
    IF @IsIJON = 0          
        BEGIN                 
            IF @TotalSupplierEmployeeIncome > 0          
                BEGIN              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
          )          
                    VALUES  ( 'APINCSPL2' ,          
     'C' ,          
                              @TotalSupplierEmployeeIncome ,          
                             -- - @TotalSupplierEmployeeTaxAmount , --Novia remark, 17062016          
                              @AgreementNo ,          
                              '-'              
          )              
                END          
    --Dessy Add 26092012          
        END          
    ELSE          
        BEGIN          
            IF @CommisionMainSuppEmp > 0          
                BEGIN          
   --APINCSPL2          
                    IF @TotalSupplierEmployeeIncome - @CommisionMainSuppEmp > 0          
                        BEGIN              
                            INSERT  INTO #TempTable          
                                    ( PaymentAllocationID ,          
                                      Post ,          
   Amount ,          
                                      RefDesc ,          
                                      VoucherDesc               
               )          
                            VALUES  ( 'APINCSPL2' ,          
                                      'C' ,          
                                      @TotalSupplierEmployeeIncome          
                                      --- @TotalSupplierEmployeeTaxAmount --Novia remark, 17062016          
                                      - @CommisionMainSuppEmp ,          
                                      @AgreementNo ,          
                                      '-'              
               )              
                        END          
              
   --PREPAIDKMB            
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
             )          
                    VALUES  ( 'PREPAIDKMB' ,          
                              'C' ,          
                              @CommisionMainSuppEmp ,          
                              @AgreementNo ,          
                              '-'              
             )              
                END          
        END          
    /*----------End Dessy 26092012 : FMF CR IJON-----------------*/          
              
              
    IF @TotalSupplierEmployeeTaxAmount > 0          
        BEGIN              
            SET @TotalSupplierTaxAmountPersonal = @TotalSupplierTaxAmountPersonal          
                + @TotalSupplierEmployeeTaxAmount          
--   INSERT INTO #TempTable(              
--    PaymentAllocationID,              
--    Post,              
--    Amount,              
--    RefDesc,               
--    VoucherDesc               
--   ) VALUES (              
--    'APTAXPS',              
--    'C',              
--    @TotalSupplierEmployeeTaxAmount,              
--    @AgreementNo,               
--    '-'              
--   )              
--   if @@error <> 0 goto ExitSP              
--  END              
        END      
    IF @TotalSupplierTaxAmountPersonal > 0          
        BEGIN          
            INSERT  INTO #temptable          
                    ( paymentallocationid ,          
                      post ,          
                      amount ,          
                      refdesc ,          
                      voucherdesc          
                    )          
            VALUES  ( 'APTAXPS' ,          
                      'C' ,          
                      @TotalSupplierTaxAmountPersonal ,          
                      @AgreementNo ,          
                      '-'          
                    )          
            IF @@ERROR <> 0          
                GOTO exitsp          
        END          
    ------------------------end menyamakan dengan versi BII Lisa 20080703          
    IF @ReferenceNameInsuranceIncome + @ReferenceUppingBungaInsuranceIncome          
        + @ReferenceOtherFeeInsuranceIncome          
  + @ReferenceNameProvisionFee > 0 --Aditia FMF-1640 12032018 Tambah @ReferenceNameProvisionFee          
        BEGIN              
            INSERT  INTO #TempTable          
                ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'APINCSPL3' ,          
                      'C' ,          
                      @ReferenceNameInsuranceIncome          
                      + @ReferenceUppingBungaInsuranceIncome          
                      + @ReferenceOtherFeeInsuranceIncome          
       + @ReferenceNameProvisionFee --Aditia FMF-1640 12032018          
                      - -- Added by Albert Ricia on 16 Agustus 2016 (FMF-1515)          
       ( CASE @CalculateTaxMethodSupllier          
                          WHEN 'GR' THEN 0          
                          WHEN 'NE' THEN @ReferenceNameTaxAmount1          
                          ELSE @ReferenceNameTaxAmount1          
                        END ) ,          
       -- End Added          
                      @AgreementNo ,          
                      '-'              
                    )              
              
            IF @@error <> 0          
                GOTO ExitSP              
              
            IF @ReferenceType = 'P'          
                BEGIN               
                    SET @APTAXTYPE = 'APTAXREFPS'              
                END              
            IF @ReferenceType = 'C'          
                BEGIN               
                    SET @APTAXTYPE = 'APTAXREFCO'              
                END              
              
  --ratna 10 mei 2005              
  --insert ke temptable hanya bila amount > 0              
            IF @ReferenceNameTaxAmount1 > 0          
                BEGIN              
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( @APTAXTYPE ,          
                              'C' ,          
                              @ReferenceNameTaxAmount1 ,          
                              @AgreementNo ,          
                              '-'              
                            )              
                    IF @@error <> 0          
                        GOTO ExitSP              
                END              
        END               
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : INSURINC              
-- ratna 17/12 : hanya u/Paid By Customer              
-- nilai didapat dari Premi ke Customer - Premi ke InsCo - komisi yg sudah diberikan              
-------------------------------------------------------------------------------              
          
--Anita, 20150709 tambahan (@IsAssetInsured = 0 AND @LifeInsuranceIncome <> 0)  supaya dapat handle Life Insurance electronic           
    IF ( @InsAssetPaidBy = 'CU'          
         AND @InsAssetInsuredBy = 'CO'          
       )          
        OR ( @IsAssetInsured = 0          
             AND @LifeInsuranceIncome <> 0          
           )  
  --Add Victor 19 oktober 2023 FMF-4676    
     OR (@InsAssetPaidBy = 'CU' AND @InsAssetInsuredBy = 'CU' AND @LifeInsuranceIncome <> 0 )     
     OR (@InsAssetInsuredBy = 'UI' AND @LifeInsuranceIncome <> 0 )    
    --End Victor 19 oktober 2023 FMF-4676    
        BEGIN              
/*David 25jan2010 : diremark dan ganti baru          
 IF  (@PremiumAmountByCust + @AdminFeeToCust + @MeteraiFeeToCust) -                
  (@PremiumAmountToInsCo + @AdminFeeToInsCo + @MeteraiFeeToInsCo) -              
  @TotalInsuranceIncome               
  > 0              
 BEGIN              
                
  INSERT INTO #TempTable(              
   PaymentAllocationID,              
   Post,              
   Amount,              
   RefDesc,               
   VoucherDesc               
              
  ) VALUES (              
   'INSURINC',              
   'C',              
   (@PremiumAmountByCust + @AdminFeeToCust + @MeteraiFeeToCust) - (@PremiumAmountToInsCo + @AdminFeeToInsCo + @MeteraiFeeToInsCo) - @TotalInsuranceIncome,              
   @AgreementNo,               
   '-'              
  )              
  if @@error <> 0 goto ExitSP              
 END              
 ELSE              
 BEGIN              
  INSERT INTO #TempTable(              
   PaymentAllocationID,              
   Post,              
   Amount,              
   RefDesc,               
   VoucherDesc               
              
  ) VALUES (              
   'INSURINC',              
   'D',              
   ((@PremiumAmountByCust + @AdminFeeToCust + @MeteraiFeeToCust) - (@PremiumAmountToInsCo + @AdminFeeToInsCo + @MeteraiFeeToInsCo) - @TotalInsuranceIncome) *-1,              
   @AgreementNo,               
   '-'              
  )              
  if @@error <> 0 goto ExitSP              
 END    */          
          
/*David 25Jan2010 : Bagian yang baru : */          
            DECLARE @PaymentAllocID2 VARCHAR(10)          
    IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'DEFINSINC'          
                        AND assettypeid = @assettypeid          
               ) = 1 --jika DEFINSINC  diamortize          
                AND ( ABS(dbo.FnGetDeferredInsuranceToAmortize(@BranchID,          
                                                              @ApplicationId)+@CreditInsAmountTotal) ) >= ( SELECT          
                                                              AmountMinimum          
                                                              FROM          
                                                              AmortizationMaster          
                                                              WITH ( NOLOCK )          
                                                              WHERE          
                                                              AmortizationID = 'DEFINSINC'          
                                                              AND assettypeid = @assettypeid          
                                                              )          
                BEGIN          
                    SET @PaymentAllocID = 'DEFINSUR'          
                    SET @PaymentAllocID2 = 'INSREXPDEF'           
                END          
            ELSE --jika DEFINSINC  tidak diamortize          
                BEGIN          
                    SET @PaymentAllocID = 'INSURINC'          
                    SET @PaymentAllocID2 = 'INSRCRTEXP'           
                END          
            IF (dbo.FnGetDeferredInsuranceToAmortize(@BranchID, @ApplicationId)) > 0 --edit fuji,12122019 (fmf-1819) tambah @CreditInsAmountTotal, edit Adhitya. 11 Mar 2020 (FMF-1819) hapus @CreditInsAmountTotal          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                  VALUES  ( @PaymentAllocID ,          
                              'C' ,          
                              (dbo.FnGetDeferredInsuranceToAmortize(@BranchID,          
                                                              @ApplicationId)) ,--edit fuji,12122019 (fmf-1819) tambah @CreditInsAmountTotal, edit Adhitya. 11 Mar 2020 (FMF-1819) hapus @CreditInsAmountTotal          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END             
            ELSE          
                IF (dbo.FnGetDeferredInsuranceToAmortize(@BranchID,          
                                                        @ApplicationId)) < 0 --edit fuji,12122019 (fmf-1819) tambah @CreditInsAmountTotal, edit Adhitya. 11 Mar 2020 (FMF-1819) hapus @CreditInsAmountTotal          
                    BEGIN          
                        INSERT  INTO #temptable          
                                ( paymentallocationid ,          
                                  post ,          
                                  amount ,          
                                  refdesc ,          
                                  voucherdesc          
                                )          
                        VALUES  ( @PaymentAllocID2 ,          
                           'D' ,          
                                 ( ( dbo.FnGetDeferredInsuranceToAmortize(@BranchID,          
                                                              @ApplicationId) ) ) --edit fuji,12122019 (fmf-1819) tambah @CreditInsAmountTotal, edit Adhitya. 11 Mar 2020 (FMF-1819) hapus @CreditInsAmountTotal          
                                  * -1 ,          
                                  @AgreementNo ,          
                                  '-'          
                                )          
                        IF @@ERROR <> 0          
                            GOTO exitsp          
                    END          
/*David selesai*/          
 END              
    /*Arif 13 okt 2010 : Tambah pengecekan jika CSTSVYFEE diamortize atau tidak*/           
    ----=======Modified by Arif Sucipto=DI KASIH ERROR SENGAJA=====-------          
    /*Edited by Rudi, 05 Dec 2011          
    IF ( SELECT costofsurvey          
         FROM   dbo.Agreement WITH (NOLOCK)          
         WHERE  ApplicationId = @ApplicationId          
                AND BranchId = @BranchID          
       ) > 0           
        BEGIN          
            UPDATE  Agreement          
            SET     costofsurvey = costofsurvey * -1          
            WHERE   ApplicationId = @ApplicationId          
                    AND BranchId = @BranchID          
                    AND costofsurvey > 0*/  
					        
  --Begin Restu FMF-4862 Remark update ini karena sudah dihandle dengan generator interestportion    
 --   UPDATE  dbo.InstallmentSchedule          
 --   SET     CostOfSurveyFeeAmount = CostOfSurveyFeeAmount * -1          
 --WHERE   ApplicationId = @ApplicationId          
 --           AND BranchId = @BranchID          
 --           AND CostOfSurveyFeeAmount > 0  
 --END Restu FMF-4862        
        --END     
   
---======End Arif===---          
    DECLARE @costofsurveyid1 VARCHAR(10)          
    DECLARE @costofsurveyid2 VARCHAR(10)          
    IF ABS(@CostofSurvey) > 0          
        BEGIN          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'CSTSVYFEE'          
                        AND assettypeid = @assettypeid          
               ) = 1          
                AND ( SELECT    amountminimum          
                      FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'CSTSVYFEE'          
                                AND assettypeid = @assettypeid          
                    ) <= ABS(@CostofSurvey)          
                BEGIN          
                    SET @costofsurveyid1 = 'CSTSVYDEF'          
             
                END          
            ELSE          
                BEGIN          
                    SET @costofsurveyid1 = 'CSTSVYFEE'          
             
                END          
            
            
           
            INSERT  INTO #temptable          
                    ( paymentallocationid ,          
                      post ,          
                      amount ,          
                      refdesc ,          
                      voucherdesc          
                    )          
            VALUES  ( @costofsurveyid1 ,          
                      'D' ,          
                      ABS(@CostofSurvey) ,          
                      @AgreementNo ,          
                      '-'          
                    )          
             
            
            INSERT  INTO #temptable          
                    ( paymentallocationid ,          
                      post ,          
                      amount ,          
                      refdesc ,          
                      voucherdesc          
                    )          
            VALUES  ( 'APCSTSVY' ,          
                      'C' ,          
                      ABS(@CostofSurvey) ,          
                      @AgreementNo ,          
                      '-'          
                    )          
            
        END           
/*David 25jan2010 : */          
    DECLARE @InsuranceDiscountAmount AMOUNT          
    SELECT  @InsuranceDiscountAmount = dbo.Fngetinsurancecommisiontoamortize(@BranchID,          
                                                              @ApplicationId)  
        
    IF @InsuranceDiscountAmount > 0          
        BEGIN          
    --David 25jan2010 : tidak dijurnal lagi jika INSINC dan DEFINSINC tidak di amortize          
    -- arif 11 okt 2010 : edit untuk insurance commision           
  --IF EXISTS( SELECT 1 FROM AmortizationMaster WHERE  AmortizationID IN ('INSINC','DEFINSINC ') AND IsActive=1 AND assettypeid = @assettypeID)           
            IF ( ( SELECT   isactive          
                   FROM     AmortizationMaster WITH ( NOLOCK )          
                   WHERE    AmortizationID = 'INSINC'          
                            AND assettypeid = @assettypeid          
                 ) = 1          
                 AND ( SELECT   AmountMinimum          
                       FROM     AmortizationMaster WITH ( NOLOCK )          
                       WHERE    AmortizationID = 'INSINC'          
                                AND assettypeid = @assettypeid          
                     ) <= ABS(@InsuranceDiscountAmount) ----=======Modified by Arif Sucipto======-------          
               )          
                OR ( ( SELECT   isactive          
                       FROM     AmortizationMaster WITH ( NOLOCK )          
                       WHERE    AmortizationID = 'DEFINSINC'          
      AND assettypeid = @assettypeid          
                     ) = 1          
                     AND ( SELECT   AmountMinimum          
                           FROM     AmortizationMaster WITH ( NOLOCK )          
                           WHERE    AmortizationID = 'DEFINSINC'          
                                    AND assettypeid = @assettypeid          
                         ) <= ABS(dbo.FnGetDeferredInsuranceToAmortize(@BranchID,          
                                                              @ApplicationId))          
                   )          
                BEGIN          
             
             
                    IF ( SELECT IsActive          
                         FROM   AmortizationMaster WITH ( NOLOCK )          
                         WHERE  AmortizationID = 'INSINC'          
                                AND assettypeid = @assettypeID          
                       ) = 1          
                        AND --jika INSINC diamortize          
                        ( SELECT    amountminimum          
                          FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                          WHERE     AmortizationID = 'INSINC'          
                                    AND assettypeid = @assettypeid          
                        ) <= ABS(@InsuranceDiscountAmount)          
                        BEGIN          
                            INSERT  INTO #temptable          
                                    ( paymentallocationid ,          
                                      post ,          
                                      amount ,          
                                      refdesc ,          
                                      voucherdesc          
                                    )          
                            VALUES  ( 'INSRRFDEXP' ,          
                                      'D' ,          
                                      @InsuranceDiscountAmount ,          
                                      @AgreementNo ,          
                                      '-'          
                                    )          
                        END          
                    ELSE --jika INSINC tidak diamortize          
                        BEGIN          
                            INSERT  INTO #temptable          
                                    ( paymentallocationid ,          
                                      post ,          
                                      amount ,          
                                      refdesc ,          
                                      voucherdesc          
                                    )          
                            VALUES  ( 'COMINSEXP' ,          
                                      'D' ,          
                                      @InsuranceDiscountAmount ,          
                                      @AgreementNo ,          
                                      '-'          
                                    )          
                        END          
              
                END           
                
        END          
/*David 25Jan2010 selesai*/          
          
-------------------------------------------------------------------------------              
-- Journal -- (Life Insurance)              
-- Emilia 9/2/06 : LFINSURINC              
-- nilai didapat dari Premi ke Customer - Premi ke InsCo - komisi yg sudah diberikan              
-------------------------------------------------------------------------------              
 /* Remark by Benny, 29 juni 2015 FMF-1422  Life Insurance          
    IF @PaidBy = 'CU'          
        AND @InsuredBy = 'CO'           
        BEGIN              
            PRINT 'CU'              
            IF ( @Premium + @LifeAdminFee + @LifeStampDutyFee )          
                - ( @PremiumToInsCo + @LifeAdminFee + @LifeStampDutyFee )          
                - @TotalInsuranceIncome > 0           
       BEGIN              
               
                    INSERT  INTO #TempTable          
                            (          
                              PaymentAllocationID,          
                     Post,          
                              Amount,          
                              RefDesc,          
                              VoucherDesc               
              
                            )          
                    VALUES  (          
                              'LFINSURINC',          
                              'C',          
                              ( @Premium + @LifeAdminFee + @LifeStampDutyFee )          
                              - ( @PremiumToInsCo + @LifeAdminFee          
                                  + @LifeStampDutyFee )          
                              - @TotalInsuranceIncome,          
                              @AgreementNo,          
                              '-'              
                            )              
                    IF @@error <> 0           
                        GOTO ExitSP              
                END              
            ELSE           
                IF ( @Premium + @LifeAdminFee + @LifeStampDutyFee )          
                    - ( @PremiumToInsCo + @LifeAdminFee + @LifeStampDutyFee )          
                    - @TotalInsuranceIncome < 0 --David 25Jan2010 : tambah pengecekan supaya jika 0 tdk masuk jurnal          
                    BEGIN              
                        INSERT  INTO #TempTable          
                                (          
                                  PaymentAllocationID,          
                                  Post,          
                                  Amount,          
                                  RefDesc,          
                                  VoucherDesc               
              
                                )          
                        VALUES  (          
                                  'LFINSURINC',          
                                  'D',          
                                  ( ( @Premium + @LifeAdminFee          
                                      + @LifeStampDutyFee )          
                                    - ( @PremiumToInsCo + @LifeAdminFee          
                                        + @LifeStampDutyFee )          
                                    - @TotalInsuranceIncome ) * -1,          
                                  @AgreementNo,          
                                  '-'              
                                )              
                        IF @@error <> 0           
                            GOTO ExitSP              
                    END              
        END              
              
    */          
              
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : APSUPPLIER              
-------------------------------------------------------------------------------              
    DECLARE @POTotal amount              
              
    SELECT  @POTotal = SUM(POTotal)          
    FROM    PurchaseOrder WITH ( NOLOCK )          
    WHERE   BranchID = @BranchID          
            AND ApplicationID = @ApplicationID               
--Johnson, 15 Juli 2005 @TDPAmount Sudah Termasuk Dalam @POTotal               
--IF @POTotal+ @ContractPrepaidAmount > 0               
          
    IF @POTotal > 0          
        BEGIN              
  --Anita, 20150710 FMF-1427 tambah pengecekan @TransferApDisb          
            IF ( @TransferApDisb = 'C' )          
                BEGIN          
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
      )          
                    VALUES  ( 'APCustLB' ,          
                              'C' ,          
                              @POTotal ,              
     --@POTotal+ @ContractPrepaidAmount,              
                              @AgreementNo ,          
                              '-'              
                   )               
                    IF @@error <> 0          
                        GOTO ExitSP           
            
                END          
            ELSE          
                BEGIN          
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'APSUPPLIER' ,          
                              'C' ,          
                              @POTotal ,              
     --@POTotal+ @ContractPrepaidAmount,              
                              @AgreementNo ,          
                              '-'              
                   )               
                    IF @@error <> 0          
                        GOTO ExitSP           
                END          
                         
        END              
          
 --arinta, 28 des 2015, fmf-1465          
           
    IF @AddOtherFee > 0          
        BEGIN              
            IF ( @TransferApDisb = 'C' )          
                BEGIN          
                 INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'APBRANCHCS' ,          
                              'C' ,          
                              @AddOtherFee ,          
                              @AgreementNo ,          
                              '-'              
                   )               
                    IF @@error <> 0          
                        GOTO ExitSP           
            
                END          
            ELSE          
                BEGIN          
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'APBRANCH' ,          
                              'C' ,          
                              @AddOtherFee ,          
      @AgreementNo ,          
                              '-'              
                   )               
                    IF @@error <> 0          
                        GOTO ExitSP           
                END          
                         
        END              
    --end arinta          
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : ECI              
------------------------------------------------------------------------------            
--Remark by Gema, 20101008 : Pindain cek amortisasinya kedalam if karena ada tambahan cek minimumamount            
--/*David, 25Jan2010 : Tambahkan pengecheck-an amortisasi*/          
--DECLARE @subsidyID VARCHAR(20), @refundID VARCHAR(20)          
--IF ( SELECT IsActive FROM AmortizationMaster WHERE  AmortizationID = 'DIFFRATE' AND assettypeid = @assettypeID) = 1 --jika DIFFRATE    diamortize          
--BEGIN          
-- SET @subsidyID='RATESSIDY'          
-- SET @refundID='RATERFND'          
--END          
--ELSE --jika DEFINSINC  tidak diamortize          
--BEGIN          
-- SET @subsidyID='SSIDYINC'          
-- SET @refundID='RFNDEXP'          
--END          
--/*David 25Jan2010 selesai*/          
          
    DECLARE @subsidyID VARCHAR(20) ,          
        @refundID VARCHAR(20)          
          
        
  
    IF @EffectiveRate < @SupplierRate          
        AND @DiffRateAmount <> 0 -- Subsidy              
    --===============================ubah mul          
        BEGIN              
  
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'DIFFRATE'          
                        AND assettypeid = @assettypeID          
               ) = 1 --jika DIFFRATE    diamortize          
                AND ( SELECT    AmountMinimum          
                      FROM      AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'DIFFRATE'          
                                AND assettypeid = @assettypeID          
                    ) <= ABS(@DiffRateAmount)          
                BEGIN          
                    SET @subsidyID = 'RATESSIDY'          
                    SET @refundID = 'RATERFND'          
                END          
            ELSE --jika DEFINSINC  tidak diamortize          
                BEGIN          
                    SET @subsidyID = 'SSIDYINC'          
                    SET @refundID = 'RFNDEXP'          
                END          
          
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( --'ECISSIDY',              
  -- 'ECISSIDYAR',              
                      @subsidyID ,--'RATESSIDY',  --David 25Jan2010          
                      'C' ,          
                      @DiffRateAmount * -1 ,          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
              
-- ratna 17 dec              
-- dulu ECI, skrg diganti jadi ECIRFND              
    IF @EffectiveRate > @SupplierRate          
        AND @TotalUppingBungaFee > 0 -- Refund              
        BEGIN              
              
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'DIFFRATE'          
                        AND assettypeid = @assettypeID          
               ) = 1 --jika DIFFRATE    diamortize          
                AND ( SELECT    AmountMinimum          
                      FROM      AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'DIFFRATE'          
                                AND assettypeid = @assettypeID          
                    ) <= ABS(@TotalUppingBungaFee)          
                BEGIN          
                    SET @subsidyID = 'RATESSIDY'          
                    SET @refundID = 'RATERFND'          
                END          
            ELSE --jika DEFINSINC  tidak diamortize          
                BEGIN          
                    SET @subsidyID = 'SSIDYINC'          
                    SET @refundID = 'RFNDEXP'          
                END             
              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( -- Yovita 19 Okt 2007: ubah paymentallocationid dari ECIRFNDAR jadi RATERFND untuk samain dengan KITAF            
  --'ECIRFNDAR',            
                      @refundID ,--'RATERFND',  --David 25Jan2010          
                      'D' ,          
             @TotalUppingBungaFee ,          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
--=========28052008 kasus elektronik jika subsidy di set di product LELE BEGIN          
    IF @TotalUppingBungaFee > 0          
        AND @EffectiveRate = @SupplierRate -- Refund              
        BEGIN             
          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'DIFFRATE'          
                        AND assettypeid = @assettypeID          
               ) = 1 --jika DIFFRATE    diamortize          
                AND ( SELECT    AmountMinimum          
                      FROM      AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'DIFFRATE'          
                                AND assettypeid = @assettypeID          
                    ) <= ABS(@TotalUppingBungaFee)          
                BEGIN          
                    SET @subsidyID = 'RATESSIDY'          
                    SET @refundID = 'RATERFND'          
                END          
            ELSE --jika DEFINSINC  tidak diamortize          
                BEGIN          
                    SET @subsidyID = 'SSIDYINC'          
                    SET @refundID = 'RFNDEXP'          
                END              
              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
  RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( -- Yovita 19 Okt 2007: ubah paymentallocationid dari ECIRFNDAR jadi RATERFND untuk samain dengan KITAF            
  --'ECIRFNDAR',            
                      @refundID ,--'RATERFND',  --David 25Jan2010           
                      'D' ,          
                      @TotalUppingBungaFee ,          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
              
    IF @TotalUppingBungaFee < 0          
        AND @EffectiveRate = @SupplierRate -- Subsidy              
        BEGIN           
          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'DIFFRATE'          
                        AND assettypeid = @assettypeID          
               ) = 1 --jika DIFFRATE    diamortize          
                AND ( SELECT    AmountMinimum          
                      FROM      AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'DIFFRATE'          
                                AND assettypeid = @assettypeID          
                    ) <= ABS(@TotalUppingBungaFee)          
                BEGIN          
                    SET @subsidyID = 'RATESSIDY'          
                    SET @refundID = 'RATERFND'          
                END          
            ELSE --jika DEFINSINC  tidak diamortize          
                BEGIN          
                    SET @subsidyID = 'SSIDYINC'          
                    SET @refundID = 'RFNDEXP'          
                END                
              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
              VoucherDesc               
                    )          
            VALUES  ( -- Yovita 19 Okt 2007: ubah paymentallocationid dari ECIRFNDAR jadi RATERFND untuk samain dengan KITAF            
  --'ECIRFNDAR',            
                      @subsidyID ,--'RATESSIDY',  --David 25Jan2010          
                      'C' ,          
                      @TotalUppingBungaFee * -1 ,          
                      @AgreementNo ,          
                      '-'              
                    )              
       IF @@error <> 0          
                GOTO ExitSP              
        END            
--=========28052008 kasus elektronik jika subsidy di set di product LELE END          
/*David 17Des2009 : diganti sebagai other refund          
-------------------------------------------------------------------------------              
-- Journal --              
-- Widi  23/09 : COMMEXP              
-- ratna 17/12 : skrg dibedakan untuk Supplier COMMEXP1, Salesman COMMEXP2, dan Referantor COMMEXP3              
-------------------------------------------------------------------------------              
If  isnull(@SupplierOtherFeeIncome1,0) + isnull(@SupplierOtherFeeIncome2,0) + isnull(@SupplierOtherFeeIncome3,0) > 0              
BEGIN              
              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'COMMEXP1',              
  'D',              
  isnull(@SupplierOtherFeeIncome1,0) + isnull(@SupplierOtherFeeIncome2,0) + isnull(@SupplierOtherFeeIncome3,0),               
  @AgreementNo,               
  '-'              
 )              
 if @@error <> 0 goto ExitSP              
END              
              
If  isnull(@SupplierEmployeeOtherFeeIncome1,0) + isnull(@SupplierEmployeeOtherFeeIncome2,0) + isnull(@SupplierEmployeeOtherFeeIncome3,0) > 0              
BEGIN              
              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'COMMEXP2',              
  'D',              
  isnull(@SupplierEmployeeOtherFeeIncome1,0) + isnull(@SupplierEmployeeOtherFeeIncome2,0) + isnull(@SupplierEmployeeOtherFeeIncome3,0),               
  @AgreementNo,               
  '-'               
 )              
 if @@error <> 0 goto ExitSP              
END              
              
If  isnull(@ReferenceOtherFeeInsuranceIncome,0) > 0              
BEGIN              
 INSERT INTO #TempTable(              
  PaymentAllocationID,              
  Post,              
  Amount,              
  RefDesc,               
  VoucherDesc               
 ) VALUES (              
  'COMMEXP3',              
  'D',              
  isnull(@ReferenceOtherFeeInsuranceIncome,0),               
  @AgreementNo,               
  '-'              
 )              
 if @@error <> 0 goto ExitSP              
END              
David selesai remark */          
/*David 25Jan2010 : bagian baru sebagai pengganti COMMXP 1, 2, DAN 3*/          
    IF (@TotalOtherFee + dbo.FnGetProvisionFeeToAmortize(@BranchID, @ApplicationID)) > 0 --Aditia FMF-1640 13032018 Tambah dbo.FnGetProvisionFeeToAmortize(@BranchID, @ApplicationID)          
        BEGIN          
            IF ( SELECT IsActive          
                 FROM   AmortizationMaster WITH ( NOLOCK )          
                 WHERE  AmortizationID = 'REFOTHR'          
                        AND assettypeid = @assettypeID          
               ) = 1          
                AND ( SELECT    amountminimum          
                      FROM      dbo.AmortizationMaster WITH ( NOLOCK )          
                      WHERE     AmortizationID = 'REFOTHR'          
                                AND assettypeid = @assettypeid          
                    ) <= ABS(@TotalOtherFee  + dbo.FnGetProvisionFeeToAmortize(@BranchID, @ApplicationID)) ----=======Modified by Arif Sucipto======------- ;Aditia FMF-1640 13032018 Tambah dbo.FnGetProvisionFeeToAmortize(@BranchID, @ApplicationID)       
  
   
  --jika REFOTHR    diamortize          
                BEGIN      
     --Added by Candra 9 Nov 2020 [FMF-2451]: hitung jika provision fee nya di amortisasi atau tidak    
     DECLARE @Amount NUMERIC(17,2)    
     IF ( SELECT IsActive          
       FROM   AmortizationMaster WITH ( NOLOCK )          
       WHERE  AmortizationID = 'PROVFEE'          
        AND assettypeid = @assettypeID          
        ) = 1    
      BEGIN    
       SET @Amount = ISNULL(@TotalOtherFee, 0) + dbo.FnGetProvisionFeeToAmortize(@BranchID, @ApplicationID)    
      END    
     ELSE    
      BEGIN    
       SET @Amount = ISNULL(@TotalOtherFee, 0)    
      END    
     --End Candra    
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
                              amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'COMOTHDEF' ,          
                              'D' ,          
         --Modified by Candra 9 Nov 2020 [FMF-2451]: tambah penjagaan    
                              --ISNULL(@TotalOtherFee, 0) + dbo.FnGetProvisionFeeToAmortize(@BranchID, @ApplicationID), --Aditia FMF-1640 12032018 Tambah function provisionfee          
         @Amount,    
         --End Candra    
                              @AgreementNo ,          
                           '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
            ELSE          
                BEGIN          
                    INSERT  INTO #temptable          
                            ( paymentallocationid ,          
                              post ,          
             amount ,          
                              refdesc ,          
                              voucherdesc          
                            )          
                    VALUES  ( 'COMOTHEXP' ,          
                              'D' ,          
                ISNULL(@TotalOtherFee, 0),          
                              @AgreementNo ,          
                              '-'          
                            )          
                    IF @@ERROR <> 0          
                        GOTO exitsp          
                END          
        END          
          
/*David bagian baru selesai*/          
          
-------------------------------------------------------------------------------              
-- Journal --              
-- Dessy 31082012 : APVOUCHER               
------------------------------------------------------------------------------            
    IF @TotalOtherFee > 0          
        BEGIN          
            INSERT  INTO #temptable          
                    ( paymentallocationid ,          
                      post ,          
                      amount ,          
                      refdesc ,          
                      voucherdesc          
                    )          
            VALUES  ( 'APVOUCHER' ,          
                      'C' ,          
                      ISNULL(@TotalOtherFee, 0) ,          
                      @AgreementNo ,          
                      '-'          
                    )          
            IF @@ERROR <> 0          
                GOTO exitsp          
        END          
----- End Dessy 31082012          
          
-------------------------------------------------------------------------------              
-- Journal --             
-- MUL 13/06/2008 : RATEINEXP               
------------------------------------------------------------------------------              
--Add Eka 09 Januari 2019 FMF-1761          
select @InterestExpenseAmount = InterestExpenseAmount from Agreement with(nolock) where BranchID=@BranchID and ApplicationID = @ApplicationID          
--End Eka          
    IF @InterestExpenseAmount > 0  -- interestExpense              
        BEGIN              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'RATEINEXP' ,          
                      'D' ,          
                      @InterestExpenseAmount ,          
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
 --Add Eka 09 Januari 2019 FMF-1761          
 ELSE IF @InterestExpenseAmount < 0              
  BEGIN          
    INSERT  INTO #TempTable          
      ( PaymentAllocationID ,          
        Post ,          
        Amount ,          
        RefDesc ,          
        VoucherDesc               
      )          
    VALUES  ( 'RATEINEXP' ,          
        'C' ,          
        ABS(@InterestExpenseAmount),          
        @AgreementNo ,          
        '-'              
      )              
    IF @@error <> 0          
     GOTO ExitSP             
  END          
  --End Eka          
          
--Gema, 20081016 : Pindain OTHERINC dibawah 'RATEINEXP'          
---------------------------------            
-- Tambah Other Income         --            
-- Gema, 2 Oktober 2007        --            
---------------------------------            
    DECLARE @Debit NUMERIC(17, 2) ,          
        @Credit NUMERIC(17, 2) ,          
        @AmountJournal NUMERIC(17, 2) ,          
        @Rounded NUMERIC(17, 2) ,          
        @post CHAR(1)            
            
    SELECT  @Rounded = Rounded          
    FROM    Currency WITH ( NOLOCK )          
    WHERE   CurrencyID = @CurrencyID                  
            
    SELECT  @Debit = SUM(Amount)          
    FROM    #TempTable          
    WHERE   post = 'D'            
    SELECT  @Credit = SUM(Amount)          
    FROM    #TempTable          
    WHERE   post = 'C'            
            
    IF ( @Debit <> @Credit )          
        BEGIN            
            IF ( @Debit - @Credit ) >= 0          
                BEGIN                  
             SET @post = 'C'                  
                    SET @AmountJournal = @Debit - @Credit            
                END                 
            ELSE          
                BEGIN                  
                    SET @post = 'D'                  
                    SET @AmountJournal = -1 * ( @Debit - @Credit )            
                END                 
                    
            IF ( @AmountJournal <= @Rounded )          
                BEGIN             
          
 --revised by Andy 29 Mei 2008 : mencegah agar proses insert tetap dapat dijalankan untuk OTHERINC          
                    SET @strTemp = LTRIM(RTRIM(@AgreementNo)) + '#'          
                        + LTRIM(RTRIM(@CustomerName))          
               
                    INSERT  INTO #TempTable          
                            ( PaymentAllocationID ,          
                              Post ,          
                              Amount ,          
                              RefDesc ,          
                              VoucherDesc               
                            )          
                    VALUES  ( 'OTHERINC' ,          
                              @post ,          
                              @AmountJournal ,          
                              @strTemp ,          
                              '-'              
                            )              
                    IF @@error <> 0          
BEGIN            
                            GOTO ExitSP              
                        END             
                END            
            
                  
        END                
          
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : spProcessCreateJournal              
-------------------------------------------------------------------------------         
    SELECT  *          
    FROM    #temptable           
                 
--select * from installmentschedule where applicationid = @ApplicationID           
    EXEC @error = spProcessCreateJournal @CompanyID, @BranchID, 'ACT',          
        @BusinessDate, @EffectiveDate, @AgreementNo, @ApplicationID, 'O', '',          
        0, @CurrencyID, @CurrencyRate, 1, @Tr_Nomor OUTPUT              
          
    IF @error <> 0          
        GOTO ExitSP              
              
--===============================================================================================              
--ADD BY Gema, 25 September 2007 : Update GLJournalD untuk paymentallocation ARBNK dari FundingCoy              
--==============================              
--select * from #TempTable              
--==============================              
              
    DECLARE @COAAR VARCHAR(25)              
              
    SELECT  @COAAR = COAAR          
    FROM    FundingCoy WITH ( NOLOCK )          
            INNER JOIN Agreement WITH ( NOLOCK ) ON FundingCoy.FundingCoyID = Agreement.FundingCoyID          
    WHERE   Agreement.BranchID = @BranchID          
            AND Agreement.ApplicationID = @ApplicationID              
              
--=========================              
--print @COAAR              
--print @tr_nomor              
--=========================              
              
    UPDATE  GLJOURNALD          
    SET     COAID = @COAAR          
    WHERE   tr_nomor = @tr_nomor          
            AND PaymentAllocationID = 'ARBNK'              
    IF @error <> 0          
        GOTO ExitSP               
              
    --SELECT  *          
    --FROM    GLJournalH          
    --WHERE   tr_nomor = @Tr_Nomor              
    --SELECT  *          
    --FROM    GLJournalD          
    --WHERE   tr_nomor = @Tr_Nomor               
--===============================================================================================              
              
-------------------------------------------------------------------------------              
-- ratna 22/12/2004              
-- Update field COA ID di tbl GLJournalD, untuk transaksi AP to InsCo              
-- COA diambil dari tbl InsuranceCoyBranch      
-------------------------------------------------------------------------------              
    UPDATE  GLJournalD          
    SET     COAID = @AccountGL          
    WHERE   Tr_Nomor = @Tr_Nomor          
            AND PaymentAllocationID = 'APINSUR'              
    IF @error <> 0          
        GOTO ExitSP               
               
-------------------------------------------------------------------------------          
-- Adhitya 11/06/2020 FMF-2220              
-- Update Field COAID di tbl GLJournalD, untuk transaksi Credit Insurance          
-- COA diambil dari table CreditInsuranceCoyBranch          
-------------------------------------------------------------------------------          
 DECLARE @AccountCredIns varchar(25)          
 SELECT @AccountCredIns = cicb.AccountGL   
 FROM dbo.CreditInsuranceData cid with(nolock)          
   INNER JOIN dbo.CreditInsuranceCoyBranch cicb with(nolock)   
    ON cid.CreditInsuranceCoyID = cicb.CreditInsuranceCoyID          
    AND cid.CreditInsuranceCoyBranchID = cicb.CreditInsuranceCoyBranchID          
 WHERE cid.BranchID = @BranchID AND cid.ApplicationID = @ApplicationID          
          
 UPDATE GLJournalD          
 SET  GLJournalD.COAID = isnull(@AccountCredIns,'')          
 FROM GLJournalD          
 WHERE Tr_Nomor = @Tr_Nomor        
   AND PaymentAllocationID = 'APCRDINS'          
  
 IF @error <> 0          
  GOTO ExitSP          
      
 ---Candra, 29 April 2021 [FMF-2748] : Remark update COA INSREXPDEF, karena pas accrued on due dan on eom masih pakai journalscheme  
 --UPDATE GLJournalD          
 --SET  GLJournalD.COAID = isnull(@AccountCredIns,'')          
 --from GLJournalD          
 --WHERE Tr_Nomor = @Tr_Nomor          
 --  AND PaymentAllocationID = 'INSREXPDEF'    
           
 --IF @error <> 0          
 -- GOTO ExitSP   
 ---End Candra [FMF-2748]         
          
-------------------------------------------------------------------------------              
-- emilia 9/2/06 (untuk life insurance)              
-- Update field COA ID di tbl GLJournalD, untuk transaksi AP to InsCo              
-- COA diambil dari tbl LifeInsuranceCoyBranch              
-------------------------------------------------------------------------------              
              
              
    UPDATE  GLJournalD          
    SET     COAID = @AccountGLLifeIns --Modif Eka 09 Januari 2019 FMF-1763 ubah dari @AccountGL jadi @AccountGLLifeIns          
    WHERE   Tr_Nomor = @Tr_Nomor          
            AND PaymentAllocationID = 'APLFINSUR'              
    IF @error <> 0          
        GOTO ExitSP               
               
          
    IF @FirstInstallment = 'AD'          
        BEGIN              
 -------------------------------------------------------------------------------              
 -- ratna 02/11/2004              
 -- u/payment history              
 -- tambahkan alokasi INSTALLRCV              
 -------------------------------------------------------------------------------            
            DECLARE @FirstPrincipal NUMERIC(17, 2)            
            
            SELECT  @FirstPrincipal = SUM(PrincipalAmount)          
            FROM    installmentSchedule WITH ( NOLOCK )          
            WHERE   applicationid = @ApplicationID          
                    AND BranchID = @BranchID          
                    AND InsSeqNo <= @NumofAdvanceInstallment      
       
     
              
            INSERT  INTO #TempTable          
                    ( PaymentAllocationID ,          
                      Post ,          
                      Amount ,          
                      RefDesc ,          
                      VoucherDesc               
                    )          
            VALUES  ( 'INSTALLRCV' ,          
                      'C' ,          
                      @FirstPrincipal ,              
   --@InstallmentAmount * @NumofAdvanceInstallment,               
                      @AgreementNo ,          
                      '-'              
                    )              
            IF @@error <> 0          
                GOTO ExitSP              
              
 -------------------------------------------------------------------------------              
 -- ratna 02/11/2004              
 -- ARGROSS ditambahkan dengan INSTALLRCV          
 -------------------------------------------------------------------------------              
 -- Gema, 2 September 2007 : Ubah TempTable tampa Funding            
            SELECT  @ARGross = SUM(InstallmentAmount) ,          
                    @TotalInterest = SUM(InterestAmount)          
            FROM    InstallmentSchedule WITH ( NOLOCK )          
            WHERE   BranchID = @BranchID          
                    AND ApplicationID = @ApplicationID             
  --15052008 MUL BEGIN             
            IF @ARGross < 0          
                BEGIN           
                    SET @ARGross = @ARGross * -1          
                END              
 --15052008 MUL END           
            UPDATE  #TempTable          
            SET     Amount = @ARGross          
            WHERE   PaymentAllocationID = 'ARGROSS'              
            IF @@error <> 0          
                BEGIN             
                    GOTO ExitSP              
                END            
            
         UPDATE  #TempTable          
            SET     Amount = @TotalInterest          
            WHERE   PaymentAllocationID = 'UCI'              
            IF @@error <> 0          
                BEGIN             
                    GOTO ExitSP              
                END              
               
            DELETE  FROM #TempTable          
            WHERE   PaymentAllocationID = 'ARBNK'          
                    OR PaymentAllocationID = 'OTHERINC'            
            IF @@error <> 0          
                BEGIN             
                    GOTO ExitSP              
                END              
            
            SELECT  @Debit = SUM(Amount)          
            FROM    #TempTable          
            WHERE   post = 'D'            
            SELECT  @Credit = SUM(Amount)          
         FROM    #TempTable          
            WHERE   post = 'C'            
            
            IF ( @Debit <> @Credit )          
                BEGIN            
                    IF ( @Debit - @Credit ) >= 0          
                        BEGIN                  
                            SET @post = 'C'                  
                            SET @AmountJournal = @Debit - @Credit            
                        END                 
                    ELSE          
                        BEGIN                  
                            SET @post = 'D'                  
                            SET @AmountJournal = -1 * ( @Debit - @Credit )            
                        END                 
                    
                    IF ( @AmountJournal <= @Rounded )          
                        BEGIN          
                    
                            INSERT  INTO #TempTable          
                                    ( PaymentAllocationID ,          
                                      Post ,          
                                      Amount ,          
                                      RefDesc ,          
                                      VoucherDesc               
                                    )          
                            VALUES  ( 'OTHERINC' ,          
                                      @post ,          
                                      @AmountJournal ,          
                                      @strTemp ,          
                                      '-'              
                                    )              
                            IF @@error <> 0          
                                BEGIN            
                                    GOTO ExitSP              
                                END             
                        END            
                END            
            
            
        END              
             
    --SELECT  *          
    --FROM    dbo.GLJournalD          
    --WHERE   Tr_Nomor = @Tr_Nomor           
-------------------------------------------------------------------------------              
-- ratna 02/11/2004              
-- u/advance installment,               
-- bila tbl installmentschedule sudah diupdate paidamount dan paiddate nya,               
-- maka proses payment history akan salah, krn dia anggap 2 angsuran yg advance itu sudah dibayar              
-- untuk itu, paid amount dan paid date harus dikosongkan dulu sebelum payment history              
-------------------------------------------------------------------------------              
    IF @FirstInstallment = 'AD'          
        BEGIN              
            UPDATE  InstallmentSchedule          
            SET     PaidAmount = 0 ,          
                    PaidDate = NULL          
            WHERE   ( BranchID = @BranchID )          
                    AND ( ApplicationID = @ApplicationID )              
            IF @@error <> 0          
                GOTO ExitSP              
        END              
              
              
-- Tendi 20 June 2007---------------------------------------------------              
-- Update Installment Untuk Channeling dan Join Finance yang Off BalanceSheet dan Before GoLIve              
-- Perbaikan untuk isAdvance          
       
    IF @CoyPortion > 0          
        BEGIN              
            IF ( ( SELECT   IsAdvance          
                   FROM     FundingContract WITH ( NOLOCK )          
                   WHERE    FundingCoyID = @FundingCoyID          
                            AND FundingContractNo = @FundingContractNo          
                 ) = '1' )          
                BEGIN              
                    UPDATE  InstallmentSchedule          
                    SET     fUNDINGcOYpORTION = @CoyPortion          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )              
                END              
            ELSE          
                BEGIN              
                    UPDATE  InstallmentSchedule          
                    SET     fUNDINGcOYpORTION = @CoyPortion          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )          
                            AND InsSeqNo > @NumofAdvanceInstallment              
                END              
        END              
              
         
    EXECUTE @Error = spProcessCreatePaymentHistory @BranchID, @ApplicationID,          
        @BusinessDate, @EffectiveDate, '-', '-', 0, 0, '', '', 'CP', 'GOLIVE',          
        0, @Tr_Nomor, '', @HistorySequenceNo OUTPUT              
    IF @Error <> 0          
        GOTO ExitSP              
                
-------------------------------------------------------------------------------              
-- ratna 02/11/2004              
-- setelah proses payment history, maka untuk advance installment,               
-- tbl installmentschedule akan diupdate kembali paidamount dan paiddate nya              
-------------------------------------------------------------------------------              
    SET @CtrNo = 1               
    IF @FirstInstallment = 'AD'          
        BEGIN              
            WHILE @CtrNo < = @NumofAdvanceInstallment          
                BEGIN              
                    UPDATE  InstallmentSchedule          
                    SET PaidAmount = @FirstPrincipal ,--@InstallmentAmount,               
                            PaidDate = @EffectiveDate          
                    WHERE   ( BranchID = @BranchID )          
                            AND ( ApplicationID = @ApplicationID )          
                            AND ( InsSeqNo = @CtrNo )              
                    SET @CtrNo = @CtrNo + 1               
                    IF @@error <> 0          
                        GOTO ExitSP              
                END              
        END              
                
-------------------------------------------------------------------------------              
-- Journal --              
-- ratna 05/09 : Update Tr_Nomor di tbl Agreement              
-- Yovita Jan 25 2006 : Update CurrencyRate Di tblAgreement dari table Currency              
-------------------------------------------------------------------------------              
    UPDATE  Agreement          
    SET     Tr_Nomor = @Tr_Nomor ,          
            CurrencyRate = @CurrencyRate       
    WHERE   ( BranchID = @BranchID )          
            AND ( ApplicationID = @ApplicationID )              
    IF @@error <> 0          
        GOTO ExitSP            
  
        
  
-- Vincenza FMF-2705 22032022  
 declare @TotalIJON int, @TotalAllocIjon numeric(17,2), @CountIjon int,  
   @LCInstIjon numeric(17,2), @InstDueIjon numeric(17,2), @TotalAmtIjon numeric(17,2), @APNo varchar(20),  
  @APType VARCHAR(10), @PaymentTypeID VARCHAR(2), @AccountNameTo VARCHAR(50),@AccountNoTo VARCHAR(50),@BankNameTo VARCHAR(50),  
  @BankBranchTo VARCHAR(50), @BankAccountID VARCHAR(10), @PaymentVoucherNo TransactionNo, @PVNotes VARCHAR(100),   
  @DisbAppUpdateError VARCHAR(100) = '', @APAmountIjon numeric(17,2), @RcvFrom varchar(50), @countIjonD int, @HistSeqNoIJON smallint, @isOpen bit  
   
 if @FlagIjon = 1   
 begin   
  select @IJONAllocationID = IJONAllocationID, @TotalAllocIjon = TotalAllocation, @APAmountIjon = APAmount from AgreementIJONAllocation with (nolock)  
  where ApplicationID = @ApplicationID   
  
  select @countIjonD = ISNULL(count(''),0) from AgreementIJONAllocationDetail with (nolock)  
  where IJONAllocationID = @IJONAllocationID   
  
  if @countIjonD > 0 and @TotalAllocIjon > 0  
  begin  
   select @APNo = AccountPayableNo from AccountPayable with (nolock)  
   where ApplicationID = @ApplicationID and APType='SPPL' and APTo <> 'To Branch'  
  
   IF @@error <> 0          
   GOTO ExitSP  
  
   update AgreementIJONAllocation  
   set AccountPayableNo = @APNo   
   where ApplicationID = @ApplicationID  
  
   set @BankAccountID = 'BANKIJON'  
  
   SELECT  @BankNameTo = BankNameTo  
      , @BankBranchTo = BankBranchTo  
      , @APType = APType  
      , @APDueDate = DueDate  
      , @PaymentTypeID = PaymentTypeDefault  
      , @APTo = APTo  
      , @PaymentLocation = PaymentLocation  
      , @AccountNameTo = AccountNameTo  
      , @AccountNoTo = AccountNoTo   
      , @CurrencyID = CurrencyID   
   FROM  AccountPayable WITH (NOLOCK)  
   WHERE  AccountPayableNo = @APNo  
     
   /*  
   exec spCheckCashier @loginid = 'CSHIJON', @BranchID = '999', @BusinessDate = @BusinessDate, @isOpen = @isOpen OUTPUT  
  
   if @isOpen = 0   
   begin  
    exec spCashierTransactionOpen @cashierid = 'CSHIJON', @branchId = @PaymentLocation, @businessdate = @businessdate, @openingamount = 0, @currencyid = @CurrencyID  
    IF @@error <> 0          
    GOTO ExitSP  
   end  
   */  
   

  
   EXEC dbo.spAPSaveToPV  @PaymentLocation  
         , @BusinessDate   
         , @APDueDate  
         , @ApplicationID  
         , @APAmountIjon  
         , @APType  
         , @APTo  
         , @AccountNameTo  
         , @AccountNoTo  
         , @BankNameTo  
         , @BankBranchTo  
         , @CurrencyID  
         , 'BANKIJON'  
         , @PaymentTypeID  
         , 'CSHIJON'  
         , @PaymentVoucherNo OUTPUT;  
    
   IF @@error <> 0          
   GOTO ExitSP  
  
   EXEC spAPSaveToPVItem  @PaymentLocation  
          , @PaymentVoucherNo  
          , @APNo  
          , @BusinessDate   
          , @APAmountIjon  
          , @TotalAllocIjon ;  
    
   IF @@error <> 0          
   GOTO ExitSP  
  
   set @PVNotes = 'IJON ' + @APNo  
  
   EXEC spAPDisbAppUpdate @PaymentLocation  
         , @PaymentVoucherNo  
         , 'A'  
         , @PVNotes  
         , 'CSHIJON'  
         , @BusinessDate   
         , 'A'  
         , @DisbAppUpdateError OUTPUT  
  
   IF (@DisbAppUpdateError <> '')   
   GOTO ExitSP  
  
   if exists (select '' from #Temptable with (nolock))  
   drop table #TempTable  
  
   EXEC spAPDisbCashUpdate @PaymentLocation  
         , @PaymentVoucherNo  
         , @BankAccountID  
         , 'None'  
         , 'P'  
         , @AccountNameTo  
         , @PVNotes  
         , 'CSHIJON'  
         , @BusinessDate   
         , @PaymentTypeID  
         , @TotalAllocIjon  
         , @APType  
         , @CurrencyID  
         , 1  
         , @BusinessDate   
         , @APDueDate  
         , @ApplicationID  
         , 'IJON'  
         , @BusinessDate ;  
  
   IF @@error <> 0          
   GOTO ExitSP  
  
   select @TotalIjon = COUNT('') from AgreementIJONAllocationDetail with (nolock)  
   where IJONAllocationID = @IJONAllocationID  
  
   create table #TempIjon (  
    ID int identity(1,1),  
    ApplicationID varchar(20),  
    AmountAllocation numeric(17,2),  
    LCInstallment numeric(17,2)  
   )  
   insert into #TempIjon (ApplicationID, AmountAllocation, LCInstallment)  
   select ApplicationIDIJON, ( InstallmentDueAmount + OSAR) , LCInstallment from AgreementIJONAllocationDetail with (nolock)  
   where IJONAllocationID = @IJONAllocationID   
  
   set @CountIjon = 1  
   while @CountIjon <= @TotalIjon   
   begin  
    select @AppIdIjon = ApplicationID, @InstDueIjon = AmountAllocation, @LCInstIjon = LCInstallment, @TotalAmtIjon = AmountAllocation + LCInstallment  from #TempIjon with (nolock)  
    where ID = @CountIjon   
      
    set @RcvFrom = 'IJON ' + @AgreementNo  
  
    exec spPostingInstallment @branchid=@PaymentLocation,@companyid='001',@applicationid=@AppIdIjon ,@valuedate= @BusinessDate, @businessdate= @BusinessDate,@loginid='CSHIJON', @installmentduepaid= @InstDueIjon, @installmentduedesc='',@lcinstallmentpaid=
@LCInstIjon ,@lcinstallmentdesc='',@installmentcollpaid=0,@installmentcolldesc='',@insuranceduepaid=0,@insuranceduedesc='',@Lcinsurancepaid=0,@LCinsurancedesc='',@insurancecollpaid=0,@insurancecolldesc='',@pdcbouncefeepaid=0,@PDCBounceFeeDesc='',
@insuranceclaimexpensepaid=0,@insuranceclaimexpensepaiddesc='',@repossessionfeepaid=0,@repossessionfeepaiddesc='',@OtherID='',@Other=0,@OtherDesc='',@CurrencyID='IDR',@prepaidpaid=0,@prepaiddesc='',@receivedfrom=@RcvFrom,@referenceno=@AgreementNo ,@WOP='BA',
@bankaccountid='BANKIJON',@amountreceive=@TotalAmtIjon,@NOTES='',@ReceiptNo='-',@IsPaidbyCustomer=0,@PayerRelationship='',@PayerName='',@PayerIDNumber='',@PayerMobilePhone='',@PayerOthersInfo='',@PurposeOfPayment='',@PurposeAdminFee=0,@PurposeAdminFeeDesc=''  
  
    select @HistSeqNoIJON = max(HistorySequenceNo) from PaymentHistoryHeader with (nolock)  
    where ApplicationID = @AppIdIjon  
  
    update AgreementIJONAllocationDetail   
    set PaymentHistorySequenceNo = @HistSeqNoIJON   
    where ApplicationIDIJON = @AppIDIjon and IJONAllocationID = @IJONAllocationID   
  
    set @CountIjon = @CountIjon + 1  
   end  
   drop table #TempIjon  
  end  
 end  
 --end  
  
   
 --Vincenza FMF-2737 09062022  
 declare @OSInstallmentDue numeric(17,2),  
   @LCInstallmentAlloc numeric(17,2),  
   @CollectionExpenseAlloc numeric(17,2),  
   @InsurDueAlloc numeric(17,2),  
   @LCInsuranceAlloc numeric(17,2),  
   @PDCBounceFeeAlloc numeric(17,2)  
  
 set @RcvFrom = 'ALLOC' + @AgreementNo   
 if @FlagAlloc = 1  
 begin  
   select @APNo = AccountPayableNo from AccountPayable with (nolock)  
   where ApplicationID = @ApplicationID and APType='SPPL' and APTo <> 'To Branch'  
  
   IF @@error <> 0          
   GOTO ExitSP  
  
   set @BankAccountID = 'BANKALOC'  
  
   SELECT  @BankNameTo = BankNameTo  
      , @BankBranchTo = BankBranchTo  
      , @APType = APType  
      , @APDueDate = DueDate  
      , @PaymentTypeID = PaymentTypeDefault  
      , @APTo = APTo  
      , @PaymentLocation = PaymentLocation  
      , @AccountNameTo = AccountNameTo  
      , @AccountNoTo = AccountNoTo   
      , @CurrencyID = CurrencyID   
   FROM  AccountPayable WITH (NOLOCK)  
   WHERE  AccountPayableNo = @APNo  
     
   /*  
   exec spCheckCashier @loginid = 'CSHALOC', @BranchID = @PaymentLocation, @BusinessDate = @BusinessDate, @isOpen = @isOpen OUTPUT  
  
   if @isOpen = 0   
   begin  
    exec spCashierTransactionOpen @cashierid = 'CSHALOC', @branchId = @PaymentLocation, @businessdate = @businessdate, @openingamount = 0, @currencyid = @CurrencyID  
    IF @@error <> 0          
    GOTO ExitSP  
   end  
   */  

-- print 'debug fajar golive'
-- print '@APDueDate'
-- print @APDueDate

   EXEC dbo.spAPSaveToPV  @PaymentLocation  
         , @BusinessDate   
         , @APDueDate  
         , @ApplicationID  
         , @TotalAmountToBeAllocated   
         , @APType  
         , @APTo  
         , @AccountNameTo  
         , @AccountNoTo  
         , @BankNameTo  
         , @BankBranchTo  
         , @CurrencyID  
         , 'BANKALOC'  
         , @PaymentTypeID  
         , 'CSHALOC'  
         , @PaymentVoucherNo OUTPUT;  
    
   IF @@error <> 0          
   GOTO ExitSP  
  
   EXEC spAPSaveToPVItem  @PaymentLocation  
          , @PaymentVoucherNo  
          , @APNo  
          , @BusinessDate   
          , @PoAlloc  
          , @TotalAmountToBeAllocated ;  
    
   IF @@error <> 0          
   GOTO ExitSP  
   
   set @PVNotes = 'ALOC ' + @APNo  
  
   EXEC spAPDisbAppUpdate @PaymentLocation  
         , @PaymentVoucherNo  
         , 'A'  
         , @PVNotes  
         , 'CSHALOC'  
         , @BusinessDate   
         , 'A'  
         , @DisbAppUpdateError OUTPUT  
  
   IF (@DisbAppUpdateError <> '')   
   GOTO ExitSP  
  
   if exists (select '' from #Temptable with (nolock))  
   drop table #TempTable  
  
   EXEC spAPDisbCashUpdate @PaymentLocation  
         , @PaymentVoucherNo  
         , @BankAccountID  
         , 'None'  
         , 'P'  
         , @AccountNameTo  
         , @PVNotes  
         , 'CSHALOC'  
         , @BusinessDate   
         , @PaymentTypeID  
         , @TotalAmountToBeAllocated   
         , @APType  
         , @CurrencyID  
         , 1  
         , @BusinessDate   
         , @APDueDate  
         , @ApplicationID  
         , 'ALOC'  
         , @BusinessDate ;  
  
   IF @@error <> 0          
   GOTO ExitSP  
  if @PaymentType = 'ET'  
  begin  
  
   exec spPostingInstallment @branchid=@PaymentLocation,@companyid='001',@applicationid=@AppIDAlloc  ,@valuedate= @BusinessDate, @businessdate= @BusinessDate,@loginid='CSHALOC', @installmentduepaid=  0, @installmentduedesc='',@lcinstallmentpaid=0 ,
   @lcinstallmentdesc='',  
 @installmentcollpaid=0,@installmentcolldesc='',@insuranceduepaid=0,@insuranceduedesc='',@Lcinsurancepaid=0,@LCinsurancedesc='',@insurancecollpaid=0,@insurancecolldesc='',@pdcbouncefeepaid=0,@PDCBounceFeeDesc='',@insuranceclaimexpensepaid=0,
 @insuranceclaimexpensepaiddesc='',@repossessionfeepaid=0,@repossessionfeepaiddesc='',@OtherID='',@Other=0,@OtherDesc='',@CurrencyID='IDR',@prepaidpaid=@TotalAmountToBeAllocated,@prepaiddesc='',@receivedfrom=@RcvFrom,@referenceno=@AgreementNo ,@WOP='BA',@bankaccountid='BANKALOC',@amountreceive=@TotalAmountToBeAllocated ,@NOTES='',@ReceiptNo='-',@IsPaidbyCustomer=0,@PayerRelationship='',@PayerName='',@PayerIDNumber='',@PayerMobilePhone='',@PayerOthersInfo='',@PurposeOfPayment='',@PurposeAdminFee=0,@PurposeAdminFeeDesc=''
  
  
   exec spProcessFullPrepayExecute @BranchID = @BranchIDAlloc , @CompanyID ='001', @PrepaymentNo = @PrepaymentNo, @BusinessDate = @BusinessDate, @ToleranceAmount = 0  
   if @@ERROR <> 0  
   goto exitSP  
  end  
  else if @PaymentType = 'NM'  
  begin  
   select @OSInstallmentDue = OutstandingPrincipal + OutstandingInterest ,  
   @LCInstallmentAlloc = LCInstallment ,  
   @CollectionExpenseAlloc = CollectionExpense ,  
   @InsurDueAlloc = InsuranceDue ,  
   @LCInsuranceAlloc = LCInsurance ,  
   @PDCBounceFeeAlloc  = PDCBounceFee  from AgreementDisbAllocation with (nolock)  
   where BranchID = @BranchID and ApplicationID = @ApplicationID   
  
   exec spPostingInstallment @branchid=@PaymentLocation,@companyid='001',@applicationid=@AppIDAlloc  ,@valuedate= @BusinessDate, @businessdate= @BusinessDate,@loginid='CSHALOC', @installmentduepaid=  @OSInstallmentDue, @installmentduedesc='',
   @lcinstallmentpaid=@LCInstallmentAlloc ,@lcinstallmentdesc='',  
 @installmentcollpaid=0,@installmentcolldesc='',@insuranceduepaid=@InsurDueAlloc,@insuranceduedesc='',@Lcinsurancepaid=@LCInsuranceAlloc,@LCinsurancedesc='',@insurancecollpaid=0,@insurancecolldesc='',@pdcbouncefeepaid=@PDCBounceFeeAlloc,@PDCBounceFeeDesc=
'',@insuranceclaimexpensepaid=0,@insuranceclaimexpensepaiddesc='',@repossessionfeepaid=@CollectionExpenseAlloc,@repossessionfeepaiddesc='',@OtherID='',@Other=0,@OtherDesc='',@CurrencyID='IDR',@prepaidpaid=0,@prepaiddesc='',@receivedfrom=@RcvFrom,
@referenceno=@AgreementNo ,@WOP='BA',@bankaccountid='BANKALOC',@amountreceive=@TotalAmountToBeAllocated ,@NOTES='',@ReceiptNo='-',@IsPaidbyCustomer=0,@PayerRelationship='',@PayerName='',@PayerIDNumber='',@PayerMobilePhone='',@PayerOthersInfo='',
@PurposeOfPayment='',@PurposeAdminFee=0,@PurposeAdminFeeDesc=''  
  end  
 end  
 --end  
  
  
 -- Vin Cent FMF-3862 proses disburse selection dan approval otomatis untuk kontrak GoLive untuk TransferApDisbPO ='C'  
  
   
 --edit fuji,07 Feb 2023 (FMF-3862) SIT Tambah Select ke AccountPayable dan Perbaiki IF Kondisi  
 declare @TransferApDisbPO Char (1)  
 SELECT  @TransferApDisbPO = po.TransferApDisb        
 FROM    Agreement WITH ( NOLOCK )          
   INNER JOIN ProductOffering po WITH ( NOLOCK ) ON Agreement.BranchID = po.BranchID          
            AND Agreement.ProductOfferingID = po.ProductOfferingID          
            AND Agreement.ProductID = po.ProductID    
 where  ApplicationID=@ApplicationID  
  
  
 IF @TransferApDisbPO ='C'  -- SPPL
 BEGIN  
    
  select 'masuk'  
  EXEC dbo.spGoLiveAPIAutoDisburseKMB @BranchID = @BranchID,                 
              @ApplicationID=@ApplicationID ,                 
              @BusinessDate =@BusinessDate  
  if @@ERROR <> 0  
   goto exitSP   
 END  
    --End edit Fuji  
  
 --End Vincent FMF-3862  
 
  --Add Fajar FMF-4301 Auto Disburs non SPPL
	DECLARE @gsvalueslimit VARCHAR(8000)
	DECLARE @MinAmount NUMERIC(17,2)  
	DECLARE @MaxAmount NUMERIC(17,2)
	SELECT @gsvalueslimit=GSValue FROM dbo.GeneralSetting gs WHERE GSID = 'BCAAPIAPLimitGoLive'
	SELECT @MinAmount = MIN(LTRIM(RTRIM(Item))) FROM dbo.UFN_STRING_SPLIT(@gsvalueslimit ,'-')
	SELECT @MaxAmount = MAX(LTRIM(RTRIM(Item))) FROM dbo.UFN_STRING_SPLIT(@gsvalueslimit ,'-')

	DECLARE @gsvaluesbranch VARCHAR(8000)
	SELECT @gsvaluesbranch=GSValue FROM dbo.GeneralSetting gs WHERE GSID = 'BCAAPIBranchIDGoLive'
	
	DECLARE @gsvaluesasset VARCHAR(8000)
	SELECT @gsvaluesasset=GSValue FROM dbo.GeneralSetting gs WHERE GSID = 'BCAAPIAssetTypeIDGoLive'
		
	DECLARE @BCAAPIAP varchar(8000)
	SELECT @BCAAPIAP=GSValue from GeneralSetting where GSID = 'BCAAPIAP'
	IF EXISTS (
		select '' from AccountPayable									  
			where ApplicationID = @ApplicationID 
			and BranchID IN (SELECT LTRIM(RTRIM(Item)) FROM dbo.UFN_STRING_SPLIT(@gsvaluesbranch,','))
			and APType IN (SELECT LTRIM(RTRIM(Item)) FROM dbo.UFN_STRING_SPLIT(@BCAAPIAP,',')) 
			and APTYPE <> 'SPPL'
			and APAmount >= @MinAmount
			and APAmount <= @MaxAmount
	) and 
	EXISTS (select '' from agreementasset
		 where ApplicationID = @ApplicationID 
		 -- AND AssetTypeID IN (SELECT LTRIM(RTRIM(Item)) FROM dbo.UFN_STRING_SPLIT(@gsvaluesasset,','))
		 AND AssetTypeID = '11' --Add Fajar FMF-4301 30/11/2023 
	) 
	BEGIN

		EXEC dbo.spGoLiveAPIAutoDisburseKMBnonSPPL	@BranchID = @BranchID,                 
													@ApplicationID=@ApplicationID,                 
													@BusinessDate =@BusinessDate 

	END

  --End Fajar
  
-------------------------------  
--Add fuji 07122022,(fmf-3885) DepositAmount menambah nilai ContractPrepaidAmount Agreement  
--------------------------------  
Update Agreement Set ContractPrepaidAmount=Isnull(ContractPrepaidAmount ,0)+ isnull(DepositAmt,0)  
where BranchID=@BranchID  
and ApplicationID=@ApplicationID  
  
--end fuji  
  
--------------------------------  
  
-------------------------------------------              
-- Insert ke tbl ActivityLog --              
-- ratna 08/09              
-------------------------------------------              
    DECLARE @Activitydate DATETIME            
            
    SET @Activitydate = GETDATE()            
    EXEC @Error = spActivityLog @BranchID, @ApplicationID, 'GLV',          
        @Activitydate, @ActivityStartDate             
              
    IF @Error > 0          
        BEGIN              
            GOTO exitsp               
        END              
              
              
              
-------------------------------------------                
 -- Proses Insert Ke  SMSMessageOut --                
 -------------------------------------------                
    DECLARE @CompanyName VARCHAR(50) ,          
        @CustomerMobilePhone VARCHAR(20)              
               
    SELECT  @CompanyName = CompanyFullName          
    FROM    Company WITH ( NOLOCK )          
    WHERE   CompanyID = '001'              
              
    IF @CustomerType = 'P'          
        BEGIN              
            SELECT  @CustomerMobilePhone = ISNULL(MobilePhone, '-')          
            FROM    PersonalCustomer WITH ( NOLOCK )          
            WHERE   CustomerID = @CustomerID              
        END              
    ELSE          
        BEGIN              
            SET @CustomerMobilePhone = '-'              
        END              
              
    IF @CustomerMobilePhone = ''          
        BEGIN              
            SET @CustomerMobilePhone = '-'              
        END               
              
    IF @CustomerMobilePhone <> '-'          
        BEGIN              
            INSERT  INTO SMSMessageOut          
                    ( MessageCreatedDate ,          
                      SMSMessage ,          
                      MobilePhoneNumber ,          
                      SMSStatus               
--       BranchID,              
--       ApplicationID,              
--       NextInstallmentDueNo,              
--       NextInstallmentDueDate,              
--       LastPastDueDays              
                    )          
            VALUES  ( @BusinessDate ,          
                      CONVERT(VARCHAR(200), 'Selamat ' + @CustomerName          
                      + ', kontrak anda dengan No ' + @AgreementNo          
                      + ' telah LIVE. Dari: ' + @CompanyName) ,          
                      @CustomerMobilePhone ,          
                      'N'              
--     @BranchID,               
--     @ApplicationID,              
--     @NextInstallmentDueNumber,              
--     @NextInstallmentDueDate,              
--     @LastPastDueDays              
                    )              
                
                
                
            IF @@error > 0          
                BEGIN                
                   GOTO exitsp                 
                END                
        END              
          
---------------------------------------------------------------------          
-- Benny 29 Juni 2015 - FMF-1422 : Lifeinsurance          
-- insert ke table untuk melihat penyebaran insurance dan lifeinsuranece          
---------------------------------------------------------------------          
        
    EXEC @Error = spListLifeInsAmortize @BranchID, @ApplicationID          
   
 --SELECT * FROM dbo.tblLifeInsAmortize               
          
    IF @Error > 0          
        GOTO exitsp          
                  
--======================================================================================              
-- Add By Gema, 25 September 2007 : Add Net Rate Amortization dari KITAF                
-- Created By Henry              
-- Modifikasi Go Live Process untuk bisa create fee amortization              
-- Date Modified : 6 April 2007              
-- modifikasi mul ini dipindahkan diatas sebelum spupdateinterestinssche          
----------------------------------------------------------------------------------------              
----Declare @tblAmortizationMaster Table              
----( SeqNo Int Identity,               
---- AmortizationID char(10)              
----)              
--Declare @StartLoop Int,               
-- --@EndLoop Int,               
-- @AmortizationID varchar(10),               
-- @DateAmortization DateTime              
----            
----Insert Into @tblAmortizationMaster              
---- (AmortizationID)              
----Select AmortizationID From AmortizationMaster where isactive = 1 and AmortizationID='DIFFRATE'               
----            
----Select @EndLoop = Count (SeqNo) from @tblAmortizationMaster              
--Set @DateAmortization = dateadd(month, -1, @EffectiveDate)              
----Set @StartLoop = 1              
----            
----While @StartLoop <= @EndLoop              
----Begin              
---- Select @AmortizationID = AmortizationID From  @tblAmortizationMaster where SeqNo = @StartLoop              
-- set @AmortizationID = 'DIFFRATE'             
-- Exec @Error = spAmortizationFeeGenerator @BranchID, @ApplicationID, @DateAmortization, @AmortizationID              
-- If @Error > 0              
--  Goto ExitSp               
-- --Set @StartLoop = @StartLoop + 1               
----End              
              
              
----------------------------------------------------------------------------------------              
            
--SELECT * FROM aaa          
------------------------              
-- Commit Transaction --              
------------------------              
/*Rubianto, 20100330*/          
    DELETE  FROM TempIncomeNet          
    WHERE   ID = @ApplicationID          
            AND BranchID = @BranchID          
/*Rubianto, 20100330*/          
          
          
--===============================David 25Jan2011 recheck InsuranceAsset          
    IF EXISTS ( SELECT  ''          
                FROM    InsuranceAsset WITH ( NOLOCK )          
                WHERE   ( BranchID = @BranchID )          
                        AND ( ApplicationID = @ApplicationID )          
                        AND ISNULL(PaidAmountByCust, 0) = 0 )          
        BEGIN          
            RAISERROR ( 'Insurance Paid Amount By Customer is empty', 16, 1 )          
        END          
--===============================          
         
--===============================Felix Y 7/9/2020 Marketing Program          
  IF  (SELECT  count(mrktd.MarketingCode)         
                FROM    MarketingCampaignFreeTenorPOT mrktD WITH ( NOLOCK )         
                WHERE   mrktd.BranchId = @BranchID AND mrktD.ProductOfferingId = @ProductOfferingID AND Status = '1' AND mrktD.ProductID = @ProductID AND mrktD.TenorProgram = @Tenor    ) > 1      
        BEGIN          
            RAISERROR ( 'Please check marketing campaign setting', 16, 1 )          
        END          
      
    IF EXISTS ( SELECT  mrktd.MarketingCode          
                FROM    MarketingCampaignFreeTenorPOT mrktD WITH ( NOLOCK )         
                WHERE   mrktd.BranchId = @BranchID AND mrktD.ProductOfferingId = @ProductOfferingID AND Status = '1' AND mrktD.ProductID = @ProductID AND mrktD.TenorProgram = @Tenor)        
        BEGIN          
  DECLARE @marketingcodeMrkt varchar(50)        
  select @marketingcodeMrkt =  mrktd.MarketingCode          
                FROM    MarketingCampaignFreeTenorPOT mrktD WITH ( NOLOCK )         
                WHERE   mrktd.BranchId = @BranchID AND mrktD.ProductOfferingId = @ProductOfferingID AND Status = '1' AND mrktD.ProductID = @ProductID AND mrktD.TenorProgram = @Tenor        
            UPDATE Agreement         
   set MarketingCodeStatus ='ACT',        
   MarketingCode = @marketingcodeMrkt        
   WHERE ( BranchID = @BranchID ) AND ( ApplicationID = @ApplicationID )          
        END          
 ELSE        
  BEGIN        
   UPDATE Agreement        
   set MarketingCodeStatus ='OPN'         
   WHERE ( BranchID = @BranchID ) AND ( ApplicationID = @ApplicationID )          
  END        
--===============================          
  
  
  
 --===============================Felix Y 13/11/2020 FMF-2273 Marketing Mix 12    KreditMu  
DECLARE @ParameterLike AS VARCHAR(3000)  
SELECT @ParameterLike = GSValue from GeneralSetting where GSID = 'CKMPID'  
  
IF EXISTS(SELECT '' FROM Agreement WHERE (ProductId LIKE @ParameterLike)  AND ( ApplicationID = @ApplicationID) AND ( BranchID = @BranchID ) )  
BEGIN  
 INSERT INTO [dbo].[CustomerKreditmu]  
      ([CustomerID]  
      ,[StartDate]  
      ,[EndDate]  
      ,[DtmUpd]  
      ,[UsrUpd])  
   VALUES  
      (@CustomerID  
      ,@StartDate  
      , (SELECT RRDDate FROM Agreement where ApplicationID = @ApplicationID AND  BranchID = @BranchID)  
      ,GETDATE()  
      ,SYSTEM_USER)  
 IF @@error <> 0          
        GOTO ExitSP  
END  
--=============================   
     --select 'fmf-4017',* from gljournald where tr_nomor=@Tr_Nomor  
    COMMIT TRANSACTION tranGoLive           
 --ROLLBACK TRANSACTION tranGoLive        
    RETURN 1              
              
    ExitSP:              
    BEGIN              
 --------------------------              
 -- Rollback Transaction --              
 --------------------------           
        ROLLBACK TRANSACTION tranGoLive              
              
        RETURN 0              
    END
