SET ANSI_NULLS ON
Go
SET QUOTED_IDENTIFIER ON
Go
IF OBJECT_ID('spAssetSellingPaging') IS NOT NULL
begin
exec('



ALTER      Procedure [dbo].[spAssetSellingPaging]      
 @CurrentPage int,      
 @PageSize int,      
 @WhereCond varchar(1000),      
 @SortBy varchar(100),      
 @TotalRecords int output      
AS      
      


/******************************************************************************      
**  File:       
**  Name: [spAssetSellingPaging]      
**  Desc:       
**      
**  This template can be customized:      
**                    
**  Return values:      
**       
**  Called by:         
**                    
**  Parameters:      
**  Input       Output      
**     ----------       -----------      
**      
**  Auth: Anton       
**  Date: 10 November 2006  10:00      
*******************************************************************************      
**  Change History      
*******************************************************************************      
**  Date:  Author:    Description:      
**  --------  --------    -------------------------------------------      
**  01-10-2007 MUL created 
**  Gema, 25 Oktober 2007 : Ganti sp Paging nya   
**  Meytha 03 oct 2019 (FMF-1877) : Tambah ambil dari General Setting untuk mendapatkan n-hari asset selling days
**  Fuji 08 Oct 2019 (FMF-1877) : Asset Selling Listing yang dimunculkan jika sudah melewati 30 hari (atau sesua Settingan di GeneralSetting) dari Repossess Date
**  Fuji,25 Nov 2019 (FMF-1936) : Jika AssetType sudah di setting di DaysforAssetSellingException maka DaysForAssetSelling ambil dari DaysforAssetSellingException jika tidak ada ambil dari DAYSASSETSELLING di GeneralSetting
**	Raug, 1 Oktober 2021 [FMF-3035] : Perbaiki left join ke UnlockAssetSelling supaya jika ada double tidak menyebabkan error
**	Raug, 10 Desember 2021 [FMF-3226] : Menghilangkan beberapa baris script yang diremark saat isi @SqlStatement, karena datatype nya tidak muat
**  Fajar, 01 November 2023 [FMF-4450] : tambah PPNAS dari table AssetType
*******************************************************************************/      
      
      
 set nocount on      
      
 declare @cmdwhere varchar(3000),      
  @BusinessDate varchar(20)      
       
      
 create table #TempTable (
		TotalRecord  Int
 )
      
      
 declare @IsProductPerTenor varchar(1)      
 if exists (select '''' from ChangeSetting where CSID = ''ProductPerTenor'')      
 begin      
  Select @IsProductPerTenor = CsValue from ChangeSetting      
  where CSID = ''ProductPerTenor''      
 end      
 else      
 Begin      
  set @IsProductPerTenor = ''0''      
 End      
      
 select @BusinessDate=CONVERT(VARCHAR(8), BDCurrent, 112) from SystemControlCoy      
 
 --Meytha FMF-1877
 DECLARE @GSValue varchar(3)
 Select @GSValue = GSValue from GeneralSetting where GSID=''DAYSASSETSELLING'' AND ModuleID=''COL''
 --Meytha FMF-1877

 IF (@WhereCond = '''')      
  Set @cmdwhere = ''''      
 else      
 begin      
  if right(rtrim(@WhereCond),2) = ''%''''''      
  begin       
   set @WhereCond=replace(@WhereCond , ''='' , ''  like  '')      
   set @WhereCond = @WhereCond + ''and (
		(DayAsl.AssetTypeID IS NULL AND  (DateAdd(day,convert(int,''''''+ltrim(rtrim(@GSValue))+''''''),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''') --add Fuji 08 Oct 2019 (FMF-1877)
		OR 
		(DayAsl.AssetTypeID IS NOT NULL 
		and agreement.NTF between DayAsl.NTFFrom and  DayAsl.NTFTo 
		AND   (DateAdd(day,convert(int,DayAsl.DaysForAssetSelling),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''')
		--Vincenza FMF-2575 18022021
		OR 
		UAS.ApplicationID IS NOT NULL
		)''       -- Meytha FMF-1877 --edit fuji,27 nov 2019 (fmf-1936)
      
  end     
  
 
  SET @cmdwhere =       
   ''      
   WHERE CollectionAgreement.ActiveStatus=''''Y''''      
           and AssetRepossessionOrder.RepossesionStatus=''''E''''       
	--edit fuji,25 nov 2019 (fmf-1936)
	and (
		(DayAsl.AssetTypeID IS NULL AND  (DateAdd(day,convert(int,''''''+ltrim(rtrim(@GSValue))+''''''),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''') --add Fuji 08 Oct 2019 (FMF-1877)
		OR 
		(DayAsl.AssetTypeID IS NOT NULL 
		and agreement.NTF between DayAsl.NTFFrom and  DayAsl.NTFTo 
		AND   (DateAdd(day,convert(int,DayAsl.DaysForAssetSelling),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''')
		--Vincenza FMF-2575 18022021
		OR 
		UAS.ApplicationID IS NOT NULL
    )
	--end fuji
    and AssetRepossessionOrder.ApprovalStatus = ''''APV''''      
    and AssetRepossessionOrder.ApplicationID       
     in       
     (      
      select ExInvAppraisalasset.ApplicationID from ExInvAppraisalasset with (nolock)      
      INNER JOIN ExInvAppraisal  with (nolock)       
      on ExInvAppraisal.BranchID = ExInvAppraisalasset.BranchID and      
         ExInvAppraisal.ApplicationID = ExInvAppraisalasset.ApplicationID and      
         ExInvAppraisal.RequestNo=ExInvAppraisalAsset.RequestNo       
      where  ExInvAppraisal.ApprovalStatus=''''APV''''      
     )      
    and       
    '' + @WhereCond      
 end      
   

 
 If @SortBy=''''      
  set @SortBy='' order by Agreement.AgreementNo  ''      
 else      
 begin      
  set @SortBy=replace(@SortBy, ''AgreementNo'',''CollectionAgreement.AgreementNo'')      
  set @SortBy=replace(@SortBy, ''CustomerName'',''Customer.Name'')      
  set @SortBy=replace(@SortBy, ''AssetDescription'',''AssetMaster.Description'')      
      
  set @SortBy=replace(@SortBy, ''EstimationDate'',''AssetRepossessionOrder.EstimationDate'')      
  set @SortBy=replace(replace(@SortBy, ''AppraisalDate'',''ExInvAppraisal.RequestDate''),''Status'',''assetrepossessionorder.flagselected'')      
  set @SortBy=replace(replace(replace(@SortBy, ''EstimationAmount'',''AssetRepossessionOrder.EstimationAmount''),''ChassisNo'',''agreementasset.serialno1''),''EngineNo'',''agreementasset.serialno2'')     
  set @SortBy='' Order BY  '' + @SortBy       
 end

    DECLARE @FirstRec int, @LastRec int
    SELECT @FirstRec = (@CurrentPage - 1) * @PageSize +1
    SELECT @LastRec = (@CurrentPage * @PageSize + 1) -1



    exec (''Insert Into #TempTable(TotalRecord) 
	   Select Count(1) 
			 from  AssetRepossessionOrder with (nolock)       
		inner join collectionAgreement with (nolock)       
		on CollectionAgreement.ApplicationID=AssetRepossessionOrder.ApplicationID and CollectionAgreement.BranchID=AssetRepossessionOrder.BranchID       
		inner join Agreement with (nolock)       
		on CollectionAgreement.ApplicationID=Agreement.ApplicationID and CollectionAgreement.BranchID=Agreement.BranchID      
		inner join       
		(         
		select BranchID, ApplicationID, count(AssetSeqNo) TotalAsset      
		from AgreementAsset      
		where AssetStatus not in (''''RLS'''',''''RRD'''',''''SLD'''',''''PRP'''')      
		GROUP BY BranchID, ApplicationID      
		)qryTotalAsset      
		on qryTotalAsset.BranchID=Agreement.BranchID      
		and qryTotalAsset.ApplicationID=Agreement.ApplicationID      
		  
		inner join Customer with (nolock)       
		on Agreement.CustomerID=Customer.CustomerID      
		inner join AgreementAsset with (nolock)       
		on CollectionAgreement.ApplicationID=AgreementAsset.ApplicationID and CollectionAgreement.BranchID=AgreementAsset.BranchID   and      
		   assetRepossessionOrder.AssetSeqNo = AgreementAsset.AssetSeqNo      
		Inner join       
		(      
		 Select BranchId,ApplicationID,AssetSeqNo,      
		 Max(RepossesSeqNo) as MaxRepossesSeqNo      
		 from AssetRepossessionOrder with (noLock)      
		 Group By BranchID, ApplicationID, AssetSeqNo      
		 )QARO      
		  on QARO.BranchID = Agreement.BranchID and      
		  QARO.ApplicationID = Agreement.ApplicationID and      
		  QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo and      
		  QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo      
		inner join AssetMaster with (nolock)       
		on AssetMaster.AssetCode=AgreementAsset.AssetCode      
		inner join Currency       
		ON Agreement.CurrencyID=Currency.CurrencyID      
		  
		inner join ExInvAppraisal      
		on ExInvAppraisal.BranchID = Agreement.BranchID      
		  AND ExInvAppraisal.ApplicationID = Agreement.ApplicationID      
		  AND ExInvAppraisal.ApprovalStatus= ''''APV''''      
		  
		inner join ExInvAppraisalAsset      
		on ExInvAppraisalAsset.BranchID = Agreement.BranchID and      
		  ExInvAppraisalAsset.ApplicationID = Agreement.ApplicationID and      
		  ExInvAppraisalAsset.RequestNo = ExInvAppraisal.RequestNo and      
		  ExInvAppraisalAsset.AssetSeqNo = QARO.AssetSeqNo and      
		  ExInvAppraisalAsset.RepossessSeqNo = QARO.MaxRepossesSeqNo       
		  
		LEFT join Collector with (nolock)     
		on AssetRepossessionOrder.collectorid = Collector.collectorid    
		and AssetRepossessionOrder.cgid = Collector.cgid    
		  
		--Dedy 22 January 2006--       
		left join (      
		 select  QRY1.BranchID,      
		  QRY1.ApplicationID,      
		  QRY2.BudgetStatus,      
		  QRY1.RequestNo      
		 from      
		 (      
		  select  BranchID,      
		   ApplicationID,      
		   max(RequestNo) as RequestNo      
		  from ExBudgetExecutor with (nolock)      
		  group by BranchID,      
		   ApplicationID      
		 )QRY1      
		 inner join      
		 (      
		  select  BranchID,      
		   ApplicationID,      
		   BudgetStatus,      
		   max(RequestNo) as RequestNo      
		  from ExBudgetExecutor with (nolock)      
		  group by BranchID,      
		   ApplicationID,      
		   BudgetStatus      
		 )QRY2      
		 on QRY1.BranchID = QRY2.BranchID      
		 and QRY1.ApplicationID = QRY2.ApplicationID      
		 and QRY1.RequestNo =QRY2.REquestNo      
		)QRYBudgetStatus      
		      
		on QRYBudgetStatus.BranchID = Agreement.BranchID      
		and QRYBudgetStatus.ApplicationID = Agreement.ApplicationID      
		  
		inner join product with (nolock) on 
			agreement.productid = product.productid
		inner join assettype with (nolock) on
			product.assettypeid = assettype.assettypeid
		--Add fuji,25 Nov 2019 (FMF-1936)
		left join DaysforAssetSellingException DayAsl with (nolock)
			on AgreementAsset.AssetTypeID=DayAsl.AssetTypeID
			AND agreement.NTF BETWEEN DayAsl.NTFFrom and DayAsl.NTFTo
		--End fuji
		--Raug 1 Oktober 2021 FMF-3035 :  Ubah query nya Vincenza karena dulu belum ada penjagaan double input waktu save UnlockAssetSelling
		--Vincenza FMF-2575 18022021
		--left join UnlockAssetSelling UAS with (nolock)
		--	on agreement.BranchID = UAS.BranchID and Agreement.ApplicationID = UAS.ApplicationID and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
		--end Vincenza
		left join (	SELECT	MIN(UnlockID) UnlockID, BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo 
					FROM	UnlockAssetSelling 
					GROUP BY BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo
					) UAS
				ON Agreement.BranchID=UAS.BranchID 
				and Agreement.ApplicationID = UAS.ApplicationID 
				and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo 
				and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
		--End Raug
		'' + @cmdwhere
   )


 Declare @SqlStatement as VarChar(8000)

---Raug, 10 Desember 2021 [FMF-3226] : Menghilangkan beberapa baris script yang diremark saat isi @SqlStatement, karena datatype nya tidak muat
-- Set @SqlStatement = ''select ROW_NUMBER() OVER (''+ @SortBy + ''), 
--   Agreement.ApplicationID,
--   CollectionAgreement.AgreementNo,      
--   Agreement.CustomerID,      
--   Customer.Name CustomerName,      
--   AssetMaster.Description,      
--   agreementasset.serialno1,
--   agreementasset.serialno2,
--   (case assetrepossessionorder.flagselected when 0 then ''''Not Selected'''' else ''''Selected'''' end),
--   agreement.branchid,
--   assetrepossessionorder.assetseqno,
--   ExInvAppraisalAsset.EstimationAmount,
   
----   Currency.CurrencyID,
----	AssetRepossessionOrder.requestno,
--	AssetRepossessionOrder.repossesseqno -- Vincenza FMF-2575 18022021 
----	outstandingprinciple,
----	osinsurance,
----	agreement.lcinstallment,
----	agreement.lcinsurance,
----	agreement.pdcbouncefee,
----	repossessionfee,
----	interestdue,
----	AssetRepossessionOrder.accruedinterest,
----	outstandingprinciplealloc,
----	osinsurancealloc,
----	lcinstallmentalloc,
----	lcinsurancealloc,
----	pdcbouncefeealloc,
----	repossessionfeealloc,
----	interestduealloc,
----	accruedinterestalloc,
----	prepaidalloc,
----	agreement.approvalno,
----	AssetRepossessionOrder.approvalid,
----	approvedby,
----	agreement.ProductID,
----	AssetRepossessionOrder.approvalamount
--  from  AssetRepossessionOrder with (nolock)       
--   inner join collectionAgreement with (nolock)       
--    on CollectionAgreement.ApplicationID=AssetRepossessionOrder.ApplicationID and CollectionAgreement.BranchID=AssetRepossessionOrder.BranchID       
--   inner join Agreement with (nolock)       
--    on CollectionAgreement.ApplicationID=Agreement.ApplicationID and CollectionAgreement.BranchID=Agreement.BranchID      
--   inner join       
--   (         
--    select BranchID, ApplicationID, count(AssetSeqNo) TotalAsset      
--    from AgreementAsset      
--    where AssetStatus not in (''''RLS'''',''''RRD'''',''''SLD'''',''''PRP'''')      
--    GROUP BY BranchID, ApplicationID      
--   )qryTotalAsset      
--    on qryTotalAsset.BranchID=Agreement.BranchID      
--    and qryTotalAsset.ApplicationID=Agreement.ApplicationID      
      
--   inner join Customer with (nolock)       
--    on Agreement.CustomerID=Customer.CustomerID      
--   inner join AgreementAsset with (nolock)       
--    on CollectionAgreement.ApplicationID=AgreementAsset.ApplicationID and CollectionAgreement.BranchID=AgreementAsset.BranchID   and      
--       assetRepossessionOrder.AssetSeqNo = AgreementAsset.AssetSeqNo      
--   Inner join       
--    (      
--     Select BranchId,ApplicationID,AssetSeqNo,      
--     Max(RepossesSeqNo) as MaxRepossesSeqNo      
--     from AssetRepossessionOrder with (noLock)      
--     Group By BranchID, ApplicationID, AssetSeqNo      
--     )QARO      
--      on QARO.BranchID = Agreement.BranchID and      
--      QARO.ApplicationID = Agreement.ApplicationID and      
--      QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo and      
--      QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo      
--   inner join AssetMaster with (nolock)       
--   on AssetMaster.AssetCode=AgreementAsset.AssetCode      
--   inner join Currency       
--   ON Agreement.CurrencyID=Currency.CurrencyID      
      
--   inner join ExInvAppraisal      
--   on ExInvAppraisal.BranchID = Agreement.BranchID      
--      AND ExInvAppraisal.ApplicationID = Agreement.ApplicationID      
--      AND ExInvAppraisal.ApprovalStatus= ''''APV''''      
      
--   inner join ExInvAppraisalAsset      
--   on ExInvAppraisalAsset.BranchID = Agreement.BranchID and      
--      ExInvAppraisalAsset.ApplicationID = Agreement.ApplicationID and      
--      ExInvAppraisalAsset.RequestNo = ExInvAppraisal.RequestNo and      
--      ExInvAppraisalAsset.AssetSeqNo = QARO.AssetSeqNo and      
--      ExInvAppraisalAsset.RepossessSeqNo = QARO.MaxRepossesSeqNo       
      
--  LEFT join Collector with (nolock)     
--   on AssetRepossessionOrder.collectorid = Collector.collectorid    
--   and AssetRepossessionOrder.cgid = Collector.cgid    
      
--   --Dedy 22 January 2006--       
--   left join (      
--     select  QRY1.BranchID,      
--      QRY1.ApplicationID,      
--      QRY2.BudgetStatus,      
--      QRY1.RequestNo      
--     from      
--     (      
--      select  BranchID,      
--       ApplicationID,      
--       max(RequestNo) as RequestNo      
--      from ExBudgetExecutor with (nolock)      
--      group by BranchID,      
--       ApplicationID      
--     )QRY1      
--     inner join      
--     (      
--      select  BranchID,      
--       ApplicationID,      
--       BudgetStatus,      
--       max(RequestNo) as RequestNo      
--      from ExBudgetExecutor with (nolock)      
--      group by BranchID,      
--       ApplicationID,      
--       BudgetStatus      
--     )QRY2      
--     on QRY1.BranchID = QRY2.BranchID      
--     and QRY1.ApplicationID = QRY2.ApplicationID      
--     and QRY1.RequestNo =QRY2.REquestNo      
--    )QRYBudgetStatus      
          
--    on QRYBudgetStatus.BranchID = Agreement.BranchID      
--    and QRYBudgetStatus.ApplicationID = Agreement.ApplicationID      
      
--    inner join product with (nolock) on 
--		agreement.productid = product.productid
--	inner join assettype with (nolock) on
--		product.assettypeid = assettype.assettypeid
--	--Add fuji,25 Nov 2019 (FMF-1936)
--	left join DaysforAssetSellingException DayAsl with (nolock)
--		on AgreementAsset.AssetTypeID=DayAsl.AssetTypeID
--		AND agreement.NTF BETWEEN DayAsl.NTFFrom and DayAsl.NTFTo
--	--End fuji
--	--Raug 1 Oktober 2021 FMF-3035 :  Ubah query nya Vincenza karena dulu belum ada penjagaan double input waktu save UnlockAssetSelling
--	--Vincenza FMF-2575 18022021
--	--left join UnlockAssetSelling UAS with (nolock)
--	--	on agreement.BranchID = UAS.BranchID and Agreement.ApplicationID = UAS.ApplicationID and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
--	--end Vincenza
--	left join (	SELECT	MIN(UnlockID) UnlockID, BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo 
--				FROM	UnlockAssetSelling 
--				GROUP BY BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo
--				) UAS
--			ON Agreement.BranchID=UAS.BranchID 
--			and Agreement.ApplicationID = UAS.ApplicationID 
--			and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo 
--			and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
--	--End Raug
--    '' + @cmdwhere

Set @SqlStatement = 
	''	select	ROW_NUMBER() OVER (''+ @SortBy + ''), 
				Agreement.ApplicationID,
				CollectionAgreement.AgreementNo,      
				Agreement.CustomerID,      
				Customer.Name CustomerName,      
				AssetMaster.Description,      
				agreementasset.serialno1,
				agreementasset.serialno2,
				(case assetrepossessionorder.flagselected when 0 then ''''Not Selected'''' else ''''Selected'''' end),
				agreement.branchid,
				assetrepossessionorder.assetseqno,
				ExInvAppraisalAsset.EstimationAmount,
				AssetRepossessionOrder.repossesseqno -- Vincenza FMF-2575 18022021 
				, assettype.PPNAS  --Add Fajar FMF-4450
		from	AssetRepossessionOrder with (nolock)       
				inner join collectionAgreement with (nolock)       
					on CollectionAgreement.ApplicationID=AssetRepossessionOrder.ApplicationID and CollectionAgreement.BranchID=AssetRepossessionOrder.BranchID       
				inner join Agreement with (nolock)       
					on CollectionAgreement.ApplicationID=Agreement.ApplicationID and CollectionAgreement.BranchID=Agreement.BranchID      
				inner join       
				(         
					select BranchID, ApplicationID, count(AssetSeqNo) TotalAsset      
					from AgreementAsset      
					where AssetStatus not in (''''RLS'''',''''RRD'''',''''SLD'''',''''PRP'''')      
					GROUP BY BranchID, ApplicationID      
				)qryTotalAsset      
					on qryTotalAsset.BranchID=Agreement.BranchID      
					and qryTotalAsset.ApplicationID=Agreement.ApplicationID      
				inner join Customer with (nolock)       
					on Agreement.CustomerID=Customer.CustomerID      
				inner join AgreementAsset with (nolock)       
					on CollectionAgreement.ApplicationID=AgreementAsset.ApplicationID and CollectionAgreement.BranchID=AgreementAsset.BranchID   and      
					assetRepossessionOrder.AssetSeqNo = AgreementAsset.AssetSeqNo      
				Inner join       
				(      
					 Select BranchId,ApplicationID,AssetSeqNo,      
					 Max(RepossesSeqNo) as MaxRepossesSeqNo      
					 from AssetRepossessionOrder with (noLock)      
					 Group By BranchID, ApplicationID, AssetSeqNo      
				 )QARO      
				  on QARO.BranchID = Agreement.BranchID and      
				  QARO.ApplicationID = Agreement.ApplicationID and      
				  QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo and      
				  QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo      
				inner join AssetMaster with (nolock)       
					on AssetMaster.AssetCode=AgreementAsset.AssetCode      
				inner join Currency       
					ON Agreement.CurrencyID=Currency.CurrencyID      
				inner join ExInvAppraisal      
					on ExInvAppraisal.BranchID = Agreement.BranchID      
					AND ExInvAppraisal.ApplicationID = Agreement.ApplicationID      
					AND ExInvAppraisal.ApprovalStatus= ''''APV''''        
				inner join ExInvAppraisalAsset      
					on ExInvAppraisalAsset.BranchID = Agreement.BranchID and      
					ExInvAppraisalAsset.ApplicationID = Agreement.ApplicationID and      
					ExInvAppraisalAsset.RequestNo = ExInvAppraisal.RequestNo and      
					ExInvAppraisalAsset.AssetSeqNo = QARO.AssetSeqNo and      
					ExInvAppraisalAsset.RepossessSeqNo = QARO.MaxRepossesSeqNo       
				LEFT join Collector with (nolock)     
					on AssetRepossessionOrder.collectorid = Collector.collectorid    
					and AssetRepossessionOrder.cgid = Collector.cgid    
				--Dedy 22 January 2006--       
				left join 
				(      
					select  QRY1.BranchID,      
					QRY1.ApplicationID,      
					QRY2.BudgetStatus,      
					QRY1.RequestNo      
					from      
					(      
						select  BranchID,      
								ApplicationID,      
								max(RequestNo) as RequestNo      
						from	ExBudgetExecutor with (nolock)      
						group by BranchID,      
						ApplicationID      
					)QRY1      
					inner join      
					(      
						select  BranchID,      
								ApplicationID,      
								BudgetStatus,      
								max(RequestNo) as RequestNo      
						from	ExBudgetExecutor with (nolock)      
						group by BranchID,      
						ApplicationID,      
						BudgetStatus      
					)QRY2      
					on QRY1.BranchID = QRY2.BranchID      
					and QRY1.ApplicationID = QRY2.ApplicationID      
					and QRY1.RequestNo =QRY2.REquestNo      
			)QRYBudgetStatus          
				on QRYBudgetStatus.BranchID = Agreement.BranchID      
				and QRYBudgetStatus.ApplicationID = Agreement.ApplicationID       
			inner join product with (nolock) on 
				agreement.productid = product.productid
			inner join assettype with (nolock) on
				product.assettypeid = assettype.assettypeid
			--Add fuji,25 Nov 2019 (FMF-1936)
			left join DaysforAssetSellingException DayAsl with (nolock)
				on AgreementAsset.AssetTypeID=DayAsl.AssetTypeID
				AND agreement.NTF BETWEEN DayAsl.NTFFrom and DayAsl.NTFTo
			--End fuji
			--Raug 1 Oktober 2021 FMF-3035 :  Ubah query nya Vincenza karena dulu belum ada penjagaan double input waktu save UnlockAssetSelling
			--Vincenza FMF-2575 18022021
			--left join UnlockAssetSelling UAS with (nolock)
			--	on agreement.BranchID = UAS.BranchID and Agreement.ApplicationID = UAS.ApplicationID and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
			--end Vincenza
			left join 
			(	SELECT	MIN(UnlockID) UnlockID, BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo 
				FROM	UnlockAssetSelling 
				GROUP BY BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo
				) UAS
			ON Agreement.BranchID=UAS.BranchID 
			and Agreement.ApplicationID = UAS.ApplicationID 
			and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo 
			and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
		---End Raug
		'' + @cmdwhere
---End Raug [FMF-3226]
    

 print  @SqlStatement
    
	exec (''
		   with AgrTemp (
			RN,ApplicationID,
		   AgreementNo,      
		   CustomerID,      
		   CustomerName,      
		   AssetDescription,      
		   ChassisNo,
		   EngineNo,
		   Status,
		   BranchID,
		   AssetSeqNO,
		   EstimationAmount,
		   
		--   CurrencyID,
		--	requestno,
			repossesseqno
		--	outstandingprinciple,
		--	osinsurance,
		--	lcinstallment,
		--	lcinsurance,
		--	pdcbouncefee,
		--	repossessionfee,
		--	interestdue,
		--	accruedinterest,
		--	outstandingprinciplealloc,
		--	osinsurancealloc,
		--	lcinstallmentalloc,
		--	lcinsurancealloc,
		--	pdcbouncefeealloc,
		--	repossessionfeealloc,
		--	interestduealloc,
		--	accruedinterestalloc,
		--	prepaidalloc,
		--	approvalno,
		--	approvalid,
		--	approvedby,
		--	ProductID,
			
		--	approvalamount
			, PPNAS -- Add Fajar FMF-4450
		   ) as 
		  ('' + @SqlStatement + '') 
				  Select DISTINCT RN,ApplicationID,
		   AgreementNo,      
		   CustomerID,      
		   CustomerName,      
		   AssetDescription,      
		   ChassisNo,
		   EngineNo,
		   Status,
		   BranchID,
		   AssetSeqNO,
		   EstimationAmount,
		   
		--   CurrencyID,
		--	requestno,
			repossesseqno
		--	outstandingprinciple,
		--	osinsurance,
		--	lcinstallment,
		--	lcinsurance,
		--	pdcbouncefee,
		--	repossessionfee,
		--	interestdue,
		--	accruedinterest,
		--	outstandingprinciplealloc,
		--	osinsurancealloc,
		--	lcinstallmentalloc,
		--	lcinsurancealloc,
		--	pdcbouncefeealloc,
		--	repossessionfeealloc,
		--	interestduealloc,
		--	accruedinterestalloc,
		--	prepaidalloc,
		--	approvalno,
		--	approvalid,
		--	approvedby,
		--	ProductID,
		--	IsProductPerTenor
		--	approvalamount
			, PPNAS -- Add Fajar FMF-4450
		  from AgrTemp
		  where Rn Between '' + @FirstRec + '' and '' +  @LastRec 
	)

SELECT @TotalRecords = TotalRecord FROM #tempTable
drop table #tempTable	 
	
set nocount off


 

')
end
else
begin
exec('



CREATE      Procedure [dbo].[spAssetSellingPaging]      
 @CurrentPage int,      
 @PageSize int,      
 @WhereCond varchar(1000),      
 @SortBy varchar(100),      
 @TotalRecords int output      
AS      
      

/******************************************************************************      
**  File:       
**  Name: [spAssetSellingPaging]      
**  Desc:       
**      
**  This template can be customized:      
**                    
**  Return values:      
**       
**  Called by:         
**                    
**  Parameters:      
**  Input       Output      
**     ----------       -----------      
**      
**  Auth: Anton       
**  Date: 10 November 2006  10:00      
*******************************************************************************      
**  Change History      
*******************************************************************************      
**  Date:  Author:    Description:      
**  --------  --------    -------------------------------------------      
**  01-10-2007 MUL created 
**  Gema, 25 Oktober 2007 : Ganti sp Paging nya   
**  Meytha 03 oct 2019 (FMF-1877) : Tambah ambil dari General Setting untuk mendapatkan n-hari asset selling days
**  Fuji 08 Oct 2019 (FMF-1877) : Asset Selling Listing yang dimunculkan jika sudah melewati 30 hari (atau sesua Settingan di GeneralSetting) dari Repossess Date
**  Fuji,25 Nov 2019 (FMF-1936) : Jika AssetType sudah di setting di DaysforAssetSellingException maka DaysForAssetSelling ambil dari DaysforAssetSellingException jika tidak ada ambil dari DAYSASSETSELLING di GeneralSetting
**	Raug, 1 Oktober 2021 [FMF-3035] : Perbaiki left join ke UnlockAssetSelling supaya jika ada double tidak menyebabkan error
**	Raug, 10 Desember 2021 [FMF-3226] : Menghilangkan beberapa baris script yang diremark saat isi @SqlStatement, karena datatype nya tidak muat
**  Fajar, 01 November 2023 [FMF-4450] : tambah PPNAS dari table AssetType
*******************************************************************************/      
      
      
 set nocount on      
      
 declare @cmdwhere varchar(3000),      
  @BusinessDate varchar(20)      
       
      
 create table #TempTable (
		TotalRecord  Int
 )
      
      
 declare @IsProductPerTenor varchar(1)      
 if exists (select '''' from ChangeSetting where CSID = ''ProductPerTenor'')      
 begin      
  Select @IsProductPerTenor = CsValue from ChangeSetting      
  where CSID = ''ProductPerTenor''      
 end      
 else      
 Begin      
  set @IsProductPerTenor = ''0''      
 End      
      
 select @BusinessDate=CONVERT(VARCHAR(8), BDCurrent, 112) from SystemControlCoy      
 
 --Meytha FMF-1877
 DECLARE @GSValue varchar(3)
 Select @GSValue = GSValue from GeneralSetting where GSID=''DAYSASSETSELLING'' AND ModuleID=''COL''
 --Meytha FMF-1877

 IF (@WhereCond = '''')      
  Set @cmdwhere = ''''      
 else      
 begin      
  if right(rtrim(@WhereCond),2) = ''%''''''      
  begin       
   set @WhereCond=replace(@WhereCond , ''='' , ''  like  '')      
   set @WhereCond = @WhereCond + ''and (
		(DayAsl.AssetTypeID IS NULL AND  (DateAdd(day,convert(int,''''''+ltrim(rtrim(@GSValue))+''''''),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''') --add Fuji 08 Oct 2019 (FMF-1877)
		OR 
		(DayAsl.AssetTypeID IS NOT NULL 
		and agreement.NTF between DayAsl.NTFFrom and  DayAsl.NTFTo 
		AND   (DateAdd(day,convert(int,DayAsl.DaysForAssetSelling),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''')
		--Vincenza FMF-2575 18022021
		OR 
		UAS.ApplicationID IS NOT NULL
		)''       -- Meytha FMF-1877 --edit fuji,27 nov 2019 (fmf-1936)
      
  end     
  
 
  SET @cmdwhere =       
   ''      
   WHERE CollectionAgreement.ActiveStatus=''''Y''''      
           and AssetRepossessionOrder.RepossesionStatus=''''E''''       
	--edit fuji,25 nov 2019 (fmf-1936)
	and (
		(DayAsl.AssetTypeID IS NULL AND  (DateAdd(day,convert(int,''''''+ltrim(rtrim(@GSValue))+''''''),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''') --add Fuji 08 Oct 2019 (FMF-1877)
		OR 
		(DayAsl.AssetTypeID IS NOT NULL 
		and agreement.NTF between DayAsl.NTFFrom and  DayAsl.NTFTo 
		AND   (DateAdd(day,convert(int,DayAsl.DaysForAssetSelling),AssetRepossessionOrder.RepossesDate))  <= '''''' + @BusinessDate + '''''')
		--Vincenza FMF-2575 18022021
		OR 
		UAS.ApplicationID IS NOT NULL
    )
	--end fuji
    and AssetRepossessionOrder.ApprovalStatus = ''''APV''''      
    and AssetRepossessionOrder.ApplicationID       
     in       
     (      
      select ExInvAppraisalasset.ApplicationID from ExInvAppraisalasset with (nolock)      
      INNER JOIN ExInvAppraisal  with (nolock)       
      on ExInvAppraisal.BranchID = ExInvAppraisalasset.BranchID and      
         ExInvAppraisal.ApplicationID = ExInvAppraisalasset.ApplicationID and      
         ExInvAppraisal.RequestNo=ExInvAppraisalAsset.RequestNo       
      where  ExInvAppraisal.ApprovalStatus=''''APV''''      
     )      
    and       
    '' + @WhereCond      
 end      
   

 
 If @SortBy=''''      
  set @SortBy='' order by Agreement.AgreementNo  ''      
 else      
 begin      
  set @SortBy=replace(@SortBy, ''AgreementNo'',''CollectionAgreement.AgreementNo'')      
  set @SortBy=replace(@SortBy, ''CustomerName'',''Customer.Name'')      
  set @SortBy=replace(@SortBy, ''AssetDescription'',''AssetMaster.Description'')      
      
  set @SortBy=replace(@SortBy, ''EstimationDate'',''AssetRepossessionOrder.EstimationDate'')      
  set @SortBy=replace(replace(@SortBy, ''AppraisalDate'',''ExInvAppraisal.RequestDate''),''Status'',''assetrepossessionorder.flagselected'')      
  set @SortBy=replace(replace(replace(@SortBy, ''EstimationAmount'',''AssetRepossessionOrder.EstimationAmount''),''ChassisNo'',''agreementasset.serialno1''),''EngineNo'',''agreementasset.serialno2'')     
  set @SortBy='' Order BY  '' + @SortBy       
 end

    DECLARE @FirstRec int, @LastRec int
    SELECT @FirstRec = (@CurrentPage - 1) * @PageSize +1
    SELECT @LastRec = (@CurrentPage * @PageSize + 1) -1



    exec (''Insert Into #TempTable(TotalRecord) 
	   Select Count(1) 
			 from  AssetRepossessionOrder with (nolock)       
		inner join collectionAgreement with (nolock)       
		on CollectionAgreement.ApplicationID=AssetRepossessionOrder.ApplicationID and CollectionAgreement.BranchID=AssetRepossessionOrder.BranchID       
		inner join Agreement with (nolock)       
		on CollectionAgreement.ApplicationID=Agreement.ApplicationID and CollectionAgreement.BranchID=Agreement.BranchID      
		inner join       
		(         
		select BranchID, ApplicationID, count(AssetSeqNo) TotalAsset      
		from AgreementAsset      
		where AssetStatus not in (''''RLS'''',''''RRD'''',''''SLD'''',''''PRP'''')      
		GROUP BY BranchID, ApplicationID      
		)qryTotalAsset      
		on qryTotalAsset.BranchID=Agreement.BranchID      
		and qryTotalAsset.ApplicationID=Agreement.ApplicationID      
		  
		inner join Customer with (nolock)       
		on Agreement.CustomerID=Customer.CustomerID      
		inner join AgreementAsset with (nolock)       
		on CollectionAgreement.ApplicationID=AgreementAsset.ApplicationID and CollectionAgreement.BranchID=AgreementAsset.BranchID   and      
		   assetRepossessionOrder.AssetSeqNo = AgreementAsset.AssetSeqNo      
		Inner join       
		(      
		 Select BranchId,ApplicationID,AssetSeqNo,      
		 Max(RepossesSeqNo) as MaxRepossesSeqNo      
		 from AssetRepossessionOrder with (noLock)      
		 Group By BranchID, ApplicationID, AssetSeqNo      
		 )QARO      
		  on QARO.BranchID = Agreement.BranchID and      
		  QARO.ApplicationID = Agreement.ApplicationID and      
		  QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo and      
		  QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo      
		inner join AssetMaster with (nolock)       
		on AssetMaster.AssetCode=AgreementAsset.AssetCode      
		inner join Currency       
		ON Agreement.CurrencyID=Currency.CurrencyID      
		  
		inner join ExInvAppraisal      
		on ExInvAppraisal.BranchID = Agreement.BranchID      
		  AND ExInvAppraisal.ApplicationID = Agreement.ApplicationID      
		  AND ExInvAppraisal.ApprovalStatus= ''''APV''''      
		  
		inner join ExInvAppraisalAsset      
		on ExInvAppraisalAsset.BranchID = Agreement.BranchID and      
		  ExInvAppraisalAsset.ApplicationID = Agreement.ApplicationID and      
		  ExInvAppraisalAsset.RequestNo = ExInvAppraisal.RequestNo and      
		  ExInvAppraisalAsset.AssetSeqNo = QARO.AssetSeqNo and      
		  ExInvAppraisalAsset.RepossessSeqNo = QARO.MaxRepossesSeqNo       
		  
		LEFT join Collector with (nolock)     
		on AssetRepossessionOrder.collectorid = Collector.collectorid    
		and AssetRepossessionOrder.cgid = Collector.cgid    
		  
		--Dedy 22 January 2006--       
		left join (      
		 select  QRY1.BranchID,      
		  QRY1.ApplicationID,      
		  QRY2.BudgetStatus,      
		  QRY1.RequestNo      
		 from      
		 (      
		  select  BranchID,      
		   ApplicationID,      
		   max(RequestNo) as RequestNo      
		  from ExBudgetExecutor with (nolock)      
		  group by BranchID,      
		   ApplicationID      
		 )QRY1      
		 inner join      
		 (      
		  select  BranchID,      
		   ApplicationID,      
		   BudgetStatus,      
		   max(RequestNo) as RequestNo      
		  from ExBudgetExecutor with (nolock)      
		  group by BranchID,      
		   ApplicationID,      
		   BudgetStatus      
		 )QRY2      
		 on QRY1.BranchID = QRY2.BranchID      
		 and QRY1.ApplicationID = QRY2.ApplicationID      
		 and QRY1.RequestNo =QRY2.REquestNo      
		)QRYBudgetStatus      
		      
		on QRYBudgetStatus.BranchID = Agreement.BranchID      
		and QRYBudgetStatus.ApplicationID = Agreement.ApplicationID      
		  
		inner join product with (nolock) on 
			agreement.productid = product.productid
		inner join assettype with (nolock) on
			product.assettypeid = assettype.assettypeid
		--Add fuji,25 Nov 2019 (FMF-1936)
		left join DaysforAssetSellingException DayAsl with (nolock)
			on AgreementAsset.AssetTypeID=DayAsl.AssetTypeID
			AND agreement.NTF BETWEEN DayAsl.NTFFrom and DayAsl.NTFTo
		--End fuji
		--Raug 1 Oktober 2021 FMF-3035 :  Ubah query nya Vincenza karena dulu belum ada penjagaan double input waktu save UnlockAssetSelling
		--Vincenza FMF-2575 18022021
		--left join UnlockAssetSelling UAS with (nolock)
		--	on agreement.BranchID = UAS.BranchID and Agreement.ApplicationID = UAS.ApplicationID and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
		--end Vincenza
		left join (	SELECT	MIN(UnlockID) UnlockID, BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo 
					FROM	UnlockAssetSelling 
					GROUP BY BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo
					) UAS
				ON Agreement.BranchID=UAS.BranchID 
				and Agreement.ApplicationID = UAS.ApplicationID 
				and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo 
				and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
		--End Raug
		'' + @cmdwhere
   )


 Declare @SqlStatement as VarChar(8000)

---Raug, 10 Desember 2021 [FMF-3226] : Menghilangkan beberapa baris script yang diremark saat isi @SqlStatement, karena datatype nya tidak muat
-- Set @SqlStatement = ''select ROW_NUMBER() OVER (''+ @SortBy + ''), 
--   Agreement.ApplicationID,
--   CollectionAgreement.AgreementNo,      
--   Agreement.CustomerID,      
--   Customer.Name CustomerName,      
--   AssetMaster.Description,      
--   agreementasset.serialno1,
--   agreementasset.serialno2,
--   (case assetrepossessionorder.flagselected when 0 then ''''Not Selected'''' else ''''Selected'''' end),
--   agreement.branchid,
--   assetrepossessionorder.assetseqno,
--   ExInvAppraisalAsset.EstimationAmount,
   
----   Currency.CurrencyID,
----	AssetRepossessionOrder.requestno,
--	AssetRepossessionOrder.repossesseqno -- Vincenza FMF-2575 18022021 
----	outstandingprinciple,
----	osinsurance,
----	agreement.lcinstallment,
----	agreement.lcinsurance,
----	agreement.pdcbouncefee,
----	repossessionfee,
----	interestdue,
----	AssetRepossessionOrder.accruedinterest,
----	outstandingprinciplealloc,
----	osinsurancealloc,
----	lcinstallmentalloc,
----	lcinsurancealloc,
----	pdcbouncefeealloc,
----	repossessionfeealloc,
----	interestduealloc,
----	accruedinterestalloc,
----	prepaidalloc,
----	agreement.approvalno,
----	AssetRepossessionOrder.approvalid,
----	approvedby,
----	agreement.ProductID,
----	AssetRepossessionOrder.approvalamount
--  from  AssetRepossessionOrder with (nolock)       
--   inner join collectionAgreement with (nolock)       
--    on CollectionAgreement.ApplicationID=AssetRepossessionOrder.ApplicationID and CollectionAgreement.BranchID=AssetRepossessionOrder.BranchID       
--   inner join Agreement with (nolock)       
--    on CollectionAgreement.ApplicationID=Agreement.ApplicationID and CollectionAgreement.BranchID=Agreement.BranchID      
--   inner join       
--   (         
--    select BranchID, ApplicationID, count(AssetSeqNo) TotalAsset      
--    from AgreementAsset      
--    where AssetStatus not in (''''RLS'''',''''RRD'''',''''SLD'''',''''PRP'''')      
--    GROUP BY BranchID, ApplicationID      
--   )qryTotalAsset      
--    on qryTotalAsset.BranchID=Agreement.BranchID      
--    and qryTotalAsset.ApplicationID=Agreement.ApplicationID      
      
--   inner join Customer with (nolock)       
--    on Agreement.CustomerID=Customer.CustomerID      
--   inner join AgreementAsset with (nolock)       
--    on CollectionAgreement.ApplicationID=AgreementAsset.ApplicationID and CollectionAgreement.BranchID=AgreementAsset.BranchID   and      
--       assetRepossessionOrder.AssetSeqNo = AgreementAsset.AssetSeqNo      
--   Inner join       
--    (      
--     Select BranchId,ApplicationID,AssetSeqNo,      
--     Max(RepossesSeqNo) as MaxRepossesSeqNo      
--     from AssetRepossessionOrder with (noLock)      
--     Group By BranchID, ApplicationID, AssetSeqNo      
--     )QARO      
--      on QARO.BranchID = Agreement.BranchID and      
--      QARO.ApplicationID = Agreement.ApplicationID and      
--      QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo and      
--      QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo      
--   inner join AssetMaster with (nolock)       
--   on AssetMaster.AssetCode=AgreementAsset.AssetCode      
--   inner join Currency       
--   ON Agreement.CurrencyID=Currency.CurrencyID      
      
--   inner join ExInvAppraisal      
--   on ExInvAppraisal.BranchID = Agreement.BranchID      
--      AND ExInvAppraisal.ApplicationID = Agreement.ApplicationID      
--      AND ExInvAppraisal.ApprovalStatus= ''''APV''''      
      
--   inner join ExInvAppraisalAsset      
--   on ExInvAppraisalAsset.BranchID = Agreement.BranchID and      
--      ExInvAppraisalAsset.ApplicationID = Agreement.ApplicationID and      
--      ExInvAppraisalAsset.RequestNo = ExInvAppraisal.RequestNo and      
--      ExInvAppraisalAsset.AssetSeqNo = QARO.AssetSeqNo and      
--      ExInvAppraisalAsset.RepossessSeqNo = QARO.MaxRepossesSeqNo       
      
--  LEFT join Collector with (nolock)     
--   on AssetRepossessionOrder.collectorid = Collector.collectorid    
--   and AssetRepossessionOrder.cgid = Collector.cgid    
      
--   --Dedy 22 January 2006--       
--   left join (      
--     select  QRY1.BranchID,      
--      QRY1.ApplicationID,      
--      QRY2.BudgetStatus,      
--      QRY1.RequestNo      
--     from      
--     (      
--      select  BranchID,      
--       ApplicationID,      
--       max(RequestNo) as RequestNo      
--      from ExBudgetExecutor with (nolock)      
--      group by BranchID,      
--       ApplicationID      
--     )QRY1      
--     inner join      
--     (      
--      select  BranchID,      
--       ApplicationID,      
--       BudgetStatus,      
--       max(RequestNo) as RequestNo      
--      from ExBudgetExecutor with (nolock)      
--      group by BranchID,      
--       ApplicationID,      
--       BudgetStatus      
--     )QRY2      
--     on QRY1.BranchID = QRY2.BranchID      
--     and QRY1.ApplicationID = QRY2.ApplicationID      
--     and QRY1.RequestNo =QRY2.REquestNo      
--    )QRYBudgetStatus      
          
--    on QRYBudgetStatus.BranchID = Agreement.BranchID      
--    and QRYBudgetStatus.ApplicationID = Agreement.ApplicationID      
      
--    inner join product with (nolock) on 
--		agreement.productid = product.productid
--	inner join assettype with (nolock) on
--		product.assettypeid = assettype.assettypeid
--	--Add fuji,25 Nov 2019 (FMF-1936)
--	left join DaysforAssetSellingException DayAsl with (nolock)
--		on AgreementAsset.AssetTypeID=DayAsl.AssetTypeID
--		AND agreement.NTF BETWEEN DayAsl.NTFFrom and DayAsl.NTFTo
--	--End fuji
--	--Raug 1 Oktober 2021 FMF-3035 :  Ubah query nya Vincenza karena dulu belum ada penjagaan double input waktu save UnlockAssetSelling
--	--Vincenza FMF-2575 18022021
--	--left join UnlockAssetSelling UAS with (nolock)
--	--	on agreement.BranchID = UAS.BranchID and Agreement.ApplicationID = UAS.ApplicationID and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
--	--end Vincenza
--	left join (	SELECT	MIN(UnlockID) UnlockID, BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo 
--				FROM	UnlockAssetSelling 
--				GROUP BY BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo
--				) UAS
--			ON Agreement.BranchID=UAS.BranchID 
--			and Agreement.ApplicationID = UAS.ApplicationID 
--			and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo 
--			and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
--	--End Raug
--    '' + @cmdwhere

Set @SqlStatement = 
	''	select	ROW_NUMBER() OVER (''+ @SortBy + ''), 
				Agreement.ApplicationID,
				CollectionAgreement.AgreementNo,      
				Agreement.CustomerID,      
				Customer.Name CustomerName,      
				AssetMaster.Description,      
				agreementasset.serialno1,
				agreementasset.serialno2,
				(case assetrepossessionorder.flagselected when 0 then ''''Not Selected'''' else ''''Selected'''' end),
				agreement.branchid,
				assetrepossessionorder.assetseqno,
				ExInvAppraisalAsset.EstimationAmount,
				AssetRepossessionOrder.repossesseqno -- Vincenza FMF-2575 18022021 
				, assettype.PPNAS  --Add Fajar FMF-4450
		from	AssetRepossessionOrder with (nolock)       
				inner join collectionAgreement with (nolock)       
					on CollectionAgreement.ApplicationID=AssetRepossessionOrder.ApplicationID and CollectionAgreement.BranchID=AssetRepossessionOrder.BranchID       
				inner join Agreement with (nolock)       
					on CollectionAgreement.ApplicationID=Agreement.ApplicationID and CollectionAgreement.BranchID=Agreement.BranchID      
				inner join       
				(         
					select BranchID, ApplicationID, count(AssetSeqNo) TotalAsset      
					from AgreementAsset      
					where AssetStatus not in (''''RLS'''',''''RRD'''',''''SLD'''',''''PRP'''')      
					GROUP BY BranchID, ApplicationID      
				)qryTotalAsset      
					on qryTotalAsset.BranchID=Agreement.BranchID      
					and qryTotalAsset.ApplicationID=Agreement.ApplicationID      
				inner join Customer with (nolock)       
					on Agreement.CustomerID=Customer.CustomerID      
				inner join AgreementAsset with (nolock)       
					on CollectionAgreement.ApplicationID=AgreementAsset.ApplicationID and CollectionAgreement.BranchID=AgreementAsset.BranchID   and      
					assetRepossessionOrder.AssetSeqNo = AgreementAsset.AssetSeqNo      
				Inner join       
				(      
					 Select BranchId,ApplicationID,AssetSeqNo,      
					 Max(RepossesSeqNo) as MaxRepossesSeqNo      
					 from AssetRepossessionOrder with (noLock)      
					 Group By BranchID, ApplicationID, AssetSeqNo      
				 )QARO      
				  on QARO.BranchID = Agreement.BranchID and      
				  QARO.ApplicationID = Agreement.ApplicationID and      
				  QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo and      
				  QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo      
				inner join AssetMaster with (nolock)       
					on AssetMaster.AssetCode=AgreementAsset.AssetCode      
				inner join Currency       
					ON Agreement.CurrencyID=Currency.CurrencyID      
				inner join ExInvAppraisal      
					on ExInvAppraisal.BranchID = Agreement.BranchID      
					AND ExInvAppraisal.ApplicationID = Agreement.ApplicationID      
					AND ExInvAppraisal.ApprovalStatus= ''''APV''''        
				inner join ExInvAppraisalAsset      
					on ExInvAppraisalAsset.BranchID = Agreement.BranchID and      
					ExInvAppraisalAsset.ApplicationID = Agreement.ApplicationID and      
					ExInvAppraisalAsset.RequestNo = ExInvAppraisal.RequestNo and      
					ExInvAppraisalAsset.AssetSeqNo = QARO.AssetSeqNo and      
					ExInvAppraisalAsset.RepossessSeqNo = QARO.MaxRepossesSeqNo       
				LEFT join Collector with (nolock)     
					on AssetRepossessionOrder.collectorid = Collector.collectorid    
					and AssetRepossessionOrder.cgid = Collector.cgid    
				--Dedy 22 January 2006--       
				left join 
				(      
					select  QRY1.BranchID,      
					QRY1.ApplicationID,      
					QRY2.BudgetStatus,      
					QRY1.RequestNo      
					from      
					(      
						select  BranchID,      
								ApplicationID,      
								max(RequestNo) as RequestNo      
						from	ExBudgetExecutor with (nolock)      
						group by BranchID,      
						ApplicationID      
					)QRY1      
					inner join      
					(      
						select  BranchID,      
								ApplicationID,      
								BudgetStatus,      
								max(RequestNo) as RequestNo      
						from	ExBudgetExecutor with (nolock)      
						group by BranchID,      
						ApplicationID,      
						BudgetStatus      
					)QRY2      
					on QRY1.BranchID = QRY2.BranchID      
					and QRY1.ApplicationID = QRY2.ApplicationID      
					and QRY1.RequestNo =QRY2.REquestNo      
			)QRYBudgetStatus          
				on QRYBudgetStatus.BranchID = Agreement.BranchID      
				and QRYBudgetStatus.ApplicationID = Agreement.ApplicationID       
			inner join product with (nolock) on 
				agreement.productid = product.productid
			inner join assettype with (nolock) on
				product.assettypeid = assettype.assettypeid
			--Add fuji,25 Nov 2019 (FMF-1936)
			left join DaysforAssetSellingException DayAsl with (nolock)
				on AgreementAsset.AssetTypeID=DayAsl.AssetTypeID
				AND agreement.NTF BETWEEN DayAsl.NTFFrom and DayAsl.NTFTo
			--End fuji
			--Raug 1 Oktober 2021 FMF-3035 :  Ubah query nya Vincenza karena dulu belum ada penjagaan double input waktu save UnlockAssetSelling
			--Vincenza FMF-2575 18022021
			--left join UnlockAssetSelling UAS with (nolock)
			--	on agreement.BranchID = UAS.BranchID and Agreement.ApplicationID = UAS.ApplicationID and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
			--end Vincenza
			left join 
			(	SELECT	MIN(UnlockID) UnlockID, BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo 
				FROM	UnlockAssetSelling 
				GROUP BY BranchId, ApplicationID, AssetSeqNo, RepossesSeqNo
				) UAS
			ON Agreement.BranchID=UAS.BranchID 
			and Agreement.ApplicationID = UAS.ApplicationID 
			and AssetRepossessionOrder.AssetSeqNo = UAS.AssetSeqNo 
			and AssetRepossessionOrder.RepossesSeqNo = UAS.RepossesSeqNo
		---End Raug
		'' + @cmdwhere
---End Raug [FMF-3226]
    

 print  @SqlStatement
    
	exec (''
		   with AgrTemp (
			RN,ApplicationID,
		   AgreementNo,      
		   CustomerID,      
		   CustomerName,      
		   AssetDescription,      
		   ChassisNo,
		   EngineNo,
		   Status,
		   BranchID,
		   AssetSeqNO,
		   EstimationAmount,
		   
		--   CurrencyID,
		--	requestno,
			repossesseqno
		--	outstandingprinciple,
		--	osinsurance,
		--	lcinstallment,
		--	lcinsurance,
		--	pdcbouncefee,
		--	repossessionfee,
		--	interestdue,
		--	accruedinterest,
		--	outstandingprinciplealloc,
		--	osinsurancealloc,
		--	lcinstallmentalloc,
		--	lcinsurancealloc,
		--	pdcbouncefeealloc,
		--	repossessionfeealloc,
		--	interestduealloc,
		--	accruedinterestalloc,
		--	prepaidalloc,
		--	approvalno,
		--	approvalid,
		--	approvedby,
		--	ProductID,
			
		--	approvalamount
			, PPNAS -- Add Fajar FMF-4450
		   ) as 
		  ('' + @SqlStatement + '') 
				  Select DISTINCT RN,ApplicationID,
		   AgreementNo,      
		   CustomerID,      
		   CustomerName,      
		   AssetDescription,      
		   ChassisNo,
		   EngineNo,
		   Status,
		   BranchID,
		   AssetSeqNO,
		   EstimationAmount,
		   
		--   CurrencyID,
		--	requestno,
			repossesseqno
		--	outstandingprinciple,
		--	osinsurance,
		--	lcinstallment,
		--	lcinsurance,
		--	pdcbouncefee,
		--	repossessionfee,
		--	interestdue,
		--	accruedinterest,
		--	outstandingprinciplealloc,
		--	osinsurancealloc,
		--	lcinstallmentalloc,
		--	lcinsurancealloc,
		--	pdcbouncefeealloc,
		--	repossessionfeealloc,
		--	interestduealloc,
		--	accruedinterestalloc,
		--	prepaidalloc,
		--	approvalno,
		--	approvalid,
		--	approvedby,
		--	ProductID,
		--	IsProductPerTenor
		--	approvalamount
			, PPNAS -- Add Fajar FMF-4450
		  from AgrTemp
		  where Rn Between '' + @FirstRec + '' and '' +  @LastRec 
	)

SELECT @TotalRecords = TotalRecord FROM #tempTable
drop table #tempTable	 
	
set nocount off


 

')
end
Go
