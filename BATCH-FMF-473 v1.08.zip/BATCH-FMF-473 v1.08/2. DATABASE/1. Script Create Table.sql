--FMF-4450
IF NOT EXISTS (
    SELECT * FROM sys.tables t 
    JOIN sys.schemas s ON (t.schema_id = s.schema_id) 
    WHERE s.name = 'dbo' AND t.name = 'InventorySellingInvoice') 
BEGIN
CREATE TABLE [dbo].[InventorySellingInvoice] (
	BranchID CHAR(3),
	ApplicationID VARCHAR(20),
	RequestNo VARCHAR(20),
	InvoiceNo VARCHAR(30),
	FirstPrintedDate DATETIME,
	DocPrintedDate DATETIME,
	LastPrintedBy VARCHAR(50),
	DocPrintedNum SMALLINT,
	UsrUpd UsrUpd,
	DtmUpd DtmUpd
);
END

IF NOT EXISTS (
    SELECT * FROM sys.tables t 
    JOIN sys.schemas s ON (t.schema_id = s.schema_id) 
    WHERE s.name = 'dbo' AND t.name = 'TblBalaiLelang') 
BEGIN
CREATE TABLE [dbo].[TblBalaiLelang] (
	[ID] [varchar](10) Null,
    [Description] [varchar](50) Null,
    [IsActive] [Bit] Null,
	[UsrUpd] [VARCHAR](20),
	[DtmUpd] datetime
);
END

--FMF-4603
IF NOT EXISTS (
    SELECT * FROM sys.tables t 
    JOIN sys.schemas s ON (t.schema_id = s.schema_id) 
    WHERE s.name = 'dbo' AND t.name = 'CashAccumulationLog') 
BEGIN
CREATE TABLE [dbo].[CashAccumulationLog] (
	[PostingDate] [datetime] NULL,
	[CustomerID] [char](20) NULL,
	[ApplicationID] [varchar](20) NULL,
	[HistorySequenceNo] [smallint] NULL,
	[CashAccumulation] [numeric](17,2) NULL,
	[UsrUpd] [VARCHAR](20),
	[DtmUpd] datetime
)
END