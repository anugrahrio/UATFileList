-- FMF-4450 
-- Table assettype
IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'assettype'
                 AND COLUMN_NAME = 'PPNAS') 
BEGIN
	Alter Table assettype
	Add PPNAS varchar(10) not null
	default '0'
END