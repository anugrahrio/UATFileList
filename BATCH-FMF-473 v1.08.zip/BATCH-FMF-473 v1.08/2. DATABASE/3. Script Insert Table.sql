-- FMF-4603
IF NOT EXISTS (SELECT * FROM GeneralSetting WHERE GSID='PAYRCVCASHLIMIT' )
BEGIN
	INSERT INTO [dbo].[GeneralSetting]
	([GSID],[ModuleID],[GSName],[GSValue],[IsUpdatable],[UsrUpd],[DtmUpd])
	VALUES
	('PAYRCVCASHLIMIT','AM','Limit Transaksi Keuangan Tunai','500000000.00','1',SYSTEM_USER,GETDATE())
END


-- FMF-4450
IF NOT EXISTS (SELECT * FROM GeneralSetting WHERE GSID='SignerInvoiceAssetSelling' )
-- Untuk GSValue disesuaikan dengan Nama Signer Invoice Asset Selling
BEGIN
	INSERT INTO [dbo].[GeneralSetting]
	([GSID],[ModuleID],[GSName],[GSValue],[IsUpdatable],[UsrUpd],[DtmUpd])
	VALUES
	('SignerInvoiceAssetSelling','AM','Signer Invoice Asset Selling','Ferry Herriawan','1',SYSTEM_USER,GETDATE())
END

IF NOT EXISTS (SELECT '' FROM GeneralSetting WHERE GSID = 'PPNAS')
BEGIN
	INSERT INTO [dbo].[GeneralSetting]
	([GSID],[ModuleID],[GSName],[GSValue],[IsUpdatable],[UsrUpd],[DtmUpd])
	VALUES
	('PPNAS','COL','PPN Percentage for Asset Selling',1.1,1,SYSTEM_USER,GETDATE())
END

IF NOT EXISTS(SELECT '' FROM PaymentAllocation WHERE PaymentAllocationID = 'APTAXAS')
-- Untuk COA dan GROUP COA mohon di ganti sesuai kebutuhan, '123' hanya sebagai placeholder
BEGIN
	INSERT INTO dbo.PaymentAllocation VALUES
	('APTAXAS','AP Tax Asset Selling','AP Tax Asset Selling',1,1,0,0,0,0,0,'','',1,SYSTEM_USER,GETDATE(),'-')
END

INSERT INTO [dbo].[TblBalaiLelang]
([ID],[Description],[IsActive],[UsrUpd],[DtmUpd])
VALUES
('BL1','Balai Lelang A',1,SYSTEM_USER,GETDATE()),
('BL2','Balai Lelang B',1,SYSTEM_USER,GETDATE()),
('BL3','Balai Lelang C',1,SYSTEM_USER,GETDATE())