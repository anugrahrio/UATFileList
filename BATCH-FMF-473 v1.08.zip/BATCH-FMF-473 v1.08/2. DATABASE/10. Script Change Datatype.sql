IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
           WHERE TABLE_NAME = 'assettype' AND COLUMN_NAME = 'PPNAS')
BEGIN
    DECLARE @defaultConstraintName NVARCHAR(200)
    SELECT @defaultConstraintName = d.name
    FROM sys.columns c
    JOIN sys.default_constraints d ON c.default_object_id = d.object_id
    WHERE c.object_id = OBJECT_ID('assettype') AND c.name = 'PPNAS'

    IF @defaultConstraintName IS NOT NULL
    BEGIN
        DECLARE @sql NVARCHAR(MAX)
        SET @sql = 'ALTER TABLE assettype DROP CONSTRAINT ' + @defaultConstraintName
        EXEC sp_executesql @sql
    END

    ALTER TABLE assettype
    ALTER COLUMN PPNAS Numeric(5,3);
END