-- FMF-4450
IF NOT EXISTS (SELECT * FROM MasterSequence WHERE MSSequenceID='INCOICEAS' )
BEGIN
	insert into MasterSequence
	(MSSequenceID,BranchID,SequenceName,SequenceNo,LengthNo,ResetFlag,UsrUpd,DtmUpd)
	Values
	('INCOICEAS','999','Invoice No',1,5,'A',SYSTEM_USER,GETDATE())
End