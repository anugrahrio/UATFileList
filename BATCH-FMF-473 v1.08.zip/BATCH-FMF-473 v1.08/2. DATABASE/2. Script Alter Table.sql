-- FMF-4450
-- Table ExInvSellingHeader
IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'BiddingType') 
BEGIN
	Alter Table ExInvSellingHeader
	Add BiddingType CHAR(1)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'NIK') 
BEGIN
	Alter Table ExInvSellingHeader
	Add NIK VARCHAR(20)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'NPWP') 
BEGIN
	Alter Table ExInvSellingHeader
	Add NPWP VARCHAR(20)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'SellingAddress') 
BEGIN
	Alter Table ExInvSellingHeader
	Add SellingAddress VARCHAR(100)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'SellingRT') 
BEGIN
	Alter Table ExInvSellingHeader
	Add SellingRT VARCHAR(3)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'SellingRW') 
BEGIN
	Alter Table ExInvSellingHeader
	Add SellingRW VARCHAR(3)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'SellingKelurahan') 
BEGIN
	Alter Table ExInvSellingHeader
	Add SellingKelurahan VARCHAR(30)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'SellingKecamatan') 
BEGIN
	Alter Table ExInvSellingHeader
	Add SellingKecamatan VARCHAR(30)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'SellingCity') 
BEGIN
	Alter Table ExInvSellingHeader
	Add SellingCity VARCHAR(30)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'SellingZipCode') 
BEGIN
	Alter Table ExInvSellingHeader
	Add SellingZipCode VARCHAR(5)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'DPP') 
BEGIN
	Alter Table ExInvSellingHeader
	Add DPP NUMERIC(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'PPN') 
BEGIN
	Alter Table ExInvSellingHeader
	Add PPN NUMERIC(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'BiddingFee') 
BEGIN
	Alter Table ExInvSellingHeader
	Add BiddingFee Numeric(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'MobilisationFee') 
BEGIN
	Alter Table ExInvSellingHeader
	Add MobilisationFee NUMERIC(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingHeader'
                 AND COLUMN_NAME = 'BalaiLelangID') 
BEGIN
	Alter Table ExInvSellingHeader
	Add BalaiLelangID VARCHAR(20)
END

-- Table ExInvSellingDetail
IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingDetail'
                 AND COLUMN_NAME = 'BiddingFee') 
BEGIN
	Alter Table ExInvSellingDetail
	Add BiddingFee Numeric(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingDetail'
                 AND COLUMN_NAME = 'MobilisationFee') 
BEGIN
	Alter Table ExInvSellingDetail
	Add MobilisationFee NUMERIC(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingDetail'
                 AND COLUMN_NAME = 'DPP') 
BEGIN
	Alter Table ExInvSellingDetail
	Add DPP NUMERIC(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingDetail'
                 AND COLUMN_NAME = 'PPN') 
BEGIN
	Alter Table ExInvSellingDetail
	Add PPN NUMERIC(17,2) DEFAULT 0 NOT NULL
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingDetail'
                 AND COLUMN_NAME = 'InvoiceNo') 
BEGIN
	Alter Table ExInvSellingDetail
	Add InvoiceNo VARCHAR(50)
END

IF NOT EXISTS(SELECT *
          FROM   INFORMATION_SCHEMA.COLUMNS
          WHERE  TABLE_NAME = 'ExInvSellingDetail'
                 AND COLUMN_NAME = 'InvoiceDate') 
BEGIN
       Alter Table ExInvSellingDetail
       Add InvoiceDate datetime NULL
END