Update AssetType
set PPNAS = '1.1'
where AssetTypeID <> '4'