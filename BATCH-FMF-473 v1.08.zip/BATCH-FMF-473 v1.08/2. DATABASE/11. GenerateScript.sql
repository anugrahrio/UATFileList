SET ANSI_NULLS OFF
Go
SET QUOTED_IDENTIFIER OFF
Go
IF OBJECT_ID('spOtherReceiveTransactionsExpiredValidation') IS NOT NULL
begin
exec('


ALTER Procedure[dbo].[spOtherReceiveTransactionsExpiredValidation]
	@ApplicationID Varchar(20),
	@PPNAS Varchar(10) output
AS



select @PPNAS = ISNUll(AssetType.PPNAS,0) from Agreement with (nolock)
Inner Join Product with (nolock) On Agreement.ProductID = Product.ProductID
Inner Join AssetType with (nolock) on  AssetType.AssetTypeID = Product.AssetTypeID
Where Agreement.ApplicationId = @ApplicationID
')
end
else
begin
exec('


CREATE Procedure[dbo].[spOtherReceiveTransactionsExpiredValidation]
	@ApplicationID Varchar(20),
	@PPNAS Varchar(10) output
AS


select @PPNAS = ISNUll(AssetType.PPNAS,0) from Agreement with (nolock)
Inner Join Product with (nolock) On Agreement.ProductID = Product.ProductID
Inner Join AssetType with (nolock) on  AssetType.AssetTypeID = Product.AssetTypeID
Where Agreement.ApplicationId = @ApplicationID
')
end
Go
