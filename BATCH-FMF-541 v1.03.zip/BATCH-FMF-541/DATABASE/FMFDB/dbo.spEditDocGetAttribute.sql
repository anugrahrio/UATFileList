SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO


ALTER Procedure [dbo].[spEditDocGetAttribute]
	/* Param List */
	@ApplicationID char(20),
	@AssetSeqNo int
AS

/******************************************************************************
**		File: 
**		Name: spEditDocGetAttribute
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:				Author:				Description:
**		--------			--------			-------------------------------------------
**		26 September 2024	Sugiono				FMF-5176 License Plate Kosong pada Agreement Asset : saat di coding untuk Licenseplate ke reset jadi '' kosong. di taruh last row agar saat set parameter save tidak  '' kosong
**    
*******************************************************************************/
set nocount on

	begin
		SELECT     
			AssetAttribute.[Name] as [Name],
			CASE WHEN AssetAttribute.AttributeType = 'C' THEN 'False' ELSE 'True' END AS AttributeType, 
			AssetAttribute.AttributeLength,
			AssetAttribute.AttributeID,
			AttributeContent as AttributeContent,
			AssetAttribute.AssetTypeID,
			AssetAttributeContent.AssetSeqNo
		FROM         
			AssetAttribute with (nolock)
		INNER JOIN 
			AssetAttributeContent with (nolock)
					     on AssetAttributeContent.AssetTypeID = AssetAttribute.AssetTypeID 
		    				and AssetAttributeContent.AttributeID = AssetAttribute.AttributeID 
		WHERE  
			AssetAttributeContent.ApplicationID=@ApplicationID and 
			AssetAttributeContent.AssetSeqNo=@AssetSeqNo
		--Sugiono FMF-5176
		ORDER BY CASE
             WHEN AssetAttribute.AttributeID = 'LICPLATE' THEN
                 1
         END ASC;
		 --End FMF-5176
	end

set nocount off





GO

