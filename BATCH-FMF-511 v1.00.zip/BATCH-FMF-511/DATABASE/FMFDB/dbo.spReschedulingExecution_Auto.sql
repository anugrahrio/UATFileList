SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO



/*   
Copy dari spReschedulingExecution, FMF-1394  
 Modified : Indra, 28Oct2014 tambah update Rescheduling and ReschedulingUpload  
�Ria 12 Nov 2014 FMF-1395  
 27 Nov 2014 fase 3  
Restu PI-189 25 Okt 2017 tambah case when PSAK karena belom tentu setiap rescheduling itu accrued PSAK, bisa jadi kalau backdated ke sebelum EOM malah reverse accrued yang dari eff date s.d EOM  
Novia 19 Februari 2019 : FMF-1753  
Mery, 31 Jul 2020 [FMF-2274] remark select @requestno  
Candra 22 Sept 2020 [FMF-2349]: unremark perbaikan mery dan tambah wherecond status rescheduling yang A  
Felix 21/10/2020 perpanjang supplier name
Raug 11 Mei 2021 [FMF-2675] : Menset Business date menjadi bdcurrent from systemcontrolcoy
Sugiono, 29 Februari 2024 : FMF-4926 Double Transaction Reschedulling : menambahkan Exit SP saat update gagal
*/

ALTER PROCEDURE [dbo].[spReschedulingExecution_Auto]
    @BranchID AS VARCHAR(3),
    @ApplicationID VARCHAR(20),
    @RequestNo VARCHAR(20),
    @SeqNo AS SMALLINT,
    @BusinessDate AS DATETIME,
    @EffectiveDate AS DATETIME,
    @ToleranceAmount AS NUMERIC(17, 2)
AS
SET NOCOUNT ON;

-- fase3  
DECLARE @GSVALUE AS CHAR(1);
IF EXISTS (SELECT '' FROM GeneralSetting WHERE GSID = 'RESCHAUTO')
BEGIN
    SELECT @GSVALUE = GSValue
    FROM GeneralSetting
    WHERE GSID = 'RESCHAUTO';
END;
ELSE
BEGIN
    SET @GSVALUE = 0;
END;


--SELECT * FROM  asd  
DECLARE @Error AS INT,
        @OTR AS Amount,
        @DP AS Amount,
        @Total AS Amount,
        @ContractPrepaidAmount AS Amount,
        @sequenceNo AS VARCHAR(20),
        @AgreementNo AS CHAR(20),
        @Name AS VARCHAR(50),
        @Desc AS VARCHAR(1000),
        @SupplierName AS VARCHAR(200), --edit felix 21/10/2020
        @SupplierID AS CHAR(10),
        @Counter AS INT,
        @AmountReceive AS Amount,
        @AmountJournal AS Amount,
        @RefDesc AS VARCHAR(50),
        @CompanyID AS VARCHAR(3),
        @PostJournal AS VARCHAR(1),
        @PaymentAllocationJournal AS VARCHAR(20),
        @TransactionID AS VARCHAR(50),
        @JournalCode AS VARCHAR(20),
        @ProcessID AS VARCHAR(20),
        @WOP AS VARCHAR(2),
        @No SMALLINT;

DECLARE @branchagreement CHAR(3),
        @applicationidagreement VARCHAR(20),
        @InsuranceClaimExpenseWaived Amount,
        @InsuranceWaived Amount,
        @Interest Amount,
        @IncRecognize Amount,
        @TotalECI Amount,
        @OSInstallmentDue Amount,
        @OSInsuranceDue Amount,
        @OSLCInstallment Amount,
        @OSLCInsurance Amount,
        @OSPDCBounceFee Amount,
        @OSRepoFee Amount,
        @RepoFeeDisc Amount,
        @AccruedAmount Amount,
        @LCInstallmentAmountDisc Amount,
        @LCInsuranceAmountDisc Amount,
        @PDCBounceFeeDisc Amount,
        @ECIAmount Amount,
        @OutstandingPrincipalOld Amount,
        @OutstandingPrincipalNew Amount,
        @OutstandingInterestNew Amount,
        @OutstandingInterestOld Amount,
        @AmountIncRec Amount,
        @InterestAmount Amount,
        @TotalAmountToBePaid Amount,
        @AdministrationFee Amount,
        @ProductID AS ProductID,
        @TotalAmount Amount,
        @TotalDiscount Amount,
        @OldSeqNo Amount,
        @NewSeq Amount,
        @LastDue DATETIME,
        @NextDue DATETIME,
        @LastIncRecognize DATETIME,
        @StartPeriod DATETIME,
        @EndPeriod DATETIME,
        @RecognizeDays SMALLINT,
        @CurrencyID CHAR(3),
        @CurrencyRate Amount,
        @TotalD Amount,
        @TotalC Amount,
        -- Add By Yovita Mar 22 2006 ======      
        @MaxSeqNo INTEGER,
        @DueDate DATETIME,
        @AmountIncRecognize NUMERIC(17, 2),
        @RecognizeAmountADJ NUMERIC(17, 2),
        @OldAmountIncRecognize NUMERIC(17, 2),
        @NewInterestAmount NUMERIC(17, 2),
        @PaymentFrequency INT,
        @OldEffectiveRate Rate,
        @NewEffectiveRate Rate,
        @InsSeqNo INTEGER,
        @AccruedResch NUMERIC(17, 2),
        @AccruedAdj NUMERIC(17, 2),
        @AccruedEOM NUMERIC(17, 2),
        @RescExpToleranceDays AS INTEGER,
        @ReQuestDate AS DATETIME,
        @EffDate AS DATETIME,
        @currencyrounded NUMERIC(17, 2),
        --Add by Gema, 20081024  
        @InterestDue NUMERIC(17, 2);
--=================================     

--SELECT * FROM asd  

SET @WOP = 'CP';
SET @ProcessID = 'RESC';
SET @TransactionID = 'RESC';
SET @Error = 0;
SET @AmountJournal = 0;

BEGIN TRANSACTION ReschedulingExec;

--Raug 11 Mei 2021 [FMF-2675]

SELECT @BusinessDate = BDCurrent
FROM SystemControlCoy;

--END Raug FMF-2675



--select * from aaa  

--Candra 22 Sept 2020 [FMF-2349]: unremark dan tambah status = A  
--Mery, 31 Jul 2020 [FMF-2274] remark select @requestno  
SELECT @RequestNo = RequestNo
FROM Rescheduling
WHERE BranchId = @BranchID
      AND ApplicationID = @ApplicationID
      AND Status = 'A'
ORDER BY InsSeqNo DESC;
--end Mery  
--End Candra  

IF NOT EXISTS
(
    SELECT ''
    FROM Rescheduling
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationID
          AND RequestNo = @RequestNo
          AND Status = 'A'
)
--And SeqNo = @SeqNo )--And  Status = 'A')      
BEGIN
    RAISERROR('Rescheduling Has Been Change By Another User', 16, 1);
    SET @Error = 1;
    IF @Error > 0
        GOTO ExitSP;
END;
ELSE IF EXISTS
(
    SELECT ''
    FROM Rescheduling R
        INNER JOIN Agreement A
            ON A.BranchID = R.BranchId
               AND A.ApplicationID = R.ApplicationID
    WHERE R.BranchId = @BranchID
          AND R.ApplicationID = @ApplicationID
          AND R.RequestNo = @RequestNo
          AND R.Status = 'A'
          AND A.DefaultStatus = 'NA'
)
BEGIN
    RAISERROR('The AgreementStatus is non Accrual, Please Reversal first!', 16, 1);
    SET @Error = 1;
    IF @Error > 0
        GOTO ExitSP;
END;
/*  
    IF ( --Add by Gema, 20081113 : Penjagaan supaya tidak lewat dari Next Installment DueDate  
         SELECT NextInstallmentDueDate  
         FROM   agreement  
         WHERE  BranchID = @BranchID  
                AND ApplicationID = @ApplicationID  
       ) <= @EffectiveDate  
        BEGIN      
            RAISERROR('The Effective Date can''t be bigger than Next Installment DueDate , Please Rerequest!', 16,1)      
            SET @Error = 1      
            IF @Error > 0  
                GOTO ExitSP      
        END      
    ELSE  
*/
BEGIN

    --Select @LastDateOfEffectiveMonth = dbo.LastFullDateOfMonth(Rtrim(Month(@Effdate)),Rtrim(Year(@Effdate)))      

    DECLARE @Dr Amount,
            @In Amount,
            @Pr Amount,
            @AdminFee Amount;
    --David 9Fe2010--  
    DECLARE @InsuranceIncomeAmount Amount,
            @DeferredInsurIncAmount Amount,
            @OtherRefundAmount Amount,
            @AdmFeeAmount Amount,
            @ProvisionFeeAmount Amount,
            @OtherFeeAmount Amount,
            @SurveyFeeAmount Amount,
            @CostOfSurveyFee Amount; --arif 15 okt 2010  
    -----------------------------------------------------      
    -- Get Due Date From installment start to Resc    --      
    -----------------------------------------------------      
    SELECT @InsSeqNo = InsSeqNo
    FROM Rescheduling
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationID
          AND RequestNo = @RequestNo
          AND Status = 'A';

    SELECT @DueDate = DueDate,
           @LastIncRecognize = ISNULL(LastIncRecognize, '')
    -- @DR = isNull((DiffRateAmount + (DiffRateRecognize * - 1)),0),  
    -- @In = isNull((Incentive - (IncentiveRecognize * - 1)),0),  
    -- @Pr = isNull((Provision - (ProvisionRecognize * - 1)),0)  
    FROM InstallmentSchedule
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationID
          AND InsSeqNo = @InsSeqNo;
    -------------------------------------------------------      


    IF @DueDate <= @BusinessDate
    BEGIN
        RAISERROR('Rescheduling Has Been Expired, because Installment Has Due. Please Re-Request!', 16, 1);
        SET @Error = 1;
        IF @Error > 0
            GOTO ExitSP;
    END;
    -------------------------------------------------------      


    IF EXISTS
    (
        SELECT PDCReceiptNo
        FROM PDCHeader
        WHERE BranchAgreement = @BranchID
              AND ApplicationId = @ApplicationID
              AND PDCStatus = 'PO'
              AND IsClearReconcile = 0
    )
    BEGIN
        RAISERROR('Please Reconcile Your PDC First', 16, 1);
        SET @Error = 1;
        IF @Error > 0
            GOTO ExitSP;
    END;
    ELSE
    BEGIN
        --Backup Agreement To OldAgreement       
        DECLARE @NextSeqNo AS SMALLINT;
        SELECT @NextSeqNo = ISNULL(MAX(AppSeqNo), 0) + 1
        FROM OldAgreement
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationID;

        EXEC @Error = spReschedulingExecutionSaveOldData @BranchID,
                                                         @ApplicationID,
                                                         @NextSeqNo;
        SET @Error = @@error;
        IF @Error > 0
            GOTO ExitSP;


        --  SELECT * FROM abc  
        SELECT @OSInstallmentDue = OSInstallmentDue,
               @OSInsuranceDue = OSInsuranceDue,
               @OSLCInstallment = OSLCInstallment,
               @OSLCInsurance = OSLCInsurance,
               @OSPDCBounceFee = OSPDCBounceFee,
               @OSRepoFee = OSReposessFee,
               @AccruedAmount = AccruedAmount,
               @LCInstallmentAmountDisc = LCInstallmentAmountDisc,
               @LCInsuranceAmountDisc = LCInsuranceAmountDisc,
               @PDCBounceFeeDisc = PDCBounceFeeDisc,
               @ECIAmount = ECIAmount,
               @OSInstallmentDue = OSInstallmentDue,
               @OSInsuranceDue = OSInsuranceDue,
               @OutstandingPrincipalOld = OutstandingPrincipalOld,
               @OutstandingPrincipalNew = OutstandingPrincipalNew,
               @OutstandingInterestNew = OutstandingInterestNew,
               @OutstandingInterestOld = OutstandingInterestOld,
               @TotalAmountToBePaid = TotalAmountToBePaid,
               @AdministrationFee = AdministrationFee,
               @NewEffectiveRate = EffectiveRate,
               @OldEffectiveRate = OldRate,
               @AccruedResch = AccruedResch,
               @AccruedEOM = AccruedEOM,
               @AccruedAdj = AccruedAdj,
               @InsSeqNo = InsSeqNo,
               @EffDate = EffectiveDate,
               @RepoFeeDisc = ReposessFeeDisc,
               --Novia modified, 20190219 FMF-1753  lepas case->when untuk kondisi Effective Date rescheduling = LastDueDate dan businessDate > EOM InsSeqNo berjalan,   
               --maka perlu dibuatkan journal reversal PSAK-nya.  
               -- Yovita 20 Sept 2007: Add Select from Rescheduling  
               /*  
                            @DR = ( CASE WHEN ISNULL(AccruedDiffRate, 0) <> 0  
                                         THEN ISNULL(AccruedDiffRate, 0)  
                                              - ISNULL(AccruedDiffRateEOM, 0)  
                                         ELSE 0  
                                    END ) ,  
                            @In = ( CASE WHEN ISNULL(AccruedIncentive, 0) <> 0  
                                         THEN ISNULL(AccruedIncentive, 0)  
                                              - ISNULL(AccruedIncentiveEOM, 0)  
                                         ELSE 0  
                                    END ) ,  
                            @Pr = ( CASE WHEN ISNULL(AccruedProvision, 0) <> 0  
                                         THEN ISNULL(AccruedProvision, 0)  
                                              - ISNULL(AccruedProvisionEOM, 0)  
                                         ELSE 0  
                                    END ) ,  
                            @AdminFee = ( CASE WHEN ISNULL(AccruedAdminFee, 0) <> 0  
                                               THEN ISNULL(AccruedAdminFee, 0)  
                                                    - ISNULL(AccruedAdminFeeEOM,  
                                                             0)  
                                               ELSE 0  
                                          END )  
        --David 9Feb2010--  
                            ,  
                            @InsuranceIncomeAmount = ( CASE WHEN ISNULL(AccruedInsuranceIncome,  
                                                              0) <> 0  
                                                            THEN ISNULL(AccruedInsuranceIncome,  
                                                              0)  
                                                              - ISNULL(AccruedInsuranceIncomeEOM,  
                                                              0)  
                                                            ELSE 0  
                                                       END ) ,  
                            @DeferredInsurIncAmount = ( CASE WHEN ISNULL(AccDeferredInsurInc,  
                                                              0) <> 0  
                                                             THEN ISNULL(AccDeferredInsurInc,  
                                                              0)  
                                                              - ISNULL(AccDeferredInsurIncEOM,  
                                                              0)  
                                                             ELSE 0  
                                                        END ) ,  
                            @OtherRefundAmount = ( CASE WHEN ISNULL(AccOtherRefund,  
                                                              0) <> 0  
                                                        THEN ISNULL(AccOtherRefund,  
                                                              0)  
                                                             - ISNULL(AccOtherRefundEOM,  
                                                              0)  
                                                        ELSE 0  
                                                   END ) ,  
                            @AdmFeeAmount = ( CASE WHEN ISNULL(AccAdmFee, 0) <> 0  
                                                   THEN ISNULL(AccAdmFee, 0)  
                                                        - ISNULL(AccAdmFeeEOM,  
                                                              0)  
               ELSE 0  
                                              END ) ,  
                            @ProvisionFeeAmount = ( CASE WHEN ISNULL(AccProvisionFee,  
                                                              0) <> 0  
                                                         THEN ISNULL(AccProvisionFee,  
                                                              0)  
                                                              - ISNULL(AccProvisionFeeEOM,  
                                                              0)  
                                                         ELSE 0  
                                                    END ) ,  
                            @OtherFeeAmount = ( CASE WHEN ISNULL(AccOtherFee,  
                                                              0) <> 0  
                                                     THEN ISNULL(AccOtherFee,  
                                                              0)  
                                                          - ISNULL(AccOtherFeeEOM,  
                                                              0)  
                                                     ELSE 0  
                                                END ) ,  
                            @SurveyFeeAmount = ( CASE WHEN ISNULL(AccSurveyFee,  
                                                              0) <> 0  
                                                      THEN ISNULL(AccSurveyFee,  
                                                              0)  
                                                           - ISNULL(AccSurveyFeeEOM,  
                                                              0)  
                                                      ELSE 0  
                                                 END ) ,  
                            @CostOfSurveyFee = ( CASE WHEN ISNULL(AccCostOfSurveyAmountFee,  
                                                              0) <> 0  
                                                      THEN ISNULL(AccCostOfSurveyAmountFee,  
                                                              0)  
                                                           - ISNULL(AccCostOfSurveyAmountFeeEOM,  
                                                              0)  
                                                      ELSE 0  
                                                 END )  
       */
               @Dr = ISNULL(AccruedDiffRate, 0) - ISNULL(AccruedDiffRateEOM, 0),
               @In = ISNULL(AccruedIncentive, 0) - ISNULL(AccruedIncentiveEOM, 0),
               @Pr = ISNULL(AccruedProvision, 0) - ISNULL(AccruedProvisionEOM, 0),
               @AdminFee = ISNULL(AccruedAdminFee, 0) - ISNULL(AccruedAdminFeeEOM, 0),
               @InsuranceIncomeAmount = ISNULL(AccruedInsuranceIncome, 0) - ISNULL(AccruedInsuranceIncomeEOM, 0),
               @DeferredInsurIncAmount = ISNULL(AccDeferredInsurInc, 0) - ISNULL(AccDeferredInsurIncEOM, 0),
               @OtherRefundAmount = ISNULL(AccOtherRefund, 0) - ISNULL(AccOtherRefundEOM, 0),
               @AdmFeeAmount = ISNULL(AccAdmFee, 0) - ISNULL(AccAdmFeeEOM, 0),
               @ProvisionFeeAmount = ISNULL(AccProvisionFee, 0) - ISNULL(AccProvisionFeeEOM, 0),
               @OtherFeeAmount = ISNULL(AccOtherFee, 0) - ISNULL(AccOtherFeeEOM, 0),
               @SurveyFeeAmount = ISNULL(AccSurveyFee, 0) - ISNULL(AccSurveyFeeEOM, 0),
               @CostOfSurveyFee = ISNULL(AccCostOfSurveyAmountFee, 0) - ISNULL(AccCostOfSurveyAmountFeeEOM, 0)
        --eo Novia, 20190219  
        FROM Rescheduling
        WHERE BranchId = @BranchID
              AND ApplicationID = @ApplicationID
              AND RequestNo = @RequestNo
              AND Status = 'A';


        SET @TotalAmount
            = @OSInstallmentDue + @OSInsuranceDue + @OSLCInstallment + @OSLCInsurance + @OSPDCBounceFee
              + @AccruedAmount;

        SET @TotalDiscount = @LCInstallmentAmountDisc + @LCInsuranceAmountDisc + @PDCBounceFeeDisc;
        SET @AmountReceive = @TotalAmount - @TotalDiscount;

        ---ALTER  Journal       

        SELECT @AgreementNo = AGR.AgreementNo,
               @ProductID = AGR.ProductID,
               @CurrencyID = AGR.CurrencyID,
               @CurrencyRate = cur.DailyExchangeRate,
               @ContractPrepaidAmount = ContractPrepaidAmount
        FROM dbo.Agreement AGR
            INNER JOIN Currency cur
                ON AGR.CurrencyID = cur.CurrencyID
        WHERE AGR.BranchID = @BranchID
              AND AGR.ApplicationID = @ApplicationID;

        SELECT @currencyrounded = Rounded
        FROM Currency
        WHERE CurrencyID = @CurrencyID;

        SET @RefDesc = RTRIM(LTRIM(@AgreementNo)) + '#' + @ProductID;

        -------Accured       

        -- modified by emilia 18-07-2006 dari alter menjadi ALTER  temptable       
        CREATE TABLE #TempTable
        (
            SeqNo INT IDENTITY PRIMARY KEY,
            PaymentAllocationID CHAR(10),
            Post CHAR(1),
            Amount NUMERIC(17, 2),
            RefDesc VARCHAR(50),
            DepartementID VARCHAR(3),
            VoucherDesc VARCHAR(50)
        );

        --Anton 16-10-2006      
        DECLARE @Prepaid Amount;

        SET @Prepaid = @ContractPrepaidAmount;

        -- Yovita Nov 29 2006 : Ubah kondisi untuk ambil @ContractPrepaidAmount terkait dengan ToleranceAmount prepaid       
        IF @TotalAmountToBePaid < @Prepaid
        BEGIN
            SET @ContractPrepaidAmount = @TotalAmountToBePaid - @ToleranceAmount;
        END;
        ELSE
        BEGIN
            SET @ContractPrepaidAmount = @TotalAmountToBePaid;
        END;

        ----------------------------------------------------------------------------------------------      

        SET @Counter = 1;
        WHILE @Counter <= 44
        BEGIN

            IF @Counter = 1
            BEGIN
                IF @OSLCInstallment > 0
                BEGIN
                    SET @AmountJournal = @OSLCInstallment;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'LCINSTALL';
                END;
            END;

            IF @Counter = 2
            BEGIN
                IF @LCInstallmentAmountDisc > 0
                BEGIN
                    SET @AmountJournal = @LCInstallmentAmountDisc;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'LCINSTALWO';
                END;
            END;

            IF @Counter = 3
            BEGIN
                IF @OSLCInsurance > 0
                BEGIN
                    SET @AmountJournal = @OSLCInsurance;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'LCINSUR';
                END;
            END;

            IF @Counter = 4
            BEGIN
                IF @LCInsuranceAmountDisc > 0
                BEGIN
                    SET @AmountJournal = @LCInsuranceAmountDisc;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'LCINSURWO';
                END;
            END;

            IF @Counter = 5
            BEGIN
                IF @OSPDCBounceFee > 0
                BEGIN
                    SET @AmountJournal = @OSPDCBounceFee;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'PDCBNCFEE';
                END;
            END;

            IF @Counter = 6
            BEGIN
                IF @PDCBounceFeeDisc > 0
                BEGIN
                    SET @AmountJournal = @PDCBounceFeeDisc;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'PDCBNCFEWO';
                END;
            END;

            IF @Counter = 7
            BEGIN
                IF @OSRepoFee > 0
                BEGIN
                    SET @AmountJournal = @OSRepoFee;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'REPOFEE';
                END;
            END;

            IF @Counter = 8
            BEGIN
                IF @RepoFeeDisc > 0
                BEGIN
                    SET @AmountJournal = @RepoFeeDisc;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'REPOFEEWO';
                END;
            END;

            IF @Counter = 9
            BEGIN
                IF @OSInsuranceDue > 0
                BEGIN
                    SET @AmountJournal = @OSInsuranceDue;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'INSURRCV';
                END;
            END;

            IF @Counter = 10
            BEGIN
                --teddy 23 may 2007 : ubah perhitungan uci pada jurnal tidak lagi berdasarkan parameter yang dikirm melainkan dihitung ulang dari tabel installment schedule        
                SET @PaymentAllocationJournal = 'UCI';
                SET @PostJournal = 'D';
                BEGIN
                    --Set @AmountJournal = @OutstandingInterestOld-(@AccruedAmount - @ECIAmount)      
                    --- Set @AmountJournal = @OutstandingInterestOld-@AccruedEOM     
                    IF @EffectiveDate < @BusinessDate
                       AND (MONTH(@BusinessDate) - MONTH(@EffectiveDate) > 0)
                    BEGIN
                        SET @AmountJournal =
                        (
                            SELECT SUM(InterestAmount)
                            FROM InstallmentSchedule
                            WHERE BranchId = @BranchID
                                  AND ApplicationID = @ApplicationID
                                  AND DueDate > @BusinessDate
                        ) - @AccruedEOM;
                    END;
                    ELSE
                    BEGIN
                        --Add by Gema, 20081024 : rubah InterestAmount dari jadi InterestAmount-AmountIncRecognize  
                        SET @AmountJournal =
                        (
                            SELECT SUM(InterestAmount - AmountIncRecognize)
                            FROM InstallmentSchedule
                            WHERE BranchId = @BranchID
                                  AND ApplicationID = @ApplicationID
                        ); --and Duedate > @EffDate  )     
                    END;
                END;
            END;

            IF @Counter = 11
            BEGIN
                IF @AccruedEOM > 0
                BEGIN
                    SET @AmountJournal = @AccruedEOM;
                    SET @PostJournal = 'D'; -- EARNED EOM Di balikin lagi       
                    SET @PaymentAllocationJournal = 'ECI';
                END;
            -- Lisa 20110120 : Remark kembali utk Else ECI  
            -- Lisa 20101210 : Buka remark else utk ECI      
            --Else --Yovita Sept 12 2006 : Add JournalECI when not passed EOM      
            --   Begin      
            --      Set @AmountJournal = @AccruedAmount       
            --      Set @PostJournal = 'C'   -- EARNED Bertambah      
            --   ENd      

            --Set @PaymentAllocationJournal = 'ECI'    
            -- End Lisa 20101210   
            -- End Lisa 20110120   
            END;

            IF @Counter = 12
            BEGIN
                IF (@OutstandingPrincipalOld + @OutstandingInterestOld) > 0
                BEGIN -- Yovita mar 27 2006 : Add Amount Jurnal untuk ARGROSS di tambah dengan @OSInstallmentDue      
                    -- Yovita June 06 2006 : Jurnal untuk ARGROSS tidak di tambah dengan  @OSInstallmentDue      
                    SET @AmountJournal = @OutstandingPrincipalOld + @OutstandingInterestOld;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'ARGROSS';
                END;
            END;

            IF @Counter = 13
            BEGIN
                IF @OSInstallmentDue > 0 /*( @OutstandingPrincipalOld  
                                         + @OutstandingInterestOld ) > 0*/
                BEGIN -- Yovita June 06 2006 : Add Jurnal untuk INSTALLRCV dengan @OSInstallmentDue      
                    SET @AmountJournal = @OSInstallmentDue;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'INSTALLRCV';
                END;
            END;

            IF @Counter = 14
            BEGIN
                IF (@OutstandingPrincipalNew + @OutstandingInterestNew) > 0
                BEGIN
                    SET @AmountJournal = @OutstandingPrincipalNew + @OutstandingInterestNew;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'ARGROSSRSC';
                END;
            END;

            IF @Counter = 15
            BEGIN
                IF @OutstandingInterestNew > 0 -- Unearn untuk rescheduling dikurang sebesar @AccruedResch, jika sudah lewat EOM      
                BEGIN
                    --Teddy 23 May 2007 : ubah perhitungan jurnal untuk UCIRSC        
                    IF (
                           @EffectiveDate < @BusinessDate
                           AND (MONTH(@BusinessDate) - MONTH(@EffectiveDate) > 0)
                       )
                    BEGIN
                        SET @AmountJournal = @OutstandingInterestNew - @AccruedResch + @AccruedAmount;
                    END;
                    ELSE
                    BEGIN
                        -- Set @AmountJournal = @OutstandingInterestNew - @AccruedResch - @AccruedAmount      
                        -- Yovita Sept 12 2006 : Amount UCIRSC only OSInterestNew when not passed EOM      
                        SET @AmountJournal = @OutstandingInterestNew;
                    END;
                    /*      
  if @AccruedEOM > 0      
  Begin      
  Set @AmountJournal = @OutstandingInterestNew - @AccruedResch + @AccruedAmount       
  End      
  else if @AccruedEOM <= 0        
  Begin      
  -- Set @AmountJournal = @OutstandingInterestNew - @AccruedResch - @AccruedAmount      
  -- Yovita Sept 12 2006 : Amount UCIRSC only OSInterestNew when not passed EOM      
  Set @AmountJournal = @OutstandingInterestNew      
  End      
  */
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'UCIRSC';
                END;
            END;

            IF @Counter = 16 -- Yovita Mar 22 06 : Add ECIRSC      
            BEGIN
                IF @AccruedResch > 0
                BEGIN

                    --Add by Gema, 20081024 : select  @InterestDue  
                    SET @InterestDue = 0;

                    IF NOT EXISTS
                    (
                        SELECT ''
                        FROM InstallmentSchedule
                        WHERE ApplicationID = @ApplicationID
                              AND BranchId = @BranchID
                              AND InsSeqNo = @InsSeqNo - 1
                              AND DueDate = @EffectiveDate
                    )
                    BEGIN
                        SELECT @InterestDue = SUM(InterestAmount - AmountIncRecognize)
                        FROM InstallmentSchedule
                        WHERE BranchId = @BranchID
                              AND ApplicationID = @ApplicationID
                              AND InsSeqNo < @InsSeqNo;

                        --Susanti, 16 Mei 2011  
                        SET @InterestDue = ISNULL(@InterestDue, 0);
                    --end Susanti, 16 Mei 2011  
                    END;

                    SET @AmountJournal = @AccruedAmount --@AccruedResch  
                                         + @InterestDue;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'ECIRSC';
                END;
            END;

            IF @Counter = 17
            BEGIN
                IF @AdministrationFee > 0
                BEGIN
                    SET @AmountJournal = @AdministrationFee;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'ADMINFEE';
                END;
            END;

            IF @Counter = 18
            BEGIN
                IF @ContractPrepaidAmount > 0
                BEGIN
                    SET @AmountJournal = @ContractPrepaidAmount;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'PREPAID';
                END;
            END;

            IF @Counter = 19
            BEGIN
                IF @ToleranceAmount > 0
                BEGIN
                    SET @AmountJournal = @ToleranceAmount;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'TOLAMOUNT';
                END;
            END;

            IF @Counter = 20
            BEGIN
                IF @Dr > 0
                BEGIN
                    SET @AmountJournal = @Dr;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'RATESSIDY';
                END;
                ELSE IF @Dr < 0
                BEGIN
                    SET @AmountJournal = -1 * @Dr;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'RFNDAMZ';
                END;
            END;

            IF @Counter = 21
            BEGIN
                IF @Dr > 0
                BEGIN
                    SET @AmountJournal = @Dr;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'SSIDYAMZ';
                END;
                ELSE IF @Dr < 0
                BEGIN
                    SET @AmountJournal = -1 * @Dr;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'RATERFND';
                END;
            END;


            IF @Counter = 22
            BEGIN
                IF @In <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0  
                BEGIN
                    --Begin Restu PI-189 25 Okt 2017    
                    --SET @AmountJournal = -1 * @In      
                    --SET @PostJournal = 'D'    
                    SET @AmountJournal = ABS(@In);
                    SET @PostJournal = CASE
                                           WHEN @In < 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    --End Restu PI-189 25 Okt 2017   
                    SET @PaymentAllocationJournal = 'INCSUPPEXP';
                END;
            END;

            IF @Counter = 23
            BEGIN
                IF @In <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0  
                BEGIN
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @AmountJournal = -1 * @In      
                    --SET @PostJournal = 'C'   
                    SET @AmountJournal = ABS(@In);
                    SET @PostJournal = CASE
                                           WHEN @In < 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    --End Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'INCENSPL1';
                END;
            END;
            --Novia modify, 20190219 : FMF-1753  
            /*  
                            IF @Counter = 24  
                                BEGIN      
                                    IF @Pr < 0  
                                        BEGIN      
                                            SET @AmountJournal = -1 * @Pr      
                                            SET @PostJournal = 'D'      
                                            SET @PaymentAllocationJournal = 'PROVEXP'      
                                        END      
                                END      
  
                            IF @Counter = 25  
                                BEGIN      
                                    IF @Pr < 0  
                                        BEGIN      
                                            SET @AmountJournal = -1 * @Pr      
                                            SET @PostJournal = 'C'      
                                            SET @PaymentAllocationJournal = 'PROVBANK'      
                                        END      
                                END      
       */
            IF @Counter = 24
            BEGIN
                IF @Pr <> 0
                BEGIN
                    SET @AmountJournal = ABS(@Pr);
                    SET @PostJournal = CASE
                                           WHEN @Pr < 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    SET @PaymentAllocationJournal = 'PROVEXP';
                END;
            END;


            IF @Counter = 25
            BEGIN
                IF @Pr <> 0
                BEGIN
                    SET @AmountJournal = ABS(@Pr);
                    SET @PostJournal = CASE
                                           WHEN @Pr < 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    SET @PaymentAllocationJournal = 'PROVBANK';
                END;
            END;
            --eo Novia, 20190219  
            --Add by Gema, 20081110 : Tambah Jurnal AdminFee ----------------  
            IF @Counter = 26
            BEGIN
                IF @AdminFee <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0  
                BEGIN
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @AmountJournal = -1 * @AdminFee      
                    --SET @PostJournal = 'D'     
                    SET @AmountJournal = ABS(@AdminFee);
                    SET @PostJournal = CASE
                                           WHEN @AdminFee < 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END; --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
                    --End Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'ADMFEEAMZ';
                END;
            END;

            IF @Counter = 27
            BEGIN
                IF @AdminFee <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0  
                BEGIN
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @AmountJournal = -1 * @AdminFee      
                    --SET @PostJournal = 'C'     
                    SET @AmountJournal = ABS(@AdminFee);
                    SET @PostJournal = CASE
                                           WHEN @AdminFee < 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END; --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
                    --End Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'ADMFEEADV';
                END;
            END;
            -- End Gema, 20081110 -----------------------------------------  

            --David 9Feb2010----------------  
            IF @Counter = 28
            BEGIN
                IF @InsuranceIncomeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@InsuranceIncomeAmount);
                    --Begin Restu PI-189 25 Okt 2017    
                    --SET @PostJournal = 'D'    
                    SET @PostJournal = CASE
                                           WHEN @InsuranceIncomeAmount < 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    --END Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'RFNINSRAMZ';
                END;
            END;

            IF @Counter = 29
            BEGIN
                IF @InsuranceIncomeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@InsuranceIncomeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'C'    
                    SET @PostJournal = CASE
                                           WHEN @InsuranceIncomeAmount < 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    --END Restu PI-189 25 Okt 2017     
                    SET @PaymentAllocationJournal = 'INSRRFDEXP';
                END;
            END;
            --===========  
            IF @Counter = 30
            BEGIN
                IF @DeferredInsurIncAmount > 0
                BEGIN
                    SET @AmountJournal = ABS(@DeferredInsurIncAmount);
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'DEFINSUR';
                END;
                ELSE IF @DeferredInsurIncAmount < 0
                BEGIN
                    SET @AmountJournal = ABS(@DeferredInsurIncAmount);
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'INSREXPAMZ';
                END;
            END;

            IF @Counter = 31
            BEGIN
                IF @DeferredInsurIncAmount > 0
                BEGIN
                    SET @AmountJournal = ABS(@DeferredInsurIncAmount);
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'INSRINCAMZ';
                END;
                ELSE IF @DeferredInsurIncAmount < 0
                BEGIN
                    SET @AmountJournal = ABS(@DeferredInsurIncAmount);
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'INSREXPDEF';
                END;
            END;
            --===========  
            IF @Counter = 32
            BEGIN
                IF @OtherRefundAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@OtherRefundAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'D'      
                    SET @PostJournal = CASE
                                           WHEN @OtherRefundAmount < 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    --End Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'COMOTHAMZ';
                END;
            END;

            IF @Counter = 33
            BEGIN
                IF @OtherRefundAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@OtherRefundAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'C'      
                    SET @PostJournal = CASE
                                           WHEN @OtherRefundAmount < 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    --End Restu PI-189 25 Okt 2017    
                    SET @PaymentAllocationJournal = 'COMOTHDEF';
                END;
            END;
            --===========  
            IF @Counter = 34
            BEGIN
                IF @AdmFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@AdmFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'D'    
                    SET @PostJournal = CASE
                                           WHEN @AdmFeeAmount > 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END; --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
                    --End Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'ADMFEEDEF';
                END;
            END;

            IF @Counter = 35
            BEGIN
                IF @AdmFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@AdmFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'C'     
                    SET @PostJournal = CASE
                                           WHEN @AdmFeeAmount > 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END; --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
                    --End Restu PI-189 25 Okt 2017   
                    SET @PaymentAllocationJournal = 'ADMNFEEAMZ';
                END;
            END;
            --===========  
            IF @Counter = 36
            BEGIN
                IF @ProvisionFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@ProvisionFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'D'  
                    SET @PostJournal = CASE
                                           WHEN @ProvisionFeeAmount > 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    --End Restu PI-189 25 Okt 2017      
                    SET @PaymentAllocationJournal = 'PRVFEEDEF';
                END;
            END;

            IF @Counter = 37
            BEGIN
                IF @ProvisionFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@ProvisionFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'C'  
                    SET @PostJournal = CASE
                                           WHEN @ProvisionFeeAmount > 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    --End Restu PI-189 25 Okt 2017     
                    SET @PaymentAllocationJournal = 'PRVFEEAMZ';
                END;
            END;
            --===========  
            IF @Counter = 38
            BEGIN
                IF @OtherFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@OtherFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'D'    
                    SET @PostJournal = CASE
                                           WHEN @OtherFeeAmount > 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    --End Restu PI-189 25 Okt 2017    
                    SET @PaymentAllocationJournal = 'OTHFEEDEF';
                END;
            END;

            IF @Counter = 39
            BEGIN
                IF @OtherFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@OtherFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'C'     
                    SET @PostJournal = CASE
                                           WHEN @OtherFeeAmount > 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    --End Restu PI-189 25 Okt 2017    
                    SET @PaymentAllocationJournal = 'OTHFEEAMZ';
                END;
            END;
            --===========  
            IF @Counter = 40
            BEGIN
                IF @SurveyFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@SurveyFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'D'    
                    SET @PostJournal = CASE
                                           WHEN @SurveyFeeAmount > 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    --End Restu PI-189 25 Okt 2017    
                    --Novia modify, 20190219 : FMF-1753  
                    --SET @PaymentAllocationJournal = 'OTHFEEDEF'      
                    SET @PaymentAllocationJournal = 'SVYFEEDEF';
                --eo Novia  
                END;
            END;

            IF @Counter = 41
            BEGIN
                IF @SurveyFeeAmount <> 0
                BEGIN
                    SET @AmountJournal = ABS(@SurveyFeeAmount);
                    --Begin Restu PI-189 25 Okt 2017  
                    --SET @PostJournal = 'C'    
                    SET @PostJournal = CASE
                                           WHEN @SurveyFeeAmount > 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    --End Restu PI-189 25 Okt 2017   
                    --Novia modify, 20190219 : FMF-1753  
                    --SET @PaymentAllocationJournal = 'OTHFEEAMZ'      
                    SET @PaymentAllocationJournal = 'SVYFEEAMZ';
                --eo Novia, 20190219  
                END;
            END;
            --===========  
            --David 9Feb2010 selesai-----------------------------------------  
            IF @Counter = 42
            BEGIN
                IF @CostOfSurveyFee <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0  
                BEGIN
                    SET @AmountJournal = ABS(@CostOfSurveyFee);
                    --Begin Restu PI-189 25 Okt 2017     
                    --SET @PostJournal = 'D'  
                    SET @PostJournal = CASE
                                           WHEN @CostOfSurveyFee < 0 THEN
                                               'D'
                                           ELSE
                                               'C'
                                       END;
                    --End Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'CSTSVYEXP';
                END;
            END;

            IF @Counter = 43
            BEGIN
                IF @CostOfSurveyFee <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0  
                BEGIN
                    SET @AmountJournal = ABS(@CostOfSurveyFee);
                    --Begin Restu PI-189 25 Okt 2017    
                    --SET @PostJournal = 'C'      
                    SET @PostJournal = CASE
                                           WHEN @CostOfSurveyFee < 0 THEN
                                               'C'
                                           ELSE
                                               'D'
                                       END;
                    --End Restu PI-189 25 Okt 2017  
                    SET @PaymentAllocationJournal = 'CSTSVYDEF';
                END;
            END;


            IF @Counter = 44
            BEGIN -- fase 3        
                IF EXISTS
                (
                    SELECT ''
                    FROM Agreement
                    WHERE BranchID = @BranchID
                          AND ApplicationID = @ApplicationID
                          AND ContractStatus = 'ICP'
                          AND OutstandingInterest > 0
                )
                   AND @GSVALUE = 1
                BEGIN
                    SELECT @AmountJournal = OutstandingInterest
                    FROM Agreement
                    WHERE BranchID = @BranchID
                          AND ApplicationID = @ApplicationID;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'INTERESTWO';
                END;
            END;

            IF @AmountJournal > 0
            BEGIN
                INSERT INTO #TempTable
                (
                    PaymentAllocationID,
                    Post,
                    Amount,
                    RefDesc,
                    VoucherDesc
                )
                VALUES
                (@PaymentAllocationJournal, @PostJournal, @AmountJournal, @RefDesc, '');
                IF @@error <> 0
                BEGIN
                    GOTO ExitSP;
                END;
            END;
            SET @AmountJournal = 0;
            SET @Counter = @Counter + 1;
        END;

        SELECT @TotalD = SUM(   (CASE
                                     WHEN Post = 'D' THEN
                                         Amount
                                 END
                                )
                            ),
               @TotalC = SUM(   (CASE
                                     WHEN Post = 'C' THEN
                                         Amount
                                 END
                                )
                            )
        FROM #TempTable;

        SELECT *
        FROM #TempTable;
        PRINT '@TotalD ';
        PRINT @TotalD;
        PRINT '@TotalC';
        PRINT @TotalC;


        IF ABS(@TotalD - @TotalC) > @currencyrounded
        BEGIN
            RAISERROR('Journal Not Balance', 16, 1);
            SET @Error = 1;
            IF @Error > 0
                GOTO ExitSP;
        END;



        IF @TotalD > @TotalC
        BEGIN
            SET @AmountJournal = @TotalD - @TotalC;
            SET @PostJournal = 'C';
            SET @PaymentAllocationJournal = 'OTHERINC';
            INSERT INTO #TempTable
            (
                PaymentAllocationID,
                Post,
                Amount,
                RefDesc,
                VoucherDesc
            )
            VALUES
            (@PaymentAllocationJournal, @PostJournal, @AmountJournal, @RefDesc, '');
        END;

        IF @TotalD < @TotalC
        BEGIN
            SET @AmountJournal = @TotalC - @TotalD;
            SET @PostJournal = 'D';
            SET @PaymentAllocationJournal = 'OTHERINC';
            INSERT INTO #TempTable
            (
                PaymentAllocationID,
                Post,
                Amount,
                RefDesc,
                VoucherDesc
            )
            VALUES
            (@PaymentAllocationJournal, @PostJournal, @AmountJournal, @RefDesc, '');
        END;



        SET @Error = @@error;
        IF @Error > 0
            GOTO ExitSP;


        EXECUTE @Error = spProcessCreateJournal @CompanyID,
                                                @BranchID,
                                                @TransactionID,
                                                @BusinessDate,
                                                @BusinessDate,
                                                @AgreementNo,
                                                @ApplicationID,
                                                'O',
                                                '',
                                                @AmountReceive,
                                                @CurrencyID,
                                                @CurrencyRate,
                                                1,
                                                @JournalCode OUTPUT;
        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;
        SELECT *
        FROM GLJournalD
        WHERE Tr_Nomor = @JournalCode;
        -- Create Payment History       
        UPDATE PaymentHistoryHeader
        SET IsCorrection = 0,
            DtmUpd = GETDATE()
        WHERE IsCorrection = 1
              AND BranchId = @BranchID
              AND ApplicationID = @ApplicationID;
        IF @@Error <> 0
        BEGIN
            GOTO ExitSP;
        END;

        -- Yovita Aug 23 2006 : Ganti ValueDate pada saat createpaymenthistory dari @BusinessDate jadi @effDate      
        DECLARE @HistorySequenceNo INT;
        EXECUTE @Error = spProcessCreatePaymentHistory @BranchID,
                                                       @ApplicationID,
                                                       @BusinessDate,
                                                       @EffDate, -- @BusinessDate,       
                                                       '-',
                                                       '-',
                                                       0,
                                                       0,
                                                       @AgreementNo,
                                                       '-',
                                                       @WOP,
                                                       @ProcessID,
                                                       @AmountReceive,
                                                       @JournalCode,
                                                       '-',
                                                       @HistorySequenceNo OUTPUT;

        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;

        EXEC @Error = spReschedulingExecutionSaveDataAgreement_Auto @BranchID,
                                                                    @ApplicationID,
                                                                    @RequestNo,
                                                                    @EffectiveDate,
                                                                    @AmountReceive,
                                                                    @Prepaid,
                                                                    @ToleranceAmount;

        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;


        --Teddy 23 May 2007 : tambahkan parameter @AccruedResch yang akan dikirimkan      
        EXEC @Error = spReschedulingExecutionAccruedProcess @BranchID,
                                                            @ApplicationID,
                                                            @EffectiveDate,
                                                            @BusinessDate,
                                                            @AccruedAmount,
                                                            @ECIAmount,
                                                            @InsSeqNo,
                                                            @AccruedAdj,
                                                            @AccruedResch; -- Yovita Ap 05 06 : AddParams @AccruedAdj      
        IF @Error <> 0
            GOTO ExitSp;


        --Update Rescheduling      
        UPDATE Rescheduling
        SET Status = 'E',
            ReschedulingDate = @BusinessDate,
            Tr_Nomor = @JournalCode,
            StatusDate = @BusinessDate,
            ToleranceAmount = @ToleranceAmount, --Anton 16-10-2006      
            DtmUpd = GETDATE()
        WHERE BranchId = @BranchID
              AND ApplicationID = @ApplicationID
              AND RequestNo = @RequestNo
              AND Status = 'A';
        SET @Error = @@error;
        IF @Error > 0
            GOTO ExitSP;
        DROP TABLE #TempTable;
        --Insert InstallmentIncomeRecognize      

        --Add Indra, 28Oct2014  
        UPDATE ReschedulingUpload
        SET Status = 'X',
            ReschedulingNo = @RequestNo
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationID;

        --Sugiono, 29 Februari 2024 : FMF-4926
        IF @Error > 0
            GOTO ExitSP;
        --End Sugiono

        DECLARE @newnextinstallmentdate DATETIME,
                @NextDuedate DATETIME,
                @TopDueDate DATETIME,
                @MaturDate DATETIME;

        SELECT @newnextinstallmentdate = newnextinstallmentdate
        FROM ReschedulingUpload
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationID;


        IF @newnextinstallmentdate IS NOT NULL
        BEGIN
            UPDATE InstallmentSchedule
            SET DueDate = DATEADD(m, InsSeqNo - @InsSeqNo, @newnextinstallmentdate)
            WHERE BranchId = @BranchID
                  AND ApplicationID = @ApplicationID
                  AND InsSeqNo >= @InsSeqNo;

            --Sugiono, 29 Februari 2024 : FMF-4926
            IF @Error > 0
                GOTO ExitSP;
            --End Sugiono

            SELECT @TopDueDate = MIN(DueDate)
            FROM InstallmentSchedule WITH (NOLOCK)
            WHERE BranchId = @BranchID
                  AND ApplicationID = @ApplicationID
                  AND InstallmentAmount - PaidAmount - WaivedAmount > 0;

            SELECT @MaturDate = MAX(DueDate)
            FROM InstallmentSchedule WITH (NOLOCK)
            WHERE BranchId = @BranchID
                  AND ApplicationID = @ApplicationID;

            UPDATE Agreement
            SET NextInstallmentDueDate = @TopDueDate,
                NextInstallmentDate = @TopDueDate,
                MaturityDate = @MaturDate
            WHERE BranchID = @BranchID
                  AND ApplicationID = @ApplicationID;
            --Sugiono, 29 Februari 2024 : FMF-4926
            IF @Error > 0
                GOTO ExitSP;
			--End Sugiono
        END;

        UPDATE dbo.Agreement
        SET ContractStatus = 'LIV'
        WHERE ApplicationID = @ApplicationID
              AND ContractStatus = 'ICP'
              AND MaturityDate > @BusinessDate;

        --Sugiono, 29 Februari 2024 : FMF-4926
        IF @Error > 0
            GOTO ExitSP;
		--End Sugiono

    END;
END;

--SELECT * FROM abc  
--RollBack Transaction ReschedulingExec      
COMMIT TRANSACTION ReschedulingExec;
RETURN @Error;

ExitSP:
BEGIN
    ROLLBACK TRANSACTION ReschedulingExec;
    RETURN @Error;
END;

/****** Object:  StoredProcedure [dbo].[spReschedulingExecutionSaveDataAgreement_Auto]    Script Date: 11/17/2014 15:51:05 ******/
SET ANSI_NULLS ON;




GO

