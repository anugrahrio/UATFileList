SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO



/*
Created by :
David 7Feb2010
Modified By :
1. Raug 16 Desember 2021 FMF-3234 : Menambahkan penjagaan jika nilai PSAK lebih besar dari 1 Milyar maka akan menjalankan spAmortizationFeeGeneratorResc_InterestPortion
2. Sugiono, 29 Februari 2024 : FMF-4926 Double Transaction Reschedulling : menambahkan penjagaan double proses resch
*/
ALTER PROCEDURE [dbo].[spAmortizationFeeGeneratorResc]
    @BranchId VARCHAR(3),
    @ApplicationID VARCHAR(20),
    @RequestNo VARCHAR(20),
    @SeqNo1 INT
AS
SET NOCOUNT ON;
--Sugiono, 29 Februari 2024 : FMF-4926
IF NOT EXISTS
(
    SELECT ''
    FROM dbo.ReschedulingUpload WITH (NOLOCK)
        INNER JOIN dbo.Rescheduling WITH (NOLOCK)
            ON Rescheduling.BranchId = ReschedulingUpload.BranchID
               AND Rescheduling.ApplicationID = ReschedulingUpload.ApplicationID
    WHERE RequestNo = @RequestNo
          AND Rescheduling.SeqNo = @SeqNo1
          AND Rescheduling.ApplicationID = @ApplicationID
)
BEGIN

    --Add Raug 16 Desember 2021 FMF-3234 : Mengecek jika Nilai PSAK lebih dari 1M maka akan menjalankan spAmortizationFeeGeneratorResc_InterestPortion
    IF EXISTS
    (
        SELECT ''
        FROM Rescheduling
        WHERE BranchID = @BranchId
              AND ApplicationID = @ApplicationID
              AND RequestNo = @RequestNo
              ---AND SeqNo = @SeqNo1
              AND
              (
                  ABS(OSDiffRate) > 1000000000
                  OR ABS(OSInsuranceIncome) > 1000000000
                  OR ABS(OSIncentive) > 1000000000
                  OR ABS(OSProvision) > 1000000000
                  OR ABS(OSAdminFee) > 1000000000
                  OR ABS(OSDeferredInsurInc) > 1000000000
                  OR ABS(OSOtherRefund) > 1000000000
                  OR ABS(OSAdmFee) > 1000000000
                  OR ABS(OSProvisionFee) > 1000000000
                  OR ABS(OSOtherFee) > 1000000000
                  OR ABS(OSSurveyFee) > 1000000000
                  OR ABS(OSCostOfSurveyAmountFee) > 1000000000
              )
    )
    BEGIN
        EXEC spAmortizationFeeGeneratorResc_InterestPortion @BranchId,
                                                            @ApplicationID,
                                                            RequestNo,
                                                            @SeqNo1;
    END;
    ELSE
    BEGIN
        --End Raug FMF-3234
        DECLARE @OSAmountInstallmentSchedule Amount,
                @FeeAmount Amount;
        DECLARE @AmortizationAmountField AS VARCHAR(100);
        DECLARE @RunningAmountField AS VARCHAR(8000);
        DECLARE @OSAmortizationAmountField VARCHAR(100),
                @StrDueDate VARCHAR(10),
                @SQLFeeAmount VARCHAR(8000),
                @SqlInstallmentSchedule VARCHAR(8000);

        --=======================================================================
        DECLARE @tblAmortizationMasterResc TABLE
        (
            seqno INT IDENTITY,
            amortizationid CHAR(10)
        );

        --select * from abc

        DECLARE @StartLoop INT,
                @EndLoop INT,
                @AmortizationID VARCHAR(10),
                @DateAmortization DATETIME;

        INSERT INTO @tblAmortizationMasterResc
        (
            amortizationid
        )
        SELECT amortizationid
        FROM AmortizationMasterResc;
        --WHERE  isactive = 1 itung aja semuanya incase kedua table tidak sama setingan activenya , toh kalo ga aktif kan amountnya nol

        SELECT @EndLoop = COUNT(seqno)
        FROM @tblAmortizationMasterResc;

        SET @StartLoop = 1;

        WHILE @StartLoop <= @EndLoop
        BEGIN
            SELECT @AmortizationID = amortizationid
            FROM @tblAmortizationMasterResc
            WHERE seqno = @StartLoop;

            --=======================================================================
            SELECT @AmortizationAmountField = AmortizationField,
                   @RunningAmountField = RunningAmountField,
                   @OSAmortizationAmountField = OSAmortizationField,
                   @SQLFeeAmount = SQLFeeAmount,
                   @SqlInstallmentSchedule = SqlInstallmentSchedule
            FROM AmortizationMasterResc
            WHERE AmortizationID = @AmortizationID;

            SET @SQLFeeAmount = REPLACE(@SQLFeeAmount, '$BranchID', '''' + @BranchId + '''');
            SET @SQLFeeAmount = REPLACE(@SQLFeeAmount, '$ApplicationID', '''' + @ApplicationID + '''');
            SET @SQLFeeAmount = REPLACE(@SQLFeeAmount, '$RequestNo', '''' + @RequestNo + '''');

            SET @SqlInstallmentSchedule = REPLACE(@SqlInstallmentSchedule, '$BranchID', '''' + @BranchId + '''');
            SET @SqlInstallmentSchedule
                = REPLACE(@SqlInstallmentSchedule, '$ApplicationID', '''' + @ApplicationID + '''');
            SET @SqlInstallmentSchedule = REPLACE(@SqlInstallmentSchedule, '$RequestNo', '''' + @RequestNo + '''');
            SET @SqlInstallmentSchedule = REPLACE(@SqlInstallmentSchedule, '$InsSeqNo', @SeqNo1);

            CREATE TABLE #OSAmountInstallmentSchedule
            (
                OSInstallmentScheduleAmount NUMERIC(17, 2)
            );

            CREATE TABLE #FeeAmountTbl
            (
                FeeAmount NUMERIC(17, 2)
            );

            EXEC ('Insert Into #FeeAmountTbl ' + @SQLFeeAmount);

            SELECT @FeeAmount = FeeAmount
            FROM #FeeAmountTbl;

            IF @FeeAmount <> 0
            BEGIN
                EXEC ('Insert Into #OSAmountInstallmentSchedule ' + @SqlInstallmentSchedule);

                SELECT @OSAmountInstallmentSchedule = OSInstallmentScheduleAmount
                FROM #OSAmountInstallmentSchedule;

                IF @OSAmountInstallmentSchedule <> 0
                BEGIN
                    EXEC ('	Update	InstallmentScheduleResch 
						set		' + @AmortizationAmountField + ' = qry1.AmortizationAmount
						From
								(Select BranchID, ApplicationID, InsSeqNo, RequestNo, 
										((' + @RunningAmountField + ' / ' + @OSAmountInstallmentSchedule + ' ) * ' + @FeeAmount + ' ) as AmortizationAmount
								From	InstallmentScheduleResch 
								where	BranchID = ''' + @BranchId + ''' and 
										applicationid = ''' + @ApplicationID + '''  and 
										RequestNo = ''' + @RequestNo + ''' and InstallmentScheduleResch.InsSeqNo >= ''' + @SeqNo1 + ''') qry1
						Where	InstallmentScheduleResch.BranchID = Qry1.BranchID 
								and InstallmentScheduleResch.ApplicationID = Qry1.ApplicationID And 
								InstallmentScheduleResch.InsSeqNo = Qry1.Insseqno 
								and InstallmentScheduleResch.RequestNo = Qry1.RequestNo');
                END;
                --------------------------------------------------------------------------------------------------------------

                EXEC ('	Update	InstallmentScheduleResch 
						Set		' + @AmortizationAmountField + ' = ' + @AmortizationAmountField + ' + Qry1.RoundedAmount
						From 
								(Select Top 1 
										BranchID, ApplicationID, RequestNo, 
										(Select Max(InsSeqNo) - 2 from InstallmentScheduleResch Inst2 Where Inst2.BranchID = InstallmentScheduleResch.BranchID and 
										Inst2.ApplicationID = InstallmentScheduleResch.ApplicationID and Inst2.RequestNo = InstallmentScheduleResch.RequestNo) AS InsSeqNo, ' + @FeeAmount + '- (	Select Sum(' + @AmortizationAmountField + ') 
															from	InstallmentScheduleResch Inst1 
															Where	Inst1.BranchID = InstallmentScheduleResch.BranchID 
																	and Inst1.ApplicationID = InstallmentScheduleResch.ApplicationID
																	AND Inst1.RequestNo = InstallmentScheduleResch.RequestNo
																	AND Inst1.InsSeqNo >= ''' + @SeqNo1 + ''') as RoundedAmount
								From	InstallmentScheduleResch 
								where	BranchID = ''' + @BranchId + ''' and 
										applicationid = ''' + @ApplicationID + ''' and RequestNo = ''' + @RequestNo + ''' ) As Qry1
						Where	InstallmentScheduleResch.BranchId = Qry1.BranchId 
								and InstallmentScheduleResch.ApplicationID = Qry1.ApplicationID
								and InstallmentScheduleResch.InsseqNo = Qry1.InsSeqNo 
								AND InstallmentScheduleResch.RequestNo = Qry1.RequestNo');

                EXEC ('	Update	InstallmentScheduleResch 
						Set		' + @OSAmortizationAmountField + ' = Qry1.OSAmortizationFee
						From
								(Select BranchID, ApplicationID, RequestNo, InsSeqNo, 
										isnull((Select Sum(' + @AmortizationAmountField + ') 
												From	InstallmentScheduleResch Inst1 
												Where	Inst1.BranchID = InstallmentScheduleResch.BranchID 
														AND Inst1.ApplicationID = InstallmentScheduleResch.ApplicationID 
														AND Inst1.RequestNo = InstallmentScheduleResch.RequestNo
														AND Inst1.InsSeqNo > InstallmentScheduleResch.InsSeqNo),0) AS OSAmortizationFee
								From	InstallmentScheduleResch 
								where	BranchID = ''' + @BranchId + ''' and 
										applicationid = ''' + @ApplicationID + ''' and 
										RequestNo = ''' + @RequestNo + ''' and InsSeqNo >= ''' + @SeqNo1 + ''') Qry1
						Where	InstallmentScheduleResch.BranchId = Qry1.BranchID 
								and InstallmentScheduleResch.ApplicationID = Qry1.ApplicationID 
								and InstallmentScheduleResch.RequestNo = Qry1.RequestNo 
								and InstallmentScheduleResch.InsSeqNo = Qry1.InsSeqNo ');
            END;
            --select * from installmentSchedule Where applicationID=@ApplicationID

            DROP TABLE #OSAmountInstallmentSchedule;
            DROP TABLE #FeeAmountTbl;

            SET @StartLoop = @StartLoop + 1;
        END;
    END; --Add Raug 16 Desember 2021 FMF-3234 : End dari If Else

END; --End Sugiono
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

