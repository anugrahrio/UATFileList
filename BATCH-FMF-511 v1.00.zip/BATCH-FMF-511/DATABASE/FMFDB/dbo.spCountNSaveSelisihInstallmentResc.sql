SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO







/*
Created by			:	David, 7Feb2010
Modification		:	
Sugiono, 29 Februari 2024 : FMF-4926 Double Transaction Reschedulling : menambahkan penjagaan double proses resch
*/


ALTER PROCEDURE [dbo].[spCountNSaveSelisihInstallmentResc]
    @BranchID CHAR(3),
    @ApplicationID CHAR(20),
    @PaymentFrequency INT,
    @NTF NUMERIC(17, 2),
    @GrossYieldAcct NUMERIC(9, 6),
    @RequestNo VARCHAR(20),
    @SeqNo1 INT
AS
SET NOCOUNT ON;
BEGIN
    --Sugiono, 29 Februari 2024 : FMF-4926
    IF NOT EXISTS
    (
        SELECT ''
        FROM dbo.ReschedulingUpload WITH (NOLOCK)
            INNER JOIN dbo.Rescheduling WITH (NOLOCK)
                ON Rescheduling.BranchId = ReschedulingUpload.BranchID
                   AND Rescheduling.ApplicationID = ReschedulingUpload.ApplicationID
        WHERE RequestNo = @RequestNo
              AND Rescheduling.SeqNo = @SeqNo1
              AND Rescheduling.ApplicationID = @ApplicationID
    )
    BEGIN

        DECLARE @MaxSeq AS INT;

        SELECT @MaxSeq = MAX(InsSeqNo)
        FROM dbo.InstallmentScheduleResch WITH (NOLOCK)
        WHERE ApplicationID = @ApplicationID
              AND BranchId = @BranchID
              AND RequestNo = @RequestNo;

        DECLARE @Start INT,
                @PreviousAmount Amount,
                @IncomeNet Amount,
                @OSPrincipleNet Amount,
                @InstallmentAmount Amount;
        SET @Start = @SeqNo1;

        SET @PreviousAmount = @NTF;


        WHILE @Start <= @MaxSeq
        BEGIN
            SELECT @InstallmentAmount = InstallmentAmount
            FROM dbo.InstallmentScheduleResch WITH (NOLOCK)
            WHERE ApplicationID = @ApplicationID
                  AND BranchId = @BranchID
                  AND RequestNo = @RequestNo
                  AND InsSeqNo = @Start;

            SET @IncomeNet = (((@GrossYieldAcct / 100) / @PaymentFrequency) * @PreviousAmount);

            SET @OSPrincipleNet = (@PreviousAmount - (@InstallmentAmount - @IncomeNet));
            SET @PreviousAmount = @OSPrincipleNet;

            UPDATE dbo.InstallmentScheduleResch
            SET IncomeNet = @IncomeNet,
                OSPrincipleNet = @OSPrincipleNet,
                GrossYieldAcct = @GrossYieldAcct
            WHERE ApplicationID = @ApplicationID
                  AND BranchId = @BranchID
                  AND RequestNo = @RequestNo
                  AND InsSeqNo = @Start;
            SET @Start = @Start + 1;
        END;
        /*Ini untuk menyesuaikan pembulatan hasil perhitungannya dan dimasukan disequence terakhir*/
        UPDATE InstallmentScheduleResch
        SET IncomeNet = IncomeNet - OSPrincipleNet,
            OSPrincipleNet = 0
        WHERE ApplicationID = @ApplicationID
              AND BranchId = @BranchID
              AND RequestNo = @RequestNo
              AND InsSeqNo = @MaxSeq;

    END; --End Sugiono  
END;
SET NOCOUNT OFF;









GO

