SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO



/*
Modification
1.Leonita 18 Agustus 2005 insert into InstallmentScheduleResch 
  BASED on effectivedate not businessdate
2.Yovita 18 Sept 2007: Add Insert DiffRateAmount, OutStandingDiffRate, DiffRateRecognize, Incentive, OutStandingIncentive, IncentiveRecognize, 
					   Provision, OutStandingProvision, ProvisionRecognize to InstallmentScheduleResch
3.Gema, 20081107: Add insert AdminFee, OSAdminFee, AdminFeeRecogNize ke OldInstallmentSchedule
4. David 5Feb2010 : Add insert InsuranceIncomeAmount,DeferredInsurInc,OtherRefund,AdmFee,ProvisionFee,OtherFee,SurveyFee
5. Rubianto, 20100331 : Tambahkan save IncomeNet, OSPrincipleNet, GrossYieldAcct
6. arif sucipto 15 okt 2010 : tambah insert costofsurvey
7. Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen FundingCoyPortion, SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installment schedule baru
8. Sugiono, 29 Februari 2024 : FMF-4926 Double Transaction Reschedulling : menambahkan penjagaan double proses resch
*/


ALTER PROCEDURE [dbo].[spReschedulingBackupSave]
    @BranchID CHAR(3),
    @ApplicationId CHAR(20),
    @ReschSeqNo SMALLINT,
    @BusinessDate DATETIME,
    @RequestNo VARCHAR(20)
AS
SET NOCOUNT ON;


DECLARE @effectivedate AS DATETIME;

BEGIN
    --Sugiono, 29 Februari 2024 : FMF-4926
    IF NOT EXISTS
    (
        SELECT ''
        FROM dbo.ReschedulingUpload WITH (NOLOCK)
            INNER JOIN dbo.Rescheduling WITH (NOLOCK)
                ON Rescheduling.BranchId = ReschedulingUpload.BranchID
                   AND Rescheduling.ApplicationID = ReschedulingUpload.ApplicationID
        WHERE RequestNo = @RequestNo
              AND Rescheduling.SeqNo = @ReschSeqNo
              AND Rescheduling.ApplicationID = @ApplicationId
    )
    BEGIN

        SELECT @effectivedate = EffectiveDate
        FROM Rescheduling WITH (NOLOCK)
        WHERE BranchId = @BranchID
              AND ApplicationID = @ApplicationId
              AND RequestNo = @RequestNo;

        INSERT INTO InstallmentScheduleResch
        (
            ApplicationID,
            BranchId,
            ReschSeqNo,
            InsSeqNo,
            DueDate,
            InstallmentAmount,
            PrincipalAmount,
            InterestAmount,
            OutstandingPrincipal,
            OutstandingInterest,
            PaidAmount,
            WaivedAmount,
            PaidDate,
            LateCharges,
            AmountIncRecognize,
            LastIncRecognize,
            RequestNo,
            FundingCoyPortion,
            -- Yovita 18 Sept 2007: Add Insert DiffRateAmount, OutStandingDiffRate, DiffRateRecognize, Incentive, OutStandingIncentive, IncentiveRecognize, 
            --  Provision, OutStandingProvision, ProvisionRecognize
            DiffRateAmount,
            OutStandingDiffRateAmount,
            DiffRateRecognize,
            Incentive,
            OSIncentive,
            IncentiveRecognize,
            Provision,
            OSProvision,
            ProvisionRecognize,
            AdminFee,
            OSAdminFee,
            AdminFeeRecognize,
            --David 5Feb2010--
            InsuranceIncomeAmount,
            OutStandingInsuranceIncomeAmount,
            InsuranceIncomeRecognize,
            DeferredInsurInc,
            OSDeferredInsurInc,
            DeferredInsurIncRecognize,
            OtherRefund,
            OSOtherRefund,
            OtherRefundRecognize,
            AdmFee,
            OSAdmFee,
            AdmFeeRecognize,
            ProvisionFee,
            OSProvisionFee,
            ProvisionFeeRecognize,
            OtherFee,
            OSOtherFee,
            OtherFeeRecognize,
            SurveyFee,
            OSSurveyFee,
            SurveyFeeRecognize,
            --Rubianto, 20100331
            IncomeNet,
            OSPrincipleNet,
            GrossYieldAcct,
            --End Rubianto
            --arif 15 okt 2010
            CostOfSurveyFeeAmount,
            CostOfSurveyRecognize,
            OSCostOfSurvey,
            --end arif

            --Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen FundingCoyPortion, SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installment schedule baru
            SpreadAmount,
            SpreadRecognize,
            LastSpreadRecognize
        --End Budiman 
        )
        SELECT ApplicationID,
               BranchId,
               @ReschSeqNo,
               InsSeqNo,
               DueDate,
               InstallmentAmount,
               PrincipalAmount,
               InterestAmount,
               OutstandingPrincipal,
               OutstandingInterest,
               PaidAmount,
               WaivedAmount,
               PaidDate,
               LateCharges,
               AmountIncRecognize,
               LastIncRecognize,
               @RequestNo,
               FundingCoyPortion,
               -- Yovita 18 Sept 2007: Add Insert DiffRateAmount, OutStandingDiffRate, DiffRateRecognize, Incentive, OutStandingIncentive, IncentiveRecognize, 
               --  Provision, OutStandingProvision, ProvisionRecognize
               DiffRateAmount,
               OutStandingDiffRateAmount,
               DiffRateRecognize,
               Incentive,
               OSIncentive,
               IncentiveRecognize,
               Provision,
               OSProvision,
               ProvisionRecognize,
               AdminFee,
               OSAdminFee,
               AdminFeeRecognize,
               --David 5Feb2010--
               InsuranceIncomeAmount,
               OutStandingInsuranceIncomeAmount,
               InsuranceIncomeRecognize,
               DeferredInsurIncAmount,
               OutstandingDeferredInsurIncAmount,
               DeferredInsurIncRecognize,
               OtherRefundAmount,
               OutStandingOtherRefundAmount,
               OtherRefundRecognize,
               AdmFeeAmount,
               OutStandingAdmFeeAmount,
               AdmFeeRecognize,
               ProvisionFeeAmount,
               OutStandingProvisionFeeAmount,
               ProvisionFeeRecognize,
               OtherFeeAmount,
               OutStandingOtherFeeAmount,
               OtherFeeRecognize,
               SurveyFeeAmount,
               OutStandingSurveyFeeAmount,
               SurveyFeeRecognize,
               --Rubianto, 20100331
               IncomeNet,
               OSPrincipleNet,
               GrossYieldAcct,
               --End Rubianto
               --arif 15 okt 2010
               CostOfSurveyFeeAmount,
               CostOfSurveyRecognize,
               OutStandingCostOfSurveyAmount,
               --end arif

               --Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen FundingCoyPortion, SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installment schedule baru
               SpreadAmount,
               SpreadRecognize,
               LastSpreadRecognize
        --End Budiman 
        FROM InstallmentSchedule WITH (NOLOCK)
        WHERE BranchId = @BranchID
              AND ApplicationID = @ApplicationId
              AND DueDate <= @effectivedate;
    -- AND PAIDAMOUNT <> 0
    --  				 And InstallmentAmount - PaidAmount - WaivedAmount = 0

    END; --End Sugiono

END;

SET NOCOUNT OFF;


RETURN;







GO

