SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO





/*  
Alter by : Yovita Mar 23 2006 : Tambah Params @InsSeqNo yang mulai di resch dan Insert Ke table Rescheduling,  
         @GracePeriod, @GracePeriodType  
  Yovita 10 Jul 06 : Tambah Insert @RepoFeeDisc ke table Rsch  
  Yovita Juli 12 2006 : Add Type to table Rescheduling  
  Yovita Oct 17 2006 : Add default status @CummulativeTenor int = 0   
  Arif, 10-9-2007 : ambil nilai diffrate, incentive, provision
-- Yovita 18 Sept 2007 : pd saat isi @AccI & @AccP Ganti dr DiffRateAmount jadi Incentive dan Provision 
-- Yovita 20 Sept 2007: Hitung nilai DiffRate, Incentive dan Provision sama dengan @BusinessDate apabila sudah lewat EOM
   Gema, 14 Juli 2008 : Remark where cond untuk Validasi kalau masih di pledge belum bisa di rescheduling
-- Gema, 20081110: Hitung nilai AdminFee sama dengan @BusinessDate apabila sudah lewat EOM dan tambahkan perhitungan AdminFee
-- Gema, 20081113 :Ambil lastduedatenya dari insseqno - 1 
--David 5Feb2010 : Tambah AccruedInsuranceIncome, AccDeferredInsurInc,AccOtherRefund,AccAdmFee,AccProvisionFee,AccOtherFee,AccSurveyFee
-- Susanti, 05 Aug 2010 : tambah isnull di waktu select @AccAdminFee
--arif 15 okt 2010 : tambah cost of survey
-- Susanti, 12 Nov 2010 : melengkapi perbaikan tanggal 5 Aug 2010
--Nahar01082011 : tambah penjagaan, untuk kontrak yang pembayarannya melebihi installmntdue tidak bisa disave.

------------------------------------- ReCreate untuk Resc Automatic ---------------------------------
Created : Welly, 27 okt 2014 FMF-1394
		  Ria, 28 okt 2014 FMF-1394
		  Welly, 12 Nov 2014 FMF 1395 : Tambah untuk kontrak mature	
		  Ria 11 Nov 2014 FMF-1395
		  Restu PI-189 25 Okt 2017 ubah cara hitung accrued PSAK berdasarkan eff date bukan bisnisdate
		  Aditia 27052019, FMF-1753 jika eff date = tgl eom, accrue 1 hari dihilangkan supaya sejalan dg accrue interest yang sampai dg eff date juga tanpa ditambah accrue 1 hari
		  Sugiono, 29 Februari 2024 : FMF-4926 Double Transaction Reschedulling : menambahkan penjagaan double proses resch
*/



ALTER PROCEDURE [dbo].[spReschedulingSave2_Auto]
    @BranchID CHAR(3),
    @ApplicationId CHAR(20),
    @SeqNo SMALLINT OUTPUT,
    @OutstandingTenor SMALLINT,
    @EffectiveDate DATETIME,
    @FlatRate FLOAT,
    @InstallmentAmount Amount,
    @RequestNo VARCHAR(20) OUTPUT,
    @EffectiveRate FLOAT,
    @NewPrincipalAmount Amount,
    @NumOfInstallment SMALLINT
AS
SET NOCOUNT ON;

--SELECT * FROM asd

DECLARE @ECIAmount Amount,
        @OldRate FLOAT,
        @OldTenor SMALLINT,
        @AmountIncRecognize Amount,
        @sequenceNo VARCHAR(20),
        @BusinessDate DATETIME,
        @PaymentFrequency VARCHAR(1),
        @Tenor SMALLINT,
        @ContractPrepaidAmount Amount,
        @OutstandingPrincipalOld Amount,
        @OSInstallmentDue Amount,
        @OSInsuranceDue Amount,
        @OSLCInstallment Amount,
        @OSLCInsurance Amount,
        @OSReposessFee Amount,
        @OSPDCBounceFee Amount,
        @AccruedAmount Amount,
        @InsSeqNo INTEGER,
        @TotalOSAR Amount,
        @OutstandingPrincipalNew Amount,
        @CustomerID CHAR(20),
        @InstallmentScheme VARCHAR(2),
        @PartialPrepaymentAmount Amount,
        @AdministrationFee NUMERIC(9),
        @OutstandingInterestNew Amount,
        @OutstandingInterestOld Amount,
        @ApprovalNo VARCHAR(50),
        @RequestTo VARCHAR(20),
        @ReasonTypeID CHAR(5),
        @ReasonID VARCHAR(10),
        @Tr_Nomor VARCHAR(50),
        @Notes VARCHAR(MAX),
        @Status VARCHAR(1),
        @GuarantorID CHAR(20),
        @InterestType VARCHAR(2),
        @LCInstallmentAmountDisc Amount,
        @LCInsuranceAmountDisc Amount,
        @PDCBounceFeeDisc Amount,
        @RepoFeeDisc Amount,
        @TotalDiscount Amount,
        @TotalAmountToBePaid Amount,
        @StepUpStepDownType VARCHAR(2),
        @GracePeriod INTEGER,
        @GracePeriodType VARCHAR(2),
        @CummulativeTenor INT,
        @DefaultStatus VARCHAR(5);


SET @InstallmentScheme = 'RF';
SET @PartialPrepaymentAmount = 0;
SET @AdministrationFee = 0;
SET @OutstandingInterestNew = 0;
SET @OutstandingInterestOld = 0;
SET @ApprovalNo = 'AUTOMATIC';
SET @RequestTo = 'AUTOMATIC';
SET @ReasonTypeID = 'RESCH';
SET @ReasonID = 'RSN9';
SET @Tr_Nomor = '-';
SET @Notes = 'AUTOMATIC by SYSTEM';
SET @Status = 'A';
SET @GuarantorID = '-';
SET @InterestType = 'FX';

--Sugiono, 29 Februari 2024 : FMF-4926
IF EXISTS
(
    SELECT ''
    FROM dbo.ReschedulingUpload WITH (NOLOCK)
        INNER JOIN dbo.Rescheduling WITH (NOLOCK)
            ON Rescheduling.BranchId = ReschedulingUpload.BranchID
               AND Rescheduling.ApplicationID = ReschedulingUpload.ApplicationID
    WHERE ReschedulingUpload.Status = 'P'
          AND Rescheduling.Status = 'A'
          AND Rescheduling.ApplicationID = @ApplicationId
)
BEGIN
    SELECT @SeqNo = Rescheduling.SeqNo,
           @RequestNo = RequestNo
    FROM dbo.ReschedulingUpload WITH (NOLOCK)
        INNER JOIN dbo.Rescheduling WITH (NOLOCK)
            ON Rescheduling.BranchId = ReschedulingUpload.BranchID
               AND Rescheduling.ApplicationID = ReschedulingUpload.ApplicationID
    WHERE ReschedulingUpload.Status = 'P'
          AND Rescheduling.Status = 'A'
          AND Rescheduling.ApplicationID = @ApplicationId;
END;
ELSE
BEGIN
    --End Sugiono

    IF EXISTS
    (
        SELECT ''
        FROM Agreement
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationId
              AND ContractStatus = 'ICP'
    )
    BEGIN
        SELECT @LCInstallmentAmountDisc = LCInstallment - LCInstallmentPaid - LCInstallmentWaived
        FROM Agreement
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationId; --0	
    END;
    ELSE
        SET @LCInstallmentAmountDisc = 0;

    SET @LCInsuranceAmountDisc = 0;
    SET @PDCBounceFeeDisc = 0;
    SET @RepoFeeDisc = 0;
    SET @TotalDiscount = 0;
    SET @TotalAmountToBePaid = 0;
    SET @StepUpStepDownType = 'NM';
    SET @GracePeriod = 0;
    SET @GracePeriodType = 0;
    SET @CummulativeTenor = 0;
    /*ria*/
    SET @OSInsuranceDue = 0;


    IF EXISTS
    (
        SELECT ''
        FROM Agreement
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationId
              AND ContractStatus = 'ICP'
    )
    BEGIN
        SELECT @OSLCInstallment = LCInstallment - LCInstallmentPaid - LCInstallmentWaived
        FROM Agreement
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationId; --0
    END;
    ELSE
        SET @OSLCInstallment = 0;

    SET @OSLCInsurance = 0;
    SET @OSReposessFee = 0;
    SET @OSPDCBounceFee = 0;
    /*ria*/
    ----------------------------------------- Set Variable -------------------------------------------

    SELECT @BusinessDate = BDCurrent
    FROM dbo.SystemControlCoy;

    SELECT @PaymentFrequency = PaymentFrequency,
           @ContractPrepaidAmount = ContractPrepaidAmount,
           @OSInstallmentDue = InstallmentDue - InstallmentDuePaid - InstallmentDueWaived,
                            /* ria
		   @OSInsuranceDue = InsuranceDue - InsuranceDuePaid - InsuranceDueWaived,
		   @OSLCInstallment = LCInstallment - LCInstallmentPaid - LCInstallmentWaived,
		   @OSLCInsurance = LCInsurance - LCInsurancePaid - LCInsuranceWaived,
		   @OSReposessFee = CollectionExpense - CollectionExpensePaid - CollectionExpenseWaived,
		   @OSPDCBounceFee = PDCBounceFee - PDCBounceFeePaid - PDCBounceFeeWaived,
		   */
           @CustomerID = CustomerID,
           @InsSeqNo = CASE
                           WHEN ContractStatus = 'ICP' THEN
                               NumOfInstallment + 1
                           ELSE
                               NextInstallmentDueNumber
                       END, -- 'remark, Welly FMF-1395
           @DefaultStatus = DefaultStatus
    FROM dbo.Agreement
    WHERE BranchID = @BranchID
          AND ApplicationID = @ApplicationId;
    /*
	--add, welly FMF-1395
    IF EXISTS ( SELECT  ''
                FROM    dbo.InstallmentSchedule
                WHERE   BranchID = @BranchID
                        AND ApplicationID = @ApplicationId
                        AND DueDate > @EffectiveDate )
        BEGIN
            SELECT  @InsSeqNo = MIN(InsSeqNo)
            FROM    dbo.InstallmentSchedule
            WHERE   BranchID = @BranchID
                    AND ApplicationID = @ApplicationId
                    AND DueDate > @EffectiveDate
        END 
    ELSE
        BEGIN
            SELECT  @InsSeqNo = MAX(InsSeqNo) + 1
            FROM    dbo.InstallmentSchedule
            WHERE   BranchID = @BranchID
                    AND ApplicationID = @ApplicationId
        END 
	--end welly
*/
    SET @Tenor = @NumOfInstallment * @PaymentFrequency;

    /* ria */
    SELECT @OutstandingPrincipalOld = SUM(InstallmentAmount /*PrincipalAmount*/ - PaidAmount - WaivedAmount)
    FROM dbo.InstallmentSchedule
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId;

    SET @AccruedAmount = dbo.FnAccruedInterest(@ApplicationId, @EffectiveDate);

    SET @TotalOSAR = @NewPrincipalAmount;
    SET @OutstandingPrincipalNew = @NewPrincipalAmount;


    UPDATE ReschedulingUpload
    SET [Status] = 'P'
    WHERE BranchID = @BranchID
          AND ApplicationID = @ApplicationId;

    -------------------------------- Reversal NA -------------------------------------------------
    IF @DefaultStatus = 'NA'
    BEGIN
        EXEC spStopAccuredReversal @BranchID,
                                   @ApplicationId,
                                   @BusinessDate,
                                   @BusinessDate,
                                   'REVERSAL by RESC AUTOMATIC';
    END;

    --Nahar01082011
    DECLARE @advanceamountreceive NUMERIC(17, 2),
            @strerror VARCHAR(500);
    SELECT @advanceamountreceive = (InstallmentDue - InstallmentDuePaid - InstallmentDueWaived) * -1
    FROM Agreement
    WHERE BranchID = @BranchID
          AND ApplicationID = @ApplicationId;

    IF @advanceamountreceive > 0
    BEGIN
        SET @strerror
            = 'This Agreement Has ' + CAST(@advanceamountreceive AS VARCHAR(17))
              + ' in Advance Payment. Please Reverse To Continue This Process Immediately';
        RAISERROR(@strerror, 16, 1);
        GOTO exitsp;
    END;
    --eo Nahar01082011


    IF EXISTS
    (
        SELECT ''
        FROM Agreement
            INNER JOIN FundingContract
                ON Agreement.FundingBankID = FundingContract.BankID
                   AND Agreement.FundingCoyID = FundingContract.FundingCoyID
                   AND Agreement.FundingContractID = FundingContract.FundingContractNo
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationId
              AND
            --Agreement.FundingPledgeStatus = 'P' and    --Remark by Gema, 14 Juli 2008
            FundingContract.FacilityKind IN ( 'JFINC', 'CHANN' )
              AND FundingContract.BalanceSheetStatus = 'F'
              AND Agreement.DefaultStatus = 'NM'
    )
    BEGIN
        RAISERROR('This Contract has been pledge, you cannot continue this transaction', 16, 1);
        GOTO exitsp;
    END;

    IF @InstallmentScheme <> 'ST'
    BEGIN
        SET @StepUpStepDownType = NULL;
    END;

    -- Set @GracePeriodType=Null  

    SELECT @SeqNo = ISNULL(MAX(SeqNo), 0) + 1
    FROM Rescheduling
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId; --And SeqNo = @SeqNo  

    EXEC spGetNoTransaction @BranchID,
                            @BusinessDate,
                            'RESC',
                            @RequestNo OUTPUT;

    -- SELECT  @InsSeqNo=  InsSeqNo  
    -- FROM  dbo.InstallmentSchedule  
    -- inner Join   
    --  (  
    --   select BranchID, ApplicationID, Min(Duedate) as MinDueDate   
    --   from InstallmentSchedule  
    --   where DueDate > @BusinessDate And PaidAmount=0    
    --   Group By BranchID, ApplicationID   
    --  ) QryMinDueDate on   
    --  InstallmentSchedule.BranchID = QryMinDueDate.BranchID and  
    --  InstallmentSchedule.ApplicationID = QryMinDueDate.ApplicationID  
    -- inner jOIN   
    --  (  
    --   select  BranchID, ApplicationID,Max(InsSeqNo) as MaxSeqNo    
    --  from InstallmentSchedule  
    --  Group By BranchID, ApplicationID   
    --  ) QryMaxSeqNo  on  
    --  InstallmentSchedule.BranchID = QryMaxSeqNo.BranchID and  
    --   InstallmentSchedule.ApplicationID = QryMaxSeqNo.ApplicationID  
    -- Where InstallmentSchedule.ApplicationID=@ApplicationID And InstallmentSchedule.BranchID=@BranchID   
    --  and InstallmentSchedule.DueDate = QryMinDueDate.MinDueDate  
    -- Group By InsSeqNo,DueDate,QryMaxSeqNo.MaxSeqNo  

    SELECT @AmountIncRecognize = AmountIncRecognize
    FROM InstallmentSchedule
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId
          AND InsSeqNo = @InsSeqNo;

    --============================================================================================================== 
    --START------Arif, 10-9-2007 : ambil nilai diffrate, incentive, provision, dan AdminFee -----------------------------------------------------
    --==============================================================================================================

    DECLARE @OSDiffRate Amount,
            @AccDREOM Amount,
            @AccDR Amount,       --(accrued Diffrate sampai dengan tanggal di rescheduling),
            @OSIncentive Amount,
            @AccIEOM Amount,
            @AccI Amount,        --(accrued Incentive sampai dengan tanggal di rescheduling),
            @OSProvision Amount,
            @ACCPEOM Amount,
            @AccP Amount,        --(accrued Provision sampai dengan tanggal di rescheduling),
            @OSAdminFee Amount,
            @AccAdminFeeEOM Amount,
            @AccAdminFee Amount, --(accrued AdminFee sampai dengan tanggal di rescheduling),
                                 --David 5Feb2010--
            @OSInsuranceIncome Amount,
            @AccInsuranceIncomeEOM Amount,
            @AccInsuranceIncome Amount,
            @OSDeferredInsurInc Amount,
            @AccDeferredInsurIncEOM Amount,
            @AccDeferredInsurInc Amount,
            @OSOtherRefund Amount,
            @AccOtherRefundEOM Amount,
            @AccOtherRefund Amount,
            @OSAdmFee Amount,
            @AccAdmFeeEOM Amount,
            @AccAdmFee Amount,
            @OSProvisionFee Amount,
            @AccProvisionFeeEOM Amount,
            @AccProvisionFee Amount,
            @OSOtherFee Amount,
            @AccOtherFeeEOM Amount,
            @AccOtherFee Amount,
            @OSSurveyFee Amount,
            @AccSurveyFeeEOM Amount,
            @AccSurveyFee Amount,
                                 --arif 15 okt 2010
            @OSCostOfSurveyAmountFee Amount,
            @AccCostOfSurveyAmountFeeEOM Amount,
            @AccCostOfSurveyAmountFee Amount;

    SET @AccDREOM = 0;
    SET @AccDR = 0;
    SET @AccIEOM = 0;
    SET @AccI = 0;
    SET @ACCPEOM = 0;
    SET @AccP = 0;
    SET @AccAdminFeeEOM = 0;
    SET @AccAdminFee = 0;
    --David 5Feb2010--
    SET @AccInsuranceIncomeEOM = 0;
    SET @AccDeferredInsurIncEOM = 0;
    SET @AccOtherRefundEOM = 0;
    SET @AccAdmFeeEOM = 0;
    SET @AccProvisionFeeEOM = 0;
    SET @AccOtherFeeEOM = 0;
    SET @AccSurveyFeeEOM = 0;
    SET @AccInsuranceIncome = 0;
    SET @AccDeferredInsurInc = 0;
    SET @AccOtherRefund = 0;
    SET @AccAdmFee = 0;
    SET @AccProvisionFee = 0;
    SET @AccOtherFee = 0;
    SET @AccSurveyFee = 0;
    --arif 15 okt 2010
    SET @AccCostOfSurveyAmountFee = 0;
    SET @AccCostOfSurveyAmountFeeEOM = 0;




    --==============================================================================================================
    -- Ambil nilai DiffRate, Incentive, Provision dan AdminFeepada saat EOM terakhir (bila sudah lewat EOM)
    --==============================================================================================================
    SELECT TOP 1
           @AccDREOM = ISNULL(DiffRateRecognize, 0), --Selisih hari = DATEDIFF(day, @effectivedate, duedate)
           @AccIEOM = ISNULL(IncentiveRecognize, 0), --Jumlah hari = DATEDIFF(day, DATEADD(month, 1, duedate), duedate)
           @ACCPEOM = ISNULL(ProvisionRecognize, 0),
           @AccAdminFeeEOM = ISNULL(AdminFeeRecognize, 0),
                                                     --David 5Feb2010--
           @AccInsuranceIncomeEOM = ISNULL(InsuranceIncomeRecognize, 0),
           @AccDeferredInsurIncEOM = ISNULL(DeferredInsurIncRecognize, 0),
           @AccOtherRefundEOM = ISNULL(OtherRefundRecognize, 0),
           @AccAdmFeeEOM = ISNULL(AdmFeeRecognize, 0),
           @AccProvisionFeeEOM = ISNULL(ProvisionFeeRecognize, 0),
           @AccOtherFeeEOM = ISNULL(OtherFeeRecognize, 0),
           @AccSurveyFeeEOM = ISNULL(SurveyFeeRecognize, 0),
                                                     --arif 15 okt 2010
           @AccCostOfSurveyAmountFeeEOM = ISNULL(CostOfSurveyRecognize, 0)
    FROM InstallmentSchedule
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND DueDate > @EffectiveDate
    ORDER BY DueDate;

    --==============================================================================================================
    -- Yovita 20 Sept 2007: Hitung nilai DiffRate, Incentive, Provision, dan AdminFee sama dengan Effective Date apabila sudah lewat EOM
    --==============================================================================================================
    DECLARE @LastDueDate AS DATETIME,
            @LastDateOfMonth AS DATETIME,
            @AccruedDayOnEOM AS INT;

    IF EXISTS (SELECT '' FROM GeneralSetting WHERE GSID = 'ACCEOMDAY')
    BEGIN
        SELECT @AccruedDayOnEOM = GSValue
        FROM GeneralSetting
        WHERE GSID = 'ACCEOMDAY';
    END;
    ELSE
    BEGIN
        SET @AccruedDayOnEOM = 0;
    END;

    --Remark By Gema, 20081113 :Ambil lastduedatenya dari insseqno - 1 
    --select @LastDueDate = DateAdd(Month,-1,min(DueDate))
    --From InstallmentSchedule
    --where	ApplicationID = @ApplicationID and   
    --		Branchid = @Branchid and 
    --		duedate > @effectivedate

    SELECT @LastDueDate = DueDate
    FROM InstallmentSchedule
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND InsSeqNo = @InsSeqNo - 1;

    SELECT @LastDateOfMonth = dbo.GetLastDateofMonth(@LastDueDate);

    --select @AccDR = sum(IsNull(DiffrateAmount-DiffRateRecognize,0)),				
    --	   @AccI = sum(IsNull(Incentive -IncentiveRecognize,0)),				
    --	   @ACCP = sum(IsNull(Provision - ProvisionRecognize,0)),
    --       @AccAdminFee = sum(IsNull(AdminFee - AdminFeeRecognize,0))  
    --from InstallmentSchedule 
    --where ApplicationID = @ApplicationID and   
    --	  Branchid = @Branchid and 
    --	  duedate <= @effectivedate

    --==============================================================================================================  
    -- Yovita 20 Sept 2007 : Jika Rescheduling di lakukan sebelum EOM, maka tidak perlu create semua DiffRate, di anggap 0
    --==============================================================================================================

    IF @AccDREOM <> 0
       OR @AccIEOM <> 0
       OR @ACCPEOM <> 0
       OR @AccAdminFeeEOM <> 0
       OR @AccInsuranceIncomeEOM <> 0
       OR @AccDeferredInsurIncEOM <> 0
       OR @AccOtherRefundEOM <> 0
       OR @AccAdmFeeEOM <> 0
       OR @AccProvisionFeeEOM <> 0
       OR @AccOtherFeeEOM <> 0
       OR @AccSurveyFeeEOM <> 0
       OR @AccCostOfSurveyAmountFeeEOM <> 0
    BEGIN
        IF @LastDateOfMonth <> @EffectiveDate
        BEGIN
            SELECT TOP 1
                   @AccDR
                       = --@AccDR + 
                ((DiffRateAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                 / DATEDIFF(DAY, @LastDueDate, DueDate)
                ),
                   @AccI
                       = --@AccI + 
                   ((Incentive * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                    / DATEDIFF(DAY, @LastDueDate, DueDate)
                   ),
                   @AccP
                       = --@AccP + 
                   ((Provision * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                    / DATEDIFF(DAY, @LastDueDate, DueDate)
                   ),
                   @AccAdminFee
                       = --@AccAdminFee+ 
                   -- Susanti, 05 Aug 2010 : tambah isnull
                   ISNULL(
                             ((AdminFee * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                              / DATEDIFF(DAY, @LastDueDate, DueDate)
                             ),
                             0
                         ),
                   --David 5Feb2010--
                   @AccInsuranceIncome
                       = ((InsuranceIncomeAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccDeferredInsurInc
                       = ((DeferredInsurIncAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccOtherRefund
                       = ((OtherRefundAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccAdmFee
                       = ((AdmFeeAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccProvisionFee
                       = ((ProvisionFeeAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccOtherFee
                       = ((OtherFeeAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccSurveyFee
                       = ((SurveyFeeAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   --arif 15 okt 2010--
                   @AccCostOfSurveyAmountFee
                       = ((CostOfSurveyFeeAmount * DATEDIFF(DAY, @LastDueDate, @EffectiveDate)) --Restu PI-189 25 Okt 2017 ubah @BusinessDate jadi @EffectiveDate
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         )
            FROM InstallmentSchedule
            WHERE ApplicationID = @ApplicationId
                  AND BranchId = @BranchID
                  AND DueDate > @EffectiveDate;

        END;
        ELSE
        BEGIN

            --Aditia 20190527 FMF-1753 hilangkan accrue EOM
            /*
                    SELECT TOP 1
                            @AccDR = --@AccDR + 
                            ( ( DiffRateAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day, @LastDueDate, duedate) ) ,
                            @AccI = --@AccI + 
                            ( ( Incentive * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day, @LastDueDate, duedate) ) ,
                            @AccP = --@AccP + 
                            ( ( Provision * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day, @LastDueDate, duedate) ) ,
                            @AccAdminFee = --@AccAdminFee + 
                                          -- Susanti, 12 Nov 2010 : tambah isnull
                            ISNULL(( ( AdminFee * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day, @LastDueDate, duedate) ),
                                   0) 
                            --David 5Feb2010--
                            ,
                            @AccInsuranceIncome = ( ( InsuranceIncomeAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day,
                                                                                                                                                @LastDueDate,
                                                                                                                                                duedate) ) ,
                            @AccDeferredInsurInc = ( ( DeferredInsurIncAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM )
                                                     / DATEDIFF(day, @LastDueDate, duedate) ) ,
                            @AccOtherRefund = ( ( OtherRefundAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day,
                                                                                                                                                @LastDueDate,
                                                                                                                                                duedate) ) ,
                            @AccAdmFee = ( ( AdmFeeAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day, @LastDueDate,
                                                                                                                                           duedate) ) ,
                            @AccProvisionFee = ( ( ProvisionFeeAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day,
                                                                                                                                                @LastDueDate,
                                                                                                                                                duedate) ) ,
                            @AccOtherFee = ( ( OtherFeeAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day, @LastDueDate,
                                                                                                                                               duedate) ) ,
                            @AccSurveyFee = ( ( SurveyFeeAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM ) / DATEDIFF(day,
                                                                                                                                                @LastDueDate,
                                                                                                                                                duedate) )
                             --arif 15 okt 2010--
                            ,
                            @AccCostOfSurveyAmountFee = ( ( CostOfSurveyFeeAmount * ( DATEDIFF(day, @LastDueDate, @BusinessDate) ) + @AccruedDayOnEOM )
                                                          / DATEDIFF(day, @LastDueDate, duedate) )
                    FROM    InstallmentSchedule
                    WHERE   ApplicationID = @ApplicationID
                            AND Branchid = @Branchid
                            AND duedate > @effectivedate
					*/
            SELECT TOP 1
                   @AccDR
                       = ((DiffRateAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccI
                       = ((Incentive * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccP
                       = ((Provision * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccAdminFee
                       = ISNULL(
                                   ((AdminFee * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                                    / DATEDIFF(DAY, @LastDueDate, DueDate)
                                   ),
                                   0
                               ),
                   @AccInsuranceIncome
                       = ((InsuranceIncomeAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccDeferredInsurInc
                       = ((DeferredInsurIncAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccOtherRefund
                       = ((OtherRefundAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccAdmFee
                       = ((AdmFeeAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccProvisionFee
                       = ((ProvisionFeeAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccOtherFee
                       = ((OtherFeeAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   @AccSurveyFee
                       = ((SurveyFeeAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         ),
                   --arif 15 okt 2010--
                   @AccCostOfSurveyAmountFee
                       = ((CostOfSurveyFeeAmount * (DATEDIFF(DAY, @LastDueDate, @EffectiveDate)))
                          / DATEDIFF(DAY, @LastDueDate, DueDate)
                         )
            FROM InstallmentSchedule
            WHERE ApplicationID = @ApplicationId
                  AND BranchId = @BranchID
                  AND DueDate > @EffectiveDate;
        --END Aditia
        END;
    END;


    --==============================================================================================================
    -- Hitung Nilai OS DiffRate, OS Incentive, OS Provision, dan OSAdminFee
    --==============================================================================================================
    SELECT @OSDiffRate = SUM(ISNULL(DiffRateAmount, 0)),                    ---DiffRateRecognize), 
           @OSIncentive = SUM(ISNULL(Incentive, 0)),                        ---IncentiveRecognize) ,
           @OSProvision = SUM(ISNULL(Provision, 0)),                        ---ProvisionRecognize),
           @OSAdminFee = ISNULL(SUM(AdminFee), 0),                          ---AdminFeeRecognize) 
                                                                            --David 5Feb2010--
           @OSInsuranceIncome = SUM(ISNULL(InsuranceIncomeAmount, 0)),
           @OSDeferredInsurInc = SUM(ISNULL(DeferredInsurIncAmount, 0)),
           @OSOtherRefund = SUM(ISNULL(OtherRefundAmount, 0)),
           @OSAdmFee = SUM(ISNULL(AdmFeeAmount, 0)),
           @OSProvisionFee = SUM(ISNULL(ProvisionFeeAmount, 0)),
           @OSOtherFee = SUM(ISNULL(OtherFeeAmount, 0)),
           @OSSurveyFee = SUM(ISNULL(SurveyFeeAmount, 0)),
           @OSCostOfSurveyAmountFee = SUM(ISNULL(CostOfSurveyFeeAmount, 0)) -- arif 15 okt 2010
    FROM InstallmentSchedule
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND DueDate > @EffectiveDate;

    --set	@OSDiffRate = @OSDiffRate - @AccDR
    --set	@OSIncentive = @OSIncentive -@AccI
    --set	@OSProvision = @OSProvision - @AccP
    --set @OSAdminFee = @OSAdminFee - @AccAdminFee

    --==============================================================================================================
    --END------Arif, 10-9-2007 : ambil nilai diffrate, incentive, provision, AdminFee ------------------------------
    --==============================================================================================================


    --Exec spAccruedInterest @ApplicationId, @EffectiveDate, @ECIAmount OUTPUT, Null, Null  

    SET @ECIAmount = ISNULL(@AccruedAmount, 0) - ISNULL(@AmountIncRecognize, 0);
    SELECT @OldTenor = Tenor,
           @OldRate = EffectiveRate
    FROM Agreement
    WHERE BranchID = @BranchID
          AND ApplicationID = @ApplicationId;

    INSERT INTO Rescheduling
    (
        ApplicationID,
        BranchId,
        RequestNo,
        SeqNo,
        CustomerID,
        GuarantorID,
        EffectiveDate,
        RequestDate,
        EffectiveRate,
        FlatRate,
        PaymentFrequency,
        InstallmentScheme,
        StepUpStepDownType,
        InterestType,
        NumOfInstallment,
        OutstandingTenor,
        Tenor,
        NewPrincipalAmount,
        InstallmentAmount,
        PartialPrepaymentAmount,
        AdministrationFee,
        ContractPrepaidAmount,
        OutstandingPrincipalNew,
        OutstandingInterestNew,
        OutstandingPrincipalOld,
        OutstandingInterestOld,
        OSInstallmentDue,
        OSInsuranceDue,
        OSLCInstallment,
        OSLCInsurance,
        OSPDCBounceFee,
                                 -- Yovita 10 Jul 06 : Tambah Insert @RepoFeeDisc ke table Rsch  
        ReposessFeeDisc,
        LCInstallmentAmountDisc,
        LCInsuranceAmountDisc,
        PDCBounceFeeDisc,
        TotalDiscount,
        TotalAmountToBePaid,
        TotalOSAR,
        AccruedAmount,
        ECIAmount,
        ApprovalNo,
        RequestBy,
        ReasonTypeID,
        ReasonID,
        Tr_Nomor,
        Notes,
        Status,
        OldRate,
        OldTenor,
        StatusDate,
                                 -- Yovita Mar 23 2006 : Tambah Informasi InsSeqNo yang mulai di resch, GracePeriod, GracePeriodType  
        InsSeqNo,
        GracePeriod,
        GracePeriodType,
        CummulativeTenor,
        Type,
        OSDiffRate,
        AccruedDiffRateEOM,
        AccruedDiffRate,
        OSIncentive,
        AccruedIncentiveEOM,
        AccruedIncentive,
        OSProvision,
        AccruedProvisionEOM,
        AccruedProvision,
        OSAdminFee,
        AccruedAdminFeeEOM,
        AccruedAdminFee,
                                 --David 5Feb2010--
        OSInsuranceIncome,
        AccruedInsuranceIncomeEOM,
        AccruedInsuranceIncome,
        OSDeferredInsurInc,
        AccDeferredInsurIncEOM,
        AccDeferredInsurInc,
        OSOtherRefund,
        AccOtherRefundEOM,
        AccOtherRefund,
        OSAdmFee,
        AccAdmFeeEOM,
        AccAdmFee,
        OSProvisionFee,
        AccProvisionFeeEOM,
        AccProvisionFee,
        OSOtherFee,
        AccOtherFeeEOM,
        AccOtherFee,
        OSSurveyFee,
        AccSurveyFeeEOM,
        AccSurveyFee,
        OSCostOfSurveyAmountFee,
        AccCostOfSurveyAmountFeeEOM,
        AccCostOfSurveyAmountFee -- arif 15 okt 2010
    )
    VALUES
    (   @ApplicationId, @BranchID, @RequestNo, @SeqNo, @CustomerID, @GuarantorID, @EffectiveDate, @BusinessDate,
        @EffectiveRate, @FlatRate, @PaymentFrequency, @InstallmentScheme, @StepUpStepDownType, @InterestType,
        @NumOfInstallment, @OutstandingTenor, @Tenor, @NewPrincipalAmount, @InstallmentAmount,
        @PartialPrepaymentAmount, @AdministrationFee, @ContractPrepaidAmount, @OutstandingPrincipalNew,
        @OutstandingInterestNew, @OutstandingPrincipalOld, @OutstandingInterestOld, @OSInstallmentDue, @OSInsuranceDue,
        @OSLCInstallment, @OSLCInsurance, @OSPDCBounceFee, @RepoFeeDisc, @LCInstallmentAmountDisc,
        @LCInsuranceAmountDisc, @PDCBounceFeeDisc, @TotalDiscount, @TotalAmountToBePaid, @TotalOSAR, @AccruedAmount,
        @ECIAmount, @ApprovalNo, @RequestTo, @ReasonTypeID, @ReasonID, @Tr_Nomor, @Notes, @Status, @OldRate, @OldTenor,
        @BusinessDate,
                                  -- Yovita Mar 23 2006 : Tambah Informasi InsSeqNo yang mulai di resch, @GracePeriod, @GracePeriodType  
        @InsSeqNo, @GracePeriod, @GracePeriodType, @CummulativeTenor, 'RSC', @OSDiffRate, @AccDREOM, @AccDR,
        @OSIncentive, @AccIEOM, @AccI, @OSProvision, @ACCPEOM, @AccP, @OSAdminFee, @AccAdminFeeEOM,
        @AccAdminFee,             --David 5Feb2010--
        @OSInsuranceIncome, @AccInsuranceIncomeEOM, @AccInsuranceIncome, @OSDeferredInsurInc, @AccDeferredInsurIncEOM,
        @AccDeferredInsurInc, @OSOtherRefund, @AccOtherRefundEOM, @AccOtherRefund, @OSAdmFee, @AccAdmFeeEOM,
        @AccAdmFee, @OSProvisionFee, @AccProvisionFeeEOM, @AccProvisionFee, @OSOtherFee, @AccOtherFeeEOM, @AccOtherFee,
        @OSSurveyFee, @AccSurveyFeeEOM, @AccSurveyFee, @OSCostOfSurveyAmountFee, @AccCostOfSurveyAmountFeeEOM,
        @AccCostOfSurveyAmountFee --arif 15 okt 2010
        );


END; --End Sugiono

--SELECT * FROM abc
RETURN;
exitsp:
RETURN;
SET NOCOUNT OFF;

GO

