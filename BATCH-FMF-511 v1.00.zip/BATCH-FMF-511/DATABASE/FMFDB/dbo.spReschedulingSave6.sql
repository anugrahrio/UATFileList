SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO






/*    
    
Yovita Mar 23 2006 : Change The Whole Process, to Adjust process back dated on effective Date    
Yovita May 22 2006 : Select Info Amount Before Rescheduling, SUM (Interest dan Principal Amount) from InstallmentSchedule    
Yovita Jun 12 2006 : Ubah cara hitung acc interest2, sesuai dengan eff datenya    
Henry Ganteng July 18 2006 : Ubah cara hitung OutStandingPrincipalold dan Outstandingprincipalnew    
Mul May 23 2007 : Kalau effectivedate sama dengan nextduedate,maka InsSeqNo dikurangi satu supaya ambil LastIncomeRecognize terakhir dan Interest terakhir    
      Untuk ambil OS Principal / Interest Old, dengan cara and DueDate > @EffectiveDate     
      Untuk ambil OS Principal / Interest New, dengan cara and DueDate > @EffectiveDate      
Mul May 23 2007 : ubah cara perhitungan accrued    
Yovita 21 Sept 2007: Ganti dari And duedate <=@businessdate menjadi And duedate <=@EffectiveDate  pd saat update Paid Amount di InstallmentScheduleResch  
Ria 18 Nov 2014 FMF-1395 penjagaan isnull  
Restu PI-189 10 Okt 2017 ubah pembagi untuk perhitungan accrued day tidak dihardcode tgl akhir bulan  
Restu PI-189 24 Okt 2017 ubah cara hitung accruedresch2 karena kalau sudah lewat aom tidak usah accrued bunga baru.. biarkan nanti saja saat on due atau on eom  
Budiman FMF-1710, 28 November 2018  - tambah variable OldDuedate  
         - Ambil selisih harinya dengan tanggal duedate yang lama, jangan ambil duedate yang baru  
         - Ubah LastDuedateMonthnya diambil dari old duedate, bukan new duedate  
         - ubah perhitungan AccruedDAyOnEOM dikalikan OldInterest  
Dessy 11 Des 2018 : FMF-1710, ubah rumus @AccruedInterest2 untuk kolom AccruedResch jika effective date = tgl eom, hilangkan accrue 1 hari karena akan membuat jurnal UCIRSC tidak sebesar bunga baru,   
      jadi konsep accruenya disamakan dg perubahan Restu di PI-189 yaitu accruenya sd eff date saja dan atas old interest  
Sugiono, 29 Februari 2024 : FMF-4926 Double Transaction Reschedulling : menambahkan penjagaan double proses resch
*/

ALTER PROCEDURE [dbo].[spReschedulingSave6]
    @BranchID CHAR(3),
    @ApplicationId CHAR(20),
    @RequestNo VARCHAR(20),
    @ReschSeqNo SMALLINT,
    @BusinessDate DATETIME
AS
BEGIN TRAN spReschedulingSave6;
--Sugiono, 29 Februari 2024 : FMF-4926
IF NOT EXISTS
(
    SELECT ''
    FROM dbo.ReschedulingUpload WITH (NOLOCK)
        INNER JOIN dbo.Rescheduling WITH (NOLOCK)
            ON Rescheduling.BranchId = ReschedulingUpload.BranchID
               AND Rescheduling.ApplicationID = ReschedulingUpload.ApplicationID
    WHERE RequestNo = @RequestNo
          AND Rescheduling.SeqNo = @ReschSeqNo
          AND Rescheduling.ApplicationID = @ApplicationId
)
BEGIN
    --select * from adsaas  

    DECLARE @OldInterestAmount Amount,
            @NewInterestAmount Amount,
            @NewPrincipalAmount Amount,
            @OldPrincipalAmount Amount,
            @InsSeqNo SMALLINT,
            @OldInsSeqNo SMALLINT,
            @PaidAmount Amount,
            @PaymentFrequency SMALLINT,
            @PaidDate DATETIME,
            @PaidDateNew DATETIME,
            @LastIncRecognize DATETIME,
            @LastIncRecognizeNew DATETIME,
            @DueDateNew DATETIME,
            @principal Amount,
            @maxtenor AS INTEGER,
            -- Yovita Mar 23 2006 : Add Variabel Needed -----    
            @EffectiveDate AS DATETIME,
            @LastDueDate AS DATETIME,
            @AccruedDay1 INTEGER,
            @LastDateOfMonth INTEGER,
            @AccruedInterest1 NUMERIC(17, 2),
            @OldInterest NUMERIC(17, 2),
            @AmountIncRecognizeEOM NUMERIC(17, 2),
            @LastIncRecognizeOld DATETIME,
            @AccruedDay2 INTEGER,
            @AccruedInterest2 NUMERIC(17, 2),
            @NewInterest NUMERIC(17, 2),
            @AccruedDayOnEOM INTEGER;
    --================================================    

    SET NOCOUNT ON;

    --===========================================================    
    -- Yovita Mar 23 2006 : Select Info dari table Rescheduling    
    --===========================================================    
    SELECT @InsSeqNo = InsSeqNo,
           @EffectiveDate = EffectiveDate,
           @PaymentFrequency = PaymentFrequency,
           @principal = NewPrincipalAmount,
           @maxtenor = Tenor
    FROM Rescheduling WITH (NOLOCK)
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId
          AND RequestNo = @RequestNo
          AND SeqNo = @ReschSeqNo;

    /*    
===========================================================    
Mul May 23 2007 : Kalau effectivedate sama dengan nextduedate,maka InsSeqNo dikurangi satu    
 supaya ambil LastIncomeRecognize terakhir dan Interest terakhir    
===========================================================    
*/

    IF EXISTS
    (
        SELECT ''
        FROM InstallmentSchedule WITH (NOLOCK)
        WHERE ApplicationID = @ApplicationId
              AND BranchId = @BranchID
              AND InsSeqNo = @InsSeqNo - 1
              AND DueDate = @EffectiveDate
              AND @BusinessDate < @EffectiveDate
    )
    BEGIN
        SET @InsSeqNo = @InsSeqNo - 1;
    END;


    IF @InsSeqNo > 1
    BEGIN
        SET @OldInsSeqNo = @InsSeqNo - 1;
    END;
    ELSE
    BEGIN
        SET @OldInsSeqNo = @InsSeqNo;
    END;


    --===========================================================    
    -- Yovita Mar 23 2006 : Select Info which start to Reschedule    
    --===========================================================    
    SELECT @AmountIncRecognizeEOM = ISNULL(AmountIncRecognize, 0),
           @LastIncRecognizeOld = ISNULL(LastIncRecognize, '')
    FROM InstallmentSchedule WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND InsSeqNo = @InsSeqNo;
    --===========================================================    

    --===========================================================    
    -- Yovita Mar 23 2006 : Select Info Amount Before Rescheduling    
    --===========================================================    
    SELECT @PaidAmount = PaidAmount,
           @PaidDate = PaidDate,
           @LastIncRecognize = LastIncRecognize,
           @LastDueDate = DueDate
    --  @OldInterestAmount = OutStandingInterest, --Sum(InterestAmount),    
    --  @OldPrincipalAmount = OutStandingPrincipal  --Sum(PrincipalAmount)    
    --  @OldInterest = InterestAmount      
    FROM InstallmentSchedule WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND InsSeqNo = @OldInsSeqNo;
    --===========================================================    


    --===========================================================    
    -- Yovita May 22 2006 : Select Info Amount Before Rescheduling    
    --===========================================================    
    SELECT @OldInterestAmount = SUM(InterestAmount),
           @OldPrincipalAmount = SUM(PrincipalAmount)
    FROM InstallmentSchedule WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND DueDate > @EffectiveDate; -- Modified by henry july 19 2006, ambil os principal menggunakan due date, biar flexible gitu lho    
    -- And InsSeqNo = @OldInsSeqNo    
    --===========================================================    


    --===========================================================    
    -- Yovita May 10 2006 : Select Info Amount Before Rescheduling    
    --===========================================================    
    SELECT @OldInterest = InterestAmount
    FROM InstallmentSchedule WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND InsSeqNo = @InsSeqNo;
    --===========================================================    



    SET @PaidDateNew = DATEADD(m, @PaymentFrequency, @PaidDate);
    SET @LastIncRecognizeNew = DATEADD(m, @PaymentFrequency, @LastIncRecognize);

    --===========================================================    
    -- Yovita Mar 23 2006 : Select Info Amount After Rescheduling    
    --===========================================================    
    DECLARE @duedate DATETIME; --Restu PI-189 10 Okt 2017  
    SELECT @NewInterest = InterestAmount,
           @duedate = DueDate --Restu PI-189 10 Okt 2017  
    FROM InstallmentScheduleResch WITH (NOLOCK)
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId
          AND RequestNo = @RequestNo
          AND ReschSeqNo = @ReschSeqNo
          AND InsSeqNo = @InsSeqNo;

    --  and DueDate > @BusinessDate      
    --===========================================================    

    --===========================================================    
    -- Yovita Mar 23 2006 : Select Info Amount After Rescheduling    
    --===========================================================    
    SELECT @NewInterestAmount = SUM(InterestAmount),
           @NewPrincipalAmount = SUM(PrincipalAmount)
    FROM InstallmentScheduleResch WITH (NOLOCK)
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId
          AND RequestNo = @RequestNo
          AND ReschSeqNo = @ReschSeqNo
          AND DueDate > @EffectiveDate;
    --InsSeqNo > @InsSeqNo    
    --  and DueDate > @BusinessDate      
    --===========================================================    

    --===================================================================================================    
    -- Yovita Mar 23 2006 : Hitung Accrued --------------------------------------------------------------    
    --===================================================================================================    
    /*    
penjelasan perhitungan accrued    
MUL May 23 2007 : perhitungan accrued dibagi jadi 2, komponen 1 dan komponen 2     
komponen 1 ada hanya jika sudah eom dan effective date sebelum eom dan isinya berupa accrued dari lastduedate sampai effectivedate yang dikalikan dengan old interest    
komponen 2 berisi, jika sudah eom dan effective date sebelum eom maka isinya berupa accrued dari effectivedate sampai eom + 1 hari dikalikan dengan new interest    
       jika sudah eom dan effective date sesudah eom maka isinya berupa accrued dari lastduedate sampai effectivedate dikalikan dengan old interest    
       jika sudah eom dan effective date berada tepat pada eom maka isinya berupa accrued dari lastdudate sampai effectivedate dikalikan dengan old interest dan ditambah dengan 1 hari dikalikan dengan new interest    
       jika belum eom maka isinya berupa accrued dari lastduedate sampai effective date dikalikan dengan old interest     
accrued resch dihitung dengan menambahkan komponen1 dan komponen2    
--===================================================================================================    
*/


    IF EXISTS
    (
        SELECT ''
        FROM GeneralSetting WITH (NOLOCK)
        WHERE GSID = 'ACCEOMDAY'
    )
    BEGIN
        SELECT @AccruedDayOnEOM = GSValue
        FROM GeneralSetting
        WHERE GSID = 'ACCEOMDAY';
    END;
    ELSE
    BEGIN
        SET @AccruedDayOnEOM = 0;
    END;

    --Budiman FMF-1710, 28 November 2018 tambah variable OldDuedate  
    DECLARE @OldDueDate DATETIME;

    SELECT @OldDueDate = DueDate
    FROM InstallmentSchedule WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationId
          AND BranchId = @BranchID
          AND InsSeqNo = @InsSeqNo;
    --End Budiman  

    IF @LastIncRecognizeOld > @EffectiveDate -- Eff Date di isi sebelum lewat EOM    
    BEGIN
        SET @AccruedDay1 = DATEDIFF(d, @LastDueDate, @EffectiveDate);
    END;
    ELSE
    BEGIN
        SET @AccruedDay1 = 0;
    END;

    IF @AccruedDay1 > 0
    BEGIN
        --Begin Restu PI-189 10 Okt 2017 ubah @LastDateOfMonth menjadi hitung dari last due date s.d due date  
        --Select @LastDateOfMonth = dbo.LastDateOfMonth(Rtrim(Month(@LastDueDate)), Rtrim(Year(@LastDueDate)))    

        --Budiman FMF-1710 28 November 2018, Ambil selisih harinya dengan tanggal duedate yang lama, jangan ambil duedate yang baru  
        SELECT @LastDateOfMonth = (DATEDIFF(d, @LastDueDate, @OldDueDate));
        --Select @LastDateOfMonth = (DATEDIFF(d,@LastDueDate,@duedate))  
        --End Restu PI-189 10 Okt 2017  
        --End Budiman  


        -- MUL sebenernya if yang dibawah ini tidak akan pernah masuk tetapi karena beberapa hal maka belum di remark    
        IF @LastIncRecognizeOld = @EffectiveDate -- artinya EffectiveDatenya di isi sama dengan EOM terakhir    
        BEGIN
            SET @AccruedInterest1 = ((@AccruedDay1 + @AccruedDayOnEOM) * @NewInterest) / @LastDateOfMonth;
        END;
        ELSE
        BEGIN
            SET @AccruedInterest1 = (@AccruedDay1 * @OldInterest) / @LastDateOfMonth;
        END;
    END;
    ELSE
    BEGIN
        SET @AccruedInterest1 = 0;
    END;


    /*    
Yovita Jun 12 2006 : lihat apakah eff date di isi sesudah lewat EOM atau sebelum EOM,    
jika sesudah EOM maka, yang di hitung dengan interest baru adalah mulai last due sampai    
dengan EOM, sedangkan jika sebelum EOM maka di htg interest baru dari effective sampai    
EOM, begituu lhoooo    
*/

    IF @AmountIncRecognizeEOM > 0 -- Sudah lewat EOM    
    BEGIN

        IF @LastIncRecognizeOld > @EffectiveDate -- Eff Date di isi sebelum lewat EOM    
        BEGIN
            SET @AccruedDay2 = DATEDIFF(d, @EffectiveDate, @LastIncRecognizeOld);
        END;
        ELSE -- EffDate di isi sesudah EOM terakhir    
        BEGIN
            --MUL hitung harinya jika eff sesudah eom mulai dari last sampai effective date     
            --Set @AccruedDay2 = DateDiff(d, @LastDueDate, @LastIncRecognizeOld)      
            SET @AccruedDay2 = DATEDIFF(d, @LastDueDate, @EffectiveDate);

        END;

        IF @AccruedDay2 > 0
        BEGIN
            --Begin Restu PI-189 10 Okt 2017 ubah @LastDateOfMonth menjadi hitung dari last due date s.d due date  
            --Set @LastDateOfMonth = dbo.LastDateOfMonth(Rtrim(Month(@LastIncRecognizeOld)), Rtrim(Year(@LastIncRecognizeOld)))    
            --Budiman FMF-1710 28 November 2018, Ubah LastDuedateMonthnya diambil dari old duedate, bukan new duedate  
            --Select @LastDateOfMonth = (DATEDIFF(d,@LastDueDate,@duedate))  
            SELECT @LastDateOfMonth = (DATEDIFF(d, @LastDueDate, @OldDueDate));
            --End Restu PI-189 10 Okt 2017  
            --End Budiman  


            --Set @AccruedInterest2 = ((@AccruedDay2 + @AccruedDayOnEOM) * @NewInterest ) / @LastDateOfMonth    
            --MUL May 23 2007 : ini buat perhitungan nilai komponen 2nya     
            IF @LastIncRecognizeOld < @EffectiveDate
            BEGIN
                SET @AccruedInterest2 = (@AccruedDay2 * @OldInterest) / @LastDateOfMonth;
            END;
            ELSE IF @LastIncRecognizeOld = @EffectiveDate
            BEGIN
                --Dessy modif 11 Des 2018 FMF-1710  

                ----Budiman FMF-1710, 5 November 2018 ubah perhitungan AccruedDAyOnEOM dikalikan OldInterest  
                -- --Set @AccruedInterest2 = ((@AccruedDay2 * @OldInterest ) / @LastDateOfMonth) + ((@AccruedDayOnEOM * @NewInterest)/@LastDateOfMonth)    
                -- Set @AccruedInterest2 = ((@AccruedDay2 * @OldInterest ) / @LastDateOfMonth) + ((@AccruedDayOnEOM * @OldInterest)/@LastDateOfMonth)    
                ----End Budiman  

                SET @AccruedInterest2 = ((@AccruedDay2 * @OldInterest) / @LastDateOfMonth);
            --end Dessy  
            END;
            ELSE
            BEGIN
                --Begin Restu PI-189 24 Okt 2017 kalau backdated lewat EOM tidak usah accrued bunga baru  
                --Set @AccruedInterest2 = ((@AccruedDay2 + @AccruedDayOnEOM) * @NewInterest ) / @LastDateOfMonth    
                SET @AccruedInterest2 = 0;
            --End Restu PI-189 24 Okt 2017  
            END;
        END;
        ELSE
        BEGIN
            SET @AccruedInterest2 = 0;
        END;
    END;
    ELSE
    --MUL May 23 2007 : perhitungan komponen 2 jika belum eom    
    BEGIN

        SET @LastDateOfMonth = dbo.LastDateOfMonth(RTRIM(MONTH(@LastDueDate)), RTRIM(YEAR(@LastDueDate)));

        SET @AccruedDay2 = DATEDIFF(d, @LastDueDate, @EffectiveDate);
        SET @AccruedInterest2 = (@AccruedDay2 * @OldInterest) / @LastDateOfMonth;


    -- Else    
    -- Begin    
    --  Set @AccruedInterest2 = 0    
    -- End    
    END;
    --==================================================================================================    


    UPDATE Rescheduling
    SET OutstandingInterestNew = ISNULL(@NewInterestAmount, 0),
        OutstandingInterestOld = ISNULL(@OldInterestAmount, 0),
        OutstandingPrincipalOld = ISNULL(@OldPrincipalAmount, 0),
        OutstandingPrincipalNew = ISNULL(@NewPrincipalAmount, 0),
        AccruedResch = ISNULL(@AccruedInterest1, 0) + ISNULL(@AccruedInterest2, 0),
        AccruedEOM = ISNULL(@AmountIncRecognizeEOM, 0),
        AccruedAdj = ISNULL(@AccruedInterest1, 0) + (ISNULL(@AccruedInterest2, 0) - ISNULL(@AmountIncRecognizeEOM, 0)), -- Jika + maka Rate Naik, - Rate Turun    
        DtmUpd = GETDATE()
    FROM Rescheduling
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId
          AND RequestNo = @RequestNo
          AND SeqNo = @ReschSeqNo;

    IF @@error <> 0
        GOTO exitsp;

    -- if  @DueDateNew <=  @BusinessDate     
    -- Begin    
    UPDATE InstallmentScheduleResch
    SET PaidAmount = InstallmentAmount - WaivedAmount,
        PaidDate = @BusinessDate,
        DtmUpd = GETDATE()
    WHERE BranchId = @BranchID
          AND ApplicationID = @ApplicationId
          AND RequestNo = @RequestNo
          AND ReschSeqNo = @ReschSeqNo
          AND InstallmentAmount - PaidAmount - WaivedAmount > 0
          -- Yovita 21 Sept 2007: Ganti dari And duedate <=@businessdate menjadi And duedate <=@EffectiveDate  pd saat update Paid Amount di InstallmentScheduleResch  
          -- And duedate <=@businessdate      
          AND DueDate <= @EffectiveDate;

    -- End    
    IF @@error <> 0
        GOTO exitsp;
/*    
Update InstallmentScheduleResch     
 Set LastIncRecognize= @LastIncRecognizeNew    
Where BranchID=@BranchID And ApplicationID=@ApplicationID And ReschSeqNo = @ReschSeqNo And ReschSeqNo = @ReschSeqNo And InsSeqNo = @InsSeqNo         
*/

END; --End Sugiono      

COMMIT TRAN spReschedulingSave6;
RETURN 1;


ExitSp:
ROLLBACK TRAN spReschedulingSave6;
RETURN 0;



SET NOCOUNT OFF;



GO

