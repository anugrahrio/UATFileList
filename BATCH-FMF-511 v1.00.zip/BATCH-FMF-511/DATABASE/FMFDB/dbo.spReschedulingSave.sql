SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO
/*  
-- Yovita April 13 2006 : Add Where Cond tidak boleh contract yang di pledge--    
--Arif 11-09-2007 tambah untuk incentive, provision, diffrate  
-- Yovita 20 Sept 2007: Set OS DiffRate, OS Provision, OS Incentive sebesar OS ybs yang masih harus di akui (jadi di kurang yang akan di akui pada saat rescheduling)   
-- Gema, 20081110: set OS AdminFee sebesar OS ybs yang masih harus di akui (jadi di kurang yang akan di akui pada saat rescheduling)   
David 7Feb2010 : meremark bagian update ke InstallmentScheduleResch karena sudah diganti menggunakan perhitungan baru untuk PSAK  
Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installmentScheduleResch  
Sugiono, 29 Februari 2024 : FMF-4926 Double Transaction Reschedulling : menambahkan penjagaan double proses resch
*/


ALTER PROCEDURE [dbo].[spReschedulingSave]
    @BranchID CHAR(3),
    @ApplicationId CHAR(20),
    @RequestNo VARCHAR(20),
    @InsSeqNo SMALLINT,
    @DueDate VARCHAR(10),
    @ReschSeqNo SMALLINT,
    @InstallmentAmount NUMERIC(17, 2),
    @PrincipalAmount NUMERIC(17, 2),
    @InterestAmount NUMERIC(17, 2),
    @OutstandingPrincipal NUMERIC(17, 2),
    @OutstandingInterest NUMERIC(17, 2),
    @BusinessDate DATETIME,
    @Output VARCHAR(50) OUTPUT
AS
SET NOCOUNT ON;


DECLARE @FundingCoyPortion INT,
        @NumOfInstallment INT,
        --Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installmentScheduleResch  
        @SpreadAmount NUMERIC(17, 2) = 0,
        @SpreadRecognize NUMERIC(17, 2) = 0,
        @LastSpreadRecognize DATETIME = NULL;
--End Budiman     
SET @Output = '';

BEGIN TRANSACTION InsertInstallmentScheduleResch;

--Sugiono, 29 Februari 2024 : FMF-4926
IF NOT EXISTS
(
    SELECT TOP 1
           ''
    FROM dbo.ReschedulingUpload WITH (NOLOCK)
        INNER JOIN dbo.Rescheduling WITH (NOLOCK)
            ON Rescheduling.BranchId = ReschedulingUpload.BranchID
               AND Rescheduling.ApplicationID = ReschedulingUpload.ApplicationID
        INNER JOIN dbo.InstallmentScheduleResch IscResch WITH (NOLOCK)
            ON IscResch.BranchId = Rescheduling.BranchId
               AND IscResch.ApplicationID = Rescheduling.ApplicationID
               AND IscResch.RequestNo = Rescheduling.RequestNo
               AND IscResch.InsSeqNo = Tenor
    WHERE Rescheduling.RequestNo = @RequestNo
          AND Rescheduling.SeqNo = @ReschSeqNo
          AND Rescheduling.ApplicationID = @ApplicationId
)
BEGIN

    -- Yovita April 13 2006 : Add Where Cond tidak boleh contract yang di pledge--    
    IF EXISTS
    (
        SELECT ''
        FROM Agreement WITH (NOLOCK)
            INNER JOIN FundingContract
                ON Agreement.FundingBankID = FundingContract.BankID
                   AND Agreement.FundingCoyID = FundingContract.FundingCoyID
                   AND Agreement.FundingContractID = FundingContract.FundingContractNo
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationId
              AND Agreement.FundingPledgeStatus = 'P'
              AND FundingContract.FacilityKind IN ( 'JFINC', 'CHANN' )
              AND FundingContract.BalanceSheetStatus = 'F'
              AND Agreement.DefaultStatus = 'NM'
    )
    BEGIN
        SET @Output = 'This Contract has been pledge, you cannot continue this transaction';
        GOTO exitsp;
    END;

    IF
    (
        SELECT COUNT(BranchId)
        FROM InstallmentScheduleResch WITH (NOLOCK)
        WHERE BranchId = @BranchID
              AND ApplicationID = @ApplicationId
              AND RequestNo = @RequestNo
              AND ReschSeqNo <> @ReschSeqNo
    ) > 0
    BEGIN
        SET @Output = 'Duplicate Key!';
    END;
    ELSE
    BEGIN

        INSERT INTO InstallmentScheduleResch
        (
            ApplicationID,
            Branchid,
            RequestNo,
            ReschSeqNo,
            InsSeqNo,
            DueDate,
            InstallmentAmount,
            PrincipalAmount,
            InterestAmount,
            OutstandingPrincipal,
            OutstandingInterest
        )
        VALUES
        (@ApplicationId, @BranchID, @RequestNo, @ReschSeqNo, @InsSeqNo, @DueDate, @InstallmentAmount, @PrincipalAmount,
         @InterestAmount, @OutstandingPrincipal, @OutstandingInterest);
        IF @@error <> 0
            GOTO exitsp;

        SELECT @NumOfInstallment = NumOfInstallment
        FROM Agreement WITH (NOLOCK)
        WHERE ApplicationID = @ApplicationId
              AND Branchid = @BranchID;

        IF @InsSeqNo > @NumOfInstallment
        BEGIN
            SELECT @FundingCoyPortion = FundingCoyPortion,
                   --Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installmentScheduleResch  
                   @SpreadAmount = SpreadAmount,
                   @SpreadRecognize = SpreadRecognize,
                   @LastSpreadRecognize = LastSpreadRecognize
            --End Budiman  
            FROM InstallmentSchedule WITH (NOLOCK)
            WHERE ApplicationID = @ApplicationId
                  AND Branchid = @BranchID
                  AND InsSeqNo = @NumOfInstallment;
        END;
        ELSE
        BEGIN
            SELECT @FundingCoyPortion = FundingCoyPortion,
                   --Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installmentScheduleResch  
                   @SpreadAmount = SpreadAmount,
                   @SpreadRecognize = SpreadRecognize,
                   @LastSpreadRecognize = LastSpreadRecognize
            --End Budiman  
            FROM InstallmentSchedule WITH (NOLOCK)
            WHERE ApplicationID = @ApplicationId
                  AND Branchid = @BranchID
                  AND InsSeqNo = @InsSeqNo;
        END;

        UPDATE InstallmentScheduleResch
        SET FundingCoyPortion = @FundingCoyPortion,
            --Budiman, 23 Oktober 2018 [FMF-1713] tambah komponen SpreadAmount, SpreadRecognize, dan LastSpreadRecognize saat pembuatan installmentScheduleResch  
            SpreadAmount = @SpreadAmount,
            SpreadRecognize = @SpreadRecognize,
            LastSpreadRecognize = @LastSpreadRecognize
        --End Budiman  
        WHERE ApplicationID = @ApplicationId
              AND Branchid = @BranchID
              AND RequestNo = @RequestNo
              AND ReschSeqNo = @ReschSeqNo
              AND InsSeqNo = @InsSeqNo;
        IF @@error <> 0
            GOTO exitsp;
        --         
        UPDATE Agreement
        SET PrepaidHoldStatus = 'RS'
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationId;
        IF @@error <> 0
            GOTO exitsp;
    /*David 7Feb2010 : Tidak perlu diupdate disini karena sudah diganti menggunakan perhitungan baru untuk PSAK  
--START--------Arif 10-9-2007 ----- update nilai diffrate, incentive, provision-----------------------------------  
-- Gema, 20081110 : update nilai AdminFee  
if @InsSeqNo = (select tenor from rescheduling where ApplicationID=@ApplicationID and Branchid=@Branchid and RequestNo=@RequestNo)  
begin  
 declare @IntAmount amount,  @DR amount,   @Pr amount,   @In amount,   @AdminFee amount,  
         @AccDR amount,  @AccI amount,  @AccP amount, @AccAdminFee amount , @InsSeqNoA int  
  
 select @IntAmount = SUM (InterestAmount) from InstallmentScheduleResch   
 where ApplicationID=@ApplicationID and Branchid=@Branchid and     
   RequestNo=@RequestNo and duedate > @businessdate   
   
 Select @DR = OSDiffRate,   @Pr = OSProvision,    @In = OSIncentive,   
   @AccDR = AccruedDiffrate, @AccP = AccruedProvision,  @AccI = AccruedIncentive,  
            @AdminFee= OSAdminFee,      @AccAdminFee = AccruedAdminFee  
 from Rescheduling   
 where ApplicationID=@ApplicationID and Branchid=@Branchid and     
    RequestNo=@RequestNo   
  
 --==========================================================================================================================  
 -- Yovita 20 Sept 2007: Set OS DiffRate, OS Provision, OS Incentive sebesar OS ybs yang masih harus di akui (jadi di kurang diffrate yang akan di akui pada saat rescheduling)   
 --==========================================================================================================================  
 set @DR = @DR - @AccDR  
 set @Pr = @Pr - @AccP  
 set @In = @In - @AccI  
    set @AdminFee = @AdminFee - @AccAdminFee  
 --==========================================================================================================================  
  
 Update InstallmentScheduleResch    
 Set  DiffRateAmount = (InterestAmount * @DR / @IntAmount),  
   OutStandingDiffRateAmount = (OutStandingInterest * @DR / @IntAmount),  
   Incentive = (InterestAmount * @In / @IntAmount),  
   OSIncentive = (OutStandingInterest * @In / @IntAmount),  
   Provision = (InterestAmount * @Pr / @IntAmount),  
   OSProvision = (OutStandingInterest * @Pr / @IntAmount),  
            AdminFee = (InterestAmount * @AdminFee / @IntAmount),  
            OSAdminFee = (OutStandingInterest * @AdminFee / @IntAmount)  
 Where ApplicationID = @ApplicationID and Branchid = @Branchid and RequestNo = @RequestNo and duedate > @businessdate   
  
   if @@error <> 0     
    goto exitsp       
  
-- Update InstallmentScheduleResch    
-- Set  DiffRateRecognize = @AccDR,  
--   IncentiveRecognize = @AccI,  
--   ProvisionRecognize = @AccP  
-- Where ApplicationID = @ApplicationID and Branchid = @Branchid and RequestNo = @RequestNo and   
--   InsSeqNo = @InsSeqNoA  
--  
--   if @@error <> 0     
--    goto exitsp       
  
end  
--END----------Arif 10-9-2007 ----- update nilai diffrate, incentive, provision-----------------------------------  
*/
    END;

END; --End Sugiono


COMMIT TRANSACTION InsertInstallmentScheduleResch;
RETURN;
exitsp:
ROLLBACK TRANSACTION InsertInstallmentScheduleResc;
RETURN;
SET NOCOUNT OFF;
GO

