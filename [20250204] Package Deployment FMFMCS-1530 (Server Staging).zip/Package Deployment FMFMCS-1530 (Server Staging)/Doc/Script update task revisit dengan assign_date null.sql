SET QUOTED_IDENTIFIER ON;

DECLARE @needUpdateCount INT = 0;
DECLARE @message varchar(100);

CREATE TABLE #revisitTaskWithNullAssignDate (
    UUID_TASK_H varchar(36)
);

-- cek apakah ada task revisit dengan assign_date null
INSERT INTO #revisitTaskWithNullAssignDate (UUID_TASK_H)
SELECT UUID_TASK_H
FROM TR_TASK_H WITH (NOLOCK)
WHERE REVISIT_ID IS NOT NULL 
    AND ASSIGN_DATE IS NULL

SELECT @needUpdateCount = COUNT(1)
FROM #revisitTaskWithNullAssignDate

SET @message = CONCAT('The number of revisit tasks that have null assign_date: ', @needUpdateCount)
RAISERROR(@message, 0, 1) WITH NOWAIT;

-- update task revisit dengan assign_date null agar nilai nya sama dengan dtm_crt
IF (@needUpdateCount > 0)
    BEGIN
        BEGIN TRY
            BEGIN TRANSACTION

                UPDATE TTH
                SET ASSIGN_DATE = DTM_CRT
                FROM TR_TASK_H TTH
                JOIN #revisitTaskWithNullAssignDate TTH_TEMP ON TTH.UUID_TASK_H = TTH_TEMP.UUID_TASK_H

                SET @message = CONCAT('Updated revisit tasks: ', @@ROWCOUNT)
                RAISERROR(@message, 0, 1) WITH NOWAIT;

            COMMIT TRANSACTION
        END TRY
        BEGIN CATCH
            IF @@TRANCOUNT > 0
                ROLLBACK TRANSACTION

            -- Log or re-throw the error if necessary
            THROW
        END CATCH

		DROP TABLE #revisitTaskWithNullAssignDate

    END
ELSE
    BEGIN

    SET @message = 'No revisit task updated.'
    RAISERROR(@message, 0, 1) WITH NOWAIT;

    DROP TABLE #revisitTaskWithNullAssignDate

    END