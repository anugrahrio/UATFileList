SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO
/*  
Created by Vincenza 10072020 FMF-2211  
Modified by:  
1. Niko  FMF-4464 28 Jul 2023: Ubah cara dapet TotalCost agar termasuk hitungan OnTheFly
2. Rey	 FMF-4596 20 September 2023 Ubah cara pengambilan TotalCost 
3. Rey	 FMF-4615 22 September 2023 :	- Ubah cara ambil tanggal untuk perhitungan TotalCost, 
										bukan pakai BusinessDate tapi WaivedDate, 
										karena kalo request dan approval beda hari jadi tidak keupdate statusnya jadi P. 
										- Update TotalCost dan TotalDayExtend 
4. Sugiono 20 Mei 2024 FMF-5056 CLONE - DOUBLE POSTING BPKB EXTEND COST WAIVE : menambahkan penjagaan double posting proses Waived Extend BPKB Cost
*/




ALTER PROCEDURE [dbo].[spBPKBWaiveApproval]
    @BranchID AS VARCHAR(3),
    @ApplicationID AS VARCHAR(20),
    @WaiveNo AS VARCHAR(20),
    @Notes AS VARCHAR(400),
    @Approval AS CHAR(1),
    @LoginID AS VARCHAR(20),
    @strerror AS VARCHAR(100) OUTPUT
AS
BEGIN TRANSACTION BPKBWaivedTransaction;
SET NOCOUNT ON;

--select * from abc  

DECLARE @Waive AS Amount,
        @WaiveBefore AS Amount,
        @BusinessDate AS DATETIME,
        @TotalCost AS Amount,
        @Paid AS Amount;
DECLARE @AgreementNo VARCHAR(20),
        @WaivedAmount AS Amount;

----------------------------------------------------------------------------------
DECLARE @waivedDate DATETIME;---Reyvano, 22 September 2023 (FMF-4615)

---Reyvano, 22 September 2023 (FMF-4615)
SELECT	@waivedDate = WaiveDate
FROM	dbo.BPKBExtendCostWaiveTrx WITH (NOLOCK)
WHERE	Applicationid = @ApplicationID
		AND WaiveNo = @WaiveNo;
---End Reyvano (FMF-4615)

----------------------------------------------------------------------------------

SET @BusinessDate =
(
    SELECT BDCurrent FROM SystemControlCoy WITH (NOLOCK)
);
SET @Waive =
(
    SELECT WaiveAmount
    FROM BPKBExtendCostWaiveTrx WITH (NOLOCK)
    WHERE BranchId = @BranchID
          AND Applicationid = @ApplicationID
          AND WaiveNo = @WaiveNo
);
SET @WaiveBefore =
(
    SELECT WaivedAmount
    FROM BPKBExtendCost WITH (NOLOCK)
    WHERE BranchID = @BranchID
          AND ApplicationID = @ApplicationID
);
SET @Paid =
(
    SELECT PaidAmount
    FROM BPKBExtendCost WITH (NOLOCK)
    WHERE BranchID = @BranchID
          AND ApplicationID = @ApplicationID
);

DECLARE @TotalDayExtend INT;---Reyvano, 22 September 2023 (FMF-4615)

---Reyvano, 22 September 2023 (FMF-4615) : Ubah query biar bisa ambil TotalDayExtend juga
--BEGIN Niko FMF-4464  
--set @TotalCost = (select TotalCost from BPKBExtendCost with (nolock) where BranchID = @BranchID and ApplicationID=@ApplicationID  )  
--SET @TotalCost =
--(
SELECT	--START Rey FMF-4596
		--CASE
		--              WHEN QryTotal.TotalDayExtendFly > bpkb.MaxDayDocSave THEN
		--                  CASE
		--                      WHEN QryTotal.TotalCostFly > atbe.MaximumCost THEN
		--                          atbe.MaximumCost
		--                      ELSE
		--                          ISNULL(QryTotal.TotalCostFly, 0)
		--                  END
		--              ELSE
		--                  ISNULL(bpkb.TotalCost, 0)
		--          END AS TotalCost
		@TotalCost = CASE
						 WHEN QryTotal.TotalCostFly > atbe.MaximumCost THEN
							 atbe.MaximumCost
						 ELSE
							 ISNULL(QryTotal.TotalCostFly, 0)
					 END,
		--END Rey FMF-4596
		@TotalDayExtend = QryTotal.TotalDayExtendFly ---Reyvano, 22 September 2023 (FMF-4615) : tambah select totalday nya
FROM	BPKBExtendCost bpkb WITH (NOLOCK)
		INNER JOIN Agreement agr WITH (NOLOCK)
			ON agr.BranchID = bpkb.BranchID
           AND agr.ApplicationID = bpkb.ApplicationID
		INNER JOIN Branch brh WITH (NOLOCK)
			ON bpkb.BranchID = brh.BranchID
		INNER JOIN Customer cust WITH (NOLOCK)
			ON agr.CustomerID = cust.CustomerID
		INNER JOIN AgreementAsset ast WITH (NOLOCK)
			ON agr.BranchID = ast.BranchID
			   AND agr.ApplicationID = ast.ApplicationID
		INNER JOIN AssetMaster am WITH (NOLOCK)
			ON am.AssetCode = ast.AssetCode
			   AND am.AssetTypeID = ast.AssetTypeID
		INNER JOIN AssetTypeBPKBExtendCost atbe WITH (NOLOCK)
			ON ast.AssetTypeID = atbe.AssetTypeID
		--Add Adhitya 17/09/2020  
		INNER JOIN
		(
			SELECT	ApplicationID,
					BranchID,
					AssetSeqNo,
					---Reyvano, 22 September 2023 (FMF-4615) : ubah @BusinessDate jadi @WaivedDate
					TotalDayExtendFly = DATEDIFF(d, ProcessDate, CONVERT(DATETIME, @waivedDate, 103)) - MaxDayDocSave,
					TotalCostFly = (DATEDIFF(d, ProcessDate, CONVERT(DATETIME, @waivedDate, 103)) - MaxDayDocSave)
								  * CostPerDay
					---End Reyvano (FMF-4615)
			FROM	BPKBExtendCost WITH(NOLOCK) ---Reyvano, 22 September 2023 (FMF-4615) : Tambah WITH(NOLOCK)
			WHERE	BranchID = @BranchID
					AND ApplicationID = @ApplicationID
		) QryTotal
			ON QryTotal.BranchID = bpkb.BranchID
			AND QryTotal.ApplicationID = bpkb.ApplicationID
			AND QryTotal.AssetSeqNo = bpkb.AssetSeqNo
--End Adhitya  
WHERE	bpkb.BranchID = @BranchID
		AND bpkb.ApplicationID = @ApplicationID;
--);
--END Niko FMF-4464  
---End Reyvano (FMF-4615)

SELECT	@AgreementNo = AgreementNo
FROM	Agreement WITH(NOLOCK) ---Reyvano, 22 September 2023 (FMF-4615) : Tambah WITH(NOLOCK)
WHERE	BranchID = @BranchID
		AND ApplicationID = @ApplicationID;

SET @WaivedAmount = @Waive;
--Sugiono 20 Mei 2024 FMF-5056 
IF EXISTS
(
    SELECT ''
    FROM dbo.BPKBExtendCost Cost WITH (NOLOCK)
        INNER JOIN
        (
            SELECT H.BranchID,
                   H.ApplicationID,
                   SUM(Trx.WaiveAmount) WaiveAmount
            FROM dbo.BPKBExtendCostWaiveTrx Trx WITH (NOLOCK)
                INNER JOIN dbo.BPKBExtendCost H WITH (NOLOCK)
                    ON H.BranchID = Trx.BranchId
                       AND H.ApplicationID = Trx.Applicationid
            WHERE Trx.Status = 'A'
                  AND H.BranchID = @BranchID
                  AND H.ApplicationID = @ApplicationID
			GROUP BY H.BranchID,
                   H.ApplicationID
        ) QryTrx
            ON QryTrx.BranchID = Cost.BranchID
               AND QryTrx.ApplicationID = Cost.ApplicationID
    WHERE QryTrx.WaiveAmount = Cost.WaivedAmount
          AND Cost.BranchID = @BranchID
          AND Cost.ApplicationID = @ApplicationID
)
BEGIN
    RAISERROR('Waive Transaction Completed', 16, 1);
    GOTO ExitSP;
END;
--End Sugiono

UPDATE	BPKBExtendCostWaiveTrx
SET		Status = @Approval,
		DtmUpd = GETDATE(),
		StatusDate = @BusinessDate,
		UsrUpd = @LoginID,
		ApprovalNotes = @Notes
WHERE	WaiveNo = @WaiveNo
		AND Applicationid = @ApplicationID
		AND BranchId = @BranchID;

IF @Approval = 'A'
BEGIN
    --Stefani, 18/09/2020  
    SELECT @AgreementNo = AgreementNo
    FROM Agreement WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationID;

    CREATE TABLE #TempTable
    (
        SeqNo INT IDENTITY PRIMARY KEY,
        PaymentAllocationID CHAR(20),
        Post CHAR(1),
        Amount NUMERIC(17, 2),
        RefDesc VARCHAR(50),
        DepartementID VARCHAR(3),
        VoucherDesc VARCHAR(50)
    );

    INSERT INTO #TempTable
    (
        PaymentAllocationID,
        Post,
        Amount,
        RefDesc,
        VoucherDesc
    )
    VALUES
    ('ECBPKBLC', 'C', @WaivedAmount, 'ECBPKBLC -' + @AgreementNo, '');

    DECLARE @HistorySequenceNo INT,
            @Error INT;

    EXEC @Error = dbo.spProcessCreatePaymentHistory @BranchID = @BranchID,                          -- varchar(3)      
                                                    @ApplicationID = @ApplicationID,                -- varchar(20)      
                                                    @BusinessDate = @BusinessDate,                  -- datetime      
                                                    @ValueDate = @waivedDate,                     -- datetime     ---Reyvano, 22 September 2023 (FMF-4615) : Ubah valuedate pakai waiveddate 
                                                    @BankID = '',                                   -- varchar(5)      
                                                    @GiroNo = '-',                                  -- varchar(20)      
                                                    @IsCorrection = 0,                              -- bit      
                                                    @CorrectionHistorySequence = 0,                 -- smallint      
                                                    @ReferenceNo = @AgreementNo,                    -- varchar(20)      
                                                    @ReceivedFrom = '',                             -- Name      
                                                    @WOP = 'WA',                                    -- varchar(5)      
                                                    @ProcessID = 'BPKBEC',                          -- varchar(10)      
                                                    @AmountReceive = @WaivedAmount,                 -- Amount      
                                                    @JournalCode = '',                              -- JournalCOA      
                                                    @BankAccountID = '',                            -- varchar(10)      
                                                    @HistorySequenceNo = @HistorySequenceNo OUTPUT, -- int      
                                                    @ReceiptNo = '',                                -- varchar(20)      
                                                    @VoucherNo = '',                                -- varchar(20)      
                                                    @IsPaidbyCustomer = DEFAULT,                    -- bit      
                                                    @PayerRelationship = DEFAULT,                   -- varchar(10)      
                                                    @PayerName = DEFAULT,                           -- varchar(100)      
                                                    @PayerIDNumber = DEFAULT,                       -- varchar(40)      
                                                    @PayerMobilePhone = DEFAULT;                    -- varchar(20)       
    IF @Error > 0
    BEGIN
        RAISERROR('Error When Process Create Payment History', 16, 1);
        GOTO ExitSP;
    END;
    --End Stefani*/  

    UPDATE	BPKBExtendCost
    SET		WaivedAmount = WaivedAmount + @Waive,
			---Reyvano, 22 September 2023 (FMF-4615) : Tambah update TotalCost dan TotalDayExtend
			TotalCost = @TotalCost,
			TotalDayExtend = @TotalDayExtend,
			---End Reyvano (FMF-4615)
			DtmUpd = GETDATE(),
			UsrUpd = @LoginID
    WHERE	ApplicationID = @ApplicationID
			AND BranchID = @BranchID;

    IF @TotalCost = (@Waive + @WaiveBefore + @Paid)
    BEGIN
        UPDATE	BPKBExtendCost
        SET		Status = 'P',
				PaymentDate = @waivedDate,--Reyvano, 22 September 2023 (FMF-4615) : Tambah update TotalCost dan TotalDayExtend
				PaymentBy = @LoginID
        WHERE	ApplicationID = @ApplicationID
				AND BranchID = @BranchID;
    END;
END;

--Sugiono 20 Mei 2024 FMF-5056 : double penjagaan
IF EXISTS
(
    SELECT ''
    FROM dbo.BPKBExtendCost Cost WITH (NOLOCK)
        INNER JOIN
        (
            SELECT H.BranchID,
                   H.ApplicationID,
                   SUM(Trx.WaiveAmount) WaiveAmount
            FROM dbo.BPKBExtendCostWaiveTrx Trx WITH (NOLOCK)
                INNER JOIN dbo.BPKBExtendCost H WITH (NOLOCK)
                    ON H.BranchID = Trx.BranchId
                       AND H.ApplicationID = Trx.Applicationid
            WHERE Trx.Status = 'A'
                  AND H.BranchID = @BranchID
                  AND H.ApplicationID = @ApplicationID
			GROUP BY H.BranchID,
                   H.ApplicationID
        ) QryTrx
            ON QryTrx.BranchID = Cost.BranchID
               AND QryTrx.ApplicationID = Cost.ApplicationID
    WHERE QryTrx.WaiveAmount <> Cost.WaivedAmount
          AND Cost.BranchID = @BranchID
          AND Cost.ApplicationID = @ApplicationID
)
BEGIN
    RAISERROR('Please Contact Administrator, Waive Amount BPKBExtendCost not equal Waive Amount Transaction', 16, 1);
    GOTO ExitSP;
END;
--End Sugiono

IF @@Error <> 0
BEGIN
    SET @strerror = 'Terjadi error saat mengupdate Approval!';
    GOTO exitsp;
END;
COMMIT TRANSACTION BPKBWaivedTransaction;
SET @strerror = 'Approval Berhasil!';
RETURN;

ExitSP:
BEGIN
    ROLLBACK TRANSACTION BPKBWaivedTransaction;
    RETURN;
END;
GO

