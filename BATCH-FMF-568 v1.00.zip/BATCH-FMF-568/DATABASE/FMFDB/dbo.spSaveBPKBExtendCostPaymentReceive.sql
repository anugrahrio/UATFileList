SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO

/*    
 Author : Mahendra, 15/11/2019, FMF-1818    
 Modify :    
 1. Remarked Adhitya 06/03/2020 FMF-1818    
 2. Adhitya FMF-1818 20/03/2020 : Diperbolehkan jika amount yang diterima itu 0 dan validasi jika amount kurang dari 0
 3. Vincenza FMF-2211 13072020 : Perubahan ke PaidAmount  
 4. Adhitya FMF-2211: Untuk amount 0 sudah tidak bisa lagi
 5. Adhitya, Penambahan Penjagaan Jika Amount + Paid Amount + Waived Amount > TotalCost, Muncul Pesan Warning 16/09/2020
 6. Niko 17 Nov 2023 FMF-4716 :	Tambah penjagaan double klik
 7. Niko 22 Des 2023 FMF-4754 : Tambah penjagaan double klik di paling bawah
 8. Reyvano 17 April 2024 FMF-5008 : tambah penjagaan terhadap perbedaan tanggal harinya, tanggal BDCurrent, dan tanggal BusinessDate. agar tetap selalu sama
 9. Sugiono 08 Januari 2025 FMF-5318 CLONE - [Error] Kwitansi digunakan oleh nomor dua agreement berbeda : penjagaan untuk receiptno
*/
ALTER PROCEDURE [dbo].[spSaveBPKBExtendCostPaymentReceive]
    @ApplicationID VARCHAR(20),
    @BranchID CHAR(3),
    @AssetSeqNo INT,
    @TotalDayExtend INT,
    @Amount NUMERIC(17, 2),
    @LoginID VARCHAR(50),
    @BusinessDate DATETIME,
    @ReceiveFrom VARCHAR(50),
    @BankAccountID VARCHAR(50),
    @WOP VARCHAR(2),
    @CurrencyID CHAR(3),
    @CurrencyRate dbo.Amount,
    @ReferenceNo AS VARCHAR(20),
    @Note VARCHAR(100),
    --Vincenza add
    @TotalCost NUMERIC(17, 2),
    @WaivedAmount NUMERIC(17, 2),
    @PaidAmount NUMERIC(17, 2),
    --end Vincenza
    --Stefani, 17/09/2020
    @ReceiptNo AS VARCHAR(20) = ''
--End Stefani
--@BranchAgrmnt char(3) Remarked Adhitya 06/03/2020 FMF-1818 
AS
BEGIN
    


    --SELECT * FROM ljekdkde;

    BEGIN TRANSACTION SaveBPKBExtendCost;
    SAVE TRANSACTION SaveBPKBExtendCost;
    SET IMPLICIT_TRANSACTIONS ON;

	--Sugiono 08 Januari 2025 FMF-5318
	IF EXISTS (SELECT '' FROM dbo.PaymentHistoryHeader WITH (NOLOCK) WHERE CorrectionHistSequence = 0 AND ReceiptNoFormControl = @ReceiptNo) OR
	EXISTS (SELECT '' FROM dbo.PaymentHistoryHeaderEXP WITH (NOLOCK) WHERE CorrectionHistSequence = 0 AND ReceiptNoFormControl = @ReceiptNo)
	BEGIN
	    RAISERROR('The ReceiptNo entered is already registered under a different agreement!', 16, 1);
        GOTO ExitSp;
	END
	--End Sugiono

	--Add Reyvano [FMF-5008] 17 April 2024
    DECLARE @TanggalHariIni DATE;
    DECLARE @BDCurrent DATE;
    DECLARE @ErrMessage VARCHAR(100);
    DECLARE @ErrMessage2 VARCHAR(100);

    SELECT @TanggalHariIni = GETDATE();
    SELECT @BDCurrent = BDCurrent
    FROM dbo.SystemControlCoy WITH (NOLOCK);
    SET @ErrMessage
        = 'Current date : ' + CAST(CAST(@TanggalHariIni AS DATE) AS CHAR(10)) + ' is different with system date : '
          + CAST(CAST(@BDCurrent AS DATE) AS CHAR(10)) + ' , please ReLogin';
    SET @ErrMessage2
        = 'System date : ' + CAST(CAST(@BDCurrent AS DATE) AS CHAR(10)) + ' is different with BusinessDate : '
          + CAST(CAST(@BusinessDate AS DATE) AS CHAR(10)) + ' , please ReLogin';
	
    IF @TanggalHariIni <> @BDCurrent
    BEGIN
        RAISERROR(@ErrMessage, 16, 1);
        GOTO exitsp;
    END;

    IF @BDCurrent <> CAST(@BusinessDate AS DATE)
    BEGIN
        RAISERROR(@ErrMessage2, 16, 1);
        GOTO exitsp;
    END;
    --End Reyvano [FMF-5008]

    DECLARE @BranchIdHO CHAR(3),
            @Error INT;

    --BEGIN Niko FMF-4716 Penjagaan double klik
    IF EXISTS
    (
        SELECT ''
        FROM dbo.PaymentHistoryHeader
        WHERE ValueDate = @BusinessDate
              AND ProcessID = 'BPKBEC'
              AND Amount = @Amount
              AND DATEDIFF(n, DtmUpd, GETDATE()) < 1
              AND ApplicationID = @ApplicationID
              AND BranchId = @BranchID
    )
    BEGIN
        RAISERROR('BPKBExtendCostPaymentReceive Process has been changed by another user!', 16, 1);
        GOTO ExitSp;
    END;
    --END Niko FMF-4716

    IF NOT EXISTS
    (
        SELECT TOP 1
               ISNULL(OpeningSequence, 0)
        FROM dbo.CashierHistory WITH (NOLOCK)
        WHERE BranchId = @BranchID
              AND LoginId = @LoginID
              AND OpeningDate >= CONVERT(DATETIME, LEFT(CONVERT(VARCHAR(20), @BusinessDate), 11), 101)
              AND CashierStatus = 'O'
        ORDER BY OpeningSequence DESC
    )
    BEGIN
        RAISERROR('Please Open Cashier First', 16, 1);
        RETURN 0;
    END;

    --Add Adhitya Penambahan Penjagaan 16/09/2020
    IF @Amount + @PaidAmount + @WaivedAmount > @TotalCost
    BEGIN
        RAISERROR('Your Amount + PaidAmount + WaivedAmount > TotalCost. Process Is Abort', 16, 1);
        RETURN 0;
    END;
    --End Adhitya Penambahan Penjagaan

    DECLARE @BranchAgrmnt CHAR(3);

    SELECT @BranchIdHO = BranchID
    FROM dbo.Branch
    WHERE IsHeadOffice = 1;
    SELECT @BranchAgrmnt = BranchID
    FROM Agreement WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationID;
    IF @Amount > 0
    BEGIN
        DECLARE @OpeningSequence INT;
        EXEC @Error = dbo.spProcessUpdateCashBank @BranchID,
                                                  @BankAccountID,
                                                  @LoginID,
                                                  @BusinessDate,
                                                  @WOP,        --@WOP    
                                                  @Amount,     --@AmountPayment    
                                                  @CurrencyID, --@CurrencyID    
                                                  @OpeningSequence OUTPUT;
        IF @Error > 0
            GOTO ExitSP;

        CREATE TABLE #TempTable
        (
            SeqNo INT IDENTITY PRIMARY KEY,
            PaymentAllocationID CHAR(20),
            Post CHAR(1),
            Amount NUMERIC(17, 2),
            RefDesc VARCHAR(50),
            DepartementID VARCHAR(3),
            VoucherDesc VARCHAR(50)
        );

        INSERT INTO #TempTable
        (
            PaymentAllocationID,
            Post,
            Amount,
            RefDesc,
            VoucherDesc
        )
        VALUES
        ('ECBPKBLC', 'C', @Amount, 'ECBPKBLC -' + @ReferenceNo, '');

        --INSERT INTO #TempTable (PaymentAllocationID, Post, Amount, RefDesc, VoucherDesc)    
        --VALUES ('OTHRINCBNK', 'D', @Amount, 'OTHRINCBNK -' + @ReferenceNo, '')    

        DECLARE @JournalCode VARCHAR(20);
        EXEC @Error = dbo.spProcessCreateJournal @CoyID = '',                        -- varchar(3)    
                                                 @BranchID = @BranchID,              -- varchar(3)    
                                                 @TransactionID = 'BEC',             -- varchar(8)    
                                                 @BusinessDate = @BusinessDate,      -- datetime    
                                                 @ValueDate = @BusinessDate,         -- datetime    
                                                 @ReferenceNo = @ReferenceNo,        -- varchar(50)    
                                                 @ApplicationID = @ApplicationID,    -- varchar(20)    
                                                 @Flag = 'R',                        -- char(1)    
                                                 @BankAccountID = @BankAccountID,    -- varchar(10)    
                                                 @AmountReceive = @Amount,           -- numeric(26, 9)    
                                                 @CurrencyID = @CurrencyID,          -- char(3)    
                                                 @CurrencyRate = @CurrencyRate,      -- Amount    
                                                 @IsActive = 1,                      -- bit    
                                                 @JournalCode = @JournalCode OUTPUT, -- varchar(20)    
                                                 @BranchIDX = NULL,                  -- varchar(3)    
                                                 @CurrencyIDX = NULL;                -- varchar(3)    
        IF @Error > 0
        BEGIN
            RAISERROR('Error When Process Create Journal', 16, 1); --Add Adhitya 18/09/2020 Menambah Penjagaan jika error munculin RaisError
            GOTO ExitSP;
        END;

        DECLARE @VoucherNo VARCHAR(20);
        EXEC @Error = dbo.spProcessCreateCashBankTransactions @BranchID = @BranchID,           -- varchar(3)    
                                                              @ProcessID = 'BPKBEC',           -- varchar(10)    
                                                              @BusinessDate = @BusinessDate,   -- datetime    
                                                              @ValueDate = @BusinessDate,      -- datetime    
                                                              @OpeningSequence = 0,            -- int    
                                                              @LoginID = @LoginID,             -- varchar(12)    
                                                              @Wop = @WOP,                     -- varchar(5)    
                                                              @ReceiveFrom = @ReceiveFrom,     -- varchar(50)    
                                                              @ReferenceNo = @ReferenceNo,     -- varchar(20)    
                                                              @JournalCode = @JournalCode,     -- varchar(20)    
                                                              @ApplicationID = @ApplicationID, -- varchar(20)    
                                                              @Flag = 'R',                     -- char(1)    
                                                              @BankAccountID = @BankAccountID, -- varchar(10)    
                                                              @AmountReceive = @Amount,        -- Amount    
                                                              @Notes = @Note,                  -- varchar(100)    
                                                              @CurrencyID = @CurrencyID,       -- char(3)    
                                                              @BGno = '-',                     -- char(20)    
                                                              @BGDueDate = NULL,               -- datetime    
                                                              @IsReconcile = 1,                -- bit    
                                                              @VoucherNo = @VoucherNo OUTPUT,  -- varchar(20)    
                                                              @ReferencePDC = NULL,            -- varchar(50)    
                                                              @BranchIDX = NULL;               -- varchar(3)      

        IF @Error > 0
        BEGIN
            RAISERROR('Error When Process Create Cash Bank Transaction', 16, 1); --Add Adhitya 18/09/2020 Menambah Penjagaan jika error munculin RaisError
            GOTO ExitSP;
        END;

        DECLARE @HistorySequenceNo INT,
                @BankID VARCHAR(5);
        SELECT @BankID = ISNULL(BankID, '-')
        FROM BankAccount WITH (NOLOCK)
        WHERE BranchID = @BranchID
              AND BankAccountID = @BankAccountID;

        EXEC @Error = dbo.spProcessCreatePaymentHistory @BranchID = @BranchID,                          -- varchar(3)    
                                                        @ApplicationID = @ApplicationID,                -- varchar(20)    
                                                        @BusinessDate = @BusinessDate,                  -- datetime    
                                                        @ValueDate = @BusinessDate,                     -- datetime    
                                                        @BankID = @BankID,                              -- varchar(5)    
                                                        @GiroNo = '-',                                  -- varchar(20)    
                                                        @IsCorrection = 0,                              -- bit    
                                                        @CorrectionHistorySequence = 0,                 -- smallint    
                                                        @ReferenceNo = @ReferenceNo,                    -- varchar(20)    
                                                        @ReceivedFrom = @ReceiveFrom,                   -- Name    
                                                        @WOP = @WOP,                                    -- varchar(5)    
                                                        @ProcessID = 'BPKBEC',                          -- varchar(10)    
                                                        @AmountReceive = @Amount,                       -- Amount    
                                                        @JournalCode = @JournalCode,                    -- JournalCOA    
                                                        @BankAccountID = @BankAccountID,                -- varchar(10)    
                                                        @HistorySequenceNo = @HistorySequenceNo OUTPUT, -- int    
                                                        @ReceiptNo = @ReceiptNo,                        --Stefani, 17/09/2020 -- varchar(20)    
                                                        @VoucherNo = @VoucherNo,                        -- varchar(20)    
                                                        @IsPaidbyCustomer = DEFAULT,                    -- bit    
                                                        @PayerRelationship = DEFAULT,                   -- varchar(10)    
                                                        @PayerName = DEFAULT,                           -- varchar(100)    
                                                        @PayerIDNumber = DEFAULT,                       -- varchar(40)    
                                                        @PayerMobilePhone = DEFAULT;                    -- varchar(20)     
        IF @Error > 0
        BEGIN
            RAISERROR('Error When Process Create Payment History', 16, 1); --Add Adhitya 18/09/2020 Menambah Penjagaan jika error munculin RaisError
            GOTO ExitSP;
        END;
    END;
    ELSE
    BEGIN
        IF @Amount = 0
        BEGIN
            SET @Amount = 0;
            RAISERROR('Amount Receive can not be 0 !!!, Your Process Is Aborted', 16, 1);
        END;
        ELSE
        BEGIN
            RAISERROR('Amount Receive can not be minus or less than 0. ', 16, 1);
            RETURN 0;
        END;
    END;
    -- add Vincenza
    IF EXISTS
    (
        SELECT ''
        FROM BPKBExtendCost
        WHERE ApplicationID = @ApplicationID
              AND BranchID = @BranchAgrmnt
              AND AssetSeqNo = @AssetSeqNo
    )
    BEGIN
        DECLARE @CheckTotal AS NUMERIC(17, 2),
                @FlagStat CHAR(1);
        SET @CheckTotal = @Amount + @WaivedAmount + @PaidAmount;
        IF @TotalCost = @CheckTotal
            SET @FlagStat = 'P';
        ELSE
            SET @FlagStat = 'N';
        --end 
        SELECT @AssetSeqNo,
               @ApplicationID,
               @BranchAgrmnt;

        DECLARE @tgl DATETIME;

        SELECT @tgl = DtmUpd
        FROM BPKBExtendCost
        WHERE Status = @FlagStat
              AND TotalDayExtend = @TotalDayExtend
              AND TotalCost = @TotalCost
              AND PaymentDate = @BusinessDate
              AND PaymentBy = @LoginID
              AND BankAccountID = @BankAccountID
              AND Note = @Note
              AND UsrUpd = @LoginID
              AND ApplicationID = @ApplicationID
              AND BranchID = @BranchAgrmnt
              AND AssetSeqNo = @AssetSeqNo;

        UPDATE dbo.BPKBExtendCost
        SET Status = @FlagStat,
            TotalDayExtend = @TotalDayExtend,
            --add Vincenza 
            TotalCost = @TotalCost,
            PaidAmount = PaidAmount + @Amount,
            --end Vincenza
            PaymentDate = @BusinessDate,
            PaymentBy = @LoginID,
            BankAccountID = @BankAccountID,
            Note = @Note,
            UsrUpd = @LoginID,
            DtmUpd = GETDATE()
        WHERE ApplicationID = @ApplicationID
              AND BranchID = @BranchAgrmnt
              AND AssetSeqNo = @AssetSeqNo;
        IF @@Error > 0
            GOTO ExitSP;
    END;
    ELSE
    BEGIN
        RAISERROR('Not Found', 16, 1);
        GOTO ExitSP;
    END;

    --BEGIN Niko FMF-4754 Tambah penjagaan double klik dibawah
    IF
    (
        SELECT COUNT(*)
        FROM dbo.PaymentHistoryHeader
        WHERE ValueDate = @BusinessDate
              AND ProcessID = 'BPKBEC'
              AND Amount = @Amount
              AND DATEDIFF(n, DtmUpd, GETDATE()) < 1
              AND ApplicationID = @ApplicationID
              AND BranchId = @BranchID
    ) > 1
    BEGIN
        RAISERROR('BPKBExtendCostPaymentReceive Process has been changed by another user!', 16, 1);
        GOTO ExitSp;
    END;
    --END Niko FMF-4754


    COMMIT TRANSACTION SaveBPKBExtendCost;
    RETURN 0;

    ExitSP:
    BEGIN
        ROLLBACK TRANSACTION SaveBPKBExtendCost;
        RETURN 0;

    END;


END;
GO

