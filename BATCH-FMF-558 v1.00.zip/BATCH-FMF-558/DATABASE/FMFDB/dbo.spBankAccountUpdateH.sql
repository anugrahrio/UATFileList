SET QUOTED_IDENTIFIER OFF
SET ANSI_NULLS OFF
GO


--Modify Arinta, 22 Des 2015 menambahkan @IsMainBankAcc --arinta FMF - 1465 CR Sales and Lease Back
--Modify Sugiono, 21 November 2024 : FMF-5202 Data cash on hand : tambah update dtmupd


ALTER Procedure [dbo].[spBankAccountUpdateH]
	@branchid char(3), 
	@bankaccountid char(10), 
	@bankaccountname varchar(50), 
	@coa varchar(25), 
	@bankaccounttype varchar(5), 
	@bankpurpose varchar(5), 	
	@Status bit, 
	@currencyid char(3),
	@IsMainBankAcc BIT--arinta FMF - 1465 CR Sales and Lease Back


As
		
		

if @IsMainBankAcc =1
		Begin
			IF EXISTS ( SELECT '' FROM  BankAccount WHERE branchid = @branchid AND IsMainBankAccount =1 and BankAccountID <> @bankaccountid)
			BEGIN
				RAISERROR ( 'Can not checked main bank account, because other bank account has been saved', 16, 1 )
			END
		End

		Update bankaccount set
			bankaccountname = @bankaccountname, 
			coa = @coa,
			bankaccounttype = @bankaccounttype, 
			bankpurpose = @bankpurpose, 
			isactive = @Status, 
			currencyid = @currencyid,
			IsMainBankAccount = @IsMainBankAcc --arinta FMF - 1465 CR Sales and Lease Back
			--Sugiono, 21 November 2024 : FMF-5202
			, UsrUpd= SYSTEM_USER 
			, DtmUpd = GETDATE() 
			--End Sugiono
		where bankaccountid = @bankaccountid and branchid = @branchid







GO

