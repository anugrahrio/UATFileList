/****** Object:  StoredProcedure [dbo].[spPO_Save2]    Script Date: 9/6/2023 4:57:09 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spPO_Save2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spPO_Save2]
GO
/****** Object:  StoredProcedure [dbo].[spPO_Save2]    Script Date: 9/6/2023 4:57:09 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spPO_Save2]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'









/*
   Widi 27 Agustus 2004

	select * from PurchaseOrder   
modified ; emilia 4/4/2006 add supplieraccountid ke tabel agreementasset 
29052008 MUL penjagaan jika dalam branch,aplikasi,supplierid yang sama tidak boleh ada 
satria.sm April 13, 2010 : Penambahan penjagaan untuk Account Name, Bank Name, Account No agar tidak null
Gema, 20111031 : Tambah penjagaan if exist PONo
Rudi, 17 Nov 2011 : Tambah insert ke PurchaseOrderDetail
Benny, 30 juni 2015 : FMF-1422 Lifeinsurance
Albert Ricia on 04-07-2015 : FMF-1427 tambah pengecekan transferAPDisb
Arinta 15 Januari 2016 : FMF 1465 Sales and Lease Back
Restu FMF-1546 : tambah where supplierid untuk yang multi supplier, ubah cara insert OTR dan DP ke po detail agar support multi asset
Aditia FMF-1640 09032018 Tambah pengecekkan is capitalized provision dan admin
Vincenza FMF-2420 Penambahan AgentFee
Vincenza FMF-3854 19102022 : Penjagaan Agreement Allocation 
Fuji,06122022 : FMF-3885 Save Deposit Amount ke PODetail
Fuji,26012023 : (FMF-4017) Ubah perhitungan SubsidyCommision jika ada VAT
Fuji,08032023 : (FMF-4127)  Save Take Over Amount ke PODetail dan
				Tambah validasi pada waktu Puchase Order, dimana Take Over Amount tidak boleh lebih besar dari Total AP ke dealer/customer
Fuji,30052023(fmf-4127)UAT TakeOverAmt mengurangi nilai @PODetail
Sugiono 06 September 2023 : FMF-4563 CLONE - Kendala PURCHASE ORDER : penyesuaian untuk OTRAmount (sum OTRAmount untuk semua asset)
*/

CREATE  Procedure [dbo].[spPO_Save2]
	      @BranchID char(3),
		  @ApplicationID varchar(20),
		  @PONo varchar(50) output,
		  @SupplierID char(10),
		  @IsMainPO char(1),
		  @PODate datetime, 	
		  @Notes text,
		  @SupplierAccID  char(10),
		  @ProductOfferingID char(10),
		  @ProductID char(10),
		  @POTotal amount

	 

As














Set NoCount On
	DECLARE @DaysPOExpiration integer,
		@SupplierBankID char(5),
		@SupplierBankBranch varchar(30),
		@SupplierAccountNo varchar(25),
		@SupplierAccountNama varchar(50),
		@Err Varchar(100),
		@BankName varchar(50),
		@error	int,
		@CustomerID char(20),
		@CustomerType char(1),
		@TransferApDisb char(1) --Added by Albert Ricia on 04-07-2015

-- Declare @cPODate As varchar(50)
-- set @cPODate = Convert(varchar(10),@PODate,101)
-- Set @cPODate = left(@cPODate,10) + '' '' +
-- 						 LTrim(str(Datepart(hh, getdate()))) + '':'' +
-- 						 LTrim(str(Datepart(n, getdate()))) +  '':'' +
-- 						 LTrim(str(Datepart(ss, getdate())))		 	
-- Set @PODate = Convert(dateTime,@cPODate)

	--Vincenza FMF-2420 18112020

	DECLARE @AgentFeePercentage Numeric(9,6)
	select @AgentFeePercentage = ISNULL(AgentFeePercentage,0) from Supplier Sup with (nolock)
	inner join Agreement Agr with (nolock) on Agr.SupplierID = Sup.SupplierID 
	where Agr.BranchID = @BranchID and Agr.ApplicationID = @ApplicationID 

	BEGIN TRANSACTION POSave
	BEGIN
	--SELECT * FROM abc
	set @Err=''''
	select @DaysPOExpiration=DaysPOExpiration
	from ProductOffering  with (nolock) where
		ProductOfferingID=@ProductOfferingID and ProductID=@ProductID
		and BranchID=@BranchID

	-- Albert Ricia on 04-07-2015
	-- Check TransferApDisb to customer or dealer
	Select @CustomerID = customerID, @TransferApDisb = TransferAPDisb From Agreement with(nolock) Where ApplicationID=@ApplicationID And BranchID=@BranchID

	IF (@TransferApDisb = ''D'' OR @TransferApDisb IS NULL)
		BEGIN
			Select  @SupplierBankID=SupplierBankID,@SupplierBankBranch=SupplierBankBranch,@SupplierAccountNo=SupplierAccountNo,
				@SupplierAccountNama=SupplierAccountName from SupplierAccount with (nolock) 
			Where 	SupplierAccID = @SupplierAccID And SupplierID = @SupplierID
		END
	ELSE IF (@TransferApDisb = ''C'')
		BEGIN
			Select @CustomerType = CustomerType FROM Customer with (nolock) WHERE customerID = @CustomerID
			
			IF (@CustomerType = ''P'') 
				BEGIN
					Select  @SupplierBankID=BankID,@SupplierBankBranch=BankBranch,@SupplierAccountNo=AccountNo,
						@SupplierAccountNama=AccountName from PersonalCustomer with (nolock) 
					Where 	customerID = @CustomerID
				END
			ELSE IF (@CustomerType = ''C'')
				BEGIN
					Select  @SupplierBankID=BankID,@SupplierBankBranch=BankBranch,@SupplierAccountNo=AccountNo,
						@SupplierAccountNama=AccountName from CompanyCustomer with (nolock) 
					Where 	customerID = @CustomerID
				END
		END
	-- End Added by Albert Ricia
	--End
	--Vincenza FMF-3854 19102022
	declare @AgreementNoAlloc varchar(20), @TotalAmountToBeAllocated numeric(17,2)
	select @AgreementNoAlloc = ISNULL(AgreementNoAllocation,'''') from Agreement with (nolock)
	where BranchID = @BranchID and ApplicationID = @ApplicationID and IsAgreementAllocation = 1

	if @AgreementNoAlloc <> '''' 
	begin
		if exists ( select '''' from AgreementDisbAllocation with (nolock) where branchID = @BranchID and ApplicationID = @ApplicationID )
		begin
			delete AgreementDisbAllocation
			where BranchID = @BranchID and  ApplicationID = @ApplicationID 
		end

		exec spAgrAllocCalculate @BranchID = @BranchID, @ApplicationID = @ApplicationID
		select @TotalAmountToBeAllocated = ISNULL(TotalAmountToBeAllocated,-1) from AgreementDisbAllocation with (nolock)
		where BranchID = @BranchID and ApplicationID = @ApplicationID

		if @TotalAmountToBeAllocated >= 0 
		begin
			if @TotalAmountToBeAllocated  >  @POTotal
			begin
				RAISERROR(''Nilai Pelunasan Agreement Lama <= Nilai PO agreement baru!'',16,1)
			end
		end
	end
	--end 

	Select @BankName = BankName from BankMaster with (nolock) 
	Where BankID = @SupplierBankID
	

-- ratna 07 jan 2005
-- no po digenerate disini, bukan di form
exec @error=spGetNoTransaction @BranchID, @PODate, ''PO'', @PONo output  


if @error <> 0
	goto exitSP
	
	--- Purchase Order
	if exists(select '''' from PurchaseOrder with (nolock) where 
			BranchID=@BranchID and ApplicationID=@ApplicationID And supplierid=@SupplierID )--29052008 MUL
	begin
		set @Err=''Double''
	end
	else
	begin
	
		--Gema, 20111031 : Tambah penjagaan if exist PONo
	    if exists(select '''' from PurchaseOrder with (nolock)  where 
			BranchID = @BranchID and PONo =@PONo )
		begin
			set @Err=''PO Number Already Use, please repeat proses PO again''
			GOTO exitsp	
		end
		else
		Begin
				Insert into PurchaseOrder 
					(BranchID, ApplicationID, PONo,  SupplierID, BankName, 
					BankBranch, AccountName, AccountNo, PODate, POOriginalExpiredDate, POExpiredDate, POTotal, Notes,
					SupplierBankID,SupplierBankBranch,SupplierAccountNo,SupplierAccountName,IsMainPO
					) 
					values 
					(@BranchID, @ApplicationID, @PONo, @SupplierID, @BankName, 
					@SupplierBankBranch, @SupplierAccountNama, @SupplierAccountNo, @PODate, Dateadd(day, @DaysPOExpiration, @PODate), 
					Dateadd(day, @DaysPOExpiration, @PODate),@POTotal, @Notes,@SupplierBankID,@SupplierBankBranch, @SupplierAccountNo,@SupplierAccountNama,
					(case @IsMainPO when ''1'' then 1 else 0 end))
				IF @@error > 0 
				BEGIN
					GOTO exitsp	
				END

			
				update AgreementAsset set supplieraccountid = @SupplierAccID 
				where branchid=@branchid and applicationid=@applicationid and supplierid = @SupplierID
				
				IF @@error > 0 
				BEGIN
					GOTO exitsp	
				END
				
				--Added by Rudi, 17 Nov 2011
				DECLARE	@SeqNo SMALLINT,
						@NumofAdvance Amount,
						@FirstInst VARCHAR(2),
						@InstallmentAmount Amount,
						@AdminFee Amount,
						@InsurancePremium Amount,
						@IsLifeInsurance CHAR(1),
						@LifeInsurancePremium Amount,
						@OtherFee Amount,
						@TDPAmount Amount,
						@AssetDesc VARCHAR(50),
						@OTRPrice Amount,
						@DPAmount Amount,
						@DiscountOTR Amount,
						@SubsidyCommission Amount,
						@AdditionalOtherFee Amount -- arinta, 28 des 1015, fmf-1465
						,@AgentFee Amount --Vincenza FMF-2420 18112020
						,@InterestRate Amount
						,@CreditInsuranceAgentPremi Amount
						,@DepositAmount Amount --add fuji,06122022 (fmf-3885)
						,@TakeOverAmount Amount --Add fuji,08032023 (fmf-4127)

				SELECT @NumofAdvance = NumOfAdvanceInstallment, @FirstInst = FirstInstallment
				FROM dbo.Agreement WITH(NOLOCK) WHERE BranchID = @BranchID AND ApplicationID = @ApplicationID

				IF @FirstInst = ''AD''
				   BEGIN
					SELECT @InstallmentAmount = SUM(InstallmentAmount) FROM dbo.InstallmentSchedule WITH(NOLOCK)
					WHERE BranchID = @BranchID AND ApplicationID = @ApplicationID AND InsSeqNo <= @NumofAdvance
				  END
				ELSE
				BEGIN
  					SET @InstallmentAmount = 0
				END
				
				SELECT
					@AssetDesc = c.Description,
					@OTRPrice = b.OTRPrice,
					@DPAmount = b.DPAmount,
					@DiscountOTR = TotalDiscOTR,
					--Anita, 20150710
					--@SubsidyCommission = ISNULL((Qry2.SupplierInsuranceIncome + Qry2.SupplierUppingBunga + Qry2.SupplierOtherFee - Qry2.SupplierTaxAmount),0),
					@SubsidyCommission =	CASE ISNULL(@TransferApDisb,''D'')
												WHEN ''C'' THEN 0 --Novia tambah isnull, sementara nanti diganti dengan yg bener, novia 04102016 : ganti jadi D
												--EDIT FUJI,26012023 (FMF-4017)
												ELSE  CASE WHEN ISNULL(SupplierPPNAmount,0) > 0 then (SupplierDPPAmount+SupplierPPNAmount-SupplierTaxAmount) else  
													 CASE ISNULL(qry2.CalculateTaxMethodSupplier,''NE'')
														WHEN ''NE'' THEN ISNULL((Qry2.SupplierInsuranceIncome + Qry2.SupplierUppingBunga + Qry2.SupplierOtherFee + Qry2.SupplierProvisionFee - Qry2.SupplierTaxAmount),0) --Restu FMF-1546 tambah isnull calculatetaxmethod; Aditia FMF-1640 13032018 Tambah Qry2.SupplierProvisionFee
														WHEN ''GR'' THEN ISNULL((Qry2.SupplierInsuranceIncome + Qry2.SupplierUppingBunga + Qry2.SupplierOtherFee + Qry2.SupplierProvisionFee),0) --Restu FMF-1546 tambah isnull calculatetaxmethod; Aditia FMF-1640 13032018 Tambah Qry2.SupplierProvisionFee
													END
												END
												--END FUJI
											END,
					--End Anita	
					@AdminFee = a.AdminFee - ISNULL(a.AdminFeeCapitalized,0), --Aditia FMF-1640 09032018 Tambah Case IsCapitalized
					@InsurancePremium = a.InsAssetReceivedinAdv,
					@IsLifeInsurance = ISNULL(a.IsLifeInsurance, ''0''),
					@LifeInsurancePremium = ISNULL(a.lifeinsurancepremium, ''0'') - ISNULL(a.LifeInsuranceCapitalized, ''0'') , --ISNULL(a.LifeInsurancePremium, ''0'') + ISNULL(d.AdminFee, ''0'') + ISNULL(d.StampDutyFee, ''0''), --Modify by Benny 30 juni 2015, FMF-1422 Lifeinsurance
					@OtherFee = a.FiduciaFee + (a.ProvisionFee - ISNULL(a.ProvisionFeeCapitalized,0)) + a.NotaryFee + a.SurveyFee + a.OtherFee, --Aditia FMF-1640 09032018 Tambah Case IsCapitalized
					@AdditionalOtherFee = ISNULL(a.AdditionalOtherFee,''0''),--arinta, fmf-1465, 28 des 2015
					--Vincenza FMF-2420 18112020
					@AgentFee = 
					CASE WHEN ISNULL(AT.IsFactoring,0) = 1 then (ISNULL(@AgentFeePercentage,0) * a.OutstandingInterest / 100 )
					WHEN ISNULL(AT.IsFactoring,0) = 0 then 0 END ,
					@InterestRate = 
					CASE	WHEN ISNULL(AT.IsFactoring,0) = 1 then 
							CASE	WHEN ISNULL(a.CreditInsuranceBy,'''') = ''A'' then ISNULL(a.InterestRate,0)
									ELSE 0 END
							WHEN ISNULL(AT.IsFactoring,0) = 0 then 0 END,
					@CreditInsuranceAgentPremi = 
					CASE	WHEN ISNULL(AT.IsFactoring,0) = 1 then 
							CASE	WHEN ISNULL(a.CreditInsuranceBy,'''') = ''A'' then ( ISNULL(CID.Premium,0) + ISNULL(CID.AdminFee,0) + ISNULL(CID.StampDutyFee,0) )
									ELSE 0 END
							WHEN ISNULL(AT.IsFactoring,0) = 0 then 0 END,
					--end Vincenza
					@TDPAmount = a.TDPAmount
					,@DepositAmount=ISNULL(a.DepositAmt,0) --add fuji,06122022 (fmf-3885)
					,@TakeOverAmount =isnull(a.TakeOverAmt,0 ) --Add fuji,08032023 (fmf-4127)
				FROM dbo.Agreement a WITH(NOLOCK)
				INNER JOIN dbo.AgreementAsset b WITH(NOLOCK)
					ON a.BranchID = b.BranchID AND a.ApplicationID = b.ApplicationID
				INNER JOIN dbo.AssetMaster c WITH(NOLOCK)
					ON b.AssetCode = c.AssetCode
				--Vincenza FMF-2420 18112020
				INNER JOIN AssetType AT with (nolock) on c.AssetTypeID = AT.AssetTypeID and b.AssetTypeID = AT.AssetTypeID
				LEFT JOIN CreditInsuranceData CID with (nolock) on b.BranchID = CID.BranchID and b.ApplicationID = CID.ApplicationID
				--end Vincenza
				/*LEFT JOIN dbo.LifeInsuranceAgreement d WITH(NOLOCK)
					ON d.BranchID = a.BranchID AND d.ApplicationID = a.ApplicationID*/	--Remark by Benny 30 juni 2015, FMF-1422 Lifeinsurance
				INNER JOIN
						(SELECT BranchID, ApplicationID, SupplierID, SUM(CASE WHEN DiscountOTRAmount IS NULL THEN 0 ELSE DiscountOTRAmount END) TotalDiscOTR
						 FROM dbo.AgreementAsset b WHERE BranchID = @BranchID AND ApplicationID = @ApplicationID GROUP BY BranchID, ApplicationID, SupplierID) qryjoin
					ON qryjoin.BranchID = b.BranchID AND qryjoin.ApplicationID = b.ApplicationID AND qryjoin.SupplierID = b.SupplierID
				LEFT JOIN
						(SELECT BranchId, ApplicationId, SupplierID, SUM(SupplierInsuranceIncome) AS SupplierInsuranceIncome,
								SUM(SupplierUppingBunga) AS SupplierUppingBunga, SUM(SupplierOtherFee) AS SupplierOtherFee, 
								SUM(SupplierTaxAmount) AS SupplierTaxAmount,
								 --ADD FUJI,26012023(FMF-4017)
								SUM(ISNULL(SupplierDPPAmount,0)) AS SupplierDPPAmount,
								SUM(ISNULL(SupplierPPNAmount,0)) AS SupplierPPNAmount,						
							--END EDIT FUJI 
								SUM(ISNULL(SupplierProvisionFee,0)) AS SupplierProvisionFee, --Aditia FMF-1640 13032018
								CalculateTaxMethodSupplier --Restu FMF-1546
						 FROM dbo.Commision WITH(NOLOCK)
						 WHERE BranchId = @BranchID AND ApplicationId = @ApplicationID  
						 GROUP BY BranchId, ApplicationId, SupplierID, CalculateTaxMethodSupplier) Qry2
					ON b.BranchID = Qry2.BranchId AND b.ApplicationID = Qry2.ApplicationId AND b.SupplierID = Qry2.SupplierID
				WHERE a.BranchID = @BranchID AND a.ApplicationID = @ApplicationID
					 and b.SupplierID = @SupplierID --Restu FMF-1546
				
				--Add Fuji,08032023 (FMF-4127) Add Validasi Jika @TakeOverAmount > APAmount to Dealer/Cust maka proses PO tidak bisa di teruskan
				 DECLARE @APAmount Amount
				  
				SET @APAmount = isnull(@OTRPrice,0) + (isnull(@DPAmount,0) * -1) + (isnull(@DiscountOTR,0) * -1) + isnull(@SubsidyCommission,0) 
				+ (isnull(@InstallmentAmount,0) * -1) + (isnull(@AdminFee,0) * -1) + (isnull(@InsurancePremium,0) * -1)  + (CASE WHEN @IsLifeInsurance <> ''0'' THEN 				(isnull(@LifeInsurancePremium,0) * -1) ELSE ''0'' END) + (isnull(@OtherFee,0) * -1) + (isnull(@AdditionalOtherFee,0) * -1)+ (isnull(@TDPAmount,0)
				+ (ISNULL(@AgentFee,0) * 1) + (ISNULL(@InterestRate,0) * -1) + (ISNULL(@CreditInsuranceAgentPremi,0)) + (isnull(@DepositAmount,0) * -1) ) 

				IF @TakeOverAmount > @APAmount
				begin
					raiserror(''Take Over Amount Must be Less Than AP Amount to Dealer/Customer !!'' ,16,1)
					GOTO exitsp	
				end
				--end fuji

				--Benny 15 oct 2015
                DECLARE @PODetail Amount

				--Sugiono 06 September 2023 : FMF-4563
				DECLARE @OTRPriceAllAsset AMOUNT

				SELECT @OTRPriceAllAsset = a.TotalOTR
				FROM dbo.Agreement a WITH (NOLOCK)
				WHERE a.BranchID = @BranchID
					  AND a.ApplicationID = @ApplicationID;
				--End Sugiono

				SET @PODetail = ISNULL(@OTRPriceAllAsset, 0) --ISNULL(@OTRPrice,0) ----Sugiono 06 September 2023 : FMF-4563 --ganti @OTRPrice dengan @OTRPriceAllAsset
				+ (isnull(@DPAmount,0) * -1) + (isnull(@DiscountOTR,0) * -1) + isnull(@SubsidyCommission,0) 
				+ (isnull(@InstallmentAmount,0) * -1) + (isnull(@AdminFee,0) * -1) + (isnull(@InsurancePremium,0) * -1)  + (CASE WHEN @IsLifeInsurance <> ''0'' THEN 				(isnull(@LifeInsurancePremium,0) * -1) ELSE ''0'' END) + (isnull(@OtherFee,0) * -1) + (isnull(@AdditionalOtherFee,0) * -1)+ (isnull(@TDPAmount,0)
				--Vincenza FMF-2420 18112020
				+ (ISNULL(@AgentFee,0) * 1) + (ISNULL(@InterestRate,0) * -1) + (ISNULL(@CreditInsuranceAgentPremi,0)) + (isnull(@DepositAmount,0) * -1)+ (isnull(@TakeOverAmount,0) * -1) ) --fuji,06122022 (fmf-3885) DepositAmount --fuji,30052023(fmf-4127)TakeOverAmt
				

				
				IF (@IsLifeInsurance <> ''0'' AND @PODetail <> @POTotal)
				begin
					raiserror(''Total Amount PO Detail not equal Total Amount PO'' ,16,1)
					GOTO exitsp	
				end
				--end Benny

				SET @SeqNo = 1
				--PRINT @SubsidyCommission
				--Begin Restu
				--INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				--VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''OTR Price - '' + @AssetDesc, isnull(@OTRPrice,0), ''OTR'')
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				SELECT @BranchID, @ApplicationID, @PONo, ROW_NUMBER() OVER (PARTITION BY @PONo ORDER BY @PONo), ''OTR Price - '' + c.Description, ISNULL(b.OTRPrice,0), ''OTR''
				FROM dbo.Agreement a WITH(NOLOCK)
					 INNER JOIN dbo.AgreementAsset b WITH(NOLOCK)
								ON a.BranchID = b.BranchID AND a.ApplicationID = b.ApplicationID
					 INNER JOIN dbo.AssetMaster c WITH(NOLOCK)
								ON b.AssetCode = c.AssetCode
					 /*LEFT JOIN dbo.LifeInsuranceAgreement d WITH(NOLOCK)
								ON d.BranchID = a.BranchID AND d.ApplicationID = a.ApplicationID*/	--Remark by Benny 30 juni 2015, FMF-1422 Lifeinsurance
					 INNER JOIN
								(SELECT BranchID, ApplicationID, SupplierID, SUM(CASE WHEN DiscountOTRAmount IS NULL THEN 0 ELSE DiscountOTRAmount END) TotalDiscOTR
								FROM dbo.AgreementAsset b WHERE BranchID = @BranchID AND ApplicationID = @ApplicationID GROUP BY BranchID, ApplicationID, SupplierID) qryjoin
								ON qryjoin.BranchID = b.BranchID AND qryjoin.ApplicationID = b.ApplicationID AND qryjoin.SupplierID = b.SupplierID
					  LEFT JOIN
								(SELECT BranchId, ApplicationId, SupplierID, SUM(SupplierInsuranceIncome) AS SupplierInsuranceIncome,
								SUM(SupplierUppingBunga) AS SupplierUppingBunga, SUM(SupplierOtherFee) AS SupplierOtherFee, 
								SUM(SupplierTaxAmount) AS SupplierTaxAmount
								FROM dbo.Commision WITH(NOLOCK)
								WHERE BranchId = @BranchID AND ApplicationId = @ApplicationID  
								GROUP BY BranchId, ApplicationId, SupplierID) Qry2
					  ON b.BranchID = Qry2.BranchId AND b.ApplicationID = Qry2.ApplicationId AND b.SupplierID = Qry2.SupplierID
				WHERE a.BranchID = @BranchID AND a.ApplicationID = @ApplicationID
					 and b.SupplierID = @SupplierID

				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END
				
				--SET @SeqNo = @SeqNo + 1
				--INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				--VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''DPAmount - '' + @AssetDesc, isnull(@DPAmount,0) * -1, ''DP'')
				
				SELECT @SeqNo = MAX(SEQNO) FROM dbo.PurchaseOrderDetail WITH(NOLOCK) WHERE ApplicationID = @ApplicationID AND BranchID = @BranchID AND PONo = @PoNo

				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				SELECT @BranchID, @ApplicationID, @PONo, (ROW_NUMBER() OVER (PARTITION BY @PONo ORDER by @POno)) + @seqno, ''DPAmount - '' + c.Description, (ISNULL(b.DPAmount,0) * -1), ''DP''
				FROM dbo.Agreement a WITH(NOLOCK)
					 INNER JOIN dbo.AgreementAsset b WITH(NOLOCK)
								ON a.BranchID = b.BranchID AND a.ApplicationID = b.ApplicationID
					 INNER JOIN dbo.AssetMaster c WITH(NOLOCK)
								ON b.AssetCode = c.AssetCode
					 /*LEFT JOIN dbo.LifeInsuranceAgreement d WITH(NOLOCK)
								ON d.BranchID = a.BranchID AND d.ApplicationID = a.ApplicationID*/	--Remark by Benny 30 juni 2015, FMF-1422 Lifeinsurance
					 INNER JOIN
								(SELECT BranchID, ApplicationID, SupplierID, SUM(CASE WHEN DiscountOTRAmount IS NULL THEN 0 ELSE DiscountOTRAmount END) TotalDiscOTR
								FROM dbo.AgreementAsset b WHERE BranchID = @BranchID AND ApplicationID = @ApplicationID GROUP BY BranchID, ApplicationID, SupplierID) qryjoin
								ON qryjoin.BranchID = b.BranchID AND qryjoin.ApplicationID = b.ApplicationID AND qryjoin.SupplierID = b.SupplierID
					  LEFT JOIN
								(SELECT BranchId, ApplicationId, SupplierID, SUM(SupplierInsuranceIncome) AS SupplierInsuranceIncome,
								SUM(SupplierUppingBunga) AS SupplierUppingBunga, SUM(SupplierOtherFee) AS SupplierOtherFee, 
								SUM(SupplierTaxAmount) AS SupplierTaxAmount
								FROM dbo.Commision WITH(NOLOCK)
								WHERE BranchId = @BranchID AND ApplicationId = @ApplicationID  
								GROUP BY BranchId, ApplicationId, SupplierID) Qry2
					  ON b.BranchID = Qry2.BranchId AND b.ApplicationID = Qry2.ApplicationId AND b.SupplierID = Qry2.SupplierID
				WHERE a.BranchID = @BranchID AND a.ApplicationID = @ApplicationID
					 and b.SupplierID = @SupplierID

				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END
				

				SELECT @SeqNo = MAX(SEQNO) FROM dbo.PurchaseOrderDetail WITH(NOLOCK) WHERE ApplicationID = @ApplicationID AND BranchID = @BranchID AND PONo = @PoNo

				--End Restu
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Discount OTR'', isnull(@DiscountOTR,0) * -1, ''DISCOTR'')
				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END
				
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Commission(Subsidy)'', isnull(@SubsidyCommission,0), ''SUBCOM'')
				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END
				
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Installment Amount'', isnull(@InstallmentAmount,0) * -1, ''INSTALL'')
				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END
				
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Admin Fee'', isnull(@AdminFee,0) * -1, ''ADMINFEE'')
				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END
				
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Net Insurance Premium'', isnull(@InsurancePremium,0) * -1, ''INSUR'')
				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END
				
				SET @SeqNo = @SeqNo + 1
				
				IF @IsLifeInsurance <> ''0''
				BEGIN
					INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
					VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Net Life Insurance Premium'', isnull(@LifeInsurancePremium,0) * -1, ''LIFEINSUR'')
					
					IF @@ERROR > 0
					BEGIN
						GOTO exitsp
					END
					
					SET @SeqNo = @SeqNo + 1
				END
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Other'', isnull(@OtherFee,0) * -1, ''OTHER'')

				
				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp	
				END
				
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''TDP Paid at Coy'', isnull(@TDPAmount,0), ''TDPAmount'')
				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp	
				END

				SET @SeqNo = @SeqNo + 1
				--arinta, 28 des 2015, fmf-1465
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Add Other Fee'', isnull(@AdditionalOtherFee,0) * -1, ''AddOthFee'')
				--end arinta

				IF @@ERROR > 0
				BEGIN
					GOTO exitsp	
				END

				--Vincenza FMF-2420 18112020
				update Agreement 
				Set AgentFee = @AgentFee 
				where ApplicationID = @ApplicationID and BranchID = @BranchID 
				
				SET @SeqNo = @SeqNo + 1
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Agent Fee'', isnull(@AgentFee ,0) , ''AGENTFEE'')

				
				IF @@ERROR > 0
				BEGIN
					GOTO exitsp	
				END

				SET @SeqNo = @SeqNo + 1
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Interest Rate'', (isnull(@InterestRate  ,0) * -1) , ''INTRSTRATE'')

				IF @@ERROR > 0
				BEGIN
					GOTO exitsp	
				END

				SET @SeqNo = @SeqNo + 1
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Credit Insurance by Agent Premi '', isnull(@CreditInsuranceAgentPremi   ,0) , ''AGENTPREMI'')
				--end 

				IF @@ERROR > 0
				BEGIN
					GOTO exitsp
				END

				--add fuji,06122022 (fmf-3885)
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Deposit Amount'', isnull(@DepositAmount,0) * -1, ''DepAmt'')
				

				IF @@ERROR > 0
				BEGIN
					GOTO exitsp	
				END
				--end fuji

				--add fuji,08032023 (fmf-4127)
				SET @SeqNo = @SeqNo + 1
				
				INSERT INTO dbo.PurchaseOrderDetail (BranchID, ApplicationID, PONo, SeqNo, PODescription, POAmount, POID)
				VALUES (@BranchID, @ApplicationID, @PONo, @SeqNo, ''Take Over Amount'', isnull(@TakeOverAmount,0) * -1, ''TOAmt'')
				

				IF @@ERROR > 0
				BEGIN
					GOTO exitsp	
				END
				--end fuji


				--End Rudi
		end
		--End Gema, 20111031 : Tambah penjagaan if exist PONo

	End
	
	--IF @@error > 0 
	--BEGIN
	--	GOTO exitsp	
	--END
	
	--add by satria.sm April 13, 2010
	--print @PONo
	IF EXISTS(
				SELECT '''' FROM PurchaseOrder WHERE PONo = @PONo AND (bankname IS NULL OR accountname IS NULL OR accountno IS NULL)
			 )
		BEGIN
			raiserror(''Bank Name or Account Name OR Account No IS NULL   '' ,16,1)
			GOTO exitsp
		END
	--end Satria.sm
	

	COMMIT TRANSACTION POSave
	return 
		set nocount off
	
	exitsp:
		BEGIN
			ROLLBACK TRANSACTION POSave
			return 
		END

End








' 
END
GO
