SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO


-- =============================================    
-- Author:  Hafizhan  -- Modif by Vincenza  
-- Create date: 2022-03-30    
-- Description: FMF-2904    
/*
Modify :
1. Fuji,13 Des 2022 (FMF-4010) : Ubah Wherecond CustomerName dan SurgateMotherName menggunakan '=' bukan Like untuk menghindari Jika ada nama yang sama tidak masuk ke dalam blacklist 
2. Sugiono 21 Februari 2024 FMF-4920 FLag Customer High Risk dan Blacklist : menambahkan beberapa kondisi menyesuaikan dengan yang ada di proposal FMF-2904
*/
-- =============================================    
ALTER PROCEDURE [dbo].[spGetNegativeCustomerCriteria]
    -- Add the parameters for the stored procedure here    
    @CustomerID VARCHAR(20)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from    
    -- interfering with SELECT statements.    
    SET NOCOUNT ON;

    -- Insert statements for procedure here    
    DECLARE @IsActive BIT = 0,
            @IsHighRisk BIT = 0,
            @Birthdate DATETIME,
            @IDType VARCHAR(10),
            @IDNumber VARCHAR(80),
            @Name VARCHAR(100),
            @SurgateMotherName VARCHAR(100),
            @IsBlackListCust BIT = 0,
            @IsActiveCust BIT = 0,
            @BadTypeCust CHAR(1) = NULL,
            @IsFinal BIT = 0,
            @IsValidated BIT = 0;

    CREATE TABLE #BlackListCust
    (
        IsBlackList BIT,
        IsActiveCust BIT,
        BadTypeCust CHAR(1),
        IDNumber VARCHAR(80),
        BirthDate DATETIME,
        SurgateMotherName VARCHAR(100),
        CustomerName VARCHAR(100),
        IsValidated BIT
    );

    SELECT @IDType = IDType,
           @IDNumber = IDNumber,
           @Name = FullName,
           @Birthdate = BirthDate,
           @SurgateMotherName = SurgateMotherName,
           @IsHighRisk = ISNULL(IsHighRisk, 0)
    FROM PersonalCustomer pc WITH (NOLOCK)
        LEFT JOIN TblMapProfJobEmp job WITH (NOLOCK)
            ON job.TblProfessionID = pc.ProfessionID
               AND job.TblJobTypeID = pc.JobTypeID
               AND job.TblJobPositionID = pc.JobPos
    WHERE CustomerID = @CustomerID;

    INSERT INTO #BlackListCust
    SELECT ISNULL(NCSDS.IsBlackList, 0),
           ISNULL(NC.IsActive, 0),
           ISNULL(NC.BadType, ''),
           ISNULL(NC.IDNumber, ''),
           ISNULL(NC.BirthDate, ''),
           ISNULL(SurgateMotherName, ''),
           ISNULL(CustomerName, ''),
           0
    FROM NegativeCustomer NC WITH (NOLOCK)
        LEFT JOIN NegativeCustomerDataSource NCSDS WITH (NOLOCK)
            ON NC.DataSource = NCSDS.NCDataSourceID
    WHERE --(CustomerName Like '%' + @Name + '%' and BirthDate = @BirthDate) 
        (
            CustomerName = @Name
            AND BirthDate = @Birthdate
        ) --edit fuji,13122022(fmf-4010) ubah like jadi '='
        OR
        (
            IDType = @IDType
            AND IDNumber = @IDNumber
        )
        -- or  (CustomerName Like '%' + @Name + '%' and SurgateMotherName like  '%' + @SurgateMotherName + '%')
        --Sugiono 21 Februari 2024 FMF-4920 : Comment WhereCond, menyesuaikan dengan yang ada di proposal FMF-2904, untuk SurgateMotherName dan CustomerName tidak perlu masuk dalam kondisi
		--OR
        --(
            --CustomerName = @Name
            --AND SurgateMotherName = @SurgateMotherName
        --); --edit fuji,13122022(fmf-4010) ubah like jadi '=' 
		--End Sugiono

    SELECT TOP 1
           @IsBlackListCust = ISNULL(IsBlackList, 0),
           @IsActiveCust = ISNULL(IsActiveCust, 0),
           @BadTypeCust = ISNULL(BadTypeCust, 'W')
    FROM #BlackListCust
    WHERE IsActiveCust = 1
          AND BadTypeCust = 'B'
          AND IsBlackList = 1;


    UPDATE #BlackListCust
    SET IsValidated = CASE
                          WHEN (CustomerName = @Name)
                               AND BirthDate = @Birthdate
                               AND SurgateMotherName = @SurgateMotherName THEN
                              1
                          WHEN (CustomerName = @Name)
                               AND BirthDate = @Birthdate THEN
                              1
                          WHEN (CustomerName = @Name)
                               AND SurgateMotherName = @SurgateMotherName THEN
                              1
                          WHEN (IDNumber = @IDNumber) THEN
                              1
                      END
    WHERE IsBlackList = 1
	AND BadTypeCust = 'B' AND IsActiveCust = 1 --Sugiono 21 Februari 2024 FMF-4920 : menyesuaikan dengan yang ada di proposal FMF-2904 untuk cust BlackList ngecek juga di BadType dan IsActivenya
	;

    UPDATE #BlackListCust
    SET IsValidated = 0
    WHERE IsValidated IS NULL;

    SELECT @IsValidated = ISNULL(IsValidated, 0)
    FROM #BlackListCust
    WHERE IsBlackList = 1
          AND IsActiveCust = 1
          AND BadTypeCust = 'B'
          AND IsValidated = 1;

    IF @IsValidated = 1
    BEGIN
        SELECT 'BLACKLIST APU-PPT' AS Criteria;
    END;
    ELSE
    BEGIN
        IF EXISTS
        (
            SELECT ''
            FROM #BlackListCust WITH (NOLOCK)
            WHERE IsActiveCust = 1
        )
        BEGIN
            IF @IsFinal = 0
            BEGIN
                IF EXISTS
                (
                    SELECT ''
                    FROM #BlackListCust
                    WHERE IsActiveCust = 1
                          AND IsBlackList = 1
                          AND BadTypeCust = 'B'
                )
                BEGIN
                    SELECT 'BLACKLIST APU-PPT' AS Criteria;
                    SET @IsFinal = 1;
                END;
            END;

            IF @IsFinal = 0
            BEGIN
                IF EXISTS
                (
                    SELECT ''
                    FROM #BlackListCust
                    WHERE IsActiveCust = 1
                          AND BadTypeCust = 'B'
						  --Sugiono 21 Februari 2024 FMF-4920
						  AND IsBlackList = 0
						  AND @IsHighRisk = 0
						  --End Sugiono
                )
                BEGIN
                    SELECT 'BLACKLIST System' AS Criteria;
                    SET @IsFinal = 1;
                END;
            END;

            IF @IsFinal = 0
            BEGIN
                IF EXISTS
                (
                    SELECT ''
                    FROM #BlackListCust
                    WHERE IsActiveCust = 1
                          AND @IsHighRisk = 1
                )
                BEGIN
                    SELECT 'HIGHRISK APU-PPT' AS Criteria;
                    SET @IsFinal = 1;
                END;
            END;

            IF @IsFinal = 0
            BEGIN
                IF EXISTS
                (
                    SELECT ''
                    FROM #BlackListCust
                    WHERE IsActiveCust = 1
                          AND BadTypeCust = 'W'
						  AND @IsHighRisk = 0 --Sugiono 21 Februari 2024 FMF-4920
                )
                BEGIN
                    SELECT 'WARNING' AS Criteria;
                    SET @IsFinal = 1;
                END;
            END;
        END;

        ELSE
        BEGIN
            IF (@IsHighRisk = 1)
                SELECT 'HIGHRISK APU-PPT' AS Criteria;
            ELSE
                SELECT 'WHITELIST' AS Criteria;
        END;
    END;

    DROP TABLE #BlackListCust;
END;




GO

