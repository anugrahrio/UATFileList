SET QUOTED_IDENTIFIER OFF
SET ANSI_NULLS ON
GO

/*
Create by : David 6Jan2010
Modification Hist:
24 Jul 2023	FMF-4454	Restu Fauzia, tambah hitung waiveamount agar handle kontrak lunas dan diwaive
*/
ALTER      Function [dbo].[FnCalcReportLCDaysEXP]
	(@BranchID varchar(3),
	 @ApplicationID varchar(20),
	 @InsSeqNo Integer,
	 @ValueDate datetime) Returns Int
as
Begin
Declare @LCDays as Int
	Set @LCDays = 0 
	declare @DueDate datetime, @GracePeriod smallint, @HolidayRange int, @dateRange int,
		@LCCalcMethod varchar(2), @StartDate datetime, @PaidDate datetime, 
		-- Irfan 23/01/2007 --
		@PaidAmount as Amount, @InstallmentAmount as Amount 
		, @WaivedAmount NUMERIC(17,2) --Restu FMF-4454

	select 	@PaidDate = dbo.InstallmentScheduleEXP.PaidDate, 
		@GracePeriod= dbo.agreement.GracePeriodLateCharges,
		@LCCalcMethod = dbo.agreement.lccalcmethod,
		@DueDate = dbo.InstallmentScheduleEXP.DueDate,
		-- Irfan 23/01/2007 --
		@InstallmentAmount = dbo.InstallmentScheduleEXP.InstallmentAmount,
		@PaidAmount= dbo.InstallmentScheduleEXP.PaidAmount
		, @WaivedAmount = InstallmentScheduleEXP.WaivedAmount  --Restu FMF-4454
	from 	dbo.agreement with (nolock) inner join 
		dbo.InstallmentScheduleEXP with (nolock) 
		on 	dbo.agreement.applicationid = dbo.InstallmentScheduleEXP.applicationid and
			dbo.agreement.branchid = dbo.InstallmentScheduleEXP.branchid

	where 	dbo.InstallmentScheduleEXP.branchid = @branchid and dbo.InstallmentScheduleEXP.applicationid = @applicationid and 
		dbo.InstallmentScheduleEXP.insseqno = @insseqno 

	If @PaidDate Is Null
	Begin
		set @dateRange = datediff(day,@duedate,@ValueDate)
		Set @StartDate = @DueDate
	End
	else if @PaidDate > @duedate
	Begin
		-- Irfan 24/01/2007 : Tambah pengecekan apakah sebelumnya sudah bayar parsial atau tidak
		--if @PaidAmount < @InstallmentAmount --Restu FMF-4454 (remark)
		IF (@PaidAmount + @WaivedAmount) < @InstallmentAmount --Restu FMF-4454 (add)
		begin
			set @dateRange = datediff(day,@PaidDate, @ValueDate)
			Set @StartDate = @PaidDate
		End
		Else
		Begin
			set @dateRange = datediff(day,@DueDate, @PaidDate)
			-- Lisa 20090825 : Tambah utk jika sudah lunas perhitungan holiday nya hanya antara duedate dan paiddate
			--Set @StartDate = @PaidDate
			SET @StartDate = @DueDate
			SET @ValueDate = @PaidDate
			-- End Lisa 20090825
		End 
	End
	else 
	Begin
-- 		set @dateRange = datediff(day,@duedate,@ValueDate)
		-- Irfan 24/01/2007 : Tambah pengecekan apakah sebelumnya sudah bayar parsial atau tidak
		--if @PaidAmount < @InstallmentAmount --Restu FMF-4454 (remark)
		IF (@PaidAmount + @WaivedAmount) < @InstallmentAmount --Restu FMF-4454 (add)
		begin
			set @dateRange = datediff(day,@duedate,@ValueDate)
			Set @StartDate = @DueDate
		End 
		Else
		Begin
			set @dateRange = datediff(day,@duedate,@PaidDate)
			Set @StartDate = @DueDate
		End	
	End 


-- 	set @dateRange = datediff(day,@DueDate,@PaidDate)

	if @lccalcmethod = 'CD'
	begin
		set @HolidayRange = 0

	end
	else if @lccalcmethod = 'WD'
	begin
		set @HolidayRange = dbo.fnHolidayRange(@StartDate,@valuedate)
	end

	If @dateRange > @GracePeriod + @HolidayRange
	Begin
		Set @LCDays = @dateRange
	End
	Else
	Begin	
		Set @LCDays = 0
	End

	If @LCDays < 0
	Begin
		Set @LCDays = 0 
	End 

return @LCDays
End
-- print dbo.FnCalcReportLCDays('800','800A200411000072', '16', '2006-03-13')









GO