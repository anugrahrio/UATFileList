USE [FMFDB]
GO
/****** Object:  StoredProcedure [dbo].[spApplicationSaveAdd]    Script Date: 06/12/2024 10:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








/*      
Parameter input   : @BranchID, @ApplicationID, @CustomerID, @ProductID, @ProductOfferingID, @FinanceType,       
  @DefaultStatus, @ApplicationStep, @NumOfAssetUnit, @InterestType, @InstallmentScheme, @GuarantorID,       
  @SpouseID, @WayOfPayment, @AgreementDate, @SurveyDate, @ApplicationSource, @PercentagePenalty,       
         @AdminFee, @FiduciaFee, @ProvisionFee, @NotaryFee, @SurveyFee, @BBNFee, @OtherFee,       
  @CrossDefaultApplicationId, @Notes, @ReferenceName, @ReferenceJobTitle, @ReferenceAddress,       
  @ReferenceRT, @ReferenceRW, R@eferenceKelurahan, @ReferenceKecamatan, @ReferenceCity, @ReferenceZipCode,       
         @ReferenceAreaPhone1, @ReferencePhone1, @ReferenceAreaPhone2, @ReferencePhone2, @ReferenceAreaFax,       
  @ReferenceFax, @ReferenceMobilePhone, @ReferenceEmail, @ReferenceNotes, @MailingAddress,       
  @MailingRT, @MailingRW, @MailingKelurahan, @MailingKecamatan, @MailingCity, @MailingZipCode,       
         @MailingAreaPhone1, @MailingPhone1, @MailingAreaPhone2, @MailingPhone2, @MailingAreaFax, @MailingFax,       
  @IsNST      
Parameter output : @Err, @ApplicationID      
Created by       : Vera, July 25, 2003      
Modification     :       
- ratna 06/09 : Tambahkan BeginTransaction      
  Insert ke tbl ActivityLog      
    
Modification     :       
- widi 14/06 : Update tabel prospect    
    
--Modified  by arinta 7 oct 2014 - menambahkan kriteria insert @VoucherExpense     
    
      
1. Jumat 21 Nov 2003 Jam 13:11 Additional AdminFee      
2. Jumat 04 June 2004 Jam 09:45 Tambahkan Pilihan Mandatory/Optional untuk fiducia Fee    
tambahan @StatusFiducia   - Kukuh TW    
    
Jumat 9 July 2004 Tambahan ---Widi    
    
10 dec 2004 -- tambahan Kesimpulan, Rony    
    
Select rEFERENCEKELURAHAN,MAILINGKELURAHAN FROM AGREEMENT    
    
declare @P1 varchar(100)    
set @P1=''    
declare @P2 char(20)    
set @P2='900A200308000225    '    
exec spApplicationSaveAdd @BranchID = '900', @CustomerID = '0102609             ', @ProductID = 'ELECTRONIC', @ProductOfferingID = 'NONPAKET  ', @IsNST = '0', @ContractStatus = 'PRP', @DefaultStatus = 'NM ', @ApplicationStep = 'NAP', @NumOfAssetUnit = 1, 
  
@InterestType = 'FX', @InstallmentScheme = 'RF', @GuarantorID = '          ', @SpouseID = '          ', @WayOfPayment = 'BT', @AgreementDate = '', @SurveyDate = '20030801', @ApplicationSource = 'I', @PercentagePenalty = 0, @AdminFee = 0, @FiduciaFee = 0, 
  
@ProvisionFee = 0, @NotaryFee = 0, @SurveyFee = 0, @BBNFee = 0, @OtherFee = 0, @MailingFax = '          ', @Notes = '', @ReferenceName = '', @ReferenceJobTitle = '', @ReferenceAddress = '', @ReferenceRT = '   ', @ReferenceRW = '   ', @ReferenceKelurahan =
  
 '-', @ReferenceKecamatan = '', @ReferenceCity = '', @ReferenceZipCode = '     ', @ReferenceAreaPhone1 = '    ', @ReferencePhone1 = '          ', @ReferenceAreaPhone2 = '    ', @ReferencePhone2 = '          ', @ReferenceAreaFax = '    ', @ReferenceFax = '
  
          ', @ReferenceMobilePhone = '', @ReferenceEmail = '', @ReferenceNotes = '', @MailingAddress = 'KP.ASEMUDA RT.14/05 PATRASANA  KRESEK TANGGERANG  15620', @MailingRT = '   ', @MailingRW = '   ', @MailingKelurahan = '', @MailingKecamatan = 'KRESEK',
  
 @MailingCity = '-', @MailingZipCode = '15620', @MailingAreaPhone1 = '11  ', @MailingPhone1 = '0818694907', @MailingAreaPhone2 = '11  ', @MailingPhone2 = '0818694907', @MailingAreaFax = '    ', @Err = @P1 output, @ApplicationID = @P2 output, @businessdate
  
 = 'Aug  4 2003 12:00:00:000AM', @AdditionalAdminFee = 0, @StepUpStepDownType = NULL, @StatusFiducia = '0 ', @ProspectAppID = '-                   ', @CurrencyID = 'IDR', @Tenor = 23, @InsInsuredBy = 'CO', @InsPaidBy = 'AC', @Period = 'FT', @GuarantorRela
  
tionShip = 'Select One', @AOID = 'AAG       ', @CAID = '1103      ', @SurveyorID = 'ACH       ', @BankID = '0    ', @BankBranch = '', @AccountNo = '                    ', @AccountName = N''    
select @P1, @P2    
    
    
3. Johnson 31 Mar 2005 Ubah @GuarantorID dan @SpouseID jadi Char(20)    
4. Teddy, 18 April 2005 : Add Parameter @ReferenceType     
5. Johnson, 28 April 2005 : Tambah Param @IsSurveyResidenceAddress    
6. Johnson, 4 April 2005 : Tambah Proses insert ke SMSMessageOut    
7. Teddy, 23 June 2005 : add Insert Into Agreement.graceperiodlatecharges     
8. Teddy, June 3rd, 2005 : add Process Update Agreement.StandardRate = ProductOffering.EffectiveRate    
     add Process Update Agreement.GrossYieldStandard = ProductOffering.GrossYield    
9. Teddy, July 5th, 2005 : add Process Update Agreement.ProductType = ProductOffering.ProductType    
10. Yovita 21 Dec 2005 : Tambah Jam pada @DateEntryAssetData, @BusinessDate, @AgreementDate, @SurveyDate    
11. Emilia, 30 Jan 2006 : tambah @isLifeInsurance    
12. Emilia 22/2/2006 : add effectiveratetype    
13. Dwiajeng 20/4/2006 : Nambahin Deposito    
14. Yovita June 07 2006 : Select Standard Rate From ProductOfferingPErTenor jika CSValue = 1    
15. Yovita Juli 11 2006 : hapus params @Deposito    
16. Anton Juli 21 2006 : add @LoginId char(10)    
17. Yovita 25 Juli 2006 : Set Portion jadi 0 saja, bukan NULL    
18. Irfan 11/8/2006 : Update LCCalcMethod dari Product    
19. Anton Agustus 29 2006 : Menghapus @LoginId char(10)    
20. Yovita 11 Oct 2006 : Add params to insert @StandardRate, @GrossYieldRate if effectiveratetype = 'B'    
21. Yovita Nov 15 2006 : set LCCalcMethod ambil dari Product    
22. Kristina Feb 7 2007 : ambil approvalschemeid untuk insert ke agreement    
    
--    
22. Anton 26 July 2007: Tambahkan parameter @ActivityStartDate varchar(20) dan menhilangkan param fee    
23. Anton 26 July 2007: Menhilangkan param @IsSurveyResidenceAddress    
24. Yovita Sept 05 2007: Tambah Insert NewApplicationdate    
25. Yovita Nov 22 2007: tambah param @cBusinessDate1 untuk insert newapplicationdate (tidak pake jam)    
26. MUL 03042008 : table agreement.mailingzipcode not allow null sehingga tidak boleh di set null    
27. Andy 11042008 : bikin validasi spy yang sudah menikah harus punya spouse    
28.Amelya 17062008: tambah param @ApplicationPriority    
29.Puma 30 Mar 2010: tambah BranchIDColl     
30.Puma 2 Mei 2010 : ganti branchIDColl -> POSID    
31.David 19apr2011 : tambah INSERT ProgramID ke agreement    
32. Dessy, 31 Agustus 2012 : FMF-1141 tambah insert VoucherExpense yang diambil dari ProductOffering jika Program Marketingnya=KMBMGM dan VoucherType=Voucher Potong Angsuran    
33. Arinta, 8 Oct 2014 : menambahkan kriteria insert VoucherExpense     
34. inggrid 16 juni 2015 : menambahkan parameter @islifeinsuranceNew --@PaymentTo    
35. Albert 6 Juli 2015 : menambahkan field TransferApDisb    
36. rahmat, 16 Nov 2015 : FMF-1454 tambah purposeoffinancingid dan wayoffinancingid    
37. Albert 4 April 2016 : Unremarked POF dan WOF Parameter for POJK (FMF-1454)    
38. azka, 23/3/2017 : Add SLIKOrentationID (CR SLIK)    
39. Aditia 27/10/2017: ADD SLIKSifatKredit (CR SLIK)    
40. Adi Z, 19/11/2018: FMF-1727    
41. Felix Yustian 12/8/2020 mengubah email menjadi varchar 100  
42. Vincenza FMF-2737 27042022 : Add AgrAlloc
43. Reyvano FMF-5185 17/10/2024 : tambah insert IsIntervalLCScheme ke table Agreement berdasarkan IsIntervalLCScheme Product-nya
44. Aurellie, 4 Desember 2024 FMF-5280 CLONE - [Pertanyaan] Mappingan ApplicationSource pada table agreement serta pengecekan applicationID : validator ketika get data dilakukan bersamaan dalam 1 waktu
45. Aurellie, 6 Desember 2024 FMF-5280 CLONE - [Pertanyaan] Mappingan ApplicationSource pada table agreement serta pengecekan applicationID : tambahan validator untuk pengecekan pada hari yang sama dengan rentang 1 menit
46. Aurellie, 13 Januari 2025 FMF-5280 : Penyesuaian businessdate
*/




ALTER PROCEDURE [dbo].[spApplicationSaveAdd]
    @BranchID CHAR(3),                   --0    
    @CustomerID CHAR(20),                --1    
    @ProductID CHAR(10),                 --2    
    @ProductOfferingID CHAR(10),         --3    
    @IsNST CHAR(1),                      --4    
    @ContractStatus CHAR(3),             --5    
    @DefaultStatus CHAR(3),              --6    
    @ApplicationStep CHAR(3),
    @NumOfAssetUnit TINYINT,
    @InterestType CHAR(2),
    @InstallmentScheme CHAR(2),
    @GuarantorID CHAR(20),
    @SpouseID CHAR(20),
    @WayOfPayment CHAR(2),
    @AgreementDate DATETIME,
                                         --@SurveyDate varchar(8),       
    @ApplicationSource CHAR(1),
                                         --@PercentagePenalty numeric(9,6),       
                                         --@AdminFee fee,       
                                         --    
                                         --@FiduciaFee numeric(12,2),   --19    
                                         --@ProvisionFee numeric(12,2),       
                                         --@NotaryFee numeric(12,2),       
    @IsLifeInsurance BIT,
                                         --@SurveyFee numeric(12,2),       
                                         --@BBNFee numeric(12,2),       
                                         --@OtherFee numeric(12,2),       
    @MailingFax Phone,
    @Notes Notes,
    @ReferenceName Name,
    @ReferenceJobTitle Name,
    @ReferenceAddress Address,
    @ReferenceRT RT,
    @ReferenceRW RW,
    @ReferenceKelurahan Kelurahan,
    @ReferenceKecamatan Kecamatan,
    @ReferenceCity City,
    @ReferenceZipCode ZipCode,
    @ReferenceAreaPhone1 AreaPhone,
    @ReferencePhone1 Phone,
    @ReferenceAreaPhone2 AreaPhone,
    @ReferencePhone2 Phone,
    @ReferenceAreaFax AreaPhone,
    @ReferenceFax Phone,
    @ReferenceMobilePhone MobilePhone,
    @ReferenceEmail VARCHAR(100),
    @ReferenceNotes Notes,
    @MailingAddress Address,
    @MailingRT RT,
    @MailingRW RW,
    @MailingKelurahan Kelurahan,
    @MailingKecamatan Kecamatan,
    @MailingCity City,
    @MailingZipCode ZipCode,
    @MailingAreaPhone1 AreaPhone,
    @MailingPhone1 Phone,
    @MailingAreaPhone2 AreaPhone,        --54    
    @MailingPhone2 Phone,                --55    
    @MailingAreaFax AreaPhone,           --56    
    @Err VARCHAR(100) OUTPUT,            --57    
    @ApplicationID CHAR(20) OUTPUT,      --58    
    @businessdate DATETIME,              --59    
                                         --@AdditionalAdminFee fee , --60    
    @StepUpStepDownType CHAR(2),         --61    
                                         --@StatusFiducia char(2), --62    
    @ProspectAppID CHAR(20),
    @CurrencyID CHAR(3),
                                         ---Tambahan Ajeng-----    
                                         --@Deposito amount,    
                                         --@Deposito numeric(12,2),    
                                         -----tambahan widi---------------    
    @Tenor SMALLINT,
    @InsInsuredBy VARCHAR(10),
    @InsPaidBy VARCHAR(10),
    @Period CHAR(2),
    @GuarantorRelationShip VARCHAR(10),
    @AOID VARCHAR(10),
                                         --@CAID char(10),    
                                         --@SurveyorID char(10),    
    @BankID CHAR(5),
    @BankBranch VARCHAR(50),
    @AccountNo CHAR(20),
    @AccountName NVARCHAR(100),
    @CatatanPembayaran CHAR(1),          --10 Dec 2004 Tambah 10 param    
    @Karakter VARCHAR(100),
    @Resiko VARCHAR(100),
    @Kesanggupan VARCHAR(100),
    @Jaminan VARCHAR(100),
    @JaminanTambahan CHAR(2),
    @HargaPasar CHAR(1),
    @Dokumen CHAR(1),
    @Lainlain VARCHAR(100),
    @Rekomendasi VARCHAR(16),
    @ReferenceType CHAR(1),
    @ActivityStartDate VARCHAR(50),
                                         --, @IsSurveyResidenceAddress bit    

                                         --,@LoginId char(10) -- 21-07-2006 Anton    
    @ApplicationPriority VARCHAR(20),
                                         --Puma 3Mei2010    
    @POSID CHAR(3),
                                         --Puma END    
    @ProgramID VARCHAR(10),              --David 19Apr2011    
                                         --add inggrid 16 juni 2015    
    @islifeinsuranceNew BIT,
                                         --, @PaymentTo varchar(2)    
    @TransferApDisb CHAR(1) = NULL,      --Albert Ricia 2Jul2015    
                                         --Unremarked by Albert Ricia on 4 April 2016 (FMF-1454)    
                                         --rahmat, 16 Nov 2015 : FMF-1454    
    @PurposeofFinancingID VARCHAR(10),
    @WayofFinancingID VARCHAR(10),
                                         --end rahmat    
                                         --end Albert    
    @SLIKEconomySector VARCHAR(10) = '', --azka, 23/3/2017 (CR SLIK)    
    @SLIKSifatKredit VARCHAR(1) = '9',   --ADITIA, 27/10/2017 CR SLIK    
    @FinancingObject VARCHAR(10),        -- ADI Z,19/11/2018 FMF-1727    
    @FinancingObjectOther VARCHAR(10),   -- ADI Z,19/11/2018 FMF-1727   
                                         --Vincenza FMF-2737 27042022
    @IsAgrAlloc BIT = 0,
    @AgrAllocType VARCHAR(2) = NULL,
    @AgrAllocNo VARCHAR(20) = NULL
--end Vincenza

AS
SET NOCOUNT ON;
BEGIN TRANSACTION ApplicationSaveAdd;

DECLARE @error INT,
        @FinanceType CHAR(2),
        @IsRecourse CHAR(1),
        @SeqNo VARCHAR(7),
        @IsYear CHAR(1),
        @graceperiodlatecharges SMALLINT,
        @StandardRate NUMERIC(9, 6),
        @GrossYieldRate NUMERIC(9, 6),
        @ProductType CHAR(2),
        @ApprovalSchemeID CHAR(10),
        @VoucherExpense NUMERIC(17, 2), --Dessy Add 31082012    
        @CustStat VARCHAR(20);          -- arinta 8 Oct 2014    

SET @Err = '';
SET @ApplicationID = '';
SET @BranchID = REPLACE(@BranchID, '''', '');

--arinta 8 Oct 2014    
IF EXISTS
(
    SELECT ''
    FROM Agreement
    WHERE CustomerID = @GuarantorID
          AND ContractStatus IN ( 'LIV', 'ICP' )
    HAVING SUM(OutstandingPrincipal + OutstandingInterest) > 0
)
BEGIN
    SET @CustStat = 'Active';
END;
ELSE
BEGIN
    SET @CustStat = 'NonActive';
END;

-- Andy 11 April 2008 : bikin validasi spy yang sudah menikah harus punya spouse    
IF
(
    SELECT ISNULL(MaritalStatus, '')
    FROM PersonalCustomer
    WHERE CustomerID = @CustomerID
) = 'M'
BEGIN
    IF
    (
        SELECT ISNULL(fam.Name, '')
        FROM PersonalCustomer percust
            LEFT JOIN Family fam
                ON percust.CustomerID = fam.CustomerID
                   AND FamilyRelation = 'SP'
        WHERE percust.CustomerID = @CustomerID
    ) = ''
    BEGIN
        RAISERROR(
                     'Marital Status of this customer is married. Please fill this customer''s spouse to continue this process-',
                     16,
                     10
                 );
        GOTO exitSP;
        RETURN;
    END;
END;

-- End Andy 11 April 2008    

-- Kristina 7 Feb 2007 : ambil approvalschemeid untuk insert ke agreement    
SELECT @ApprovalSchemeID = ApprovalSchemeId
FROM ProductApprovalScheme WITH (NOLOCK)
WHERE ProductId = @ProductID
      AND ApprovalTypeId = 'RCA_';

EXEC @error = spGetNoTransaction @BranchID,
                                 @businessdate,
                                 'APPLNO',
                                 @ApplicationID OUTPUT;
IF @error <> 0
    GOTO exitSP;

SELECT @FinanceType = FinanceType,
       @graceperiodlatecharges = GracePeriodLateCharges,
       -- @StandardRate = ProductOffering.EffectiveRate,    
       -- @GrossYieldRate = ProductOffering.GrossYieldRate,    
       @ProductType = ProductType,
       --Dessy Add 31082012    
       @VoucherExpense = (CASE
                              WHEN RTRIM(ProgramID) = 'KMBMGM'
                                   AND VoucherTypeID = 'VOPA' THEN
                                  --arinta 7 oct 2014    
                                  CASE @CustStat
                                      WHEN 'Active' THEN
                                          TotalVoucherAmount
                                      WHEN 'NonActive' THEN
                                          TotVoucherAmtCustNonActive
                                      ELSE
                                          '0'
                                  --ELSE ''    
                                  END

                              --end arinta    
                              --then TotalVoucherAmount    
                              ELSE
                                  0
                          END
                         )
--End Dessy    
FROM ProductOffering WITH (NOLOCK)
WHERE BranchID = @BranchID
      AND ProductID = @ProductID
      AND ProductOfferingID = @ProductOfferingID;


SELECT @CustStat AS CustStat;
------- 21-07-2006 Anton Untuk MO yang EFL ----------------------------------------------------------------    

DECLARE @IsEFL CHAR(1),
        @IsCustomerEFL CHAR(1),
        @PortionForSales NUMERIC(9, 6),
        @PortionForIncome NUMERIC(9, 6),
        @PortionForLoss NUMERIC(9, 6);

--sp_datadictionary2 EFLPortion    



--untuk check apakah EFL    
SELECT @IsEFL = ISNULL(IsEFL, '0')
FROM Product WITH (NOLOCK)
WHERE ProductID = @ProductID;


--  --untuk check apakah user tsb MO EFL    
--  select  @IsMOEFL = isnull(IsEFL,'0')    
--  from  BranchEmployee with (nolock)    
--  where  EmployeeID = @LoginId    

IF @IsEFL = '1'
BEGIN

    SELECT @IsCustomerEFL = ISNULL(IsEFL, '0')
    FROM Customer WITH (NOLOCK)
    WHERE CustomerID = @CustomerID;

    IF @IsCustomerEFL = '0'
    BEGIN
        IF EXISTS
        (
            SELECT ''
            FROM EFLPortion WITH (NOLOCK)
            WHERE CustomerTypeEFL = 'E'
        )
        BEGIN
            --CustomerTypeEFL PortionForSales PortionForIncome PortionForLoss    
            SELECT @PortionForSales = PortionForSales,
                   @PortionForIncome = PortionForIncome,
                   @PortionForLoss = PortionForLoss
            FROM EFLPortion WITH (NOLOCK)
            WHERE CustomerTypeEFL = 'E';
        END;
    END;
    ELSE IF @IsCustomerEFL = '1'
    BEGIN
        IF EXISTS
        (
            SELECT ''
            FROM EFLPortion WITH (NOLOCK)
            WHERE CustomerTypeEFL = 'N'
        )
        BEGIN
            SELECT @PortionForSales = PortionForSales,
                   @PortionForIncome = PortionForIncome,
                   @PortionForLoss = PortionForLoss
            FROM EFLPortion WITH (NOLOCK)
            WHERE CustomerTypeEFL = 'N';
        END;
    END;

END;
ELSE IF @IsEFL = '0'
BEGIN
    -- Yovita 25 Juli 2006 : Set jadi 0 saja, bukan NULL --    
    SET @PortionForSales = 0;
    SET @PortionForIncome = 0;
    SET @PortionForLoss = 0;

END;

--------------------------------------------------------------------------------------------------------    



-- Yovita June 07 2006 : Select Standard Rate From ProductOfferingPErTenor jika CSValue = 1    
DECLARE @CSValue AS INTEGER;
IF EXISTS (SELECT '' FROM ChangeSetting WHERE CSId = 'ProductPerTenor')
BEGIN
    SELECT @CSValue = CSValue
    FROM ChangeSetting
    WHERE CSId = 'ProductPerTenor';
END;


-- emilia 22/2/2006 : --------------------------------------------------------------------------------    
DECLARE @effectiveratetype CHAR(1);
SELECT @effectiveratetype = ISNULL(EffectiveRateType, 'S')
FROM ProductOffering
WHERE BranchID = @BranchID
      AND ProductID = @ProductID
      AND ProductOfferingID = @ProductOfferingID;

-- Yovita 11 Oct 2006 : Add params to insert @StandardRate, @GrossYieldRate if effectiveratetype = 'B'    

DECLARE @CostOfFund NUMERIC(9, 6);


SELECT @CostOfFund = CostOfFund
FROM Currency
WHERE CurrencyID = @CurrencyID;
-------------------------------------------------------------------------------------    

IF @CSValue = 1
BEGIN
    IF @effectiveratetype = 'S'
    BEGIN
        SELECT @StandardRate = ProductOfferingPerTenor.EffectiveRate,
               @GrossYieldRate = ProductOfferingPerTenor.GrossYieldRate
        FROM ProductOfferingPerTenor WITH (NOLOCK)
        WHERE BranchId = @BranchID
              AND ProductId = @ProductID
              AND ProductOfferingId = @ProductOfferingID
              AND Tenor = @Tenor;
    END;
    ELSE
    BEGIN
        SELECT @StandardRate = ProductOfferingPerTenor.EffectiveRate + @CostOfFund,
               @GrossYieldRate = ProductOfferingPerTenor.GrossYieldRate + @CostOfFund
        FROM ProductOfferingPerTenor WITH (NOLOCK)
        WHERE BranchId = @BranchID
              AND ProductId = @ProductID
              AND ProductOfferingId = @ProductOfferingID
              AND Tenor = @Tenor;
    END;

END;
ELSE
BEGIN
    IF @effectiveratetype = 'S'
    BEGIN
        SELECT @StandardRate = ProductOffering.EffectiveRate,
               @GrossYieldRate = ProductOffering.GrossYieldRate
        FROM ProductOffering WITH (NOLOCK)
        WHERE BranchID = @BranchID
              AND ProductID = @ProductID
              AND ProductOfferingID = @ProductOfferingID;
    END;
    ELSE
    BEGIN
        SELECT @StandardRate = ProductOffering.EffectiveRate + @CostOfFund,
               @GrossYieldRate = ProductOffering.GrossYieldRate + @CostOfFund
        FROM ProductOffering WITH (NOLOCK)
        WHERE BranchID = @BranchID
              AND ProductID = @ProductID
              AND ProductOfferingID = @ProductOfferingID;
    END;
END;
--==================================================================================================================    

DECLARE @cDateEntryAssetData AS VARCHAR(50);
DECLARE @cBusinessDate AS VARCHAR(50);
DECLARE @cAgreementDate AS VARCHAR(50);
DECLARE @cSurveyDate AS VARCHAR(50);
DECLARE @SurveyDate1 AS VARCHAR(50);

-- Irfan 11/8/2006 --    
DECLARE @LCCalcMethod AS CHAR(2);
DECLARE @IsIntervalLCScheme AS BIT; --Add by Reyvano FMF-5185
--------------------------------------------------------    
-- Yovita Nov 15 2006 : set LCCalcMethod ambil dari ProductOffering    
--------------------------------------------------------    
SELECT @LCCalcMethod = LCCalcMethod,
       @IsIntervalLCScheme = IsIntervalLCScheme --Add by Reyvano FMF-5185
FROM Product WITH (NOLOCK)
WHERE ProductID = @ProductID;
--------------------------------------------------------    


SET @cBusinessDate = CONVERT(VARCHAR(10), @businessdate, 101);

DECLARE @cBusinessDate1 AS DATETIME;
SET @cBusinessDate1 = @cBusinessDate;

	--Add : Aurellie, 13 Januari 2025 FMF-5280 
--SET @cBusinessDate
--     LEFT(@cBusinessDate, 10) + ' ' + LTRIM(STR(DATEPART(hh, GETDATE()))) + ':' + LTRIM(STR(DATEPART(n, GETDATE())))
--      + ':' + LTRIM(STR(DATEPART(ss, GETDATE())));
SET @cBusinessDate =
    CONVERT(NVARCHAR(10), GETDATE(), 120) + ' ' 
    + RIGHT('0' + CAST(DATEPART(HOUR, GETDATE()) AS NVARCHAR), 2) + ':' 
    + RIGHT('0' + CAST(DATEPART(MINUTE, GETDATE()) AS NVARCHAR), 2) + ':' 
    + RIGHT('0' + CAST(DATEPART(SECOND, GETDATE()) AS NVARCHAR), 2);
	--End Aurellie

SET @businessdate = CONVERT(DATETIME, @cBusinessDate);

--Add : Aurellie 4 Desember 2024 FMF-5280 CLONE - [Pertanyaan] Mappingan ApplicationSource pada table agreement serta pengecekan applicationID
IF EXISTS (

	SELECT TOP 1
           sm.ApplicationID
    FROM STAGING_TEMP.STAGING.dbo.STG_GEN_APP AS SA WITH (NOLOCK)
	INNER JOIN agreement ON Agreement.CustomerID =@CustomerID
        inner JOIN STAGING_TEMP.STAGING.dbo.STG_MAIN AS SM WITH (NOLOCK)
            ON SA.BranchID = SM.BranchID
               AND SA.ProspectId = SM.ProspectID
    WHERE DataType = 'G'
          AND SM.Status  IN ( 'P' )
          AND SM.CustomerID = @CustomerID
          AND SA.BranchID = @branchid
		  AND DATEPART(MINUTE,DateEntryApplicationData) - DATEPART(MINUTE,@businessdate) BETWEEN 0 AND 1 --Add : Aurellie, 6 Desember 2024 FMF-5280 
		  AND CONVERT(DATE,DateEntryApplicationData) = CONVERT(DATE,@businessdate) --Add : Aurellie, 6 Desember 2024 FMF-5280 

    ORDER BY SM.DtmUpd DESC

    )
	BEGIN 
        RAISERROR ('ProspectID has been processed', 16, 1)
        GOTO ExitSP
	END 
--End Aurellie FMF-5280

IF @GuarantorID = ''
BEGIN
    SET @GuarantorID = NULL;
    SET @GuarantorRelationShip = NULL;
END;
IF @SpouseID = ''
    SET @SpouseID = NULL;

IF @AgreementDate = ''
    SET @AgreementDate = NULL;
ELSE
BEGIN
    SET @cAgreementDate = CONVERT(VARCHAR(10), @AgreementDate, 101);
    SET @cAgreementDate
        = LEFT(@cAgreementDate, 10) + ' ' + LTRIM(STR(DATEPART(hh, GETDATE()))) + ':'
          + LTRIM(STR(DATEPART(n, GETDATE()))) + ':' + LTRIM(STR(DATEPART(ss, GETDATE())));
    SET @AgreementDate = CONVERT(DATETIME, @cAgreementDate);
END;

IF @ReferenceName = ''
    SET @ReferenceName = NULL;
IF @ReferenceJobTitle = ''
    SET @ReferenceJobTitle = NULL;
IF @ReferenceAddress = ''
    SET @ReferenceAddress = NULL;
IF @ReferenceRT = ''
    SET @ReferenceRT = NULL;
IF @ReferenceRW = ''
    SET @ReferenceRW = NULL;
IF @ReferenceKelurahan = ''
    SET @ReferenceKelurahan = NULL;
IF @ReferenceKecamatan = ''
    SET @ReferenceKecamatan = NULL;

IF @ReferenceCity = ''
    SET @ReferenceCity = NULL;
IF @ReferenceZipCode = ''
    SET @ReferenceZipCode = NULL;
IF @ReferenceAreaPhone1 = ''
    SET @ReferenceAreaPhone1 = NULL;
IF @ReferencePhone1 = ''
    SET @ReferencePhone1 = NULL;
IF @ReferenceAreaPhone2 = ''
    SET @ReferenceAreaPhone2 = NULL;
IF @ReferencePhone2 = ''
    SET @ReferencePhone2 = NULL;
IF @ReferenceAreaFax = ''
    SET @ReferenceAreaFax = NULL;
IF @ReferenceFax = ''
    SET @ReferenceFax = NULL;
IF @ReferenceMobilePhone = ''
    SET @ReferenceMobilePhone = NULL;
IF @ReferenceEmail = ''
    SET @ReferenceEmail = NULL;
IF @MailingAddress = ''
    SET @MailingAddress = NULL;
IF @MailingKelurahan = ''
    SET @MailingKelurahan = '-';
IF @MailingKecamatan = ''
    SET @MailingKecamatan = '-';
IF @MailingCity = ''
    SET @MailingCity = '-';
IF @MailingZipCode = ''
    SET @MailingZipCode = ''; --03042008 MUL table not allow null    
IF @MailingRT = ''
    SET @MailingRT = NULL;
IF @MailingRW = ''
    SET @MailingRW = NULL;
IF @MailingAreaPhone1 = ''
    SET @MailingAreaPhone1 = NULL;
IF @MailingPhone1 = ''
    SET @MailingPhone1 = NULL;
IF @MailingAreaPhone2 = ''
    SET @MailingAreaPhone2 = NULL;
IF @MailingPhone2 = ''
    SET @MailingPhone2 = NULL;
IF @MailingAreaFax = ''
    SET @MailingAreaFax = NULL;
IF @MailingFax = ''
    SET @MailingFax = NULL;
IF @IsRecourse = ''
    SET @IsRecourse = NULL;
IF @GuarantorRelationShip = 'Select One'
    SET @GuarantorRelationShip = NULL;
IF @BankID = '0'
    SET @BankID = NULL;
IF @BankID = ''
    SET @BankID = NULL;
IF @BankBranch = ''
    SET @BankBranch = NULL;
IF @AccountNo = ''
    SET @AccountNo = NULL;
IF @AccountName = ''
    SET @AccountName = NULL;


IF @CatatanPembayaran = ''
    SET @CatatanPembayaran = NULL;
IF @Karakter = ''
    SET @Karakter = NULL;
IF @Resiko = ''
    SET @Resiko = NULL;
IF @Kesanggupan = ''
    SET @Kesanggupan = NULL;
IF @Jaminan = ''
    SET @Jaminan = NULL;
IF @JaminanTambahan = ''
    SET @JaminanTambahan = NULL;
IF @HargaPasar = ''
    SET @HargaPasar = NULL;
IF @Dokumen = ''
    SET @Dokumen = NULL;
IF @Lainlain = ''
    SET @Lainlain = NULL;
IF @Rekomendasi = ''
    SET @Rekomendasi = NULL;

--Vincenza FMF-2737 27042022
IF @IsAgrAlloc = 0
BEGIN
    SET @AgrAllocType = NULL;
    SET @AgrAllocNo = NULL;
END;

DECLARE @NumOfAsset SMALLINT,
        @AssetTypeID VARCHAR(10),
        @IsFactoring BIT;

IF @AgrAllocNo IS NOT NULL
BEGIN
    SELECT TOP 1
           @NumOfAsset = agr.NumOfAssetUnit,
           @AssetTypeID = aga.AssetTypeID,
           @IsFactoring = at.isFactoring
    FROM Agreement agr WITH (NOLOCK)
        INNER JOIN AgreementAsset aga WITH (NOLOCK)
            ON agr.BranchID = aga.BranchID
               AND agr.ApplicationID = aga.ApplicationID
        INNER JOIN AssetType at WITH (NOLOCK)
            ON aga.AssetTypeID = at.AssetTypeID
    WHERE agr.AgreementNo = @AgrAllocNo;

    IF @AgrAllocType = 'TP'
    BEGIN
        IF @NumOfAsset > 1
        BEGIN
            RAISERROR('Asset Number for Allocation Must be 1 if the Type is Top Up', 16, 1);
            GOTO exitsp;
        END;
        IF @AssetTypeID IN ( 4, 10 )
        BEGIN
            RAISERROR('Cannot Choose for Electronic or KTA', 16, 1);
            GOTO exitsp;
        END;
        IF @IsFactoring = 1
        BEGIN
            RAISERROR('Cannot Top Up for Factoring', 16, 1);
            GOTO exitsp;
        END;
    END;
END;
--end

-- if @SurveyDate = '' set @SurveyDate = null    
-- else    
-- Begin      
--  set @cSurveyDate = Convert(varchar(10),@SurveyDate,101)    
--  Set @cSurveyDate = left(@cSurveyDate,10) + ' ' +    
--       LTrim(str(Datepart(hh, getdate()))) + ':' +    
--    
--       LTrim(str(Datepart(n, getdate()))) +  ':' +    
--       LTrim(str(Datepart(ss, getdate())))        
--  Set @SurveyDate1 = Convert(dateTime,@cSurveyDate)    
-- end    

--=====================================================================================      

BEGIN

    SELECT @cBusinessDate;
    SELECT @businessdate;

    --- ---------------------------------------------------------------------------------------------------      
    INSERT INTO Agreement
    (
        BranchID,
        ApplicationID,
        CustomerID,
        ProductID,
        ProductOfferingID,
        FinanceType,
        ContractStatus,
        DefaultStatus,
        ApplicationStep,
        NumOfAssetUnit,
        InterestType,
        InstallmentScheme,
        GuarantorID,
        SpouseID,
        WayOfPayment,
        AgreementDate,
                            --SurveyDate,     
        ApplicationSource,
                            --PercentagePenalty,       
                            --AdminFee, FiduciaFee, ProvisionFee, NotaryFee, SurveyFee, OtherFee,       
        Notes,
        ReferenceName,
        ReferenceJobTitle,
        ReferenceAddress,
        ReferenceRT,
        ReferenceRW,
        ReferenceKelurahan,
        ReferenceKecamatan,
        ReferenceCity,
        ReferenceZipCode,
        ReferenceAreaPhone1,
        ReferencePhone1,
        ReferenceAreaPhone2,
        ReferencePhone2,
        ReferenceAreaFax,
        ReferenceFax,
        ReferenceMobilePhone,
        ReferenceEmail,
        ReferenceNotes,
        MailingAddress,
        MailingRT,
        MailingRW,
        MailingKelurahan,
        MailingKecamatan,
        MailingCity,
        MailingZipCode,
        MailingAreaPhone1,
        MailingPhone1,
        MailingAreaPhone2,
        MailingPhone2,
        MailingAreaFax,
        MailingFax,
        IsNST,
        DateEntryApplicationData,
                            --AddAdminFee,    
        StepUpStepDownType,
                            --IsFiduciaCovered,    
        CurrencyID,
        Tenor,
        InsAssetInsuredBy,
        InsAssetPaidBy,
        InsAssetPeriod,
        GuarantorRelationship,
        AOID,
                            --CAID ,SurveyorID ,     
        ReferenceBankID,
        ReferenceBankBranch,
        ReferenceAccountNo,
        ReferenceAccountName,
        CatatanPembayaran,
        Karakter,
        Resiko,
        Kesanggupan,
        Jaminan,
        JaminanTambahan,
        HargaPasar,
        Dokumen,
        LainLain,
        Rekomendasi,
        ReferenceType,
                            --  , IsSurveyResidenceAddress    
        GracePeriodLateCharges,
        StandardRate,
        GrossYieldStandard,
        ProductType,
                            --IsLifeInsurance,    
        EffectiveRateType,
        PortionForSales,
        PortionForIncome,
        PortionForLoss,
                            -- Irfan 11/8/2006    
        LCCalcMethod,
                            -- Kristina 7 feb 2007    
        ApprovalSchemeID,
                            -- Yovita Sept 05 2007: Tambah Insert NewApplicationdate    
        NewApplicationDate,
                            --amelya 17062008     
        ApplicationPriority,
                            --,BranchIDColl--Puma 30 Mar 2010    
        POSID,              --Puma 2 Mei 2010    
        ProgramID,          --David 19Apr2011      
        VoucherExpense,     --Dessy Add 31082012    
        IsLifeInsurance,
                            --,lifeinspaymethod    
        TransferAPDisb,     -- Albert Ricia add 02072015    
                            --Unremarked by Albert Ricia on 4 April 2016 (FMF-1454)    
                            --rahmat, 16 Nov 2015 : FMF-1454    
        PurposeofFinancingID,
        WayofFinancingID,
                            --end rahmat    
                            --end Albert    
        SLIKOrentationCode, --azka, 23/3/2017 (CR SLIK)    
        SLIKSifatKredit,    --Aditia, 27/10/2017 CR SLIK    
                            --,FinancingObjectID --Adi Z 19/11/2018 FMF-1727    
                            --,FinancingObjectOther --Adi Z 19/11/2018 FMF-1727    
                            --Vincenza FMF-2737 27042022
        IsAgreementAllocation,
        AgreementAllocationType,
        AgreementNoAllocation,
                            --end 
        IsIntervalLCScheme  --Add by Reyvano FMF-5185
    )

    --Tambahan AdditionalAdminFEe,StepUpStepDownType      
    VALUES
    (   @BranchID, @ApplicationID, @CustomerID, @ProductID, @ProductOfferingID, @FinanceType, @ContractStatus,
        @DefaultStatus, @ApplicationStep, @NumOfAssetUnit, @InterestType, @InstallmentScheme, @GuarantorID, @SpouseID,
        @WayOfPayment, @AgreementDate,
                                                                                  -- @SurveyDate1,     
        @ApplicationSource,
                                                                                  --@PercentagePenalty,       
                                                                                  --@AdminFee, @FiduciaFee, @ProvisionFee, @NotaryFee, @SurveyFee, @OtherFee,       
        @Notes, @ReferenceName, @ReferenceJobTitle, @ReferenceAddress, @ReferenceRT, @ReferenceRW, @ReferenceKelurahan,
        @ReferenceKecamatan, @ReferenceCity, @ReferenceZipCode, @ReferenceAreaPhone1, @ReferencePhone1,
        @ReferenceAreaPhone2, @ReferencePhone2, @ReferenceAreaFax, @ReferenceFax, @ReferenceMobilePhone,
        @ReferenceEmail, @ReferenceNotes, @MailingAddress, @MailingRT, @MailingRW, @MailingKelurahan,
        @MailingKecamatan, @MailingCity, @MailingZipCode, @MailingAreaPhone1, @MailingPhone1, @MailingAreaPhone2,
        @MailingPhone2, @MailingAreaFax, @MailingFax, @IsNST, @businessdate,
                                                                                  --@AdditionalAdminFee,    
        @StepUpStepDownType,
                                                                                  --@StatusFiducia,    
        @CurrencyID, @Tenor, @InsInsuredBy, @InsPaidBy, @Period, @GuarantorRelationShip, @AOID,
                                                                                  --@CAID ,     
                                                                                  --@SurveyorID ,     
        @BankID, @BankBranch, @AccountNo, @AccountName, @CatatanPembayaran, @Karakter, @Resiko, @Kesanggupan, @Jaminan,
        @JaminanTambahan, @HargaPasar, @Dokumen, @Lainlain, @Rekomendasi, @ReferenceType,
                                                                                  --  , @IsSurveyResidenceAddress    
        @graceperiodlatecharges, @StandardRate, @GrossYieldRate, @ProductType,    --, @IsLifeInsurance    
        @effectiveratetype, @PortionForSales, @PortionForIncome, @PortionForLoss, --Irfan 11/8/2006    
        @LCCalcMethod,
                                                                                  --Kristina 7 feb 2007    
        @ApprovalSchemeID, @cBusinessDate,
                                                                                  --amelya17062008    
        @ApplicationPriority,                                                     --,@BranchID --Puma 30 Mar 2010    
        @POSID,                                                                   --Puma 3Mei2010    
        @ProgramID,                                                               --David 19Apr2011      
        @VoucherExpense,                                                          --Dessy Add 31082012    
                                                                                  -- add inggrid 16 juni 2015    
        @islifeinsuranceNew,                                                      --,@PaymentTo    
        @TransferApDisb,                                                          --Albert Ricia add 02072015    
                                                                                  -- Unremarked by Albert Ricia on 4 April 2016    
                                                                                  --rahmat, 16 Nov 2015 : FMF-1454    
        @PurposeofFinancingID, @WayofFinancingID,                                 --end rahmat    
                                                                                  --end Unremarked    
        @SLIKEconomySector,                                                       --azka, 23/3/2017 (CR SLIK)    
        @SLIKSifatKredit,                                                         --Aditia, 27/10/2017 CR SLIK    
                                                                                  --,@FinancingObject --Adi Z 19/11/2018 FMF-1727    
                                                                                  --,@FinancingObjectOther --Adi Z 19/11/2018 FMF-1727    
                                                                                  --Vincenza FMF-2737 27042022
        @IsAgrAlloc, @AgrAllocType, @AgrAllocNo,
                                                                                  --end 
        @IsIntervalLCScheme                                                       --Add by Reyvano FMF-5185
        );

    IF @@error > 0
    BEGIN
        GOTO exitsp;
    END;



    -------------------------------------------      
    -- Insert ke tbl ActivityLog --      
    -------------------------------------------      
    DECLARE @ActivityDate DATETIME;
    SET @ActivityDate = GETDATE();

    EXEC @error = spActivityLog @BranchID,
                                @ApplicationID,
                                'NAP',
                                @ActivityDate,
                                @ActivityStartDate;
    IF @error > 0
    BEGIN
        GOTO exitsp;
    END;

    --=====================================================================================      

    -------------------------------------------      
    -- Update  ke tbl Prospect --      
    -------------------------------------------      
    IF @ProspectAppID <> '-'
    BEGIN
        UPDATE Prospect
        SET ApplicationID = @ApplicationID
        WHERE BranchID = @BranchID
              AND ProspectAppID = @ProspectAppID;
        IF @@error > 0
        BEGIN
            GOTO exitsp;
        END;
    END;

-- --=====================================================================================      
--    
-- -------------------------------------------      
-- -- Proses Insert Ke  SMSMessageOut --      
-- -------------------------------------------      
--if @IsSurveyResidenceAddress = 0     
--BEGIN    
-- Declare @SurveyorName Varchar(50),    
--  @SurveyorMobilePhone Varchar(20),    
--  @CustomerName varchar(50)    
--      
-- SELECT @SurveyorName = EmployeeName,    
--  @SurveyorMobilePhone = isnull(MobilePhone,'-')    
-- FROM BranchEmployee with (nolock)     
-- WHERE branchID = @BranchID and EmployeeID = @SurveyorID    
--     
-- SELECT @CustomerName = Name    
-- FROM Customer with (nolock)     
-- WHERE CustomerID = @CustomerID    
--     
-- IF @SurveyorMobilePhone =''    
--  BEGIN    
--   SET @SurveyorMobilePhone='-'    
--  END     
--     
-- IF @SurveyorMobilePhone <> '-'     
--  BEGIN    
--   Insert into SMSMessageOut ( MessageCreatedDate,    
--       SMSMessage,    
--       MobilePhoneNumber,    
--       SMSStatus    
-- --       BranchID,    
-- --       ApplicationID,    
-- --       NextInstallmentDueNo,    
-- --       NextInstallmentDueDate,    
-- --       LastPastDueDays    
--      )    
--    values(    
--     @BusinessDate,    
--     convert(varchar(200), @SurveyorName + ', tolong disurvey '+ @CustomerName + ', di alamat ' + @MailingAddress + ' RT/RW ' + @MailingRT + '/' + @MailingRW + ' Kel.' + @MailingKelurahan + ', ' + @MailingCity),    
--     @SurveyorMobilePhone,    
--     'N'    
-- --     @BranchID,    
-- --     @ApplicationID,    
-- --     @NextInstallmentDueNumber,    
-- --     @NextInstallmentDueDate,    
-- --     @LastPastDueDays    
--       )    
--       
--       
--       
--    IF @@error > 0       
--     BEGIN      
--      GOTO exitsp       
--     END      
--  END    
--END         
-- --=====================================================================================      

--Add : Aurellie 4 Desember 2024 FMF-5280 CLONE - [Pertanyaan] Mappingan ApplicationSource pada table agreement serta pengecekan applicationID
IF EXISTS (

	SELECT TOP 1
           sm.ApplicationID
    FROM STAGING_TEMP.STAGING.dbo.STG_GEN_APP AS SA WITH (NOLOCK)
	INNER JOIN agreement ON Agreement.CustomerID =@CustomerID
        inner JOIN STAGING_TEMP.STAGING.dbo.STG_MAIN AS SM WITH (NOLOCK)
            ON SA.BranchID = SM.BranchID
               AND SA.ProspectId = SM.ProspectID
    WHERE DataType = 'G'
          AND SM.Status  IN ( 'P' )
          AND SM.CustomerID = @CustomerID
          AND SA.BranchID = @branchid
		  AND DATEPART(MINUTE,DateEntryApplicationData) - DATEPART(MINUTE,@businessdate) BETWEEN 0 AND 1 --Add : Aurellie, 6 Desember 2024 FMF-5280 
		  AND CONVERT(DATE,DateEntryApplicationData) = CONVERT(DATE,@businessdate) --Add : Aurellie, 6 Desember 2024 FMF-5280 
		  AND Agreement.ApplicationID <> @ApplicationID  

    ORDER BY SM.DtmUpd DESC

    )
	BEGIN 
        RAISERROR ('ProspectID has been processed', 16, 1)
        GOTO ExitSP
	END 
--End Aurellie FMF-5280


END;

COMMIT TRANSACTION ApplicationSaveAdd;
RETURN 1;

SET NOCOUNT OFF;

exitsp:
BEGIN
    ROLLBACK TRANSACTION ApplicationSaveAdd;
    RETURN 0;
END;
/***************************************************************************************************************************/
/****** Object:  StoredProcedure [dbo].[spApplicationSaveAddKTA]    Script Date: 05/03/2010 19:30:59 ******/
SET ANSI_NULLS ON;




