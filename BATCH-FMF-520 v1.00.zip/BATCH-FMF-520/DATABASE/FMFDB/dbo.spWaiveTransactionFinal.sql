SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO

 


-- 14 Feb 2005 Rony
-- Modification : update paymenthistoryheader set isCorrection = 0 where isCorrection = 1 and branchid = @BranchId and applicationid = @ApplicationID
-- Yovita on April 18 2006 : jika ada trans waive, trans sebelumnya tetap bisa di correction (reverse), tidak perlu update iscorrection jadi 0
-- Yovita Jully 06 2006 : ganti cara pengecekan untuk ALTER  jurnal IRW dan spPostingInstallmentCheckContractStatus,
--			  ubah process spCheckContractStatus setelah process spPostingInstallmentCheckContractStatus
-- Yovita Des 05 2006 : Ubah Cara pengecekan untuk create GLJournalH, jika tidak ada tunggakan lagi semua, baru create journal Header
-- 27 Jan 2016 perbaiki untuk pengambilan fundingcoyportion dan pembuatan jurnal IRW 
-- Sugiono, 22 April 2024 FMF-5013 Validasi Backadted Proses Reschedulling dan Waive Transaction : menambahkan penjagaan check Backdate process Login Menu (session tidak jalan)
ALTER       Procedure [dbo].[spWaiveTransactionFinal]
	@ApprovalNo As Varchar(50),
	@ApprovalResult As Varchar(1), 
	@BranchID AS Varchar(3), 
	@Businessdate AS DateTime
As


set Nocount ON

--Begin Transaction WaiveTransaction
Declare @ApplicationID Varchar(20),  @WaiveNo as Varchar(20), 
	@ValueDate as DateTime, @OSLCInstallment as Amount, 
	@OSLCInsurance as Amount , @LCInstallment as Amount, @LCInsurance As Amount, 
	@OSPDCBounceFee As Amount, @LCInstallmentWaived as Amount, 
	@LCInsuranceWaive as Amount, @InstallCollectionFeeWaive As Amount, 
	@PDCBounceFeeWaive as Amount , @Error as Int, @OSRepoFee Amount, @RepoFeeWaive amount,
	@AgreementBranch as Varchar(3), @JournalCode as varchar(20), @VoucherNo as varchar(20), @HistorySequenceNo as Int,
	@TransactionID as varchar(10), @referencedesc varchar(50)
--Status ('R'-Request,'A'-Approve,'P-Paid','C'-Cancel,'X'-Expire,'J'-Reject,'E'-Execute)

Select @AgreementBranch = BranchID, @ApplicationID = Applicationid, @WaiveNo = WaiveNo, 
	@ValueDate=EffectiveDate, 
	@OSLCInstallment = OSLCInstallment, 
	@OSLCInsurance = OSLCInsurance, 
	@LCInstallment = LCInstallment, 
	@LCInsurance = LCInsurance, 
	@OSPDCBounceFee = OSPDCBounceFee, 
	@LCInstallmentWaived = LCInstallmentWaive, 
	@LCInsuranceWaive = LCInsuranceWaive, 
	@PDCBounceFeeWaive = PDCBounceFeeWaive, 
	@OSRepoFee = OSRepoFee, 
	@RepoFeeWaive = RepossessionFeeWaive
from WaivedTransaction Where ApprovalNo = @ApprovalNo 
Declare @AmountJournal Amount
Declare @PostJournal as Char(1)
Declare @PaymentAllocationJournal as Varchar(10)
Declare @WOP as varchar(2)
Declare @ProcessID as Varchar(10)
Declare @RefDesc as varchar(50)
Declare @AgreementNo as Varchar(20)
Declare @LastLCInstallCalcDate as DateTime, 
	@LastLCInsurCalcDate as DateTime
declare @ProductID as ProductID

--Sugiono, 22 April 2024 FMF-5013
IF @Businessdate <> (SELECT BDCurrent FROM dbo.SystemControlCoy WITH (NOLOCK))
BEGIN
    Raiserror('Status Date terminated re-login please', 16,1)
	Set @Error = 1
	If @Error > 0 
		Goto ExitSP
END
--End Sugiono

If exists(Select '' from PDCHeader Where 
		BranchAgreement = @AgreementBranch and ApplicationID = @ApplicationID And 
		PDCStatus='PO' and IsClearReconcile = 0)
Begin
	Raiserror('Please Reconcile Your PDC First', 16,1)
	Set @Error = 1
	If @Error > 0 
		Goto ExitSP
End
Else
Begin
	If @ApprovalResult = 'A'
	Begin
			Set @WOP = 'WA'
			Set @ProcessID = 'WATRS'
			select @AgreementNo = AgreementNo,
				@ProductID = ProductID
				from Agreement Where BranchID = @AgreementBranch and ApplicationID = @ApplicationID 
			Set @RefDesc = Rtrim(Ltrim(@AgreementNo))
			create table #TempTable (
				SeqNo INT IDENTITY PRIMARY KEY, 
				PaymentAllocationID char(20),
				Post Char(1), 
				Amount Numeric(17,2), 
				RefDesc Varchar(50), 
				DepartementID Varchar(3), 
				VoucherDesc Varchar(50)
			)
			Declare	@Counter Int
			
			Set @Counter = 1 
			While @Counter <= 8
			Begin
				If @Counter = 1
				Begin
					If  @LCInstallmentWaived > 0 
					Begin
						Set @AmountJournal = @LCInstallmentWaived
						Set @PostJournal = 'C'
						Set @PaymentAllocationJournal = 'LCINSTALL'
					end
				end 
				Else If @Counter = 2
				Begin
					If @LCInsuranceWaive > 0 
					Begin
						Set @AmountJournal = @LCInsuranceWaive
						Set @PostJournal = 'C'
						Set @PaymentAllocationJournal = 'LCINSUR'
					end
				End
				Else If @Counter = 3
				Begin
					If @PDCBounceFeeWaive > 0
					Begin
						Set @AmountJournal =  @PDCBounceFeeWaive
						Set @PostJournal = 'C'
						Set @PaymentAllocationJournal = 'PDCBNCFEE'
					ENd
				End
				Else If @Counter = 4
				Begin
					If @LCInstallmentWaived > 0
					Begin
						Set @AmountJournal = @LCInstallmentWaived
						Set @PostJournal = 'D'
						Set @PaymentAllocationJournal = 'LCINSTALWO'
					End
				End
				Else If @Counter = 5
				Begin
					If @LCInsuranceWaive > 0
					Begin
						Set @AmountJournal = @LCInsuranceWaive
						Set @PostJournal = 'D'
						Set @PaymentAllocationJournal = 'LCINSURWO'
					End
				End
				Else If @Counter = 6
				Begin
					If @PDCBounceFeeWaive > 0 
					Begin
						Set @AmountJournal = @PDCBounceFeeWaive
						Set @PostJournal = 'D'
						Set @PaymentAllocationJournal = 'PDCBNCFEWO'
					End
				End
				Else If @Counter = 7
				Begin
					If @RepoFeeWaive > 0 
					Begin
						Set @AmountJournal = @RepoFeeWaive
						Set @PostJournal = 'D'
						Set @PaymentAllocationJournal = 'REPOFEEWO'
					End
				End
				Else If @Counter = 8
				Begin
					If @RepoFeeWaive > 0 
					Begin
						Set @AmountJournal = @RepoFeeWaive
						Set @PostJournal = 'C'
						Set @PaymentAllocationJournal = 'REPOFEE'
					End
				End
				If @AmountJournal > 0 
				Begin
					Insert Into #TempTable (PaymentAllocationID, Post, Amount, 
							RefDesc, VoucherDesc)
					Values(@PaymentAllocationJournal, @PostJournal, @AmountJournal, @Refdesc, '')
					If @@error <>  0 
					Begin
						Goto ExitSP
					End	
				end
				Set @AmountJournal = 0
				Set @Counter = @Counter + 1
			End
			Declare @LastHistorySequenceNo as Varchar(20)
			
			-- Remark By Yovita on April 18 2006 : jika ada trans waive, trans sebelumnya tetap bisa di correction (reverse)
-- 			update paymenthistoryheader
-- 			set isCorrection = 0
-- 			where isCorrection = 1
-- 				and branchid = @AgreementBranch and applicationid = @ApplicationID
-- 			If @@Error <>  0 
-- 			Begin
-- 				Goto ExitSP
-- 			End	
			--Select * from #TempTable
			
			Execute @Error = spProcessCreatePaymentHistory
				@AgreementBranch, @ApplicationID, @BusinessDate, @ValueDate, '-', '-', 0, 
				0, @WaiveNo, '-', @WOP, @ProcessID, 0, '-', '-', @LastHistorySequenceNo Output
			If @error <>  0 
			Begin
				Goto ExitSP
			End	
		/*
			declare @holidaydate datetime,@daterange integer, @datetmp datetime,
				@lccalcmethod varchar(2), @graceperiod smallint,@graceperioddate datetime,@percentagepenalty dec(5,3),@lccharge dec(18,2),
				@lblnHitung bit,@isPartialPaid bit,@paiddate datetime, @paidamount dec(18,2),
				@graceperiodtmp integer, @intholiday integer
			Declare @OSInstallment as amount
			select  @graceperiod=graceperiodlatecharges,
				@percentagepenalty=percentagepenalty
				from dbo.agreement where applicationid = @applicationid
		
			Update Agreement Set LCInsurance = LCInsurance + dbo.FnCalculationForLCInsurance(@ApplicationID, @BusinessDate), 
				LastLCInsuranceCalcDate = @BusinessDate
				Where  BranchID = @BranchID And ApplicationID = @ApplicationID
			If @@error > 0 
			Begin
				Goto ExitSp
			End
	
			DECLARE @DateCurrent As datetime
			Declare @InsSeqNo as Int
			Declare @DueDate AS datetime
			Declare @LcAmount Amount
			Declare @LCdays Int
			Set @LCDays  = 0 
			Set @LCAmount = 0 
			Declare curInstallmentSchedule Cursor Local Read_Only Fast_Forward For
				Select InsSeqNo, DueDate, installmentamount-paidamount-waivedamount as OSInstallment
				from InstallmentSchedule
				Where branchId = @branchid and  applicationid = @applicationid and 
					installmentamount-paidamount-waivedamount>0 and DueDate <=  Convert(DateTime,@valuedate,102)
				Order BY InsSeqNo
			Open curInstallmentSchedule
				Fetch Next From curInstallmentSchedule Into
		  		@InsSeqno, @DueDate, @OSInstallment
			WHILE @@Fetch_Status = 0
			BEGIN
			
				If @PaidDate Is Null
					set @dateRange = datediff(day,@duedate,@valuedate)
				else	if @PaidDate > @duedate  
					set @dateRange = datediff(day,@PaidDate, @valuedate)			
				else 
					set @dateRange = datediff(day,@duedate,@valuedate)

				if (@dateRange > @graceperiod)
					Set @LCAmount = (@dateRange * @OSInstallment) * (@percentagepenalty/1000)
				Else
					Set @LCAmount = 0
		
				Set @LCDays = @dateRange 
				Update Agreement Set LCInstallment = LCInstallment + @LCAmount, 		
					LastLCInstallmentCalcDate = @ValueDate
					Where  BranchID = @BranchID And ApplicationID = @ApplicationID
				If @@error > 0 
				Begin
					Goto ExitSp
				End
				Insert Into PaymentHistoryDetail (BranchID, ApplicationID, HistorySequenceNo, PaymentAllocationID, 
					InsSeqNo, Description, DebitAmount, CreditAmount, LCAmount, LCDays) Values
				(@BranchID, @ApplicationID, @LastHistorySequenceNo, 'INSTALLRCV', @InsSeqno, '-', 
				0,0, @LCAmount, @LCDays)
				If @@error > 0 
				Begin
					Goto ExitSp
				End
				Fetch Next From curInstallmentSchedule Into @InsSeqno, @DueDate, @OSInstallment
			End
			close curInstallmentSchedule
			deallocate curInstallmentSchedule
		*/
				
			Update Agreement Set 
				LCInstallmentWaived = LCInstallmentWaived + @LCInstallmentWaived,
				LCInsuranceWaived = LCInsuranceWaived + @LCInsuranceWaive,
				PDCBounceFeeWaived = PDCBounceFeeWaived + @PDCBounceFeeWaive, 
				CollectionExpenseWaived = CollectionExpenseWaived + @RepoFeeWaive
			Where branchId = @AgreementBranch and ApplicationID = @ApplicationID
		
			If @@error > 0 
			Begin
				Goto ExitSp
			End
			
			Declare @totalpdcbouncefee as Amount ,
				@totalcollectionfee as Amount ,
				@lastlcinstallcharge as Amount ,
				@lastlcinscharge as Amount ,
				@totallcinstallment as Amount ,
				@totalLCInsurance as Amount,
				@osinsurance as Amount

			select @totalpdcbouncefee=pdcbouncefee-pdcbouncefeepaid-pdcbouncefeewaived,
				@totalcollectionfee=collectionexpense-collectionexpensepaid-collectionexpensewaived,
				@lastlcinstallcharge =lcinstallment-lcinstallmentpaid-lcinstallmentwaived,
				@lastlcinscharge=lcinsurance-lcinsurancepaid-lcinsurancewaived,
				@osinsurance = insurancedue - insuranceduepaid - insuranceduewaived
			From Agreement
			Where branchId = @AgreementBranch and ApplicationID = @ApplicationID

			set @totallcinstallment = @lastlcinstallcharge + dbo.FnCalculationForLCInstallment(@ApplicationID, @BusinessDate)
			Set @totalLCInsurance = @lastlcinscharge + dbo.FnCalculationForLCInsurance(@ApplicationID, @BusinessDate)
						
			declare @FundingCoyPortion amount,
				@IsBalanceSheet bit, 
				@AmountReceive amount,
				@FundingCoyPortionAmount Amount

 			Declare @ContractStatus varchar(3), @Prefix varchar(3), @BatchID varchar(3)

			--PRINT @osinsurance
			--PRINT @totallcinstallment
			--PRINT @totalLCInsurance
			--PRINT @totalpdcbouncefee
			--PRINT @totalcollectionfee
-- 			Select @ContractStatus = ContractStatus from agreement where branchid = @AgreementBranch and ApplicationID = @ApplicationID
			-- If @ContractStatus = 'RRD'

-- 			If Not Exists(Select '' from Installmentschedule where BranchID = @BranchID and 
-- 					ApplicationID = @ApplicationID and 
-- 					InstallmentAmount - PaidAmount - WaivedAmount > 0
-- 					and @totallcinstallment > 0
-- 					and @totallcinsurance > 0
-- 					and @totalpdcbouncefee > 0
-- 					and @totalcollectionfee > 0)

			-- Yovita Des 05 : Ubah Cara pengecekan untuk create journal Header
			If Not exists(Select '' from Installmentschedule where BranchID = @AgreementBranch and 
				ApplicationID = @ApplicationID and 
				InstallmentAmount - PaidAmount - WaivedAmount > 0)
			Begin
				IF @osinsurance <= 0 and @totallcinstallment <= 0 and @totallcinsurance <= 0 and @totalpdcbouncefee <= 0 and @totalcollectionfee <= 0
				BEGIN
					if exists(Select '' from Agreement 
						Inner Join FundingContract On	
								Agreement.FundingBankID = FundingContract.BankID and 
								Agreement.FundingCoyID = FundingContract.FundingCoyID 
								and Agreement.FundingContractID = FundingContract.FundingContractNo 
						Where BranchID = @AgreementBranch and ApplicationID = @ApplicationID and 
						Agreement.FundingPledgeStatus = 'P' and  
						FundingContract.FacilityKind In ('JFINC', 'CHANN') and 
						FundingContract.BalanceSheetStatus = 'F' and 
						Agreement.DefaultStatus = 'NM')
					Begin
					-- 27 Jan 2016 

						 Select @AmountReceive = Sum((InterestAmount-AmountIncRecognize) * (100 - FundingCoyPortion) / 100)
						 from InstallmentSchedule where BranchID = @AgreementBranch  
						 and ApplicationID = @ApplicationID  
						 Select @FundingCoyPortionAmount = Sum((InterestAmount-AmountIncRecognize) * FundingCoyPortion / 100) from InstallmentSchedule 
						 where BranchID = @AgreementBranch  
						  and ApplicationID = @ApplicationID  
						 Set @IsBalanceSheet = 1  
						
					End
					Else
					BEGIN
						Select @AmountReceive = (Sum(InterestAmount-AmountIncRecognize)) from InstallmentSchedule where BranchID = @AgreementBranch
						and ApplicationID = @ApplicationID
						set @FundingCoyPortionAmount = 0 
						Set @IsBalanceSheet = 0
					End
					
					declare 
					 @amountdiff numeric(17,2)
					,@amountincentive numeric(17,2)
					,@amountprovision numeric(17,2)
					,@amountAdminFee numeric(17,2) 
					,@InsuranceIncomeAmount numeric(17,2) 
					,@DeferredInsurIncAmount numeric(17,2) 
					,@OtherRefundAmount numeric(17,2) 
					,@AdmFeeAmount numeric(17,2) 
					,@ProvisionFeeAmount numeric(17,2) 
					,@OtherFeeAmount numeric(17,2) 
					,@SurveyFeeAmount numeric(17,2) 
					,@CostOfSurveyAmount numeric(17,2)  

					select	@amountdiff = Sum((diffrateamount-diffraterecognize)) ,
						@amountincentive = Sum((Incentive-IncentiveRecognize)) ,
						@amountprovision = Sum((provision-ProvisionRecognize)),
						@amountAdminFee = Sum((AdminFee-AdminFeeRecognize)) 
						
						,@InsuranceIncomeAmount = Sum((InsuranceIncomeAmount-InsuranceIncomeRecognize))
						,@DeferredInsurIncAmount = Sum((DeferredInsurIncAmount-DeferredInsurIncRecognize))
						,@OtherRefundAmount = Sum((OtherRefundAmount-OtherRefundRecognize))
						,@AdmFeeAmount = Sum((AdmFeeAmount-AdmFeeRecognize))
						,@ProvisionFeeAmount = Sum((ProvisionFeeAmount-ProvisionFeeRecognize))
						,@OtherFeeAmount = Sum((OtherFeeAmount-OtherFeeRecognize))
						,@SurveyFeeAmount = Sum((SurveyFeeAmount-SurveyFeeRecognize))
						,@CostOfSurveyAmount = SUM((CostOfSurveyFeeAmount - CostOfSurveyRecognize)) -- arif
						from InstallmentSchedule where BranchID  = @AgreementBranch
						and ApplicationID = @ApplicationID
	
					If ( @AmountReceive >0 or @amountdiff<> 0  or @amountincentive <> 0 or @amountAdminFee <> 0 
					or @InsuranceIncomeAmount <> 0 or @DeferredInsurIncAmount <> 0 or @OtherRefundAmount <> 0 or 
					@AdmFeeAmount <> 0 or @ProvisionFeeAmount <> 0 or @OtherFeeAmount <> 0 or @SurveyFeeAmount <> 0 
					or @CostOfSurveyAmount <> 0 or @amountprovision <> 0)
					-- end 27 Jan 2016
					Begin							
							
							Set @TransactionID = 'IRW'
							Execute  @Error =  spGetJournalNo	@AgreementBranch, @TransactionID, @businessdate, @JournalCode Output, @Prefix Output, @BatchID Output
								If @Error > 0
									Goto exitsp
							
							Insert Into GLJournalH (CompanyID, BranchID, Tr_Nomor, PeriodYear, PeriodMonth, 
										TransactionID, Tr_date, Reff_no, Reff_date, Tr_Desc, JournalAmount, BatchID, SubSystem, 
										Status_Tr, IsActive, Flag)
									Values (dbo.FnGetCompanyName(), @AgreementBranch, @JournalCode, DatePart(Year,@Businessdate), 
										datePart(Month,@businessdate), @Prefix, @BusinessDate, @AgreementNo, @BusinessDate, 
										convert(varchar(100), ltrim(Rtrim(dbo.FnGetDescGLMasterSequence(@AgreementBranch, @TransactionID))) + '' +@AgreementNo), 
										0, @BatchID, 'Eloan','OP', 1, 'O')
							Set @Error = @@Error
							if @Error > 0 
								goto exitsp
							
							execute @Error = spPostingInstallmentCheckContractStatus
								@AgreementBranch, @AgreementBranch, @applicationid, @BusinessDate, @BusinessDate, @productid, @journalcode,
								@voucherno, @LastHistorySequenceNo, @transactionid, @processid, @AgreementNo
							If @Error > 0 
							Begin
									Goto ExitSP
							End	
					End
				End
			End


			execute @Error= spCheckContractStatus @AgreementBranch, @applicationid, @valuedate, @BusinessDate, 
					@productid, NULL, NUll

					If @@error > 0 
					Begin
						Goto ExitSP
					End	
	End
	
	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[#TempTable]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	Drop table #TempTable
		
	Update dbo.WaivedTransaction Set Status = @ApprovalResult, StatusDate = @BusinessDate
				Where  BranchID = @AgreementBranch and ApprovalNo = @ApprovalNo 
	If @@error > 0 
	Begin
		Goto ExitSp
	End
	
	update dbo.Agreement set PrepaidHoldStatus='NM'
		where BranchID = @AgreementBranch and ApplicationId=@ApplicationId
	If @@error > 0 
	Begin
		Goto ExitSp
	End
End
--Commit Transaction WaiveTransaction
return 
ExitSP:
Begin
--	Rollback Transaction WaiveTransaction
	Return 
End


















GO

