SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO

   
   
  
/* 14 Feb 2005 Rony      
Modification : update paymenthistoryheader set isCorrection = 0 where isCorrection = 1 and branchid = @BranchId and applicationid = @ApplicationID      
   Other Income kalau nol jangan dicreate, cek kondisinya dirubah !      
      
Yovita Mar 22 2006 : ALTER  Jurnal Tutup ECIEOM dan Buat Jurnal ECIRSC      
-- Yovita Mar 24 2006 : PaymentAllocationJurnal untuk LCINSTALLWO jangan double L      
-- Yovita June 06 2006 : Jurnal untuk ARGROSS tidak di tambah dengan  @OSInstallmentDue      
-- Yovita June 06 2006 : Add Jurnal untuk INSTALLRCV dengan @OSInstallmentDue      
-- Yovita 10 Jul 06 : Add select @RepoFeeDisc dr table Rsch      
-- emilia 18-07-2006 dari alter menjadi ALTER  temptable       
Yovita Aug 3 2006 : Lakukan validasi agar contract NA tidak bisa rescheduling      
Yovita Aug 23 2006 : Ganti ValueDate pada saat createpaymenthistory dari @BusinessDate jadi @effDate      
Yovita Sept 12 2006 : Add JournalECI when not passed EOM with AccruedAmount (Accrued interest yang di kirim dari program)      
   & Amount UCIRSC only OSInterestNew when not passed EOM      
Yovita Sept 12 2006 : Journal ECI di C jika belom lewat EOM      
Anton 16-10-2006 : Add @ToleranceAmount, @Prepaid      
Yovita Nov 29 2006 : Ubah kondisi untuk ambil @ContractPrepaidAmount terkait dengan ToleranceAmount prepaid       
Anton 17-04-2007 : Menambahkan mengisi parameter @OSRepoFee dengan mengambil OsRepossesFee dari tabel rescheduling      
Teddy 23 may 2007 : ubah perhitungan uci pada jurnal tidak lagi berdasarkan parameter yang dikirim melainkan dihitung ulang dari tabel installment schedule      
     ubah perhitungan jurnal untuk UCIRSC       
     tambahkan parameter @AccruedResch yang akan dikirimkan ke spReschedulingExecutionAccruedProcess      
Arif 11-09-2007 tambah jurnal untuk diffrate, incentive, dan provision  
Yovita 20 Sept 2007: Add Select from Rescheduling  
Yovita 19 Okt 2007: ubah paymentallocationid :  
      RFNDEXP --> RFNDAMZ  
      ECIRFNDAR --> RATERFND  
      ECISSIDYAR --> RATESSIDY  
      ECISSIDY --> SSIDYAMZ  
      untuk samain dengan KITAF  
Leonita 22 Maret 2008 untuk perhitungan uci dilakukan pengecekan kembali   
jika eff date < businessdate dan bulan eff date berbeda dgn bulan businessdate baru dihitung ulang  
jika tidak maka diambil dari cut off eff date   
Gema, 20081024 :Perbaiki ECIRECH + interst due yang blom diaccrued  
Gema, 20081110 :Tambah jurnal untuk AdminFee  
Gema, 20081113 : Add Penjagaan supaya tidak lewat dari Next Installment DueDate  
David 9Feb2010 : Tambah jurnal untuk InsuranceIncomeAmount,DeferredInsurIncAmount,OtherRefundAmount,AdmFeeAmount,ProvisionFeeAmount,OtherFeeAmount, dan SurveyFeeAmount  
arif 15 okt 2010 : tambah costofsurvey  
Lisa 20101210 : Buka remark else utk ECI   
Lisa 20110120 : Remark kembali utk Else ECI  
Susanti, 16 Mei 2011 : tambah isnull untuk pengambilan nilai ECIRSC  
Susanti, 05 Mei 2015, FMF-1419 : ubah pengecekkan pembentukan journal OtherIncome  
Restu PI-189 25 Okt 2017 tambah case when PSAK karena belom tentu setiap rescheduling itu accrued PSAK, bisa jadi kalau backdated ke sebelum EOM malah reverse accrued yang dari eff date s.d EOM  
Budiman 5 November 2018 FMF-1710  - lepas case->when untuk kondisi Effective Date rescheduling = LastDueDate dan businessDate > EOM InsSeqNo berjalan,   
          - ubah kondisi If dari < 0 menjadi <> 0 untuk allocation 'ADMFEEADV', 'CSTSVYEXP',   
          - Ubah allocationJournal sesua dengan parameternya  
          - remark post journal 'ADMFEEADV', seharusnya menggunakan case-when bukan di hardcode  
          - Ubah cara ambil posting untuk komponen Provision  
Adhitya 22/04/2020 FMF-2185 update pada field Is_MonitoringAfterReschdule, ReschedulingMonitoringDate, OverdueDaysBeforRescheduling pada table Agreement khusus reason-nya COVID  
Adhitya 29/06/2020 FMF-2185 Menambahkan penjagaan via general setting  
Adhitya 16/07/2020 FMF-2255 Menambahkan IsFeeBase Charging dan Set 0 Untuk Fee base yang ditangguhkan jika IsFeeBaseCharging = 1  
Dwi 16 Juli 2020 FMF-2262 Penambahan validasi OS AR di Rescheduling dengan OS AR di InstallmentSchedule  
Dwi 21 Juli 2020 FMF-2262 Penambahan field OSInstallmentDue untuk validasi kontrak yang nunggak  
Adhitya 17/08/2020 FMF-2303 Menambahkan LateCharges Pada Angsuran Keberapa Jika IsFeebasePostPoned = 1 dan Update LastLCInstallmentCalcDate  
Mery, 19 Aug 2020 [FMF-2309] tambah penjagaan jika RequestDate dan ReschedulingDate beda bulan maka harus request ulang Rescheduling  
Nadhia, 21/08/2020 (FMF-2297) : Untuk status ICP penjagaan "Penjagaan supaya tidak lewat dari Next Installment DueDate" dilepas  
Candra, 30 Sept 2020 [FMF-2382] : tambah penjagaan agar jika selisih perhitungan tidak lebih dari 1 maka akan lolos  
felix 21/10/2020 tambah length supplier name
Silvia, 20 November 2020 [FMF-2471] : Ubah post journal INSURRCV jadi di Credit
Raug, 19 November 2021 [FMF-3049] : Menggubah kondisi Penjagaan supaya tidak lewat dari Next Installment DueDate 
Niko, 20 Des 2022 [FMF-4076]: Pindahin Update Rescheduling Tr_nomor dari bawah spReschedulingExecutionSaveDataAgreement ke atasnya
Sugiono, 22 April 2024 FMF-5013 Validasi Backadted Proses Reschedulling dan Waive Transaction : menambahkan penjagaan check Backdate process Login Menu (session tidak jalan)
*/      
      
ALTER Procedure  [dbo].[spReschedulingExecution]      
 @BranchID as Varchar(3),        
 @ApplicationID varchar(20),      
 @RequestNo varchar(20),      
 @SeqNo as smallint,       
 @BusinessDate as DateTime,      
 @EffectiveDate as Datetime,      
 @ToleranceAmount AS numeric(17,2)       
as  


Set nocount on      
  
--SELECT * FROM abca  
Declare @Error as Int,      
 @OTR as amount,      
 @DP as amount,      
 @Total as amount,      
 @ContractPrepaidAmount as amount,      
 @sequenceNo as varchar(20),      
 @AgreementNo as char(20),      
 @Name as varchar(50),       
 @Desc as varchar(1000),      
 @SupplierName as varchar(200), --edit felix 21/10/2020     
 @SupplierID as char(10),      
 @Counter as int,      
 @AmountReceive as amount,      
 @AmountJournal As Amount,      
 @RefDesc as Varchar(50),      
 @CompanyID AS Varchar(3),       
 @PostJournal As Varchar(1),      
 @PaymentAllocationJournal As Varchar(20),      
 @TransactionID as Varchar(50),      
 @JournalCode as Varchar(20),      
 @ProcessID as Varchar(20),      
 @WOP as Varchar(2),      
 @No smallint ,  
 @ContractStatus VARCHAR(3) --Nadhia, 21/08/2020 (FMF-2297)  
  
 Declare @branchagreement char(3),      
 @applicationidagreement varchar(20),       
 @InsuranceClaimExpenseWaived amount,      
 @InsuranceWaived amount,      
 @Interest amount,      
 @IncRecognize amount,       
 @TotalECI amount,       
 @OSInstallmentDue amount,       
 @OSInsuranceDue amount,       
 @OSLCInstallment amount,       
 @OSLCInsurance amount,       
 @OSPDCBounceFee amount,       
 @OSRepoFee amount,      
 @RepoFeeDisc amount,      
 @AccruedAmount amount,       
 @LCInstallmentAmountDisc amount,      
 @LCInsuranceAmountDisc amount,      
 @PDCBounceFeeDisc amount,      
 @ECIAmount amount,      
 @OutstandingPrincipalOld  amount,      
 @OutstandingPrincipalNew  amount,      
 @OutstandingInterestNew  amount,      
 @OutstandingInterestOld  amount,      
 @AmountIncRec amount,      
 @InterestAmount amount,      
 @TotalAmountToBePaid amount,      
 @AdministrationFee Amount,      
 @ProductID As ProductID,      
 @TotalAmount amount,      
 @TotalDiscount amount,      
 @OldSeqNo amount,      
 @NewSeq amount,      
 @LastDue datetime,      
 @NextDue datetime,      
 @LastIncRecognize datetime,      
 @StartPeriod datetime,      
 @EndPeriod datetime,      
 @RecognizeDays smallint,      
 @CurrencyID char(3),      
 @CurrencyRate amount,      
 @TotalD amount,      
 @TotalC amount,       
 -- Add By Yovita Mar 22 2006 ======      
 @MaxSeqNo integer,      
 @DueDate Datetime,      
 @AmountIncRecognize Numeric(17,2),      
 @RecognizeAmountADJ Numeric(17,2),      
 @OldAmountIncRecognize Numeric(17,2),      
 @NewInterestAmount Numeric(17,2),      
 @PaymentFrequency int,      
 @OldEffectiveRate rate,      
 @NewEffectiveRate rate,      
 @InsSeqNo Integer,      
 @AccruedResch Numeric(17,2),      
 @AccruedAdj Numeric(17,2),      
 @AccruedEOM Numeric(17,2),      
 @RescExpToleranceDays as Integer,      
 @ReQuestDate as DateTime,      
 @EffDate as DateTime   ,  
 @currencyrounded numeric(17,2),  
--Add by Gema, 20081024  
 @InterestDue numeric(17,2),  
 @IsFeeBasePostPonded bit, --Add Adhitya FMF-2255 16/07/2020  
 --Add By Dwi 7/16/2020  
 @InstallmentAmount  Numeric(17,2),     
 @PaidAmount Numeric(17,2),     
 @WaivedAmount Numeric(17,2)  
  
 --=================================      
      
Set @WOP = 'CP'      
Set @ProcessID = 'RESC'      
Set @TransactionID = 'RESC'      
Set @Error = 0       
Set @AmountJournal = 0      
      
Begin Transaction ReschedulingExec      

--Sugiono, 22 April 2024 FMF-5013
IF @Businessdate <> (SELECT BDCurrent FROM dbo.SystemControlCoy WITH (NOLOCK))
BEGIN
    Raiserror('Status Date terminated re-login please', 16,1)
	Set @Error = 1
	If @Error > 0 
		Goto ExitSP
END
--End Sugiono
      
If Not exists(Select '' from Rescheduling Where      
  BranchID = @BranchID And ApplicationID = @ApplicationID      
  and RequestNo = @RequestNo and Status = 'A')      
   --And SeqNo = @SeqNo )--And  Status = 'A')      
Begin      
 Raiserror('Rescheduling Has Been Change By Another User', 16,1)      
 Set @Error = 1      
 If @Error > 0       
  Goto ExitSP      
End      
Else       
If Exists(Select '' from Rescheduling R      
  Inner Join Agreement A on  A.branchID = R.BranchID and      
        A.ApplicationID = R.ApplicationID      
  Where R.BranchID = @BranchID And R.ApplicationID = @ApplicationID      
   and R.RequestNo = @RequestNo and R.Status = 'A'      
   And A.DefaultStatus = 'NA')      
Begin      
 Raiserror('The AgreementStatus is non Accrual, Please Reversal first!', 16,1)      
 Set @Error = 1      
 If @Error > 0       
  Goto ExitSP      
End     
  
-- Dwi 21 Juli 2020 - FMF 2262  
Select @OutstandingPrincipalOld = OutstandingPrincipalOld, @OutstandingInterestOld = OutstandingInterestOld, @OSInstallmentDue = OSInstallmentDue  
from Rescheduling   
where ApplicationID = @ApplicationID and RequestNo = @RequestNo and BranchId = @BranchID  
  
Select @InstallmentAmount = Sum(InstallmentAmount), @PaidAmount = Sum(PaidAmount), @WaivedAmount = Sum(WaivedAmount)  
from InstallmentSchedule  
where ApplicationID = @ApplicationID and BranchId = @BranchID  
  
--Dwi 16 Juli 2020 - FMF 2262  
--Dwi 22 Juli 2020 - FMF 2262  
If (@OutstandingPrincipalOld + @OutstandingInterestOld + @OSInstallmentDue) != (@InstallmentAmount - @PaidAmount - @WaivedAmount)   
 AND (@OutstandingPrincipalOld + @OutstandingInterestOld + @OSInstallmentDue) - (@InstallmentAmount - @PaidAmount - @WaivedAmount) > 1 --Added by Candra 30 Sept 2020 [FMF-2382]: tambah penjagaan jika selisih nya lebih dari 0.1 maka akan muncul error  
Begin  
 print ('@OutstandingPrincipalOld: ' + convert(varchar,@OutstandingPrincipalOld))  
 print ('@@OutstandingInterestOld: ' + convert(varchar,@OutstandingInterestOld))  
 print ('@@OSInstallmentDue: ' + convert(varchar,@OSInstallmentDue))  
 print('total: ' + convert(varchar,@OutstandingPrincipalOld + @OutstandingInterestOld + @OSInstallmentDue))  
 print ('@InstallmentAmount: '+ convert(varchar,@InstallmentAmount))  
 print ('@@PaidAmount: '+ convert(varchar,@PaidAmount))  
 print ('@@WaivedAmount: '+ convert(varchar,@WaivedAmount))  
 print('totalB: ' + convert(varchar,@InstallmentAmount + @PaidAmount + @WaivedAmount))  
 Raiserror('Data Has Been Update by Another User',16,1)  
 Set @Error = 1  
 IF @error > 0  
 begin  
  Goto ExitSP  
 end  
End  
  
--Nadhia, 21/08/2020 (FMF-2297)  
SELECT  @ContractStatus = ContractStatus  
FROM    dbo.Agreement  
WHERE   BranchID = @BranchID  
        AND ApplicationID = @ApplicationID    
IF @ContractStatus <> 'ICP'  
    BEGIN  
--End Nadhia  
        IF ( --Add by Gema, 20081113 : Penjagaan supaya tidak lewat dari Next Installment DueDate  
             SELECT NextInstallmentDueDate  
             FROM   agreement  
             WHERE  BranchID = @BranchID  
                    AND ApplicationID = @ApplicationID  
           ) < @EffectiveDate  --<= @EffectiveDate  --Raug FMF-3149 19 November 2021
            BEGIN      
                RAISERROR('The Effective Date can''t be bigger than Next Installment DueDate , Please Rerequest!', 16,1)      
                SET @Error = 1      
                IF @Error > 0  
                    GOTO ExitSP      
            END     
    END   
--Else       
Begin      
   --Select @LastDateOfEffectiveMonth = dbo.LastFullDateOfMonth(Rtrim(Month(@Effdate)),Rtrim(Year(@Effdate)))      
         
declare @Dr amount, @In amount, @Pr amount, @AdminFee amount  
--David 9Fe2010--  
DECLARE @InsuranceIncomeAmount Amount  
  ,@DeferredInsurIncAmount Amount  
  ,@OtherRefundAmount Amount  
  ,@AdmFeeAmount Amount  
  ,@ProvisionFeeAmount Amount  
  ,@OtherFeeAmount Amount  
  ,@SurveyFeeAmount Amount  
  ,@CostOfSurveyFee Amount --arif 15 okt 2010  
   -----------------------------------------------------      
   -- Get Due Date From installment start to Resc    --      
   -----------------------------------------------------      
   Select @InsSeqNo= InsSeqNo,  
   @ReQuestDate = RequestDate --added by Mery, 19 Aug 2020 [FMF-2309]      
   from Rescheduling      
   Where BranchID = @BranchID And ApplicationID=@ApplicationID      
    And RequestNo = @RequestNo And Status='A'        
      
   Select @DueDate = DueDate,      
    @LastIncRecognize = IsNull(LastIncRecognize,'')  
-- @DR = isNull((DiffRateAmount + (DiffRateRecognize * - 1)),0),  
-- @In = isNull((Incentive - (IncentiveRecognize * - 1)),0),  
-- @Pr = isNull((Provision - (ProvisionRecognize * - 1)),0)  
   From  InstallmentSchedule      
   Where  BranchID = @BranchID And      
    ApplicationID = @ApplicationID And      
    InsSeqNo = @InsSeqNo      
   -------------------------------------------------------      
     
   --add Mery, 19 Aug 2020 [FMF-2309]  
   IF YEAR(@ReQuestDate) = YEAR(@BusinessDate) AND MONTH(@ReQuestDate) <> MONTH(@BusinessDate)  
   BEGIN  
 RAISERROR ('Rescheduling Has Been Expired. Please Re-Request!', 16,1)      
    SET @Error = 1      
    IF @Error > 0       
     GOTO ExitSP    
   END  
   --end Mery      
      
   if @DueDate <= @BusinessDate      
   Begin      
    Raiserror('Rescheduling Has Been Expired, because Installment Has Due. Please Re-Request!', 16,1)      
    Set @Error = 1      
    If @Error > 0       
     Goto ExitSP      
   End      
   -------------------------------------------------------      
      
      
   If exists(Select PDCReceiptNo from PDCHeader Where       
     BranchAgreement = @BranchID and ApplicationID = @ApplicationID And       
     PDCStatus='PO' and IsClearReconcile = 0)      
   Begin      
    Raiserror('Please Reconcile Your PDC First', 16,1)      
    Set @Error = 1      
    If @Error > 0       
     Goto ExitSP      
   End      
   Else      
   Begin      
    --Backup Agreement To OldAgreement       
     declare @NextSeqNo as smallint      
     select @NextSeqNo = isnull(max(appseqno),0) + 1 from oldagreement       
      where branchid = @BranchID and ApplicationID = @ApplicationID  
      
     Exec @error = spReschedulingExecutionSaveOldData @BranchID, @ApplicationID, @NextSeqNo      
     Set @Error = @@error      
     If @Error > 0       
      Goto ExitSP      
      
          
      --  SELECT * FROM abc  
     Select  @OSInstallmentDue = OSInstallmentDue,       
      @OSInsuranceDue=OSInsuranceDue,       
      @OSLCInstallment=OSLCInstallment,       
      @OSLCInsurance=OSLCInsurance,         
      @OSPDCBounceFee =OSPDCBounceFee,       
      @OSRepoFee = OSReposessFee,              
      @AccruedAmount =AccruedAmount,       
      @LCInstallmentAmountDisc = LCInstallmentAmountDisc,       
      @LCInsuranceAmountDisc = LCInsuranceAmountDisc,        
      @PDCBounceFeeDisc =PDCBounceFeeDisc,        
      @ECIAmount = ECIAmount,      
      @OSInstallmentDue = OSInstallmentDue,      
      @OSInsuranceDue = OSInsuranceDue,      
      @OutstandingPrincipalOld = OutstandingPrincipalOld,      
      @OutstandingPrincipalNew = OutstandingPrincipalNew,      
      @OutstandingInterestNew = OutstandingInterestNew,      
      @OutstandingInterestOld = OutstandingInterestOld,      
      @TotalAmountToBePaid = TotalAmountToBePaid,      
      @AdministrationFee = AdministrationFee,      
      @NewEffectiveRate = EffectiveRate,      
      @OldEffectiveRate = OldRate,      
      @AccruedResch = AccruedResch,      
      @AccruedEOM = AccruedEOM,      
      @AccruedAdj = AccruedAdj,      
      @InsSeqNo= InsSeqNo,      
      @EffDate = EffectiveDate,      
      @RepoFeeDisc = ReposessFeeDisc,  
     
   --Budiman modified, 5 November 2018 FMF-1710  lepas case->when untuk kondisi Effective Date rescheduling = LastDueDate dan businessDate > EOM InsSeqNo berjalan,   
   --maka perlu dibuatkan journal reversal PSAK-nya.  
  ---- Yovita 20 Sept 2007: Add Select from Rescheduling  
   --@DR = (case when isNull(AccruedDiffRate,0) <> 0 then isNull(AccruedDiffRate,0) - IsNull(AccruedDiffRateEOM,0) else 0 end),   
   --@In = (case when isNull(AccruedIncentive,0) <> 0 then isNull(AccruedIncentive,0) - IsNull(AccruedIncentiveEOM,0) else 0 end),  
   --@Pr = (case when isNull(AccruedProvision,0) <> 0 then  isNull(AccruedProvision,0) - IsNull(AccruedProvisionEOM,0) else 0 end),  
   --@AdminFee = (case when isNull(AccruedAdminFee,0) <> 0 then  isNull(AccruedAdminFee,0) - IsNull(AccruedAdminFeeEOM,0) else 0 end)  
     
        ----David 9Feb2010--  
        --,@InsuranceIncomeAmount = (case when isNull(AccruedInsuranceIncome,0) <> 0 then  isNull(AccruedInsuranceIncome,0) - IsNull(AccruedInsuranceIncomeEOM,0) else 0 end)  
        --,@DeferredInsurIncAmount = (case when isNull(AccDeferredInsurInc,0) <> 0 then  isNull(AccDeferredInsurInc,0) - IsNull(AccDeferredInsurIncEOM,0) else 0 end)  
        --,@OtherRefundAmount = (case when isNull(AccOtherRefund,0) <> 0 then  isNull(AccOtherRefund,0) - IsNull(AccOtherRefundEOM,0) else 0 end)  
        --,@AdmFeeAmount = (case when isNull(AccAdmFee,0) <> 0 then  isNull(AccAdmFee,0) - IsNull(AccAdmFeeEOM,0) else 0 end)  
        --,@ProvisionFeeAmount = (case when isNull(AccProvisionFee,0) <> 0 then  isNull(AccProvisionFee,0) - IsNull(AccProvisionFeeEOM,0) else 0 end)  
        --,@OtherFeeAmount = (case when isNull(AccOtherFee,0) <> 0 then  isNull(AccOtherFee,0) - IsNull(AccOtherFeeEOM,0) else 0 end)  
        --,@SurveyFeeAmount = (case when isNull(AccSurveyFee,0) <> 0 then  isNull(AccSurveyFee,0) - IsNull(AccSurveyFeeEOM,0) else 0 end)  
        --,@CostOfSurveyFee = (case when isNull(AccCostOfSurveyAmountFee,0) <> 0 then  isNull(AccCostOfSurveyAmountFee,0) - IsNull(AccCostOfSurveyAmountFeeEOM,0) else 0 end)  
  
   @DR = isNull(AccruedDiffRate,0) - IsNull(AccruedDiffRateEOM,0),   
   @In = isNull(AccruedIncentive,0) - IsNull(AccruedIncentiveEOM,0),  
   @Pr = isNull(AccruedProvision,0) - IsNull(AccruedProvisionEOM,0),  
   @AdminFee = isNull(AccruedAdminFee,0) - IsNull(AccruedAdminFeeEOM,0)  
   ,@InsuranceIncomeAmount = isNull(AccruedInsuranceIncome,0) - IsNull(AccruedInsuranceIncomeEOM,0)  
   ,@DeferredInsurIncAmount = isNull(AccDeferredInsurInc,0) - IsNull(AccDeferredInsurIncEOM,0)  
   ,@OtherRefundAmount = isNull(AccOtherRefund,0) - IsNull(AccOtherRefundEOM,0)  
   ,@AdmFeeAmount = isNull(AccAdmFee,0) - IsNull(AccAdmFeeEOM,0)  
   ,@ProvisionFeeAmount = isNull(AccProvisionFee,0) - IsNull(AccProvisionFeeEOM,0)  
   ,@OtherFeeAmount =  isNull(AccOtherFee,0) - IsNull(AccOtherFeeEOM,0)  
   ,@SurveyFeeAmount =  isNull(AccSurveyFee,0) - IsNull(AccSurveyFeeEOM,0)  
   ,@CostOfSurveyFee =  isNull(AccCostOfSurveyAmountFee,0) - IsNull(AccCostOfSurveyAmountFeeEOM,0)  
  --End Budiman  
  ,@IsFeeBasePostPonded = ISNULL(IsFeeBasePostPonded, 0) --Add Adhitya FMF-2255 16/07/2020  
      from Rescheduling      
      Where BranchID = @BranchID And ApplicationID=@ApplicationID      
      And RequestNo = @RequestNo And Status='A'      
      
 --Add Adhitya FMF-2255 16/07/2020  
  IF @IsFeeBasePostPonded = 1  
  BEGIN  
  SET @OSInsuranceDue = 0   
  SET @OSLCInstallment = 0  
  SET @OSLCInsurance = 0  
  SET @OSRepoFee = 0  
  SET @OSPDCBounceFee = 0  
  END  
  --End Adhitya FMF-2255 16/07/2020  
  
     Set @TotalAmount = @OSInstallmentDue + @OSInsuranceDue + @OSLCInstallment + @OSLCInsurance +      
       @OSPDCBounceFee + @AccruedAmount       
              
     Set @TotalDiscount =  @LCInstallmentAmountDisc + @LCInsuranceAmountDisc + @PDCBounceFeeDisc      
     set @AmountReceive = @TotalAmount - @TotalDiscount               
  ---ALTER  Journal       
      
     select @AgreementNo=agr.AgreementNo,  @productid=agr.productid,       
      @CurrencyID = agr.CurrencyID, @CurrencyRate = cur.DailyExchangeRate,      
      @ContractPrepaidAmount = ContractPrepaidAmount      
     from dbo.Agreement AGR       
     inner join Currency cur on agr.CurrencyID = cur.CurrencyID      
     where AGR.BranchID = @BranchID And AGr.applicationid=@ApplicationId      
         
 select @currencyrounded = rounded from currency where currencyid=@CurrencyID  
  
     Set @RefDesc = Rtrim(Ltrim(@AgreementNo)) + '#' + @ProductID      
      
  -------Accured       
      
    -- modified by emilia 18-07-2006 dari alter menjadi ALTER  temptable       
     CREATE     table #TempTable (      
      SeqNo INT IDENTITY PRIMARY KEY,       
      PaymentAllocationID char(10),      
      Post Char(1),       
      Amount Numeric(17,2),       
      RefDesc Varchar(50),      
      DepartementID Varchar(3),       
      VoucherDesc Varchar(50)      
     )      
      
     --Anton 16-10-2006      
     declare @Prepaid Amount      
        
     set @Prepaid=@ContractPrepaidAmount      
      
     -- Yovita Nov 29 2006 : Ubah kondisi untuk ambil @ContractPrepaidAmount terkait dengan ToleranceAmount prepaid       
     If @TotalAmountToBePaid < @Prepaid       
     Begin      
      set @ContractPrepaidAmount = @TotalAmountToBePaid-@ToleranceAmount      
     End      
     Else      
     Begin      
      set @ContractPrepaidAmount = @TotalAmountToBePaid      
     End      
        
     ----------------------------------------------------------------------------------------------      
           
Set @Counter = 1      
While @Counter <= 43     
Begin      
  
If @Counter = 1      
Begin      
 If  @OSLCInstallment > 0       
 Begin      
  Set @AmountJournal = @OSLCInstallment      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'LCINSTALL'      
 end      
end       
  
If @Counter = 2      
Begin      
 If @LCInstallmentAmountDisc > 0       
 Begin      
  Set @AmountJournal = @LCInstallmentAmountDisc      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'LCINSTALWO'      
 end       
End      
  
If @Counter = 3      
Begin      
 If @OSLCInsurance > 0       
 Begin      
  Set @AmountJournal = @OSLCInsurance      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'LCINSUR'      
 end      
End      
  
If @Counter = 4      
Begin      
 If @LCInsuranceAmountDisc > 0       
 Begin      
  Set @AmountJournal = @LCInsuranceAmountDisc      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'LCINSURWO'      
 end      
End     
     
If @Counter = 5      
Begin      
 If @OSPDCBounceFee > 0       
 Begin      
  Set @AmountJournal = @OSPDCBounceFee      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'PDCBNCFEE'      
 end      
End      
  
If @Counter = 6      
Begin      
 If @PDCBounceFeeDisc > 0       
 Begin      
  Set @AmountJournal = @PDCBounceFeeDisc      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'PDCBNCFEWO'      
 end      
End      
  
If @Counter = 7      
Begin      
 If @OSRepoFee > 0       
 Begin      
  Set @AmountJournal = @OSRepoFee      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'REPOFEE'      
 end      
End      
  
If @Counter = 8      
Begin      
 If @RepoFeeDisc > 0       
 Begin      
  Set @AmountJournal = @RepoFeeDisc      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'REPOFEEWO'      
 end      
End      
  
If @Counter = 9      
Begin      
 If @OSInsuranceDue > 0       
 Begin      
  Set @AmountJournal = @OSInsuranceDue    
  ---Silvia, 20 November 2020 [FMF-2471] : Ubah post journal INSURRCV jadi di Credit  
  --Set @PostJournal = 'D'   
  Set @PostJournal = 'C'
  ---End Silvia [FMF-2471]    
  Set @PaymentAllocationJournal = 'INSURRCV'      
 end      
End      
  
If @Counter = 10      
Begin      
 --teddy 23 may 2007 : ubah perhitungan uci pada jurnal tidak lagi berdasarkan parameter yang dikirm melainkan dihitung ulang dari tabel installment schedule        
 Set @PaymentAllocationJournal = 'UCI'      
 Set @PostJournal = 'D'      
 Begin      
  --Set @AmountJournal = @OutstandingInterestOld-(@AccruedAmount - @ECIAmount)      
  --- Set @AmountJournal = @OutstandingInterestOld-@AccruedEOM     
  if @effectivedate < @businessdate And ( Month(@BusinessDate) - Month(@EffectiveDate) > 0 )  
  begin  
   Set @AmountJournal = ( Select SUM(InterestAmount) From InstallmentSchedule  Where BranchID = @BranchID And ApplicationID = @ApplicationID and Duedate > @BusinessDate  ) - @AccruedEOM      
  end  
  else  
  begin  
            --Add by Gema, 20081024 : rubah InterestAmount dari jadi InterestAmount-AmountIncRecognize  
   Set @AmountJournal = ( Select SUM(InterestAmount-AmountIncRecognize) From InstallmentSchedule  Where BranchID = @BranchID And ApplicationID = @ApplicationID) --and Duedate > @EffDate  )     
  end  
 End      
End      
  
If @Counter = 11   
   Begin      
      if @AccruedEOM > 0   
         Begin      
            Set @AmountJournal = @AccruedEOM        
            Set @PostJournal = 'D'  -- EARNED EOM Di balikin lagi       
   Set @PaymentAllocationJournal = 'ECI'         
         END  
      -- Lisa 20110120 : Remark kembali utk Else ECI  
      -- Lisa 20101210 : Buka remark else utk ECI      
      --Else --Yovita Sept 12 2006 : Add JournalECI when not passed EOM      
      --   Begin      
      --      Set @AmountJournal = @AccruedAmount       
      --      Set @PostJournal = 'C'   -- EARNED Bertambah      
      --   ENd      
  
      --Set @PaymentAllocationJournal = 'ECI'    
      -- End Lisa 20101210   
      -- End Lisa 20110120   
   END      
  
If @Counter = 12      
Begin      
 If (@OutstandingPrincipalOld + @OutstandingInterestOld) > 0       
 Begin   -- Yovita mar 27 2006 : Add Amount Jurnal untuk ARGROSS di tambah dengan @OSInstallmentDue      
  -- Yovita June 06 2006 : Jurnal untuk ARGROSS tidak di tambah dengan  @OSInstallmentDue      
  Set @AmountJournal = @OutstandingPrincipalOld + @OutstandingInterestOld      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'ARGROSS'      
 end      
End      
  
If @Counter = 13      
Begin      
 --If (@OutstandingPrincipalOld + @OutstandingInterestOld) > 0       
 If @OSInstallmentDue > 0       
 Begin   -- Yovita June 06 2006 : Add Jurnal untuk INSTALLRCV dengan @OSInstallmentDue      
  Set @AmountJournal = @OSInstallmentDue      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'INSTALLRCV'      
 end      
End      
  
If @Counter = 14      
Begin      
 If (@OutstandingPrincipalNew +  @OutstandingInterestNew) > 0       
 Begin      
  Set @AmountJournal = @OutstandingPrincipalNew +  @OutstandingInterestNew      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'ARGROSSRSC'      
 end      
End      
  
If @Counter = 15      
Begin      
 If @OutstandingInterestNew > 0 -- Unearn untuk rescheduling dikurang sebesar @AccruedResch, jika sudah lewat EOM      
 Begin      
  --Teddy 23 May 2007 : ubah perhitungan jurnal untuk UCIRSC        
  If ( @EffectiveDate < @BusinessDate  And ( Month(@BusinessDate) - Month(@EffectiveDate) > 0 ) )      
  Begin      
   Set @AmountJournal = @OutstandingInterestNew - @AccruedResch + @AccruedAmount       
  End      
  else       
  Begin      
  -- Set @AmountJournal = @OutstandingInterestNew - @AccruedResch - @AccruedAmount      
  -- Yovita Sept 12 2006 : Amount UCIRSC only OSInterestNew when not passed EOM      
   Set @AmountJournal = @OutstandingInterestNew      
  End      
  /*      
  if @AccruedEOM > 0      
  Begin      
  Set @AmountJournal = @OutstandingInterestNew - @AccruedResch + @AccruedAmount       
  End      
  else if @AccruedEOM <= 0        
  Begin      
  -- Set @AmountJournal = @OutstandingInterestNew - @AccruedResch - @AccruedAmount      
  -- Yovita Sept 12 2006 : Amount UCIRSC only OSInterestNew when not passed EOM      
  Set @AmountJournal = @OutstandingInterestNew      
  End      
  */      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'UCIRSC'    
    
 end      
End      
  
If @Counter = 16 -- Yovita Mar 22 06 : Add ECIRSC      
Begin      
 If @AccruedResch > 0       
 Begin      
         
        --Add by Gema, 20081024 : select  @InterestDue  
        set @InterestDue = 0  
  
        if Not exists    
        (     
           select '' from InstallmentSchedule where applicationid=@ApplicationId And BranchID = @BranchID    
           And InsSeqNo = @InsSeqNo - 1 and duedate = @EffectiveDate       
        )    
        begin    
   select @InterestDue = SUM(InterestAmount-AmountIncRecognize) from installmentschedule   
   Where BranchID = @BranchID And ApplicationID=@ApplicationID and insSeqno < @InsSeqNo  
     
   --Susanti, 16 Mei 2011  
   SET @InterestDue = ISNULL(@InterestDue,0)  
   --end Susanti, 16 Mei 2011  
        End  
  
  --if (@EffectiveDate < @BusinessDate  And ( Month(@BusinessDate) - Month(@EffectiveDate) > 0 ) )  
  --begin   
     
  -- set @AmountJournal = @AccruedAmount  
  --end  
  --else  
  --begin  
     
   set @AmountJournal = @AccruedResch + @InterestDue  
  --end  
          
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'ECIRSC'      
 End      
End      
  
If @Counter = 17      
Begin      
 If @AdministrationFee > 0       
 Begin      
  Set @AmountJournal = @AdministrationFee      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'ADMINFEE'      
 end      
End      
  
If @Counter = 18      
Begin      
 If @ContractPrepaidAmount > 0       
 Begin      
  Set @AmountJournal = @ContractPrepaidAmount      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'PREPAID'      
 end      
End      
  
If @Counter = 19      
Begin      
 if @ToleranceAmount > 0      
 Begin      
  Set @AmountJournal = @ToleranceAmount      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'TOLAMOUNT'      
 end      
end       
  
If @Counter = 20      
Begin      
 If @DR > 0       
 Begin      
  Set @AmountJournal = @DR      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'RATESSIDY'      
 end      
 else If @DR < 0       
 Begin      
  Set @AmountJournal = -1 * @DR      
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'RFNDAMZ'      
 end      
End     
   
If @Counter = 21      
Begin      
 If @DR > 0       
 Begin      
  Set @AmountJournal = @DR      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'SSIDYAMZ'      
 end      
 else If @DR < 0       
 Begin      
  Set @AmountJournal = -1 * @DR      
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'RATERFND'      
 end      
End      
  
  
If @Counter = 22      
Begin      
 If @In <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0       
 Begin      
  --Begin Restu PI-189 25 Okt 2017    
  --SET @AmountJournal = -1 * @In      
  --SET @PostJournal = 'D'    
  SET @AmountJournal = ABS(@In)  
  SET @PostJournal = CASE WHEN @In < 0 THEN 'D' ELSE 'C' END  
  --End Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'INCSUPPEXP'      
 end      
End      
  
If @Counter = 23      
Begin      
 If @In <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0     
 Begin      
  --Begin Restu PI-189 25 Okt 2017  
  --SET @AmountJournal = -1 * @In      
        --SET @PostJournal = 'C'   
  SET @AmountJournal = ABS(@In)  
        SET @PostJournal = CASE WHEN @In < 0 THEN 'C' ELSE 'D' END     
  --End Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'INCENSPL1'      
 end      
End      
  
--Budiman, FMF-1710 10 Des 2018, ubah posting Provision   
--If @Counter = 24      
--Begin      
-- If @Pr < 0       
-- Begin      
--  Set @AmountJournal = -1 * @Pr      
--  Set @PostJournal = 'D'      
--  Set @PaymentAllocationJournal = 'PROVEXP'      
-- end      
--End    
  
  
--If @Counter = 25      
--Begin      
-- If @Pr < 0       
-- Begin      
--  Set @AmountJournal = -1 * @Pr      
--  Set @PostJournal = 'C'      
--  Set @PaymentAllocationJournal = 'PROVBANK'      
-- end      
--End  
If @Counter = 24      
Begin    
 If @Pr <> 0       
 Begin      
  Set @AmountJournal = ABS(@Pr )  
  Set @PostJournal = CASE WHEN @pr < 0 THEN 'D' ELSE 'C' END  
  Set @PaymentAllocationJournal = 'PROVEXP'      
 end      
End    
  
  
If @Counter = 25      
Begin      
 If @Pr <> 0       
 Begin      
  Set @AmountJournal = ABS(@Pr)  
  Set @PostJournal = CASE WHEN @pr < 0 THEN 'C' ELSE 'D' END  
  Set @PaymentAllocationJournal = 'PROVBANK'      
 end      
End  
      
--End Budiman    
  
--Add by Gema, 20081110 : Tambah Jurnal AdminFee ----------------  
If @Counter = 26      
Begin      
    
 If @AdminFee <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0      
 Begin      
  --Begin Restu PI-189 25 Okt 2017  
  --SET @AmountJournal = -1 * @AdminFee      
  --SET @PostJournal = 'D'     
  SET @AmountJournal = ABS(@AdminFee)     
  SET @PostJournal = CASE WHEN @AdminFee < 0 THEN 'D' ELSE 'C' END --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
  --End Restu PI-189 25 Okt 2017      
  Set @PaymentAllocationJournal = 'ADMFEEAMZ'      
 end      
End      
  
If @Counter = 27      
Begin      
   
--Budiman, 28 November 2018 FMF-1710, ubah kondisi If dari < 0 menjadi <> 0  
 --If @AdminFee < 0   
 If @AdminFee <> 0   
--End Budiman  
 Begin      
  --Begin Restu PI-189 25 Okt 2017  
  --SET @AmountJournal = -1 * @AdminFee      
        --SET @PostJournal = 'C'     
  SET @AmountJournal = ABS(@AdminFee)     
  SET @PostJournal = CASE WHEN @AdminFee < 0 THEN 'C' ELSE 'D' END --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
  --End Restu PI-189 25 Okt 2017      
  
  --Budiman, 28 November 2018 FMF-1710, remark post journal, seharusnya menggunakan case-when di atas.  
   --Set @PostJournal = 'C'      
  --End Budiman  
  
  Set @PaymentAllocationJournal = 'ADMFEEADV'      
 end      
End      
-- End Gema, 20081110 -----------------------------------------  
  
--David 9Feb2010----------------  
If @Counter = 28      
Begin      
 If @InsuranceIncomeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@InsuranceIncomeAmount)  
  --Begin Restu PI-189 25 Okt 2017    
  --SET @PostJournal = 'D'    
        SET @PostJournal = CASE WHEN @InsuranceIncomeAmount < 0 THEN 'D' ELSE 'C' END  
  --END Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'RFNINSRAMZ'      
 end      
End      
  
If @Counter = 29      
Begin      
 If @InsuranceIncomeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@InsuranceIncomeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'C'    
        SET @PostJournal = CASE WHEN @InsuranceIncomeAmount < 0 THEN 'C' ELSE 'D' END  
  --END Restu PI-189 25 Okt 2017      
  Set @PaymentAllocationJournal = 'INSRRFDEXP'      
 end      
End      
--===========  
If @Counter = 30      
Begin      
 If @DeferredInsurIncAmount > 0       
 Begin      
  Set @AmountJournal = ABS(@DeferredInsurIncAmount)  
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'DEFINSUR'      
 end      
 ELSE If @DeferredInsurIncAmount < 0       
 Begin      
  Set @AmountJournal = ABS(@DeferredInsurIncAmount)  
  Set @PostJournal = 'D'      
  Set @PaymentAllocationJournal = 'INSREXPAMZ'      
 end    
End      
  
If @Counter = 31      
Begin      
 If @DeferredInsurIncAmount > 0       
 Begin      
  Set @AmountJournal = ABS(@DeferredInsurIncAmount)  
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'INSRINCAMZ'      
 end      
 ELSE If @DeferredInsurIncAmount < 0       
 Begin      
  Set @AmountJournal = ABS(@DeferredInsurIncAmount)  
  Set @PostJournal = 'C'      
  Set @PaymentAllocationJournal = 'INSREXPDEF'      
 end   
End      
--===========  
If @Counter = 32      
Begin      
 If @OtherRefundAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@OtherRefundAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'D'      
  SET @PostJournal = CASE WHEN @OtherRefundAmount < 0 THEN 'D' ELSE 'C' END  
  --End Restu PI-189 25 Okt 2017      
  Set @PaymentAllocationJournal = 'COMOTHAMZ'      
 end      
End      
  
If @Counter = 33      
Begin      
 If @OtherRefundAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@OtherRefundAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'C'      
  SET @PostJournal = CASE WHEN @OtherRefundAmount < 0 THEN 'C' ELSE 'D' END  
  --End Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'COMOTHDEF'      
 end      
End      
--===========  
If @Counter = 34      
Begin      
 If @AdmFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@AdmFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'D'    
  SET @PostJournal = CASE WHEN @AdmFeeAmount > 0 THEN 'D'  ELSE 'C' END  --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
  --End Restu PI-189 25 Okt 2017    
  Set @PaymentAllocationJournal = 'ADMFEEDEF'      
 end      
End      
  
If @Counter = 35      
Begin      
 If @AdmFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@AdmFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'C'     
  SET @PostJournal = CASE WHEN @AdmFeeAmount > 0 THEN 'C'  ELSE 'D' END  --Kalau accrued EOM > accrued seharusnya artinya kelebihan dan direverse  
  --End Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'ADMNFEEAMZ'      
 end      
End      
--===========  
If @Counter = 36      
Begin      
 If @ProvisionFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@ProvisionFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'D'  
  SET @PostJournal = CASE WHEN @ProvisionFeeAmount > 0 THEN 'D' ELSE 'C' END  
  --End Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'PRVFEEDEF'      
 end      
End      
  
If @Counter = 37      
Begin      
 If @ProvisionFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@ProvisionFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'C'  
  SET @PostJournal = CASE WHEN @ProvisionFeeAmount > 0 THEN 'C' ELSE 'D' END  
  --End Restu PI-189 25 Okt 2017    
  Set @PaymentAllocationJournal = 'PRVFEEAMZ'      
 end      
End      
--===========  
If @Counter = 38      
Begin      
 If @OtherFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@OtherFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'D'    
  SET @PostJournal = CASE WHEN @OtherFeeAmount > 0 THEN 'D' ELSE 'C' END  
  --End Restu PI-189 25 Okt 2017       
  Set @PaymentAllocationJournal = 'OTHFEEDEF'      
 end      
End      
  
If @Counter = 39      
Begin      
 If @OtherFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@OtherFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'C'     
  SET @PostJournal = CASE WHEN @OtherFeeAmount > 0 THEN 'C' ELSE 'D' END   
  --End Restu PI-189 25 Okt 2017  
  Set @PaymentAllocationJournal = 'OTHFEEAMZ'      
 end      
End      
--===========  
If @Counter = 40      
Begin      
 If @SurveyFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@SurveyFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'D'    
  SET @PostJournal = CASE WHEN @SurveyFeeAmount > 0 THEN 'D' ELSE 'C' END  
  --End Restu PI-189 25 Okt 2017    
    
  -- Budiman FMF-1710, 28 November 2018 Ubah allocationJournal sesua dengan parameternya  
  --Set @PaymentAllocationJournal = 'OTHFEEDEF'      
  Set @PaymentAllocationJournal = 'SVYFEEDEF'      
  -- End Budiman  
 end      
End      
  
If @Counter = 41      
Begin      
 If @SurveyFeeAmount <> 0       
 Begin      
  Set @AmountJournal = ABS(@SurveyFeeAmount)  
  --Begin Restu PI-189 25 Okt 2017  
  --SET @PostJournal = 'C'    
  SET @PostJournal = CASE WHEN @SurveyFeeAmount > 0 THEN 'C' ELSE 'D' END  
  --End Restu PI-189 25 Okt 2017      
  
  -- Budiman FMF-1710, 28 November 2018 Ubah allocationJournal sesua dengan parameternya  
  --Set @PaymentAllocationJournal = 'OTHFEEAMZ'      
  Set @PaymentAllocationJournal = 'SVYFEEAMZ'      
  -- End Budiman  
 end      
End      
--===========  
--David 9Feb2010 selesai-----------------------------------------  
If @Counter = 42      
Begin      
 --Budiman modified, FMF-1710, 28 Nov 2018 ubah < 0  menjadi <> 0  
  --If @CostOfSurveyFee < 0       
  If @CostOfSurveyFee <> 0       
 --End Budiman  
  
 Begin      
  Set @AmountJournal = ABS(@CostOfSurveyFee)     
  --Begin Restu PI-189 25 Okt 2017     
  --SET @PostJournal = 'D'  
  SET @PostJournal = CASE WHEN @CostOfSurveyFee < 0 THEN 'D' ELSE 'C' END      
  --End Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'CSTSVYEXP'      
 end      
End      
  
If @Counter = 43      
Begin      
 If @CostOfSurveyFee <> 0 --Restu PI-189 25 Okt 2017 ubah < 0 jadi <> 0     
 Begin      
  Set @AmountJournal = ABS(@CostOfSurveyFee)     
  --Begin Restu PI-189 25 Okt 2017    
  --SET @PostJournal = 'C'      
  SET @PostJournal = CASE WHEN @CostOfSurveyFee < 0 THEN 'C' ELSE 'D' END  
  --End Restu PI-189 25 Okt 2017     
  Set @PaymentAllocationJournal = 'CSTSVYDEF'      
 end      
End   
  
      
      If @AmountJournal > 0       
      Begin      
       Insert Into #TempTable (PaymentAllocationID, Post, Amount,       
         RefDesc, VoucherDesc)      
       Values(@PaymentAllocationJournal, @PostJournal, @AmountJournal, @Refdesc, '')      
       If @@error <>  0       
       Begin      
        Goto ExitSP      
       End       
      end      
      Set @AmountJournal = 0      
      Set @Counter = @Counter + 1      
     End      
      
    Select @TotalD = Sum ((Case when Post = 'D' then Amount end)) ,       
     @TotalC = Sum ((Case when Post = 'C' then Amount end))from #TempTable      
      
   select * from #temptable   
   PRINT   '@TotalD '  
   PRINT   @TotalD  
   PRINT   '@TotalC'  
   PRINT   @TotalC  
      
    --Susanti, 05 Mei 2015   
    --if abs(@TotalD - @TotalC ) > @currencyrounded       
    if abs(@TotalD - @TotalC ) > 1    
 Begin      
   Raiserror('Journal Not Balance', 16,1)      
   Set @Error = 1      
   If @Error > 0       
   Goto ExitSP      
    ENd      
   
    if  @TotalD > @TotalC      
    Begin      
     Set @AmountJournal = @TotalD - @TotalC      
     Set @PostJournal = 'C'      
     Set @PaymentAllocationJournal = 'OTHERINC'      
     Insert Into #TempTable (PaymentAllocationID, Post, Amount,       
       RefDesc, VoucherDesc)      
     Values(@PaymentAllocationJournal, @PostJournal, @AmountJournal, @Refdesc, '')      
    End       
      
    if @TotalD < @TotalC      
    Begin      
     Set @AmountJournal = @TotalC - @TotalD      
     Set @PostJournal = 'D'      
     Set @PaymentAllocationJournal = 'OTHERINC'       
     Insert Into #TempTable (PaymentAllocationID, Post, Amount,       
       RefDesc, VoucherDesc)      
     Values(@PaymentAllocationJournal, @PostJournal, @AmountJournal, @Refdesc, '')      
    End      
     
          
          
    Set @Error = @@error      
    If @Error > 0       
     Goto ExitSP      
  
       
    Execute @Error = spProcessCreateJournal      
     @CompanyID, @BranchID, @TransactionID, @BusinessDate, @BusinessDate, @AgreementNo, @ApplicationID, 'O',       
     '', @AmountReceive, @CurrencyID, @CurrencyRate, 1,      
     @JournalCode output      
    If @Error > 0       
    Begin      
     Goto ExitSP      
    End        
   select * from gljournald where tr_nomor = @JournalCode  
   -- Create Payment History       
    update paymenthistoryheader set isCorrection = 0, DtmUpd = getdate() where isCorrection = 1 and branchid = @BranchId and applicationid = @ApplicationID      
    If @@Error <>  0       
    Begin      
     Goto ExitSP      
    End       
    -- Yovita Aug 23 2006 : Ganti ValueDate pada saat createpaymenthistory dari @BusinessDate jadi @effDate      
    Declare @HistorySequenceNo int       
    Execute @Error = spProcessCreatePaymentHistory      
      @BranchID, @ApplicationID, @BusinessDate, @EffDate, -- @BusinessDate,       
      '-', '-', 0,       
      0, @AgreementNo, '-', @WOP, @ProcessID, @AmountReceive, @JournalCode, '-', @HistorySequenceNo Output      
      
    If @Error >  0       
    Begin      
     Goto ExitSP      
    End       
          
	--BEGIN Niko FMF-4076 Pindahin Update Rescheduling Tr_nomor dari bawah spReschedulingExecutionSaveDataAgreement ke atasnya
	Update Rescheduling SET  
     Tr_nomor = @JournalCode  
    Where BranchID = @BranchID and ApplicationID = @ApplicationID And RequestNo = @RequestNo and Status = 'A'  
	
	Exec @error = spReschedulingExecutionSaveDataAgreement @BranchID, @ApplicationID, @RequestNo, @EffectiveDate, @AmountReceive, @Prepaid, @ToleranceAmount      
      
    If @Error >  0 
    Begin      
     Goto ExitSP      
    End         

    
  
  --Teddy 23 May 2007 : tambahkan parameter @AccruedResch yang akan dikirimkan      
    Exec @error = spReschedulingExecutionAccruedProcess @BranchID, @ApplicationID, @EffectiveDate,       
     @BusinessDate, @AccruedAmount, @ECIAmount, @InsSeqNo, @AccruedAdj, @AccruedResch -- Yovita Ap 05 06 : AddParams @AccruedAdj      
    If @error <> 0       
     Goto ExitSp
          

	--Update Rescheduling      
    Update Rescheduling Set Status = 'E',      
     ReschedulingDate = @BusinessDate,      
     --Tr_nomor = @JournalCode, --Remarked by Niko FMF-4076
	 StatusDate = @BusinessDate,      
     ToleranceAmount = @ToleranceAmount, --Anton 16-10-2006      
     DtmUpd = getdate()    
    Where BranchID = @BranchID and ApplicationID = @ApplicationID And RequestNo = @RequestNo and Status = 'A'      
    Set @Error = @@error      
    If @Error > 0       
     Goto ExitSP
    
    Drop Table #TempTable
   --Insert InstallmentIncomeRecognize  
  
   --Nadhia, 21/08/2020 (FMF-2297)  
   IF @ContractStatus = 'ICP'  
    BEGIN  
        UPDATE  dbo.Agreement  
        SET     ContractStatus = 'LIV' ,  
                MaturityDate = MaxDueDate  
        FROM    dbo.Agreement a WITH ( NOLOCK )  
                INNER JOIN ( SELECT BranchId ,  
                                    ApplicationID ,  
                                    MAX(DueDate) MaxDueDate  
                             FROM   dbo.InstallmentSchedule isch WITH ( NOLOCK )  
                             GROUP BY BranchId ,  
                                    ApplicationID  
                           ) qry ON qry.BranchId = a.BranchID  
                                    AND qry.ApplicationID = a.ApplicationID  
        WHERE   a.BranchID = @branchid  
                AND a.ApplicationID = @ApplicationID  
    END  
   --End Nadhia  
     
   --Add Adhitya FMF-2303 16/08/2020 Menambahkan LateCharges Pada Angsuran Keberapa Jika IsFeebasePostPoned = 1  
   IF @IsFeeBasePostPonded = 1  
   BEGIN  
 update iis  
  set iis.LateCharges = phd.LCAmount  
 from InstallmentSchedule iis  
  inner join Agreement agr on iis.BranchID = agr.BranchID and iis.ApplicationID = agr.ApplicationID  
  inner join Rescheduling resc on iis.branchid = resc.BranchID and iis.ApplicationID = resc.ApplicationID and resc.IsFeeBasePostPonded = 1  
  inner join paymenthistoryheader phh on iis.BranchID = phh.BranchID and iis.ApplicationID = phh.ApplicationID and resc.Tr_Nomor = phh.Tr_Nomor and phh.ProcessID = 'RESC'  
  inner join paymenthistorydetail phd on phh.BranchID = phd.BranchID and phh.ApplicationID = phd.ApplicationID and phh.HistorySequenceNo = phd.HistorySequenceNo and PaymentAllocationID ='INSTALLRCV'  
 WHERE resc.Status = 'E' and phd.InsSeqno = iis.InsSeqNo and resc.RequestNo = @RequestNo and iis.BranchID = @branchid and iis.ApplicationID = @ApplicationID  
  
 Set @Error = @@error    
   If @Error > 0     
    Goto ExitSP   
  
 Update agr  
 set agr.LastLCInstallmentCalcDate = resc.EffectiveDate   
 FROM Agreement agr  
 INNER JOIN Rescheduling resc on agr.BranchID = resc.BranchID and agr.ApplicationID = resc.ApplicationID and resc.IsFeeBasePostPonded = 1  
 WHERE resc.OSLCInstallment > 0 AND resc.Status = 'E' and resc.RequestNo = @RequestNo  
   and agr.ApplicationID = @ApplicationID AND agr.BranchID = @BranchID  
  
 Set @Error = @@error    
   If @Error > 0     
    Goto ExitSP   
  
 Update agr  
 set agr.LastLCInsuranceCalcDate = resc.EffectiveDate   
 FROM Agreement agr  
 INNER JOIN Rescheduling resc on agr.BranchID = resc.BranchID and agr.ApplicationID = resc.ApplicationID and resc.IsFeeBasePostPonded = 1  
 WHERE resc.OSLCInsurance  > 0 and resc.Status = 'E' and resc.RequestNo = @RequestNo  
  and agr.ApplicationID = @ApplicationID AND agr.BranchID = @BranchID  
  
 Set @Error = @@error    
   If @Error > 0     
    Goto ExitSP   
  
   END  
   --End Adhitya FMF-2303  
         
   --Add Adhitya 22/04/2020 FMF-2185  
   IF EXISTS(SELECT '' FROM Rescheduling where BranchId = @BranchID and ApplicationID = @ApplicationID And RequestNo = @RequestNo And ReasonID='COVID')  
  BEGIN  
   DECLARE @gsvalueMonitoring varchar(1)  
   select @gsvalueMonitoring = GSID FROM GeneralSetting where GSID='ISRSCHMONITORING'  
  
   IF @gsvalueMonitoring = '1'  
   BEGIN  
    DECLARE @overdueDays int  
    SELECT @overdueDays = DaysOverdue from dailyaging where BranchId = @BranchID and ApplicationID = @ApplicationID and AgingDate = dateadd(d, -1, @BusinessDate)  
  
    /*  
    Declare @BucketOverDueBeforRescheduling varchar(100)  
  
    IF @overdueDays >= 1 AND @overdueDays < 31  
     BEGIN  
      set @BucketOverDueBeforRescheduling = 'OVD 001-030'  
     END  
    ELSE IF @overdueDays > 30 AND @overdueDays < 61  
     BEGIN  
      set @BucketOverDueBeforRescheduling = 'OVD 031-060'  
     END  
    ELSE IF @overdueDays > 60 AND @overdueDays < 91  
     BEGIN  
      set @BucketOverDueBeforRescheduling = 'OVD 061-090'  
     END  
    ELSE IF @overdueDays > 90 AND @overdueDays < 121  
     BEGIN  
      set @BucketOverDueBeforRescheduling = 'OVD 091-120'  
     END  
    ELSE IF @overdueDays > 120 AND @overdueDays < 151  
     BEGIN  
      set @BucketOverDueBeforRescheduling = 'OVD 121-150'  
     END  
    ELSE IF @overdueDays > 150 AND @overdueDays < 181  
     BEGIN  
      set @BucketOverDueBeforRescheduling = 'OVD 151-180'  
     END  
    ELSE IF @overdueDays > 180  
     BEGIN  
      set @BucketOverDueBeforRescheduling = 'OVD 180+'  
     END  
    ELSE  
     BEGIN  
      set @BucketOverDueBeforRescheduling = '0'  
     END  
     */  
  
    UPDATE Agreement   
     set Is_MonitoringAfterReschdule = 1, ReschedulingMonitoringDate = @BusinessDate, OverdueDaysBeforRescheduling = @overdueDays  
    where BranchId = @BranchID and ApplicationID = @ApplicationID  
    Set @Error = @@error      
    If @Error > 0       
     Goto ExitSP       
   END     
  END  
   --End Adhitya 22/04/2020 FMF-2185  
 end        
End      
      
--SELECT * FROM abc  
-- RollBack Transaction ReschedulingExec      
Commit Transaction ReschedulingExec      
Return @Error       
      
ExitSP:      
Begin      
 RollBack Transaction ReschedulingExec      
 Return @Error       
End  
GO

