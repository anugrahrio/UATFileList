USE [FMFDB]
GO
/****** Object:  StoredProcedure [dbo].[spProcessInventorySellingReceive]    Script Date: 02/01/2025 09:25:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




/*      
1. Jumat 23 July 2004 Jam 15:51: Parameter CompanyID Diikutsertakan, tambah jurnal REPOASSET      
2. Senen 27 Sept 2004 Jam 17:00: Jika Loss tidak usah ada journal Earn dan Earn Waived      
*/
/*      
 Modification : teddy, August 4th, 2004      
         Add New Process Insert Into InventorySelling        
 Modification : Andik , Sept 29th,2004      
         Modify All Process Journal, Multi Asset       
 Johnson, 5 Oct 2005 : Modify All Process!!!      
 Johnson, 21 Oct 2005 : - Ambil Currency Dengan @BranchAgreement      
         - Update AgreementAsset Set AssetStatus = 'SLD'      
 Johnson, 26 Januari 2006 : Ubah LCInstallmentPaid = LCInstallmentPaid + @LCInstallmentAloc - @LCInstallmentWaived,      
     LCInstallmentWaived  = LCInstallmentWaived + @LCInstallmentWaived      
     Update If @IsLastAssetSold = '1' then Update Agreement dan InstallmentSchedule      
 Johnson, 3 Feb 2006 : -Utk Pencarian Parm @IsLastAssetSold ubah kondisi dari       
       AssetStatus IN ('RFR', 'REP') menjadi AssetStatus NOT IN ('RRD', 'RLS')       
        - Update AgreementAsset.AssetStatus = 'RRD'      
 Johnson, 7 Feb 2006 : - Tambah Parm @NumAssetNotYetSold      
         - Ubah Kondisi Pencarian @IsLastAssetSold      
 Yovita, Mar 13 2006 : Add Condition IsNull For BankID      
 Yovita Mar 22 2006 : Change Where Cond For Updating PaidDate On Tbl InstallmentSchedule      
 Yovita Mar 22 2006 : Change Hierarki For Payment Allocation       
    From Installment, Interest, Insurance, RepoFee, LC Installment, LC     Insurance, PDCBounceFee      
    Become Installment, Insurance, RepoFee, Interest, LC Installment, LC     Insurance, PDCBounceFee      
 Yovita Mar 23 2006 : Add Condition, Agreement harus NA atau WO baru bisa selling      
 Johnson, Mar 23 2006:       
  1. pada spProcessInstallmentAllocation parm LCInstallment Kirim nilai 0      
  2. spProcessReposessionFee, spProcessReposessionWaived di Remark. Update secara Manual      
 Yovita May 22 2006 : Add Condition, Apakah Status di assetRepossessionOrder sudah Paid atau belom, jika sudah raiseerror      
 Yovita June 22 2006 : ganti Set @PaymentAllocationJournal = 'PDCBNCFWO' menjadi 'PDCBNCFEWO'      
 Gema 9 Agustus 2007 : RESIDUNPL dan SECDEPNPL               
 Yovita Oct 3 2007: Tambahin sp untuk allocation Amount Inc Recognize       
Arif 8 okt 2007: tambah jurnal untuk ARNA, UCIBA, diffrate, provision, incentive    
Yovita 14 Okt 2007 : Ubah kondisi untuk ARNA dan UCINA, jika bukan Last Asset ARNA ambil dari PrincipalAmountAloc+EarnAmountAloc dan UCINA dr EarnAmountAloc  
Yovita 18 Okt 2007: Jika bukan LastAssetSold maka DiffRate, Incentive dan Provision di set 0 saja  
        Add Update #TempTable dari ARNA jadi INSTALLRCV pd saat Create Payment History  
Yovita 19 Okt 2007: ubah paymentallocationid :  
      RFNDEXP --> RFNDAMZ  
      ECIRFNARNA --> RATERFNDNA  
      ECISUBARNA --> RATESSIDYNA  
      ECISSIDY --> SSIDYAMZ  
      untuk samain dengan KITAF  
Yovita 23 Oct 07: Apabila WO --> AR NA, UCI NA dan Amount Expense di 0 - kan, dan Create Journal CRTWORCV  
Yovita 23 Oct 07: Apabila bukan last asset, akui expensenya proportional dengan accrued interest   
Gema 31 Mar 2008 : ubah UCINA untuk Last Asset dari @UCINA = isNull(SUM(InterestAmount),0) menjadi @UCINA = isNull(SUM(InterestAmount - AmountIncRecognize),0) untuk handle parsial  
Gema 1 April 2008 : Tambah pengecekan apakah agreement nya masih di pledged atau tidak jika iya maka harus buyback dahulu.  
Leonita 23 April 2008 tambahan jika contractstatus='INV' dan perbaiki untuk validasi buyback hanya untuk contractstatus yg liv,icp dan icl  
  
1. Update AgreementAsset Set AssetStatus = 'RRD'      
  Where branchId = @BranchAgreement and ApplicationID = @ApplicationID and AssetSeqNo=@AssetSeqNo      
 If @@error <> 0       
 Begin      
  Goto ExitSP      
 End         
  
2.  Update AssetRepossessionOrder       
  Set    
   RepossesionStatus = 'P',       
   SoldJournalNo = @JournalCode,       
   VoucherNo = @VoucherNo,       
  PaidDate = @ValueDate,       
   PaidAmount = @AmountReceive,       
   SellingAmount = @AmountReceive      
   
        
3. if exists(select defaultstatus from agreement Where branchId = @BranchAgreement and ApplicationID = @ApplicationID  and defaultstatus='NA')  
 begin  
  UPDATE Agreement   
   set    
    NAPaid = NAPaid + @AmountReceive   
  Where branchId = @BranchAgreement and ApplicationID = @ApplicationID      
  If @@error <> 0       
   Begin      
    Goto ExitSP      
   End      
 end  
  
4. if exists(select defaultstatus from agreement Where branchId = @BranchAgreement and ApplicationID = @ApplicationID  and defaultstatus='WO')  
  begin  
   UPDATE Agreement   
    set    
     WOPaid = WOPaid + @AmountReceive   
   Where branchId = @BranchAgreement and ApplicationID = @ApplicationID      
   If @@error <> 0       
    Begin      
     Goto ExitSP      
    End      
  end  
  
5.  If @IsLastAssetSold = '1'      
   BEGIN       
     
    Update Agreement      
     Set   
     OutstandingPrincipal = 0,       
     OutstandingInterest = 0,      
    ContractStatus = 'RRD',      
     RRDDate = @Valuedate  
         
    Where branchId = @BranchAgreement and ApplicationID = @ApplicationID      
        
   END     
Leonita 27 April 2008 tambahan update nextinsallmentnumber dan nextinstallmentduenumber ='999'   
Leonita 6 May 2008 perbaiki RATESSIDYNA menjadi RATESIDYNA  
Andy 15 Mei 2008 : mengupdate AmountReceive pada table exinvsellingheader  
Lisa 20081109 : Ganti cara ambil UCINA utk lastassetsold  
Gema, 20081107 : Add Journal AdminFee dan perbaiki tutup journal diffrate, prov dan incv kalau WO dan NA     
Gema, 20081111 : Tambah parameter @AdminFee pd saat exec spRemedialAccrualAllocation   
Gema, 20081112 : Tambah if or untuk cekjika ada accrued expense, bukan hanya lihat eci   
Amelya 20081128 : Gabungin perubahan Gema dan Lisa  
Lisa 20081202 : Tambah plus ReceiveAmount nya untuk handle multiasset pada saat update ExInvSellingHeader  
Lisa 20090430 : Tambah untuk handle partial payment yg lbh besar dari principal 
Chris 20090515 : Tambah OtherInc (Perbaikan Tendi)
Lisa 20091012 : Remark perbaikan partial payment
Rubianto, 20100413 : Tambahkan komponen psak  
Arie, 24 09 2010: Menambahkan INSERT ke COLLECTION EVENT History 
Lisa 20101112 : Tambah kondisi jika ada advance payment yang belum ter recognize
Lisa 20101202 : Remark penambahan kondisi advance payment karena tidak sesuai dengan kondisi normal
Ruth, 20110323 : Remark @BranchId jadi @BrancAgreement
harry 07 Sep 2011 : tambah parameter @ReceiptNoFormControl untuk nyimpen nomor receive
Dewi, 28 June 2012 : tambah pengecekan apabila OSInterestnya 0 langsung di set 0 item PSAK nya.
Gema, 20121112 : CR FMF-1245 CR Perhitungan PNL INV Selling Receive, ubah urutan alokasi pembayaran dimana hanya dialokasi untuk pokok dan OS NetRate.
                 yang lainnya di discount. 
Dewi, 8 Feb 2013 : bentuk journal tutup security deposit hanya untuk defaultstatus='NA'
Dessy, 27022014 (FMF-1337) : ubah urutan OTHERINC agar journalnya balance
Rendi 3 okt 2014 [FMF-1383]
Rendi 1 DES 2014 [FMF-1405] tambah Pengecekan, Jika Agreement = NM maka langsung di NA otomatis
Rendi 18 DES 2015 [FMF-1464] : Ganti parameter ketika alokasi ke iinstallment, ambil dari @ARNA bukan dari @Amountreceive
jordan.ft, 5 jan 2016 (FMF-1577) : saat EXEC spStopAccruedAutomatic rubah lemparan param dari @BranchID => @BranchAgreement
Novia, 21 Maret 2016 [FMF-1487] : perbaikan agar handle pembayaran PARTIAL
Rendi 30 maret 2016 [FMF-1495]  : innerjoin ke agreement agar NAAmountResidue u/ kontrak bayar partial di kurang NApaid-NAWaived
Rendi 7 april 2016 [FMF-1498]   : tambah inner join ke agreement dan tambah wherecond NADate < '20160317' (jika kontrak NA sesudah CR alokasi interest golive maka ambil dari agreement)
Fuji,17 Mei 2018 ( FMF-1649) : tambah jurnal inv jika kontrak wo dan sedang di jual ke bank yang IsPaymentHierarchy nya = 1
Restu, FMF-1725 2 Nov 2018 : Tambah penjagaan apabila paidamount di ARO <> @AmountReceive maka raiseerror
Budiman, add [FMF-1731] 13 Nov 2018  tambah komponen PSAK lainnya
Budiman [FMF-1754], 21 Desember 2018 tambah validasi untuk kontrak yang masih di pledge, maka kontrak tidak boleh dilakukan selling receive
Aditia 20052019 tambah penjagaan lolos inventory selling untuk kontrak btpn ispaymenthirarki = 1
Fuji,07 Nov 2019 (fmf-1782 phase 2 B -UAT) : Perbaiki Jurnal Execution Cost dan Prepaid BNK
Fuji,26112019 (fmf-1900) : Perbaiki cara ambil ispaymenthirarki yang benar dari BranchAgreement bukan BranchReceive
Ria 02012020 set @FundingCoyPortionAgr=100
Silvia, 24 Februari 2020 [FMF-2078] : Ubah cara hitung SellingAmountBankPortion, menggunakan porsi MF di FundingContract, bukan dari Porsi Agreement/FundingAgreement
Silvia, 24 Maret 2020 [FMF-2140] : Ubah cara ambil COA PrepaidBNK, menjadi ambil dari CoaAPOther FundingCoy (FnGetCoaChanneling), diupdate setelah buat journal
Candra 30 Nov 2020 [FMF-2386]: tambah Select * from #temptable agar muncul temp journal
Silvia, 01 Des 2020 [PI-2114] : Tambah perbaikan terkait error FMF-2386, jika kondisi kontrak di insseqno Rollover ada Interest yang belum diakui akan mengurangi nilai journal REPOPNL 
Raug, 20 April 2021 [FMF-2725] : Menambahkan If islastasset = 1 pada REPOPNL
Raug, 2 Juni 2021 [FMF-2725] : Menggubah Lemparan Data untuk spProcessCreatePaymentHistory dari @BranchAgreement menjadi @BranchId
Niko, 7 Juli 2021 [FMF-2863] : Perbaikan PSAK AdminFee dan CostofSurvey agar handle Plus Minus
Vincenza FMF-2847 28072021 : Perubahan Journal REPOPNL Menjadi REPOLOSS serta PREPAID jika sesuai AssetTypeID
Vincenza FMF-2934 23082021 : Perubahan Tanpa InterestWO, LCInstallWO dan ECI
Raug, FMF-3172 24 Nov 2021 : Menambahkan ISNULL pada saat menghitung nilai @EarnAmount
Raug, FMF-3182 26 Nov 2021 : Tambah update untuk kontrak Factoring, ContractStatus jadi EXP, AssetStatus jadi RLS dan AssetDocStatus jadi R 
Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus, dan perbaiki di Journal PSAK supaya handle plus minus juga
Vincenza FMF-3221 08122021 : Perubahan REPOLOSS jadi DF dan EXP serta insert ke DF
Raug, FMF-3246 21 Des 2021 : tambah menjalankan spMoveToExpTable jika elektronik, KTA, atau kontrak isfactoring
Raug, FMF-3267 29 Des 2021 : Menambahkan pengecekan islastassetsold sebelum menjalankan spMoveToExpTable
Jason, FMF-3473 06 April 2022 : Penambahan Update DTMUPD di agreemeent ketika proses ISL
Victor, 25 February 2022 [FMF-3170] :   - Tambah hitung ulang ExecutionCost menggunakan function
										- Ubah cara update ExecutionCost di ExInvSellingHeader, jadi disummarykan dengan ExecutionCost existingnya
Victor, FMF-3439 22 Mar 2022 : remark validasi agar WOF leaseback juga menggunakan perhitungan CR LOI
Jason, 15 Agustus 2022 [FMF-3705] : Penambahan validasi jika ada kontrak yang masih ada gantungan STNK Request.
Jason, 2 September 2022 [FMF-3744] : Perbaikan cara update LCAmount di PaymentHistoryDetail dan LateCharges di InstallmentSchedule saat ISL terkait perubahan CR FMF-2934 yang mengubah cara hitung LC sampai dengan NA Date
Ria 9 Sep 2023 FMF-4450 PMK41
Fajar, 21 Sepember 2023 [FMF-4450] : Generate Invoice No dan Update table exinvsellingdetail InvoiceNo dan InvoiceDate
Reyvano, 29 November 2023 [FMF-4746] : Menambahkan perbaikan jika ada pembayaran dipercepat, maka sisa interestamountnya harus mengurangi nilai REPOLOSS
Ria 6 Dec 2023 FMF-4765	fixing receive amount untuk multiasset 
Reyvano, 6 Desember 2023 [FMF-4769] : Tambah pengecekan saat ambil @DiffforREPOPNL2 (Interest atas pembayaran dipercepat) apakah hasil ISL atau bukan, kalau bukan hasil ISL baru ngurangin Repoloss
Ria 7 Dec 2023 FMF-4765	tambah validasi DPP 
Reyvano, 17 April 2024 [FMF-5008] : tambah penjagaan terhadap perbedaan tanggal harinya, tanggal BDCurrent, dan tanggal BusinessDate. agar tetap selalu sama
Sugiono 14 Agustus 2024 FMF-5138 CLONE - Perbaikan perhitungan untuk earned income atas transaksi inventory selling : handling kontrak NA dengan NADate > EOM , NADate < DueDate
Vita N 16 Okt 2024 (FMF-5185) : tambah kondisi untuk hitung @LCInstallmentCurrent hanya untuk kontrak non interval LC 
Reyvano A 22 Nov 2024 (FMF-5229) : ubah cara ambil amount dan pembuatan untuk jurnal ECI dan REPOLOSS 
Aurellie 31 Des 2024 (FMF-5308) Inventory Selling Receive Journal Transactions Not Balance 2 Kontrak : ubah @BranchId jadi @BranchAgreement di ECIAmount
Aurellie 2 Jan 2025 (FMF-5310) : ubah parameter @BranchId yang relate dengan tiket FMF-5229 jadi @BranchAgreement, tambah ISNULL pada perhitungan installment
*/



ALTER PROCEDURE [dbo].[spProcessInventorySellingReceive]
    @BranchID AS VARCHAR(3),
    @CompanyId CHAR(3),
    @ApplicationID AS VARCHAR(20),
    @ValueDate AS DATETIME,
    @BusinessDate AS DATETIME,
    @LoginID AS VARCHAR(12),
    @BankAccountID AS VARCHAR(10),
    @AmountReceive AS Amount,
    @Notes AS VARCHAR(100),
    @ReceivedFrom AS VARCHAR(50),
    @ReferenceNo AS VARCHAR(20),
    @WOP AS VARCHAR(2),
    @BranchAgreement CHAR(3),
    @AssetSeqNo SMALLINT,
    @RequestNo CHAR(20),
                                 -- harry 
    @ReceiptNoFormControl AS VARCHAR(20) = '',
    @ExecutionCost Amount = NULL --Sugiono 04 Okt 2019 FMF-1782 CR BTPN PARTIAL PAYMENT Phase 2 
AS
--SELECT * FROM abc
SET NOCOUNT ON;
DECLARE @Error AS INT;
SET @Error = 0;
BEGIN TRANSACTION InventorySellingReceive;

----Add Reyvano [FMF-5008] 17 April 2024
--DECLARE @TanggalHariIni DATE;
--DECLARE @BDCurrent DATE;
--DECLARE @ErrMessage VARCHAR(100);
--DECLARE @ErrMessage2 VARCHAR(100);

--SELECT @TanggalHariIni = GETDATE();
--SELECT @BDCurrent = BDCurrent
--FROM dbo.SystemControlCoy WITH (NOLOCK);
--SET @ErrMessage
--    = 'Current date : ' + CAST(CAST(@TanggalHariIni AS DATE) AS CHAR(10)) + ' is different with system date : '
--      + CAST(CAST(@BDCurrent AS DATE) AS CHAR(10)) + ' , please ReLogin';
--SET @ErrMessage2
--    = 'System date : ' + CAST(CAST(@BDCurrent AS DATE) AS CHAR(10)) + ' is different with BusinessDate : '
--      + CAST(CAST(@BusinessDate AS DATE) AS CHAR(10)) + ' , please ReLogin';

--IF @TanggalHariIni <> @BDCurrent
--BEGIN
--    RAISERROR(@ErrMessage, 16, 1);
--    GOTO exitsp;
--END;

--IF @BDCurrent <> CAST(@BusinessDate AS DATE)
--BEGIN
--    RAISERROR(@ErrMessage2, 16, 1);
--    GOTO exitsp;
--END;
----End Reyvano [FMF-5008]

-- tambah validasi 7 Dec 2023
IF EXISTS
(
    SELECT ''
    FROM ExInvSellingDetail a
        INNER JOIN ExInvSellingHeader b
            ON a.RequestNo = b.RequestNo
    WHERE a.RequestNo = @RequestNo
          AND ApplicationId = @ApplicationID
          AND AssetSeqNo = @AssetSeqNo
          AND BiddingType = 'M'
          AND ABS(ISNULL(a.DPP, 0) + ISNULL(a.PPN, 0) - ISNULL(a.SellingAmount, 0)) > 100
)
BEGIN
    RAISERROR('Please check Lelang Mandiri calculation!', 16, 1);
    GOTO exitsp;
END;

IF EXISTS
(
    SELECT ''
    FROM ExInvSellingDetail a
        INNER JOIN ExInvSellingHeader b
            ON a.RequestNo = b.RequestNo
    WHERE a.RequestNo = @RequestNo
          AND ApplicationId = @ApplicationID
          AND AssetSeqNo = @AssetSeqNo
          AND BiddingType = 'B'
          AND ABS(ISNULL(a.DPP, 0) - ISNULL(a.SellingAmount, 0)) > 100
)
BEGIN
    RAISERROR('Please check Balai Lelang calculation!', 16, 1);
    GOTO exitsp;
END;

IF EXISTS
(
    SELECT ''
    FROM ExInvSellingDetail a
        INNER JOIN ExInvSellingHeader b
            ON a.RequestNo = b.RequestNo
    WHERE a.RequestNo = @RequestNo
    GROUP BY b.DPP
    HAVING ABS(ISNULL(SUM(a.DPP), 0) - ISNULL(b.DPP, 0)) > 100
)
BEGIN
    RAISERROR('Please check DPP amount!', 16, 1);
    GOTO exitsp;
END;

-- tambah validasi 7 Dec 2023

---Victor, 25 February 2022 [FMF-3170] : Tambah hitung ulang ExecutionCost menggunakan function
SET @ExecutionCost = dbo.[FnGetExecutionCost](@BranchAgreement, @ApplicationID);
---End Victor [FMF-3170]

DECLARE @OpeningSequence INT,
        @SellingDate DATETIME,
        @SellingAmount Amount,
        @EfectiveDate DATETIME,
        @RequestDate DATETIME,
        @PrepaymentType CHAR(2),
        @TotalAmountToBePaid Amount,
        @PrepaymentAmount Amount,
        @PrepaymentFee Amount,
        @OSPrincipal Amount,
        @OSInterest Amount,
        @OSInstallmentDue Amount,
        @OSInsuranceDue Amount,
        @OSLCInstallment Amount,
        @OSLCInsurance Amount,
        @LCInstallmentCurrent Amount,
        @LCInsuranceCurrent Amount,
        @OSInstallCollectionFee Amount,
        @OSInsurCollectionFee Amount,
        @OSPDCBounceFee Amount,
        @OSSTNKRenewalFee Amount,
        @OSRepossessFee Amount,
        @OSInsuranceClaimExpense Amount,
        @AccruedInterest Amount,
        @InsuranceWaived Amount,
        @ReposessWaived Amount,
        @LCInstallmentWaived Amount,
        @LCInsuranceWaived Amount,
        @InstallCollectionWaived Amount,
        @InsurCollectionWaived Amount,
        @PDCBounceWaived Amount,
        @InstallmentWaived Amount,
        @STNKWaived Amount,
        @InsuranceClaimExpenseWaived Amount, --@PrepaidAmount   Amount,      
        @PrepaidAmountAgreement Amount,      --Added by Reyvano FMF-5229 
        @PrepaidAmountAllocation Amount,
        @ReasonTypeID CHAR(5),
        @JournalNo TransactionNo,
        @InventoryAmount Amount,
        @ProfitLossAmount Amount,
        @ProfitLossIterasi Amount,
        @TotalInterestAmount Amount,
        @TotalIncomeRecognizeAmount Amount,
        @AccruedAmount Amount,
        @EarnAmount Amount,
        @EarnWaived Amount,
        @EarnPaid Amount,
        @ProfitLoss Amount,
        @RepossesSeqNO SMALLINT,
        @RefDesc VARCHAR(50),
        @TotalInstallment Amount,
        @TotalAmountPrepayment Amount,
        @TotalDiscount Amount,
        @Counter INT,
        @CounterOtherInc INT,                --Added by Reyvano FMF-5229
        @AmountJournal Amount,
        @PostJournal VARCHAR(1),
        @AgreementNo VARCHAR(20),
        @StatusDefault VARCHAR(2),
        @FinanceType VARCHAR(2),
        @Downpayment Amount,
        @ProductID ProductID,
        @NextInstallmentNumber INT,
        @LastOSInterest Amount,
        @AmountIncRec Amount,
        @PaymentAllocationJournal VARCHAR(20),
        @TransactionID VARCHAR(50),
        @JournalCode VARCHAR(20),
        @ProcessID VARCHAR(20),
        @InterestAmount Amount,
        @VoucherNo VARCHAR(20),
        @AssetStatus CHAR(3),
        @OutStandingPrincipal Amount,
        @CurrencyID CHAR(3),
        @Rate Amount,
        @LostGain Amount,
        @CoaBank JournalCOA,
        @ContractStatus CHAR(3),
        @CurrencyRounded NUMERIC(17, 2),
                                             --------------------------      
        @NAAmountResidue Amount,
        @NAWaived Amount,
        @WOAmountResidue Amount,
        @WOWaived Amount,
        @AmountReceiveResidue Amount,
        @IsLastAssetSold CHAR(1),
        @BankID CHAR(5),
        @NAAmountAloc Amount,
        @WOAmountAloc Amount,
        @EarnAmountAloc Amount,
        @OSInsuranceDueAloc Amount,
        @OSRepossessFeeAloc Amount,
        @LCInstallmentAloc Amount,
        @LCInsuranceAloc Amount,
        @OSPDCBounceFeeAloc Amount,
        @PrepaidAloc Amount,
        @LostAmount Amount,
        @HistorySequenceNo INT,
        @OSInstallmentDueBefore Amount,
        @OSInstallmentDueAfter Amount,
        @InstallmentAloc Amount,
        @NumAssetNotYetSold INT,
        @OSDiffRate Amount,
        @OSProvision Amount,
        @OSIncentive Amount,
        @OSAdminFee Amount,
                                             /*Rubianto, 20100413*/
        @OSInsuranceIncome Amount,
        @OSOtherRefund Amount,
        @OSAdmFee Amount,
        @OSProvisionFee Amount,
        @OSOtherFee Amount,
        @OSSurveyFee Amount,
        @OSDeferredInsurance Amount,
                                             /*Rubianto End*/
                                             --arif 15 okt 2010
        @OSCostOfSurvey Amount,
        @DefaultStatus CHAR(3);              --Rendi 1 Des 2014 Declare

--add fuji,16 Mei 2018
DECLARE @CalOSPrincipalAmount Amount,
        @PrepaidBNK Amount,
        @RepoFeeBankPortion Amount;

SET @CalOSPrincipalAmount = 0;
SET @PrepaidBNK = 0;
SET @RepoFeeBankPortion = 0;
--end fuji

---Raug 26 Nov 2021 FMF-3182
DECLARE @IsFactoring BIT;

---Raug 21 Desc 2021 FMF-3246
DECLARE @strerror VARCHAR(100);
SET @strerror = '';
---End Raug FMF-3246




--Add Fajar 21/09/2023 FMF-4450
DECLARE @Year INT = YEAR(@BusinessDate);
DECLARE @Month INT = MONTH(@BusinessDate);
DECLARE @Sequenceno INT;

SELECT @Sequenceno = SequenceNo
FROM MasterSequence WITH (NOLOCK)
WHERE MSSequenceID = 'INCOICEAS'
      AND BranchID = '999';

DECLARE @RomanMonth NVARCHAR(20);
SELECT @RomanMonth = CASE
                         WHEN @Month = 1 THEN
                             'I'
                         WHEN @Month = 2 THEN
                             'II'
                         WHEN @Month = 3 THEN
                             'III'
                         WHEN @Month = 4 THEN
                             'IV'
                         WHEN @Month = 5 THEN
                             'V'
                         WHEN @Month = 6 THEN
                             'VI'
                         WHEN @Month = 7 THEN
                             'VII'
                         WHEN @Month = 8 THEN
                             'VIII'
                         WHEN @Month = 9 THEN
                             'IX'
                         WHEN @Month = 10 THEN
                             'X'
                         WHEN @Month = 11 THEN
                             'XI'
                         WHEN @Month = 12 THEN
                             'XII'
                         ELSE
                             ''
                     END;

DECLARE @InvoiceNumber NVARCHAR(100);

--Vita N 16 Okt 2024 (FMF-5185)
DECLARE @IsIntervalLCScheme BIT;
SELECT @IsIntervalLCScheme = IsIntervalLCScheme
FROM dbo.Agreement
WHERE BranchID = @BranchID
      AND ApplicationID = @ApplicationID;
--End Vita

-- PMK41
DECLARE @PPN Amount,
        @DPP Amount,
        @mobfee Amount,
        @bidfee Amount,
        @allocationamount Amount;
SELECT @PPN = ISNULL(SUM(PPN), 0),
       @DPP = ISNULL(SUM(DPP), 0),
       @mobfee = ISNULL(SUM(MobilisationFee), 0),
       @bidfee = ISNULL(SUM(BiddingFee), 0)
FROM ExInvSellingDetail
WHERE RequestNo = @RequestNo
      AND ApplicationId = @ApplicationID
      -- ria
      AND AssetSeqNo = @AssetSeqNo;


IF ISNULL(@PPN, 0) > 0
   OR ISNULL(@mobfee, 0) > 0
   OR ISNULL(@bidfee, 0) > 0
   OR ISNULL(@DPP, 0) > 0
BEGIN
    SELECT @AmountReceive = ISNULL(@DPP, 0) + ISNULL(@PPN, 0) - ISNULL(@mobfee, 0) - ISNULL(@bidfee, 0);
    SELECT @allocationamount = ISNULL(@DPP, 0) - ISNULL(@mobfee, 0) - ISNULL(@bidfee, 0);
    --if @AmountReceive < 0 or @allocationamount < 0 or @AmountReceive < @allocationamount
    IF @AmountReceive <= 0
       OR @allocationamount <= 0
       OR @AmountReceive < @allocationamount
    BEGIN
        RAISERROR('Please check calculation!', 16, 1);
        GOTO exitsp;
    END;
    IF ISNULL(@PPN, 0) > 0
    BEGIN
        SET @InvoiceNumber
            = CAST(@Sequenceno AS NVARCHAR(10)) + N'/KBFMF/INV/' + @RomanMonth + N'/' + CAST(@Year AS NVARCHAR(4));

        UPDATE ExInvSellingDetail
        SET InvoiceNo = @InvoiceNumber,
            InvoiceDate = @BusinessDate
        WHERE RequestNo = @RequestNo
              AND ApplicationId = @ApplicationID
              AND BranchId = @BranchAgreement --@BranchID
              -- ria
              AND AssetSeqNo = @AssetSeqNo;

        UPDATE MasterSequence
        SET SequenceNo = SequenceNo + 1
        WHERE MSSequenceID = 'INCOICEAS'
              AND BranchID = '999';
    END;
END;
ELSE
BEGIN
    SET @allocationamount = @AmountReceive;
END;

PRINT '@allocationamount';
PRINT @allocationamount;

--end Fajar   



SELECT @IsFactoring = AssetType.isFactoring
FROM Agreement WITH (NOLOCK)
    INNER JOIN ProductOffering WITH (NOLOCK)
        ON Agreement.ProductID = ProductOffering.ProductID
           AND Agreement.ProductOfferingID = ProductOffering.ProductOfferingID
           AND Agreement.BranchID = ProductOffering.BranchID
    INNER JOIN AssetType WITH (NOLOCK)
        ON ProductOffering.AssetTypeID = AssetType.AssetTypeID
WHERE Agreement.BranchID = @BranchAgreement
      AND Agreement.ApplicationID = @ApplicationID;
---End Raug FMF-3182

DECLARE @NADate DATETIME,
        @WayOfFinancingID VARCHAR(2); --Vincenza FMF-2934 07092021

--Aditia 20052019
DECLARE @IsPaymentHierarchy BIT;
SELECT @IsPaymentHierarchy = ISNULL(fc.IsPaymentHierarchy, 0),
       --Vincenza FMF-2934
       @WayOfFinancingID = a.WayofFinancingID
FROM Agreement a WITH (NOLOCK)
    LEFT JOIN FundingContract fc WITH (NOLOCK)
        ON a.FundingCoyID = fc.FundingCoyID
           AND a.FundingContractID = fc.FundingContractNo
--WHERE	a.BranchID = @BranchID AND a.ApplicationID = @ApplicationID-- Comment Sugiono FMF-1782
WHERE a.BranchID = @BranchAgreement
      AND a.ApplicationID = @ApplicationID; --Sugiono FMF-1782
--END Aditia

--Add Fuji,07 nov 2019 (fmf-1782 - phase 2B UAT)
DECLARE @ExecutionCostBankPortion Amount,
        @FundingCoyPortionAgr NUMERIC(9, 6);

--Vincenza 26072021 FMF-2847
DECLARE @AssetTypeID VARCHAR(10),
        @FlagAssetTypeID BIT,
        @AssetTypeIDRepoloss VARCHAR(100),
        @Delimiter CHAR = ',';
SET @FlagAssetTypeID = 0;
SELECT @AssetTypeIDRepoloss = ISNULL(GSValue, '')
FROM GeneralSetting WITH (NOLOCK)
WHERE GSID = 'ASSETTYPEIDREPOLOSS';
SELECT TOP 1
       @AssetTypeID = AssetTypeID
FROM AgreementAsset WITH (NOLOCK)
WHERE BranchID = @BranchAgreement
      AND ApplicationID = @ApplicationID;

IF @AssetTypeIDRepoloss <> ''
BEGIN
    CREATE TABLE #AssetTypeIDTable
    (
        AssetTypeID VARCHAR(10) PRIMARY KEY
    );

    INSERT INTO #AssetTypeIDTable
    SELECT LTRIM(RTRIM(Split.a.value('.', 'VARCHAR(100)'))) 'Value'
    FROM
    (
        SELECT CAST('<M>' + REPLACE(@AssetTypeIDRepoloss, @Delimiter, '</M><M>') + '</M>' AS XML) AS Data
    ) AS A
        CROSS APPLY Data.nodes('/M') AS Split(a);


    IF EXISTS
    (
        SELECT ''
        FROM #AssetTypeIDTable WITH (NOLOCK)
        WHERE AssetTypeID = @AssetTypeID
    )
    BEGIN
        SET @FlagAssetTypeID = 1;
    END;
    DROP TABLE #AssetTypeIDTable;
END;

--Remark Victor 22 Maret 2022 FMF-3439 remark kondisi WOF LB agar menggunakan perhitungan CR LOI
--if @WayOfFinancingID = 'LB'
--begin
--	set @FlagAssetTypeID = 0
--end
--End Remark Victor 22 Maret 2022 FMF-3439 remark kondisi WOF LB agar menggunakan perhitungan CR LOI
--end Vincenza

--select @FundingCoyPortionAgr=ISNULL(FUNDINGCOYPORTION,0) from FundingAgreement with (nolock) 
--where BranchID = @BranchAgreement 
--AND ApplicationID = @ApplicationID
--ria 2 Jan 2020
SET @FundingCoyPortionAgr = 100;

SET @ExecutionCostBankPortion = @ExecutionCost * @FundingCoyPortionAgr / 100;

--end fuji

---Silvia, 24 Februari 2020 [FMF-2078] : Ambil FundingCoyPortion nya FundingContract
DECLARE @CoyPortionFundingContract NUMERIC(9, 6);

SELECT @CoyPortionFundingContract = FC.FundingCoyPortion
FROM FundingContract FC WITH (NOLOCK)
    INNER JOIN Agreement AGR WITH (NOLOCK)
        ON FC.FundingCoyID = AGR.FundingCoyID
           AND FC.FundingContractNo = AGR.FundingContractID
WHERE AGR.BranchID = @BranchAgreement
      AND AGR.ApplicationID = @ApplicationID;

SET @CoyPortionFundingContract = ISNULL(@CoyPortionFundingContract, 0);
---End Silvia [FMF-2078]


--Budiman FMF-1754, 21 Desember 2018 tambah validasi untuk kontrak yang masih di pledge, maka kontrak tidak boleh dilakukan selling receive
IF EXISTS
(
    SELECT ''
    FROM Agreement WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationID
          AND BranchID = @BranchAgreement
          AND FundingCoyID IS NOT NULL
          AND FundingCoyID <> ''
          AND FundingCoyID <> '-'
          AND @IsPaymentHierarchy = 0
) --Aditia 20052019 Tambah @IsPaymentHierarchy
BEGIN
    RAISERROR('Contract is being pledged! Please BuyBack First', 16, 1);
    GOTO exitsp;
END;
--End Budiman

--Rendi 1 DES 2014 [FMF-1405] tambah Pengecekan, Jika Agreement = NM maka langsung di NA otomatis
SELECT @DefaultStatus = DefaultStatus
FROM dbo.Agreement
WHERE ApplicationID = @ApplicationID;
IF @DefaultStatus = 'NM'
BEGIN

    --SELECT 'masuk', @BusinessDate as dated, /*@BranchID*/ @BranchAgreement AS branch, @ApplicationID AS appid
    EXEC spEODStopAccruedAutomatic @BusinessDate,    /*@BranchID*/
                                   @BranchAgreement, --MODIFIED BY jordan.ft, 5 jan 2016 (FMF-1577) : rubah dari BranchID => BranchAgreement
                                   @ApplicationID,
                                   '',
                                   '';
    PRINT 'DefaultStatus';
    PRINT @DefaultStatus;

END;
--End Rendi

--Andy 15 Mei 2008 BEGIN  



UPDATE ExInvSellingHeader
SET ReceiveAmount = ISNULL(ReceiveAmount, 0) + ISNULL(@AmountReceive, 0), -- Lisa 20081202 : Tambah plus ReceiveAmount nya untuk handle multiasset
                                                                          ---Victor, 25 February 2022 [FMF-3170] : Ubah cara update ExecutionCost di ExInvSellingHeader, jadi disummarykan dengan ExecutionCost existingnya
                                                                          --,ExecutionCost = ISNULL(@ExecutionCost,0) --Add Sugiono FMF-1782
    ExecutionCost = ISNULL(ExecutionCost, 0) + ISNULL(@ExecutionCost, 0)
---End Victor [FMF-3170]
WHERE RequestNo = @RequestNo;

--Andy 15 Mei 2008 END  





--  sp_datadictionary2 BankAccount      

-- Yovita Mar 23 2006 : Add Condition, Agreement harus NA atau WO baru bisa selling   



IF NOT EXISTS
(
    SELECT ''
    FROM Agreement
    WHERE BranchID = @BranchAgreement
          AND ApplicationID = @ApplicationID
          AND DefaultStatus IN ( 'NA', 'WO' )
)
BEGIN
    PRINT '-';
END;
ELSE
-- Yovita May 22 2006 : Add Condition, Apakah Status di assetRepossessionOrder sudah Paid atau belom, jika sudah raiseerror      
IF EXISTS
(
    SELECT ''
    FROM AssetRepossessionOrder
    WHERE BranchId = @BranchAgreement
          AND ApplicationId = @ApplicationID
          AND AssetSeqNo = @AssetSeqNo
          AND RepossesionStatus = 'P'
)
BEGIN
    PRINT '-';

END;
ELSE
BEGIN
    --print 'masuk'
    SELECT @CurrencyRounded = Rounded
    FROM Currency WITH (NOLOCK)
        INNER JOIN Agreement WITH (NOLOCK)
            ON Agreement.CurrencyID = Currency.CurrencyID
    WHERE Agreement.BranchID = @BranchAgreement
          AND Agreement.ApplicationID = @ApplicationID;

    SELECT @RepossesSeqNO = MAX(RepossesSeqNo)
    FROM AssetRepossessionOrder WITH (NOLOCK)
    WHERE BranchId = @BranchAgreement
          AND ApplicationId = @ApplicationID
          AND AssetSeqNo = @AssetSeqNo;

    SELECT @NumAssetNotYetSold = COUNT(AssetSeqNo)
    FROM AgreementAsset
    WHERE BranchID = @BranchAgreement
          AND ApplicationID = @ApplicationID
          AND AssetStatus NOT IN ( 'RRD', 'RLS' );

    -- Lisa 20090430 : Tambah untuk handle partial payment yg lbh besar dari principal
    DECLARE @ECIPartial Amount;
    SET @ECIPartial = 0;

    SELECT @ECIPartial = (PaidAmount - PrincipalAmount)
    FROM InstallmentSchedule
    WHERE AmountIncRecognize = 0
          AND PaidAmount <> InstallmentAmount
          AND PaidAmount > PrincipalAmount
          AND BranchId = @BranchAgreement
          AND ApplicationID = @ApplicationID;
    -- End Lisa 20090430

    IF @NumAssetNotYetSold > 1
    BEGIN
        SET @IsLastAssetSold = '0';
    END;
    ELSE
    BEGIN
        SET @IsLastAssetSold = '1';
    END;

    SELECT @CoaBank = COA,
           @BankID = ISNULL(BankID, '-')
    FROM BankAccount WITH (NOLOCK)
    WHERE BranchID = @BranchID
          AND BankAccountID = @BankAccountID;

    SET @LCInsuranceWaived = 0;
    SET @LCInstallmentWaived = 0;
    SET @InstallCollectionWaived = 0;
    SET @InsurCollectionWaived = 0;
    SET @InsuranceClaimExpenseWaived = 0;
    SET @InsuranceWaived = 0;
    SET @PDCBounceWaived = 0;
    SET @STNKWaived = 0;
    SET @ReposessWaived = 0;
    SET @SellingAmount = @AmountReceive;
    SET @EarnAmount = 0;
    SET @EarnWaived = 0;



    SELECT @AgreementNo = AgreementNo,
           @BranchAgreement = BranchID,
           @StatusDefault = DefaultStatus,
           @ProductID = ProductID,
           @FinanceType = FinanceType,
           @Downpayment = DownPayment,
           @LastOSInterest = OutstandingInterestUndue,
                            --@InventoryAmount=OutStandingPrincipal,      
           @CurrencyID = CurrencyID,
           @ContractStatus = ContractStatus,
           @NADate = NADate --Vincenza FMF-2934 07092021
    FROM dbo.Agreement AGR
    WHERE AGR.BranchID = @BranchAgreement
          AND AGR.ApplicationID = @ApplicationID;

    SELECT @Rate = DailyExchangeRate
    FROM Currency
    WHERE CurrencyID = @CurrencyID;

    SELECT @AssetStatus = AssetStatus
    FROM AgreementAsset
    WHERE BranchID = @BranchAgreement
          AND ApplicationID = @ApplicationID
          AND AssetSeqNo = @AssetSeqNo;

    CREATE TABLE #TempTable
    (
        SeqNo INT IDENTITY PRIMARY KEY,
        PaymentAllocationID CHAR(20),
        Post CHAR(1),
        Amount NUMERIC(17, 2),
        RefDesc VARCHAR(50),
        DepartementID VARCHAR(3),
        VoucherDesc VARCHAR(50)
    );



    SET @ProcessID = 'INVSELLRCV';
    SET @TransactionID = 'ISL';

    -- Untuk Metode inventory        
    IF @ContractStatus = 'INV'
    BEGIN



        SELECT @InventoryAmount = InventoryAmount
        FROM AssetRepossessionOrder
        WHERE BranchId = @BranchAgreement
              AND ApplicationId = @ApplicationID
              AND AssetSeqNo = @AssetSeqNo
              AND RepossesSeqNo = @RepossesSeqNO
              AND RepossesionStatus = 'S';



        --FYI : @LostGain > 0 Untung, @LostGain < 0 Rugi      
        --SET @LostGain = @SellingAmount - @InventoryAmount    
        --SET @LostGain = @SellingAmount - @InventoryAmount - @ExecutionCostBankPortion--@ExecutionCost --Sugiono FMF-1782   
        SET @RefDesc = 'INVSELLRCV-' + RTRIM(@ReferenceNo);

        -- PMK41
        -- remark SET @LostGain = @SellingAmount - @InventoryAmount - @ExecutionCostBankPortion--@ExecutionCost --Sugiono FMF-1782   
        IF ISNULL(@PPN, 0) > 0
           OR ISNULL(@mobfee, 0) > 0
           OR ISNULL(@bidfee, 0) > 0
           OR ISNULL(@DPP, 0) > 0
            SET @LostGain = @allocationamount - @InventoryAmount - @ExecutionCostBankPortion; --@ExecutionCost --Sugiono FMF-1782   
        ELSE
            SET @LostGain = @SellingAmount - @InventoryAmount - @ExecutionCostBankPortion; --@ExecutionCost --Sugiono FMF-1782   




        SET @Counter = 1;

        --Comment Sugiono FMF-1782
        --WHILE @Counter <= 2
        --    BEGIN      
        --        IF @Counter = 1
        --            BEGIN      
        --                SET @PaymentAllocationJournal = 'REPOASSET'      
        --                SET @PostJournal = 'C'      
        --                SET @AmountJournal = @InventoryAmount      
        --            END      
        --        ELSE
        --            IF @Counter = 2
        --                BEGIN      
        --                    SET @PaymentAllocationJournal = 'REPOPNL'      
        --                    IF @LostGain > 0
        --                        SET @PostJournal = 'C'      
        --                    ELSE
        --                        SET @PostJournal = 'D'      
        --                    SET @AmountJournal = ABS(@LostGain)      
        --                END      
        --        IF @AmountJournal > 0
        --            BEGIN      
        --                INSERT  INTO #TempTable
        --                        ( PaymentAllocationID ,
        --                          Post ,
        --                          Amount ,
        --                          RefDesc ,
        --                          VoucherDesc
        --                        )
        --                VALUES  ( @PaymentAllocationJournal ,
        --                          @PostJournal ,
        --                          @AmountJournal ,
        --                          @Refdesc ,
        --                          ''
        --                        )      
        --                IF @@error <> 0
        --                    BEGIN      
        --                        GOTO ExitSP      
        --                    END       
        --            END      
        --        SET @AmountJournal = 0      
        --        SET @Counter = @Counter + 1      
        --    END      
        WHILE @Counter <= 3
        BEGIN
            IF @Counter = 1
            BEGIN
                SET @PaymentAllocationJournal = 'REPOASSET';
                SET @PostJournal = 'C';
                SET @AmountJournal = @InventoryAmount;
            END;
            ELSE IF @Counter = 2
            BEGIN
                SET @PaymentAllocationJournal = 'REPOPNL';
                IF @LostGain > 0
                    SET @PostJournal = 'C';
                ELSE
                    SET @PostJournal = 'D';
                SET @AmountJournal = ABS(@LostGain);
            END;
            ELSE IF @Counter = 3 --Sugiono FMF-1782
            BEGIN
                IF @IsPaymentHierarchy = 1
                BEGIN
                    SET @PaymentAllocationJournal = 'EXECOST';
                    SET @PostJournal = 'C';
                    SET @AmountJournal = @ExecutionCostBankPortion; --@ExecutionCost --Edit fuji,07 nov 2019 (FMF-1782 UAT)
                END;
                ELSE
                    SET @AmountJournal = 0;
            END;
            IF @AmountJournal > 0
            BEGIN
                INSERT INTO #TempTable
                (
                    PaymentAllocationID,
                    Post,
                    Amount,
                    RefDesc,
                    VoucherDesc
                )
                VALUES
                (@PaymentAllocationJournal, @PostJournal, @AmountJournal, @RefDesc, '');
                IF @@error <> 0
                BEGIN
                    GOTO ExitSP;
                END;
            END;
            SET @AmountJournal = 0;
            SET @Counter = @Counter + 1;
        END;

        EXECUTE @Error = spProcessUpdateCashBank @BranchID,
                                                 @BankAccountID,
                                                 @LoginID,
                                                 @BusinessDate,
                                                 @WOP,
                                                 @AmountReceive,
                                                 @CurrencyID,
                                                 @OpeningSequence OUTPUT;
        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;



        SELECT *
        FROM #TempTable WITH (NOLOCK); --candra 30 Nov 2020 [FMF-2386]
        EXECUTE @Error = spProcessCreateJournal @CompanyId,
                                                @BranchID,
                                                @TransactionID,
                                                @BusinessDate,
                                                @ValueDate,
                                                @ReferenceNo,
                                                @ApplicationID,
                                                'R',
                                                @BankAccountID,
                                                @AmountReceive,
                                                @CurrencyID,
                                                @Rate,
                                                1,
                                                @JournalCode OUTPUT;

        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;

        EXECUTE @Error = spProcessCreateCashBankTransactions @BranchID,
                                                             @ProcessID,
                                                             @BusinessDate,
                                                             @ValueDate,
                                                             @OpeningSequence,
                                                             @LoginID,
                                                             @WOP,
                                                             @ReceivedFrom,
                                                             @ReferenceNo,
                                                             @JournalCode,
                                                             @ApplicationID,
                                                             'R',
                                                             @BankAccountID,
                                                             @AmountReceive,
                                                             @Notes,
                                                             @CurrencyID,
                                                             '',
                                                             NULL,
                                                             1,
                                                             @VoucherNo OUTPUT;
        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;


        EXECUTE @Error = spProcessCreatePaymentHistory
            --Raug 2 Juni 2021
            --@BranchAgreement,
            @BranchID,
            --End Raug FMF-2725
            @ApplicationID,
            @BusinessDate,
            @ValueDate,
            @BankID,
            '-',
            0,
            0,
            @ReferenceNo,
            @ReceivedFrom,
            @WOP,
            @ProcessID,
            @AmountReceive,
            @JournalCode,
            @BankAccountID,
            @HistorySequenceNo OUTPUT,
            @ReceiptNoFormControl;
        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;

        UPDATE AgreementAsset
        SET AssetStatus =
            ---Raug 26 November 2021 FMF-3182
            --'RRD'
            (CASE
                 WHEN @AssetTypeID = '4' THEN
                     'RLS'
                 WHEN @IsFactoring = 1 THEN
                     'RLS'
                 ELSE
                     'RRD'
             END
            ),
            AssetDocStatus = (CASE
                                  WHEN @AssetTypeID = '4' THEN
                                      'R'
                                  WHEN @IsFactoring = 1 THEN
                                      'R'
                                  ELSE
                                      AssetDocStatus
                              END
                             )
        ---End Raug FMF-3182
        WHERE BranchID = @BranchAgreement
              AND ApplicationID = @ApplicationID
              AND AssetSeqNo = @AssetSeqNo;
        IF @@error <> 0
        BEGIN
            GOTO ExitSP;
        END;

        UPDATE AssetRepossessionOrder
        SET RepossesionStatus = 'P',
            SoldJournalNo = @JournalCode,
            VoucherNo = @VoucherNo,
            PaidDate = @ValueDate,
            PaidAmount = @AmountReceive,
            SellingAmount = @AmountReceive
        FROM
        (
            SELECT AssetRepossessionOrder.BranchId,
                   AssetRepossessionOrder.ApplicationId,
                   AssetRepossessionOrder.AssetSeqNo,
                   AssetRepossessionOrder.RepossesSeqNo,
                   AssetRepossessionOrder.CollectionExpense,
                   AssetRepossessionOrder.CollectionExpenseWaived
            FROM AssetRepossessionOrder
                INNER JOIN
                (
                    SELECT BranchId,
                           ApplicationId,
                           AssetSeqNo,
                           MAX(RepossesSeqNo) AS MaxRepossesSeqNo
                    FROM AssetRepossessionOrder WITH (NOLOCK)
                    WHERE BranchId = @BranchAgreement
                          AND ApplicationId = @ApplicationID
                          AND AssetSeqNo = @AssetSeqNo
                    GROUP BY BranchId,
                             ApplicationId,
                             AssetSeqNo
                ) QARO
                    ON QARO.BranchId = AssetRepossessionOrder.BranchId
                       AND QARO.ApplicationId = AssetRepossessionOrder.ApplicationId
                       AND QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo
                       AND QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo
            WHERE AssetRepossessionOrder.BranchId = @BranchAgreement
                  AND AssetRepossessionOrder.ApplicationId = @ApplicationID
                  AND AssetRepossessionOrder.AssetSeqNo = @AssetSeqNo
        ) QRY
        WHERE AssetRepossessionOrder.BranchId = QRY.BranchId
              AND AssetRepossessionOrder.ApplicationId = QRY.ApplicationId
              AND AssetRepossessionOrder.AssetSeqNo = QRY.AssetSeqNo
              AND AssetRepossessionOrder.RepossesSeqNo = QRY.RepossesSeqNo;

        IF @@error <> 0
        BEGIN
            GOTO ExitSP;
        END;

        IF EXISTS
        (
            SELECT DefaultStatus
            FROM Agreement
            WHERE BranchID = @BranchAgreement
                  AND ApplicationID = @ApplicationID
                  AND DefaultStatus = 'NA'
        )
        BEGIN
            UPDATE Agreement
            SET NAPaid = NAPaid + @AmountReceive
            WHERE BranchID = @BranchAgreement
                  AND ApplicationID = @ApplicationID;
            IF @@error <> 0
            BEGIN
                GOTO ExitSP;
            END;
        END;

        IF EXISTS
        (
            SELECT DefaultStatus
            FROM Agreement
            WHERE BranchID = @BranchAgreement
                  AND ApplicationID = @ApplicationID
                  AND DefaultStatus = 'WO'
        )
        BEGIN
            UPDATE Agreement
            SET WOPaid = WOPaid + @AmountReceive
            WHERE BranchID = @BranchAgreement
                  AND ApplicationID = @ApplicationID;
            IF @@error <> 0
            BEGIN
                GOTO ExitSP;
            END;
        END;

        IF @IsLastAssetSold = '1'
        BEGIN
            --add Jason 15 Agustus 2022 [FMF-3705]
            IF EXISTS
            (
                SELECT ''
                FROM STNKRequest
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID
                      AND STNKStatus = 'REQ'
            )
            BEGIN
                RAISERROR('Contract is still on STNK Request. Please process the STNK Request first !', 16, 1);
                GOTO ExitSP;
            END;
            --end Jason [FMF-3705]

            UPDATE Agreement
            SET OutstandingPrincipal = 0,
                OutstandingInterest = 0,
                ---Raug 26 November 2021 FMF-3182
                --ContractStatus = 'RRD' ,
                ContractStatus = (CASE
                                      WHEN @AssetTypeID = '4' THEN
                                          'EXP'
                                      WHEN @AssetTypeID = '10' THEN
                                          'EXP'
                                      WHEN @IsFactoring = 1 THEN
                                          'EXP'
                                      ELSE
                                          'RRD'
                                  END
                                 ),
                ---End Raug FMF-3182
                RRDDate = @ValueDate,
                NextInstallmentDueNumber = '999',
                NextInstallmentNumber = '999',
                NextInstallmentDate = MaturityDate,
                NextInstallmentDueDate = MaturityDate,
                OutstandingPrincipalUndue = 0,
                OutstandingInterestUndue = 0,
                --Add Jason FMF-3473
                DtmUpd = GETDATE()
            --end Jason 
            WHERE BranchID = @BranchAgreement
                  AND ApplicationID = @ApplicationID;

        END;

    END;
    ELSE
    --Untuk Metode AR      
    BEGIN
        PRINT 'metode AR';

        --===================================================================================================================--      
        --===================================================================================================================--      
        SET @NAAmountAloc = 0;
        SET @NAWaived = 0;
        SET @WOAmountAloc = 0;
        SET @WOWaived = 0;
        SET @EarnAmountAloc = 0;
        SET @OSInsuranceDueAloc = 0;
        SET @OSRepossessFeeAloc = 0;
        SET @LCInstallmentAloc = 0;
        SET @LCInsuranceAloc = 0;
        SET @OSPDCBounceFeeAloc = 0;
        SET @PrepaidAloc = 0;

        SET @InstallmentWaived = 0;
        SET @LostAmount = 0;
        SET @EarnWaived = 0;
        SET @InsuranceWaived = 0;
        SET @ReposessWaived = 0;
        SET @LCInstallmentWaived = 0;
        SET @LCInsuranceWaived = 0;
        SET @PDCBounceWaived = 0;
        SET @InstallmentAloc = 0;


        SELECT @TotalInterestAmount = SUM(InterestAmount)
        FROM InstallmentSchedule
        WHERE BranchId = @BranchAgreement
              AND ApplicationID = @ApplicationID
              --AND DueDate <= @ValueDate      
              --Vincenza FMF-2934 10092021
              AND DueDate <= @NADate;

        SELECT @TotalIncomeRecognizeAmount = SUM(AmountIncRecognize)
        FROM InstallmentSchedule
        WHERE BranchId = @BranchAgreement
              AND ApplicationID = @ApplicationID
              --AND DueDate <= @ValueDate      
              --Vincenza FMF-2934 10092021
              AND DueDate <= @NADate;



        --Sugiono 14 Agustus 2024 FMF-5138
        SELECT TOP 1
               @NextInstallmentNumber = InsSeqNo + 1
        FROM InstallmentSchedule
        WHERE ApplicationID = @ApplicationID
              AND DueDate <= @NADate
        ORDER BY InsSeqNo DESC;
        IF EXISTS
        (
            SELECT ''
            FROM dbo.InstallmentSchedule Isc WITH (NOLOCK)
            WHERE Isc.BranchId = @BranchID
                  AND Isc.ApplicationID = @ApplicationID
                  AND Isc.InsSeqNo = @NextInstallmentNumber
                  AND Isc.DueDate > @NADate
        )
        BEGIN
            EXEC spAccruedInterest @ApplicationID,
                                   @NADate,
                                   NULL,
                                   @AccruedAmount OUTPUT, --pakek @dblECI dikarenakan saat NADate < DueDate, akan ambil porsi sampe NADate saja. tidak sampe Duenya
                                   NULL;
        END;
        --End Sugiono 
        ELSE
        BEGIN
            --EXEC spAccruedInterest @ApplicationId, @ValueDate,
            --    @AccruedAmount OUTPUT, NULL, NULL  
            --Vincenza FMF-2934 10092021
            EXEC spAccruedInterest @ApplicationID,
                                   @NADate,
                                   @AccruedAmount OUTPUT,
                                   NULL,
                                   NULL;
        END;

        ---Raug 24 November 2021 FMF-3172
        --SET @EarnAmount = ( @TotalInterestAmount
        --                    - @TotalIncomeRecognizeAmount )
        --    + @AccruedAmount  
        --notes REY 
        SET @EarnAmount = (ISNULL(@TotalInterestAmount, 0) - ISNULL(@TotalIncomeRecognizeAmount, 0));
        --changed by Reyvano FMF-5229 22 Nov 2024
        --+ ISNULL(@AccruedAmount, 0);
        --ended by Reyvano FMF-5229
        ---End Raug FMF-3172

        --chandra debug 10/06/09
        --PRINT @TotalInterestAmount
        --PRINT @TotalIncomeRecognizeAmount
        --PRINT @AccruedAmount
        --PRINT @earnamount

        SELECT @OSLCInstallment
            = (CASE
                   WHEN (CEILING((LCInstallment - LCInstallmentPaid - LCInstallmentWaived) * 1.0 / @CurrencyRounded)
                         * @CurrencyRounded
                        ) < 0 THEN
                       0
                   ELSE
                       CEILING((LCInstallment - LCInstallmentPaid - LCInstallmentWaived) * 1.0 / @CurrencyRounded)
                       * @CurrencyRounded
               END
              ),
               @LCInstallmentCurrent
                   = (CASE
                          WHEN (CEILING(dbo.FnCalculationForLCInstallment(   ApplicationID,
                                                                             --@valuedate) Vincenza FMF-2934 07092021
                                                                             @NADate
                                                                         ) * 1.0 / @CurrencyRounded
                                       ) * @CurrencyRounded
                               ) < 0 THEN
                              0
                          ELSE
                              CEILING((dbo.FnCalculationForLCInstallment(   ApplicationID,
                                                                            --@valuedate) ) Vincenza FMF-2934 07092021
                                                                            @NADate
                                                                        )
                                      ) * 1.0 / @CurrencyRounded
                                     ) * @CurrencyRounded
                      END
                     ),
               @OSLCInsurance
                   = (CASE
                          WHEN (CEILING((LCInsurance - LCInsurancePaid - LCInsuranceWaived) * 1.0 / @CurrencyRounded)
                                * @CurrencyRounded
                               ) < 0 THEN
                              0
                          ELSE
                              CEILING((LCInsurance - LCInsurancePaid - LCInsuranceWaived) * 1.0 / @CurrencyRounded)
                              * @CurrencyRounded
                      END
                     ),
               @LCInsuranceCurrent
                   = (CASE
                          WHEN (CEILING(dbo.FnCalculationForLCInsurance(   ApplicationID,
                                                                           --@valuedate) Vincenza FMF-2934 07092021
                                                                           @NADate
                                                                       ) * 1.0 / @CurrencyRounded
                                       ) * @CurrencyRounded
                               ) < 0 THEN
                              0
                          ELSE
                              CEILING(dbo.FnCalculationForLCInsurance(   ApplicationID,
                                                                         --@valuedate) Vincenza FMF-2934 07092021
                                                                         @NADate
                                                                     ) * 1.0 / @CurrencyRounded
                                     ) * @CurrencyRounded
                      END
                     ),
               @OSInstallmentDueBefore = InstallmentDue - InstallmentDuePaid - InstallmentDueWaived,
               @OSInsuranceDue = InsuranceDue - InsuranceDuePaid - InsuranceDueWaived,
               @OSPDCBounceFee = PDCBounceFee - PDCBounceFeePaid - PDCBounceFeeWaived,
                                                               --@OSRepossessFee = CollectionExpense - CollectionExpensePaid - CollectionExpenseWaived,

               @OSRepossessFee = (CollectionExpense - CollectionExpensePaid - CollectionExpenseWaived),
               @NAAmountResidue = ISNULL(NAAmount - NAPaid - NAWaived, 0),
               @WOAmountResidue = ISNULL(WOAmount - WOPaid - WOWaived, 0),
                                                               --@PrepaidAmount = ContractPrepaidAmount      
               --@PrepaidAmountAgreement = ContractPrepaidAmount --Added by Reyvano FMF-5229
			   @PrepaidAmountAgreement = ISNULL(ContractPrepaidAmount,0) --Added by Aurellie : FMF-5310 
        FROM Agreement
        WHERE Agreement.BranchID = @BranchAgreement
              AND Agreement.ApplicationID = @ApplicationID;
        --Novia add, 21032016 : FMF-1487
        --Rendi 7 april 2016 tambah inner join ke agreement dan tambah wherecond NADate < '20160317' (jika kontrak NA sesudah CR alokasi interest golive maka ambil dari agreement)
        --                IF EXISTS ( SELECT  ''
        --                            FROM    dbo.TempPartialPayment INNER JOIN dbo.Agreement Agr ON 
        --			TempPartialPayment.BranchID = agr.BranchID AND TempPartialPayment.ApplicationID = agr.ApplicationID
        --                            WHERE   TempPartialPayment.BranchId = @BranchAgreement
        --                                    AND TempPartialPayment.ApplicationID = @ApplicationID
        --			AND Agr.NADate < '2016-03-17' 
        --	--End Rendi
        --  )
        --                    BEGIN
        ----Rendi 30 maret 2016 innerjoin ke agreement agar NAAmountResidue u/ kontrak bayar partial di kurang NApaid-NAWaived
        --                        SELECT  @NAAmountResidue = TempPartialPayment.NAAmount - agr.NAPaid - agr.NAWaived ,
        --                                @WOAmountResidue = TempPartialPayment.WOAmount - agr.WOPaid - agr.WOWaived
        --                        FROM    dbo.TempPartialPayment
        --                                INNER JOIN agreement agr ON TempPartialPayment.Branchid = Agr.Branchid
        --                                                      AND TempPartialPayment.Applicationid = agr.ApplicationID
        --                        WHERE   TempPartialPayment.BranchId = @BranchAgreement
        --                                AND TempPartialPayment.ApplicationID = @ApplicationID
        --                    END
        --Eo Novia, 21032016


        --SET @AmountReceiveResidue = @AmountReceive     
        --PMK41
        IF ISNULL(@PPN, 0) > 0
           OR ISNULL(@mobfee, 0) > 0
           OR ISNULL(@bidfee, 0) > 0
           OR ISNULL(@DPP, 0) > 0
        BEGIN
            SET @AmountReceiveResidue = @allocationamount;
        END;
        ELSE
        BEGIN
            SET @AmountReceiveResidue = @AmountReceive;
        END;



        -- Principal      
        IF @StatusDefault = 'NA'
        BEGIN
            IF @AmountReceiveResidue > 0
            BEGIN
                IF @NAAmountResidue > @AmountReceiveResidue
                BEGIN
                    SET @NAAmountAloc = @AmountReceiveResidue;
                END;
                ELSE IF @NAAmountResidue <= @AmountReceiveResidue
                BEGIN
                    SET @NAAmountAloc = @NAAmountResidue;
                END;
                SET @AmountReceiveResidue = @AmountReceiveResidue - @NAAmountAloc;
            END;
        END;
        ELSE IF @StatusDefault = 'WO'
        BEGIN
            IF @AmountReceiveResidue > 0
            BEGIN
                IF @WOAmountResidue > @AmountReceiveResidue
                BEGIN
                    SET @WOAmountAloc = @AmountReceiveResidue;

                END;
                ELSE IF @WOAmountResidue <= @AmountReceiveResidue
                BEGIN
                    SET @WOAmountAloc = @WOAmountResidue;
                END;
                SET @AmountReceiveResidue = @AmountReceiveResidue - @WOAmountAloc;
            END;
        END;


        /* Gema, 20121112 : Remark terkait CR FMF-1245, tidak ada alokasi ke biaya lainnya
 
 -- Insurance      
                  IF @AmountReceiveResidue > 0 
                     Begin      
                        If @OSInsuranceDue > @AmountReceiveResidue 
                           BEGIN      
                              Set @OSInsuranceDueAloc = @AmountReceiveResidue      
                           END      
                        Else 
                           If @OSInsuranceDue <= @AmountReceiveResidue 
                              Begin      
                                 Set @OSInsuranceDueAloc = @OSInsuranceDue      
                              END      
                        Set @AmountReceiveResidue = @AmountReceiveResidue
                           - @OSInsuranceDueAloc   
                     END      
  
 -- Repo Fee      
                  IF @AmountReceiveResidue > 0 
                     Begin      
                        If @OSRepossessFee > @AmountReceiveResidue 
                           BEGIN      
                              Set @OSRepossessFeeAloc = @AmountReceiveResidue      
                           END      
                        Else 
                           If @OSRepossessFee <= @AmountReceiveResidue 
                              Begin      
                                 Set @OSRepossessFeeAloc = @OSRepossessFee      
                              END      
                        Set @AmountReceiveResidue = @AmountReceiveResidue
                           - @OSRepossessFeeAloc      
                     END      
      
 -- Interest      
                  IF @AmountReceiveResidue > 0 
                     Begin      
                        If @EarnAmount > @AmountReceiveResidue 
                           BEGIN      
                              Set @EarnAmountAloc = @AmountReceiveResidue      
                           END      
                        Else 
                           If @EarnAmount <= @AmountReceiveResidue 
                              Begin      
                                 Set @EarnAmountAloc = @EarnAmount      
                              END      
                        Set @AmountReceiveResidue = @AmountReceiveResidue
                           - @EarnAmountAloc      
                     END    
  
  
  -- LC Installment      
                  IF @AmountReceiveResidue > 0 
                     Begin      
                        If ( @OSLCInstallment
                             + @LCInstallmentCurrent ) > @AmountReceiveResidue 
                           BEGIN      
                              Set @LCInstallmentAloc = @AmountReceiveResidue      
                           END      
                        Else 
                           If ( @OSLCInstallment
                                + @LCInstallmentCurrent ) <= @AmountReceiveResidue 
                              Begin      
                                 Set @LCInstallmentAloc = ( @OSLCInstallment + @LCInstallmentCurrent )      
                              END      
                        Set @AmountReceiveResidue = @AmountReceiveResidue
                           - @LCInstallmentAloc      
                     END      
        
 -- LC Insurance      
                  IF @AmountReceiveResidue > 0 
                     Begin      
                        If ( @OSLCInsurance
                             + @LCInsuranceCurrent ) > @AmountReceiveResidue 
                           BEGIN      
                              Set @LCInsuranceAloc = @AmountReceiveResidue      
                           END      
                        Else 
                           If ( @OSLCInsurance
                                + @LCInsuranceCurrent ) <= @AmountReceiveResidue 
                              Begin      
                                 Set @LCInsuranceAloc = ( @OSLCInsurance + @LCInsuranceCurrent )      
                              END      
                        Set @AmountReceiveResidue = @AmountReceiveResidue
                           - @LCInsuranceAloc      
                     END      
       
 -- PDC Bounce Fee      
                  IF @AmountReceiveResidue > 0 
                     Begin      
                        If @OSPDCBounceFee > @AmountReceiveResidue 
                           BEGIN      
                              Set @OSPDCBounceFeeAloc = @AmountReceiveResidue      
                           END      
                        Else 
                           If @OSPDCBounceFee <= @AmountReceiveResidue 
                              Begin      
                                 Set @OSPDCBounceFeeAloc = @OSPDCBounceFee      
                              END      
                        Set @AmountReceiveResidue = @AmountReceiveResidue
                           - @OSPDCBounceFeeAloc      
                     END   
                     
*/
        --End Gema, 20121112 : Remark terkait CR FMF-1245


        --�������� ARIF ���� START ���������������������������������������������������������������������������������������������������������������    
        DECLARE @ARNA Amount,
                @UCINA Amount,
                @DiffRate Amount,
                @Incentive Amount,
                @Provision Amount,
                @AdminFee Amount,
                @AccDiffRate Amount,
                @AccIncentive Amount,
                @AccProvision Amount,
                @AccAdminFee Amount,
                                      /*Rubianto, 20100413*/
                @InsuranceIncome Amount,
                @OtherRefund Amount,
                @AdmFee Amount,
                @ProvisionFee Amount,
                @OtherFee Amount,
                @SurveyFee Amount,
                @DeferredInsurance Amount,
                                      /*Rubianto End*/
                @costofSurvey Amount; -- arif 15 okt 2010


        IF @IsLastAssetSold = '1'
        BEGIN
            --last asset    
            SELECT @ARNA = ISNULL(SUM(InstallmentAmount - PaidAmount - WaivedAmount), 0) --,    
            --@UCINA = isNull(SUM(InterestAmount - AmountIncRecognize),0)  -- Lisa 20081109 : Ganti cara ambil UCINA utk lastassetsold  
            --   @DiffRate = isNull(SUM(DiffRateAmount),0),    
            --   @Incentive = isNull(SUM(Incentive),0),     
            --   @Provision = isNull(SUM(Provision),0)    
            FROM InstallmentSchedule
            WHERE BranchId = @BranchAgreement
                  AND ApplicationID = @ApplicationID
                  AND (InstallmentAmount - PaidAmount - WaivedAmount) > 0;
            --select 'a',@StatusDefault ,@NAAmountResidue,@AmountReceiveResidue,@IsLastAssetSold, @UCINA,@ARNA  

            SELECT @DiffRate = ISNULL(SUM(DiffRateAmount), 0) - ISNULL(SUM(DiffRateRecognize), 0),
                   @Incentive = ISNULL(SUM(Incentive), 0) - ISNULL(SUM(IncentiveRecognize), 0),
                   @Provision = ISNULL(SUM(Provision), 0) - ISNULL(SUM(ProvisionRecognize), 0),
                   @UCINA = ISNULL(SUM(InterestAmount), 0) - ISNULL(SUM(AmountIncRecognize), 0),                 -- Lisa 20081109 : Ganti cara ambil UCINA utk lastassetsold  
                                                                                                                 /*Rubianto, 20100413*/
                   @AdminFee = ISNULL(SUM(AdminFee), 0) - ISNULL(SUM(AdminFeeRecognize), 0),
                   @InsuranceIncome = ISNULL(SUM(InsuranceIncomeAmount), 0) - ISNULL(SUM(InsuranceIncomeRecognize), 0),
                   @OtherRefund = ISNULL(SUM(OtherRefundAmount), 0) - ISNULL(SUM(OtherRefundRecognize), 0),
                   @AdmFee = ISNULL(SUM(AdmFeeAmount), 0) - ISNULL(SUM(AdmFeeRecognize), 0),
                   @ProvisionFee = ISNULL(SUM(ProvisionFeeAmount), 0) - ISNULL(SUM(ProvisionFeeRecognize), 0),
                   @OtherFee = ISNULL(SUM(OtherFeeAmount), 0) - ISNULL(SUM(OtherFeeRecognize), 0),
                   @SurveyFee = ISNULL(SUM(SurveyFeeAmount), 0) - ISNULL(SUM(SurveyFeeRecognize), 0),
                   @DeferredInsurance
                       = ISNULL(SUM(DeferredInsurIncAmount), 0) - ISNULL(SUM(DeferredInsurIncRecognize), 0),

                                                                                                                 /*Rubianto End*/
                   @costofSurvey = ISNULL(SUM(CostOfSurveyFeeAmount), 0) - ISNULL(SUM(CostOfSurveyRecognize), 0) -- arif 15 okt 2010
            FROM InstallmentSchedule
            WHERE BranchId = @BranchAgreement
                  AND ApplicationID = @ApplicationID;
        --select @AdmFee
        END;
        ELSE
        BEGIN
            --not last asset    
            -- Yovita 14 Okt 2007 : Ubah kondisi untuk ARNA dan UCINA, jika bukan Last Asset ARNA ambil dari PrincipalAmountAloc+EarnAmountAloc dan UCINA dr EarnAmountAloc  

            IF @StatusDefault = 'NA'
            BEGIN
                SET @ARNA = @NAAmountAloc + @EarnAmountAloc;
                SET @UCINA = @EarnAmountAloc;
                --                              print 'lili'
                --                              print @EarnAmountAloc


                -- Yovita 23 Oct 07: Apabila bukan last asset, akui expensenya proportional dengan accrued interest     
                SELECT @OSInterest = SUM(InterestAmount) - ISNULL(SUM(AmountIncRecognize), 0)
                FROM InstallmentSchedule
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID
                      AND DueDate <= @ValueDate;
                -- Dewi 28062012 added begin
                IF @OSInterest > 0
                BEGIN
                    -- Dewi 28062012 added end
                    SELECT @OSDiffRate = ISNULL(SUM(DiffRateAmount), 0) - ISNULL(SUM(DiffRateRecognize), 0),
                           @OSIncentive = ISNULL(SUM(Incentive), 0) - ISNULL(SUM(IncentiveRecognize), 0),
                           @OSProvision = ISNULL(SUM(Provision), 0) - ISNULL(SUM(ProvisionRecognize), 0),
                           @OSAdminFee = ISNULL(SUM(AdminFee), 0) - ISNULL(SUM(AdminFeeRecognize), 0),
                           /*Rubianto, 20100413*/
                           @OSInsuranceIncome
                               = ISNULL(SUM(InsuranceIncomeAmount), 0) - ISNULL(SUM(InsuranceIncomeRecognize), 0),
                           @OSOtherRefund = ISNULL(SUM(OtherRefundAmount), 0) - ISNULL(SUM(OtherRefundRecognize), 0),
                           @OSAdmFee = ISNULL(SUM(AdmFeeAmount), 0) - ISNULL(SUM(AdmFeeRecognize), 0),
                           @OSProvisionFee = ISNULL(SUM(ProvisionFeeAmount), 0) - ISNULL(SUM(ProvisionFeeRecognize), 0),
                           @OSOtherFee = ISNULL(SUM(OtherFeeAmount), 0) - ISNULL(SUM(OtherFeeRecognize), 0),
                           @OSSurveyFee = ISNULL(SUM(SurveyFeeAmount), 0) - ISNULL(SUM(SurveyFeeRecognize), 0),
                           @OSDeferredInsurance
                               = ISNULL(SUM(DeferredInsurIncAmount), 0) - ISNULL(SUM(DeferredInsurIncRecognize), 0),
                           /*Rubianto End*/
                           --arif 15 okt 2010
                           @OSCostOfSurvey
                               = ISNULL(SUM(CostOfSurveyFeeAmount), 0) - ISNULL(SUM(CostOfSurveyRecognize), 0)
                    --end arif
                    FROM InstallmentSchedule
                    WHERE BranchId = @BranchAgreement
                          AND ApplicationID = @ApplicationID
                          AND DueDate <= @ValueDate;

                    SET @DiffRate = @EarnAmountAloc / @OSInterest * @OSDiffRate;
                    SET @Incentive = @EarnAmountAloc / @OSInterest * @OSIncentive;
                    SET @Provision = @EarnAmountAloc / @OSInterest * @OSProvision;
                    SET @AdminFee = @EarnAmountAloc / @OSInterest * @OSAdminFee;
                    /*Rubianto, 20100413*/
                    SET @InsuranceIncome = @EarnAmountAloc / @OSInterest * @OSInsuranceIncome;
                    SET @OtherRefund = @EarnAmountAloc / @OSInterest * @OSOtherRefund;
                    SET @AdmFee = @EarnAmountAloc / @OSInterest * @OSAdmFee;
                    SET @ProvisionFee = @EarnAmountAloc / @OSInterest * @OSProvisionFee;
                    SET @OtherFee = @EarnAmountAloc / @OSInterest * @OSOtherFee;
                    SET @SurveyFee = @EarnAmountAloc / @OSInterest * @OSSurveyFee;
                    SET @DeferredInsurance = @EarnAmountAloc / @OSInterest * @OSDeferredInsurance;
                    /*Rubianto End*/
                    --arif 15 okt 2010
                    SET @costofSurvey = @EarnAmountAloc / @OSInterest * @OSCostOfSurvey;
                -- Dewi 28062012 added begin
                END;
                ELSE
                BEGIN
                    SET @DiffRate = 0;
                    SET @Incentive = 0;
                    SET @Provision = 0;
                    SET @AdminFee = 0;
                    SET @InsuranceIncome = 0;
                    SET @OtherRefund = 0;
                    SET @AdmFee = 0;
                    SET @ProvisionFee = 0;
                    SET @OtherFee = 0;
                    SET @SurveyFee = 0;
                    SET @DeferredInsurance = 0;
                    SET @costofSurvey = 0;
                END;
            -- Dewi 28062012 added end
            END;
            ELSE
            BEGIN
                -- Yovita 23 Oct 07: Apabila WO, AR NA, UCI NA dan Amount Expense di 0 - kan  
                SET @ARNA = 0;
                SET @UCINA = 0;
                SET @DiffRate = 0;
                SET @Incentive = 0;
                SET @Provision = 0;
                SET @AdminFee = 0;
                /*Rubianto, 20100413*/
                SET @InsuranceIncome = 0;
                SET @OtherRefund = 0;
                SET @AdmFee = 0;
                SET @ProvisionFee = 0;
                SET @OtherFee = 0;
                SET @SurveyFee = 0;
                SET @DeferredInsurance = 0;
                /*Rubianto End*/
                --arif 15 okt 2010					
                SET @costofSurvey = 0;
            --end arif
            END;

        -- exec spAccruedExpense @ApplicationId, @ValueDate, @AccDiffRate Output, @AccProvision Output, @AccIncentive Output    
        --    
        -- set @DiffRate = @DiffRate + @AccDiffRate    
        -- set @Incentive = @Incentive + @AccIncentive    
        -- set @Provision = @Provision + @AccProvision    
        END;

        --�������� ARIF ����  END  ���������������������������������������������������������������������������������������������������������������    

        IF @IsLastAssetSold = '1'
        BEGIN
            --Jika Last Asset Maka NAAmount/WOAmount,EarnAmount,OSInsuranceDue,OSRepossessFee, dll Harus       
            --Dialokasi penuh dan kekurangannya masuk Waive 
            -- Lisa 20101112 : Tambah kondisi jika ada advance payment yang belum ter recognize   
            DECLARE @InterestUnRecognized Amount;
            DECLARE @fundingCoyPortion Rate = 0;
            SELECT @InterestUnRecognized = SUM(ISNULL(PaidAmount, 0) - PrincipalAmount - AmountIncRecognize)
            FROM dbo.InstallmentSchedule WITH (NOLOCK)
            WHERE BranchId = @BranchAgreement
                  AND ApplicationID = @ApplicationID
                  AND PaidAmount > PrincipalAmount
                  AND AmountIncRecognize < InterestAmount;
            -- End Lisa 20101112      
            IF @StatusDefault = 'NA'
            BEGIN
                --Aditia 20190610 Tambah kondisi yang sama dengan WO (fuji) (FMF-1649)
                --IF EXISTS (SELECT '' FROM dbo.FundingAgreement fa WITH (NOLOCK)
                --				INNER JOIN dbo.FundingContract fc  WITH (NOLOCK)
                --					ON fa.FundingCoyID=fc.FundingCoyID
                --					AND fa.FundingContractNo=fc.FundingContractNo
                --				WHERE ApplicationID=@ApplicationID
                --				AND ISNULL(IsPaymentHierarchy,0)=1)
                IF @IsPaymentHierarchy = 1
                BEGIN

                    --SELECT  @CalOSPrincipalAmount = SUM(( InstallmentAmount - paidAmount - WaivedAmount )  * ( 100 - FundingCoyPortion ) / 100)
                    --- ( SUM(InterestAmount * ( 100 - FundingCoyPortion ) / 100) - SUM(AmountIncRecognize * ( 100 - FundingCoyPortion ) / 100))
                    --FROM    InstallmentSchedule
                    --WHERE   ApplicationID = @ApplicationID
                    --AND BranchId = @BranchID

                    --DECLARE @NAAmount NUMERIC(17,2) = ( SELECT NAAmount-NaPaid-NAWaived FROM Agreement WITH(NOLOCK) WHERE ApplicationID = @ApplicationID )
                    DECLARE @RepoFeeBankPortionREAL NUMERIC(17, 2);

                    SELECT @RepoFeeBankPortion = ISNULL(RepossesionFee, 0),
                           @fundingCoyPortion = ISNULL(fa.FundingCoyPortion, 0)
                    FROM dbo.FundingAgreement fa WITH (NOLOCK)
                        INNER JOIN dbo.FundingContract fc WITH (NOLOCK)
                            ON fa.FundingCoyID = fc.FundingCoyID
                               AND fa.FundingContractNo = fc.FundingContractNo
                    WHERE ApplicationID = @ApplicationID
                          AND ISNULL(IsPaymentHierarchy, 0) = 1;

                    SET @RepoFeeBankPortionREAL = @RepoFeeBankPortion * @fundingCoyPortion / 100;
                    SET @ARNA = (@ARNA * (100 - @fundingCoyPortion)) / 100;
                    SET @UCINA = (@UCINA * (100 - @fundingCoyPortion)) / 100;
                    ---Silvia, 24 Februari 2020 [FMF-2078]
                    --SET @PrepaidBNK = ((@AmountReceive-@ExecutionCost)* @fundingCoyPortion /100) -- - @RepoFeeBankPortion --edit fuji,07112019(fmf-1782 UAT) ubah perhitungan prepaid bnk
                    SET @PrepaidBNK = ((@AmountReceive - @ExecutionCost) * @CoyPortionFundingContract / 100);
                    ---End Silvia [FMF-2078]

                    IF @PrepaidBNK < 0
                        SET @PrepaidBNK = 0;
                    --SET @NAAmount = (@NAAmount * (100-@fundingCoyPortion))/100

                    --SELECT @PrepaidBNK = ((@AmountReceive - ISNULL((SUM(InstallmentAmount-PaidAmount-WaivedAmount) -SUM(InterestAmount-AmountIncRecognize)),0)) * @fundingCoyPortion /100 ) - @RepoFeeBankPortion
                    --FROM    InstallmentSchedule
                    --WHERE   ApplicationID = @ApplicationID
                    --AND BranchId = @BranchID
                    --AND ISNULL(FundingCoyPortion,0) = 0

                    SET @NAWaived = 0;
                    SET @NAAmountAloc = 0;
                    SET @NAAmountResidue = 0;
                    SET @AmountReceiveResidue = 0;
                    --SET @LostAmount = @LostAmount - ( @AmountReceive - @ARNA - @RepoFeeBankPortion - @PrepaidBNK + @UCINA )--Comment Sugiono FMF-1782


                    --SET @LostAmount = @LostAmount - ( @AmountReceive - @ARNA - @RepoFeeBankPortion - @PrepaidBNK + @UCINA - @ExecutionCostBankPortion) --@ExecutionCost --Sugiono FMF-1782
                    -- PMK41
                    SET @LostAmount
                        = @LostAmount
                          - (@allocationamount - @ARNA - @RepoFeeBankPortion - @PrepaidBNK + @UCINA
                             - @ExecutionCostBankPortion
                            ); --@ExecutionCost --Sugiono FMF-1782

                    UPDATE dbo.AssetRepossessionOrder
                    SET IsPaymentHierarchy = 1,
                        SellingAmountBankPortion = ISNULL(@PrepaidBNK, 0)
                    WHERE ApplicationId = @ApplicationID;
                END;
                ELSE
                --END Aditia
                BEGIN

                    SET @NAWaived = @NAAmountResidue - @NAAmountAloc;
                    SET @NAAmountAloc = @NAAmountResidue;
                    -- Lisa 20101202 : Remark penambahan kondisi advance payment karena tidak sesuai dengan kondisi normal      
                    SET @LostAmount = @NAWaived; -- ISNULL(@InterestUnRecognized,0)		-- Lisa 20101112 :  Lisa 20101112 : Tambah kondisi jika ada advance payment yang belum ter recognize      
                END;
            END;
            IF @StatusDefault = 'WO'
            BEGIN

                ---Add fuji,04 Mei 2018 (FMF-1649)
                --IF EXISTS (SELECT '' FROM dbo.FundingAgreement fa WITH (NOLOCK)
                --		INNER JOIN dbo.FundingContract fc  WITH (NOLOCK)
                --			ON fa.FundingCoyID=fc.FundingCoyID
                --			AND fa.FundingContractNo=fc.FundingContractNo
                --		WHERE ApplicationID=@ApplicationID
                --		AND ISNULL(IsPaymentHierarchy,0)=1)
                IF @IsPaymentHierarchy = 1
                BEGIN

                    SELECT @CalOSPrincipalAmount
                        = SUM((InstallmentAmount - PaidAmount - WaivedAmount) * (100 - FundingCoyPortion) / 100)
                          - (SUM(InterestAmount * (100 - FundingCoyPortion) / 100)
                             - SUM(AmountIncRecognize * (100 - FundingCoyPortion) / 100)
                            )
                    FROM InstallmentSchedule
                    WHERE ApplicationID = @ApplicationID
                          AND BranchId = @BranchAgreement;


                    SELECT @RepoFeeBankPortion = ISNULL(RepossesionFee, 0), -- * fc.FundingCoyPortion/100 ) ,
                           @fundingCoyPortion = ISNULL(fa.FundingCoyPortion, 0)
                    FROM dbo.FundingAgreement fa WITH (NOLOCK)
                        INNER JOIN dbo.FundingContract fc WITH (NOLOCK)
                            ON fa.FundingCoyID = fc.FundingCoyID
                               AND fa.FundingContractNo = fc.FundingContractNo
                    WHERE ApplicationID = @ApplicationID
                          AND ISNULL(IsPaymentHierarchy, 0) = 1;

                    SELECT
                        ---Silvia, 24 Februari 2020 [FMF-2078]
                        --@PrepaidBNK = (((@AmountReceive - ISNULL((SUM(InstallmentAmount-PaidAmount-WaivedAmount) -SUM(InterestAmount-AmountIncRecognize)),0))- @ExecutionCost)* @fundingCoyPortion /100 )  -- - @RepoFeeBankPortion --edit fuji,07112019(fmf-1782 UAT) ubah perhitungan prepaid bnk
                        @PrepaidBNK
                        = (((@AmountReceive
                             - ISNULL(
                                         (SUM(InstallmentAmount - PaidAmount - WaivedAmount)
                                          - SUM(InterestAmount - AmountIncRecognize)
                                         ),
                                         0
                                     )
                            ) - @ExecutionCost
                           ) * @CoyPortionFundingContract / 100
                          )
                    ---End Silvia [FMF-2078]														
                    FROM InstallmentSchedule WITH (NOLOCK)
                    WHERE ApplicationID = @ApplicationID
                          AND BranchId = @BranchAgreement
                          AND ISNULL(FundingCoyPortion, 0) = 0;

                    SET @WOWaived = 0;
                    SET @WOAmountAloc = 0;
                    SET @WOAmountResidue = 0;
                    SET @AmountReceiveResidue = 0;
                    --Comment Sugiono FMF-1782
                    --SET @LostAmount = @LostAmount - (@AmountReceive - @CalOSPrincipalAmount - @RepoFeeBankPortion - @PrepaidBNK )
                    --SET @LostAmount = @LostAmount - (@AmountReceive - @CalOSPrincipalAmount - @RepoFeeBankPortion - @PrepaidBNK - @ExecutionCostBankPortion)----@ExecutionCost)--Sugiono FMF-1782
                    --PMK41
                    SET @LostAmount
                        = @LostAmount
                          - (@allocationamount - @CalOSPrincipalAmount - @RepoFeeBankPortion - @PrepaidBNK
                             - @ExecutionCostBankPortion
                            ); ----@ExecutionCost)--Sugiono FMF-1782



                    UPDATE dbo.AssetRepossessionOrder
                    SET IsPaymentHierarchy = 1,
                        SellingAmountBankPortion = ISNULL(@PrepaidBNK, 0)
                    WHERE ApplicationId = @ApplicationID;

                END;
                --End Add Fuji
                ELSE
                BEGIN
                    SET @WOWaived = @WOAmountResidue - @WOAmountAloc;
                    SET @WOAmountAloc = @WOAmountResidue;
                    SET @LostAmount = @WOWaived;
                END;
            END;

            --Vincenza FMF-2934 14092021
            IF @IsPaymentHierarchy = 1
            BEGIN
                SET @EarnAmount = (@EarnAmount * (100 - @fundingCoyPortion)) / 100;
            END;
            --end

            --Vita N 16 Okt 2024 (FMF-5185)
            IF @IsIntervalLCScheme = 1
            BEGIN
                SET @LCInstallmentCurrent = 0;
            END;
            --End Vita

            SET @EarnWaived = @EarnAmount - @EarnAmountAloc;
            SET @InsuranceWaived = @OSInsuranceDue - @OSInsuranceDueAloc;
            SET @ReposessWaived = @OSRepossessFee - @OSRepossessFeeAloc;
            SET @LCInstallmentWaived = @OSLCInstallment + @LCInstallmentCurrent - @LCInstallmentAloc;
            SET @LCInsuranceWaived = @OSLCInsurance + @LCInsuranceCurrent - @LCInsuranceAloc;
            SET @PDCBounceWaived = @OSPDCBounceFee - @OSPDCBounceFeeAloc;

            SET @EarnAmountAloc = @EarnAmount;
            SET @OSInsuranceDueAloc = @OSInsuranceDue;
            SET @OSRepossessFeeAloc = @OSRepossessFee;
            SET @LCInstallmentAloc = @OSLCInstallment + @LCInstallmentCurrent;
            SET @LCInsuranceAloc = @OSLCInsurance + @LCInsuranceCurrent;
            SET @OSPDCBounceFeeAloc = @OSPDCBounceFee;
        END;


        IF @AmountReceiveResidue > 0
        BEGIN
            SET @LostAmount = @LostAmount - @AmountReceiveResidue;
        -- Remark By, Gema, 20121112 : Remark terkait CR FMF-1245, jika masih ada sisa maka masuk sebagai profit
        --set @PrepaidAloc = @AmountReceiveResidue      
        --Set @AmountReceiveResidue = @AmountReceiveResidue
        --   - @PrepaidAloc   
        -- End Gema, 20121112 :

        END;

        SET @RefDesc = 'INVSELLRCV' + RTRIM(@ReferenceNo);

        /*Rubianto, 20100414*/
        DECLARE @TempLostAmount dbo.Amount;

        SET @TempLostAmount = 0; --Rendi 3 okt 2014 [FMF-1383]
        --Remark Gema, 20121112 : Remark terkait CR FMF-1245,
        --If @LostAmount > 0 
        --   BEGIN
        --      SET @TempLostAmount = @LostAmount
        --   END
        --ELSE 
        --   BEGIN
        --      SET @TempLostAmount = 0
        --   END
        --End Gema, 20121112

        --Gema, 20121112 : Remark terkait CR FMF-1245 : Jika nilainya positif (+) = Rugi dan jika nilainya negatif (-) = Untung
        IF @LostAmount <> 0
        BEGIN
            SET @TempLostAmount = @LostAmount;
        END;

        IF @StatusDefault = 'NA'
        BEGIN
            IF @DiffRate < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @DiffRate);
            END;
            IF @DiffRate > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @DiffRate;
            END;
            IF @Incentive < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @Incentive);
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @Incentive > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @Incentive;
            END;
            ---End Raug 
            IF @Provision < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @Provision);
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @Provision > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @Provision;
            END;
            ---End Raug 
            IF @AdminFee < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @AdminFee);
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @AdminFee > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @AdminFee;
            END;
            ---End Raug
            IF @DeferredInsurance < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @DeferredInsurance);
            END;
            IF @DeferredInsurance > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @DeferredInsurance;
            END;
            IF @InsuranceIncome < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @InsuranceIncome);
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @InsuranceIncome > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @InsuranceIncome;
            END;
            ---End Raug 
            IF @OtherRefund < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @OtherRefund);
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @OtherRefund > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @OtherRefund;
            END;
            IF @AdmFee < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @AdmFee);
            END;
            ---End Raug
            IF @AdmFee > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @AdmFee;
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @ProvisionFee < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @ProvisionFee);
            END;
            ---End Raug
            IF @ProvisionFee > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @ProvisionFee;
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @OtherFee < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @OtherFee);
            END;
            ---End Raug
            IF @OtherFee > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @OtherFee;
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @SurveyFee < 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @SurveyFee);
            END;
            ---End Raug
            IF @SurveyFee > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @SurveyFee;
            END;
            IF @costofSurvey < 0 --arif 15 okt 2010
            BEGIN
                SET @TempLostAmount = @TempLostAmount + (-1 * @costofSurvey);
            END;
            ---Raug, FMF-3195 30 Nov 2021 : Perbaiki cara update @TempLostAmount supaya handle PSAK plus minus
            IF @costofSurvey > 0
            BEGIN
                SET @TempLostAmount = @TempLostAmount - @costofSurvey;
            END;
        ---End Raug
        END;
        /*Rubianto End*/

        IF @IsLastAssetSold = '1' -- raug 20 april 2021 [FMF-2725]
        BEGIN
            ---Silvia, 01 Des 2020 [PI-2114] : Tambah perbaikan terkait error FMF-2386, jika kondisi kontrak di insseqno Rollover ada Interest yang belum diakui akan mengurangi nilai journal REPOPNL
            IF EXISTS
            (
                SELECT ''
                FROM InstallmentSchedule WITH (NOLOCK)
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID
                      AND InstallmentAmount = 0
                      AND PrincipalAmount < 0
                      AND (InterestAmount - AmountIncRecognize) <> 0
            )
            BEGIN
                DECLARE @DiffforREPOPNL NUMERIC(17, 2);
                SET @DiffforREPOPNL = 0;

                SELECT @DiffforREPOPNL = ISNULL(SUM(InterestAmount - AmountIncRecognize), 0)
                FROM InstallmentSchedule
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID
                      AND InstallmentAmount = 0
                      AND PrincipalAmount < 0
                      AND (InterestAmount - AmountIncRecognize) <> 0;
                SET @TempLostAmount = @TempLostAmount - @DiffforREPOPNL;
            END;
            ---End Silvia [PI-2114]

            ---Reyvano, 29 November 2023 [FMF-4746] : Tambah nilai sisa interest yang belum diakui atas pembayaran dipercepat, untuk mengurangi LostAmount
            IF EXISTS
            (
                SELECT ''
                FROM InstallmentSchedule WITH (NOLOCK)
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID
                      AND InstallmentAmount > 0
                      AND (InstallmentAmount - PaidAmount - WaivedAmount) = 0
                      AND (InterestAmount - AmountIncRecognize) <> 0
                      ---Reyvano, 6 Desember 2023 [FMF-4769] : Tambah pengecekan saat ambil @DiffforREPOPNL2 (Interest atas pembayaran dipercepat) apakah hasil ISL atau bukan, kalau bukan hasil ISL baru ngurangin Repoloss
                      AND InsSeqNo NOT IN
                          (
                              SELECT PHD.InsSeqNo
                              FROM PaymentHistoryHeader PHH WITH (NOLOCK)
                                  INNER JOIN PaymentHistoryDetail PHD WITH (NOLOCK)
                                      ON PHH.BranchId = PHD.BranchId
                                         AND PHH.ApplicationID = PHD.ApplicationID
                                         AND PHH.HistorySequenceNo = PHD.HistorySequenceNo
                              WHERE PHH.BranchId = @BranchAgreement
                                    AND PHH.ApplicationID = @ApplicationID
                                    AND ProcessID = 'INVSELLRCV'
                                    AND PHD.PaymentAllocationID = 'INSTALLRCV'
                                    AND InsSeqNo <> 0
                          )
            ---End Reyvano [FMF-4769]
            )
            BEGIN
                DECLARE @DiffforREPOPNL2 NUMERIC(17, 2);
                SET @DiffforREPOPNL2 = 0;

                SELECT @DiffforREPOPNL2 = ISNULL(SUM(InterestAmount - AmountIncRecognize), 0)
                FROM InstallmentSchedule WITH (NOLOCK)
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID
                      AND InstallmentAmount > 0
                      AND (InstallmentAmount - PaidAmount - WaivedAmount) = 0
                      AND (InterestAmount - AmountIncRecognize) <> 0
                      ---Reyvano, 6 Desember 2023 [FMF-4769] : Tambah pengecekan saat ambil @DiffforREPOPNL2 (Interest atas pembayaran dipercepat) apakah hasil ISL atau bukan, kalau bukan hasil ISL baru ngurangin Repoloss
                      AND InsSeqNo NOT IN
                          (
                              SELECT PHD.InsSeqNo
                              FROM PaymentHistoryHeader PHH WITH (NOLOCK)
                                  INNER JOIN PaymentHistoryDetail PHD WITH (NOLOCK)
                                      ON PHH.BranchId = PHD.BranchId
                                         AND PHH.ApplicationID = PHD.ApplicationID
                                         AND PHH.HistorySequenceNo = PHD.HistorySequenceNo
                              WHERE PHH.BranchId = @BranchAgreement
                                    AND PHH.ApplicationID = @ApplicationID
                                    AND ProcessID = 'INVSELLRCV'
                                    AND PHD.PaymentAllocationID = 'INSTALLRCV'
                                    AND InsSeqNo <> 0
                          );
                ---End Reyvano [FMF-4769]

                SET @TempLostAmount = @TempLostAmount - @DiffforREPOPNL2;
            END;
        ---End Reyvano [FMF-4746]

        END;
        PRINT '@TempLostAmount';
        PRINT @TempLostAmount;
        PRINT @LCInstallmentAloc;
        PRINT @EarnAmountAloc;
        --Vincenza FMF-2934 23082021

        --Added by Reyvano FMF-5229 22 Nov 2024
        --DECLARE @NADate DATETIME;
        DECLARE @ECIAmount Amount;
		SET @ECIAmount = 0 --Added by Aurellie : FMF-5310

        SELECT @NADate = NADate
        FROM dbo.Agreement WITH (NOLOCK)
        WHERE BranchID = @BranchID
              AND ApplicationID = @ApplicationID;

        --SELECT @ECIAmount = SUM(AmountIncRecognize)
		SELECT @ECIAmount = SUM(ISNULL(AmountIncRecognize,0)) --Added by Aurellie : FMF-5310
        FROM dbo.InstallmentSchedule WITH (NOLOCK)
        --WHERE BranchId = @BranchId --Remark Aurellie 31 Des 2024 (FMF-5308) : ubah @BranchId jadi @BranchAgreement di ECIAmount
		WHERE BranchId = @BranchAgreement --Add Aurellie 31 Des 2024 (FMF-5308) : ubah @BranchId jadi @BranchAgreement di ECIAmount
              AND ApplicationID = @ApplicationID
              --AND DueDate <= @NADate --Remark Vita, 23 Des 2024 (FMF-5229) : take out kondisi ini untuk handle case accrued sebagian pada EOM untuk due date > NA date
              AND (InstallmentSchedule.InstallmentAmount - InstallmentSchedule.PaidAmount
                   - InstallmentSchedule.WaivedAmount
                  ) > 0
              AND AmountIncRecognize <> 0
              AND LastIncRecognize IS NOT NULL;

        --Ended by Reyvano FMF-5229

        DECLARE @RepoAmount NUMERIC(17, 2);
		SET @RepoAmount = 0 --Added by Aurellie : FMF-5310

        IF @IsPaymentHierarchy = 0
        BEGIN
            --SET @RepoAmount = @TempLostAmount + @LCInstallmentAloc + @EarnAmountAloc;
            --Changed by Reyvano FMF-5229
            --SET @RepoAmount = @TempLostAmount + @EarnAmountAloc - @ECIAmount;
			SET @RepoAmount = ISNULL(@TempLostAmount,0) + ISNULL(@EarnAmountAloc,0) - ISNULL(@ECIAmount,0); --Added by Aurellie : FMF-5310
        --ended by Reyvano FMF-5229
        END;
        IF @IsPaymentHierarchy = 1
        BEGIN
            IF @StatusDefault = 'WO'
            BEGIN
                --SET @RepoAmount = @TempLostAmount + @LCInstallmentAloc + @EarnAmountAloc;
                --Changed by Reyvano FMF-5229
                --SET @RepoAmount = @TempLostAmount + @EarnAmountAloc - @ECIAmount;
				SET @RepoAmount = ISNULL(@TempLostAmount,0) + ISNULL(@EarnAmountAloc,0) - ISNULL(@ECIAmount,0); --Added by Aurellie : FMF-5310
            --ended by Reyvano FMF-5229
            END;
            IF @StatusDefault = 'NA'
            BEGIN
                --SET @RepoAmount = @TempLostAmount + @LCInstallmentAloc + @EarnAmountAloc;
                --Chaned by Reyvano FMF-5229
                --SET @RepoAmount = @TempLostAmount + @EarnAmountAloc - @ECIAmount;
				SET @RepoAmount = ISNULL(@TempLostAmount,0) + ISNULL(@EarnAmountAloc,0) - ISNULL(@ECIAmount,0); --Added by Aurellie : FMF-5310
            --ended by Reyvano FMF-5229
            END;
        END;
        --end Vincenza



        SET @Counter = 1;
        WHILE @Counter <= 50 --PMK41 49 -- arif ganti dari 41 ke 43--Rubianto, 20100413 : Ganti dari 27 jadi 41  --Edit fuji,16 Mei 2018 (FMF-1649) ubah dari 43 -> 46 --Edit Sugiono,04 Okt 2019 (FMF-1782) ubah dari 46 -> 47 --Vincenza 26072021 FMF-2847 47 -> 49
        BEGIN
            --  If @Counter = 1      
            --  Begin      
            --   If @StatusDefault = 'NA'       
            --   BEGIN      
            --    If @NAAmountAloc > 0       
            --    Begin      
            --     Set @AmountJournal = @NAAmountAloc      
            --     Set @PostJournal = 'C'      
            --     Set @PaymentAllocationJournal = 'CRTNARCV'      
            --    End      
            --   END      
            --   If @StatusDefault = 'WO'       
            --   BEGIN      
            --    If @WOAmountAloc > 0       
            --    Begin      
            --     Set @AmountJournal = @WOAmountAloc      
            --     Set @PostJournal = 'C'      
            --     Set @PaymentAllocationJournal = 'CRTWORCV'      
            --    End      
            --   END      
            --  End      
            --  else   
            IF @Counter = 2
            BEGIN
                IF @EarnAmountAloc + @ECIAmount > 0
                BEGIN
                    --SET @AmountJournal = @EarnAmountAloc; --+ @ECIPartial		-- Lisa 20090430 : Tambah untuk handle partial payment yg lbh besar dari principal 
                    --SET @PostJournal = 'C'
                    --changed by Reyvano FMF-5229 22 Nov 2024
                    SET @AmountJournal = @EarnAmountAloc + @ECIAmount; --+ @ECIPartial		-- Lisa 20090430 : Tambah untuk handle partial payment yg lbh besar dari principal 
                    SET @PostJournal = 'D';
                    --ended by Reyvano FMF-5229
                    SET @PaymentAllocationJournal = 'ECI';
                END;
            END;

            ELSE IF @Counter = 3
            BEGIN
                IF @OSInsuranceDueAloc > 0
                BEGIN
                    SET @AmountJournal = @OSInsuranceDueAloc; -- OK      
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'INSURRCV';
                END;
            END;
            ELSE IF @Counter = 4
            BEGIN
                IF @OSRepossessFeeAloc > 0
                BEGIN
                    SET @AmountJournal = @OSRepossessFeeAloc; -- OK
                    SET @PostJournal = 'C';

                    SET @PaymentAllocationJournal = 'REPOFEE';
                END;
            END;
            ELSE IF @Counter = 5
            BEGIN
                IF @LCInstallmentAloc > 0
                BEGIN
                    SET @AmountJournal = @LCInstallmentAloc; -- OK
                    SET @PostJournal = 'C';

                    SET @PaymentAllocationJournal = 'LCINSTALL';
                END;
            END;
            ELSE IF @Counter = 6
            BEGIN
                IF @LCInsuranceAloc > 0
                BEGIN
                    SET @AmountJournal = @LCInsuranceAloc; -- OK      
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'LCINSUR';
                END;
            END;
            ELSE IF @Counter = 7
            BEGIN
                IF @OSPDCBounceFeeAloc > 0
                BEGIN
                    SET @AmountJournal = @OSPDCBounceFeeAloc; -- OK      
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'PDCBNCFEE';
                END;
            END;

            ELSE IF @Counter = 8
            BEGIN
                IF @PrepaidAloc > 0
                BEGIN
                    SET @AmountJournal = @PrepaidAloc;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'PREPAID';
                END;
            END;

            --Remark by Rubianto, 20100414  
            --Else If @Counter = 9      
            --Begin      
            -- If @LostAmount > 0      
            -- Begin      
            --  Set @AmountJournal = @LostAmount      
            --  Set @PostJournal = 'D'      
            --  Set @PaymentAllocationJournal = 'REPOPNL'      
            -- End      
            --End      
            ELSE IF @Counter = 9
            BEGIN
                IF @FlagAssetTypeID = 0 --Vincenza FMF-2847 28072021
                BEGIN
                    --IF @TempLostAmount > 0
                    IF @RepoAmount > 0
                    BEGIN
                        SET @AmountJournal = @RepoAmount;
                        SET @PostJournal = 'D';
                        SET @PaymentAllocationJournal = 'REPOPNL';
                    END;
                    ELSE IF @RepoAmount < 0
                    BEGIN
                        SET @AmountJournal = -1 * @RepoAmount;
                        SET @PostJournal = 'C';
                        SET @PaymentAllocationJournal = 'REPOPNL';
                    END;
                END;
                ELSE --Vincenza FMF-2847 28072021
                BEGIN
                    SET @AmountJournal = 0;
                END;
            END;


            ELSE IF @Counter = 10
            BEGIN
                IF @EarnWaived > 0
                BEGIN
                    SET @AmountJournal = @EarnWaived; -- OK      
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'INTERESTWO';
                END;
            END;

            ELSE IF @Counter = 11
            BEGIN
                IF @InsuranceWaived > 0
                BEGIN
                    SET @AmountJournal = @InsuranceWaived;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'INSURWO';
                END;
            END;

            ELSE IF @Counter = 12
            BEGIN
                IF @ReposessWaived > 0
                BEGIN
                    SET @AmountJournal = @ReposessWaived; -- OK      
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'REPOFEEWO';
                END;
            END;

            ELSE IF @Counter = 13
            BEGIN
                IF @LCInstallmentWaived > 0
                BEGIN
                    SET @AmountJournal = @LCInstallmentWaived;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'LCINSTALWO';
                END;
            END;

            ELSE IF @Counter = 14
            BEGIN
                IF @LCInsuranceWaived > 0
                BEGIN
                    SET @AmountJournal = @LCInsuranceWaived;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'LCINSURWO';
                END;
            END;

            ELSE IF @Counter = 15
            BEGIN
                IF @PDCBounceWaived > 0
                BEGIN
                    SET @AmountJournal = @PDCBounceWaived;
                    SET @PostJournal = 'D';
                    SET @PaymentAllocationJournal = 'PDCBNCFEWO';
                END;
            END;

            --�������� ARIF ���� START ���������������������������������������������������������������������������������������������������������������    
            ELSE IF @Counter = 16
            BEGIN
                IF @StatusDefault = 'NA'
                BEGIN
                    IF @ARNA > 0
                    BEGIN
                        SET @AmountJournal = @ARNA;
                        SET @PostJournal = 'C';
                        SET @PaymentAllocationJournal = 'ARNA';
                    END;
                END;
            END;

            ELSE IF @Counter = 17
            BEGIN
                IF @StatusDefault = 'NA'
                BEGIN
                    IF @UCINA > 0
                    BEGIN
                        SET @AmountJournal = @UCINA;
                        SET @PostJournal = 'D';
                        SET @PaymentAllocationJournal = 'UCINA';
                    END;
                END;
            END;

            ELSE IF @Counter = 18
            BEGIN
                -- Yovita 23 Oct 07: jika WO create Journal CRTWORCV  
                IF @StatusDefault = 'WO'
                BEGIN
                    IF @WOAmountAloc > 0
                    BEGIN
                        SET @AmountJournal = @WOAmountAloc;
                        SET @PostJournal = 'C';
                        SET @PaymentAllocationJournal = 'CRTWORCV';
                    END;
                END;
            END;

            /*Rubianto, 20100413 diff rate*/
            --Else If @Counter = 19      
            --Begin      
            -- Set @AmountJournal = @DiffRate      
            -- Set @PostJournal = 'D'     

            -- If @DiffRate > 0      
            --   IF @StatusDefault = 'NA' --Gema, 20081107 : cek @StatusDefault  
            --   Begin  
            --     Set @PaymentAllocationJournal = 'RATESIDYNA'      
            --   End  
            --   Else  
            --   Begin  
            --     Set @PaymentAllocationJournal = 'RATESIDYWO'      
            --   End  
            -- Else    
            -- Begin    
            --   Set @PaymentAllocationJournal = 'RFNDAMZ'     
            --   Set @AmountJournal = -1 * @DiffRate      
            -- End    

            --End      

            --Else If @Counter = 20      
            --Begin      
            -- Set @AmountJournal = @DiffRate      
            -- Set @PostJournal = 'C'   

            -- If @DiffRate > 0      
            --  Set @PaymentAllocationJournal = 'SSIDYAMZ'   
            -- Else    
            -- Begin  
            --   IF @StatusDefault = 'NA' --Gema, 20081107 : cek @StatusDefault  
            --   Begin    
            --   Set @PaymentAllocationJournal = 'RATERFNDNA'       
            --   Set @AmountJournal = -1 * @DiffRate   
            --   End     
            --   Else  
            --   Begin  
            --      Set @PaymentAllocationJournal = 'RATERFNDWO'       
            --   Set @AmountJournal = -1 * @DiffRate     
            --   End  
            -- End    
            --End      
            ELSE IF @Counter = 19
            BEGIN
                SET @AmountJournal = @DiffRate;
                SET @PostJournal = 'D';

                IF @DiffRate > 0
                BEGIN
                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'RATESIDYNA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
                ELSE
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;

            END;

            ELSE IF @Counter = 20
            BEGIN
                SET @AmountJournal = @DiffRate;
                SET @PostJournal = 'C';

                IF @DiffRate > 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;
                ELSE
                BEGIN
                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'RATERFNDNA';
                        SET @AmountJournal = -1 * @DiffRate;
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;


            --Else If @Counter = 21      
            --Begin      
            -- If @Incentive < 0      
            -- Begin      
            --   Set @AmountJournal = -1 * @Incentive      
            --   Set @PostJournal = 'D'      
            --   Set @PaymentAllocationJournal = 'INCSUPPEXP'      
            -- End      
            --End      

            --Else If @Counter = 22      
            --Begin      
            -- If @Incentive < 0      
            -- Begin      
            --   Set @AmountJournal = -1 * @Incentive      
            --   Set @PostJournal = 'C'    

            --   IF @StatusDefault = 'NA' --Gema, 20081107 : cek @StatusDefault  
            --   Begin     
            --    Set @PaymentAllocationJournal = 'INCESPL1NA'      
            --   End  
            --   Else  
            --   Begin  
            --    Set @PaymentAllocationJournal = 'INSUPEXPWO'   
            --   End    
            -- End      
            --End   
            ELSE IF @Counter = 21
            BEGIN
                IF @Incentive < 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal 
                END;
            END;

            ELSE IF @Counter = 22
            BEGIN
                IF @Incentive <> 0 ---Raug, FMF-3195 30 Nov 2021 : Supaya handle PSAK plus minus
                BEGIN
                    IF @Incentive < 0
                    BEGIN
                        SET @AmountJournal = -1 * @Incentive;
                        SET @PostJournal = 'C';
                    END;
                    ---Raug, FMF-3195 30 Nov 2021 : Supaya handle PSAK plus minus
                    ELSE IF @Incentive > 0
                    BEGIN
                        SET @AmountJournal = @Incentive;
                        SET @PostJournal = 'D';
                    END;
                    ---End Raug

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'INCESPL1NA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;



            --Else If @Counter = 23      
            --Begin      
            -- If @Provision < 0      
            -- Begin      
            --  Set @AmountJournal = -1 * @Provision      
            --  Set @PostJournal = 'D'      
            --  Set @PaymentAllocationJournal = 'PROVEXP'      
            -- End      
            --End      

            --Else If @Counter = 24    
            --Begin      
            -- If @Provision < 0      
            -- Begin      
            --   Set @AmountJournal = -1 * @Provision      
            --   Set @PostJournal = 'C'      

            --      IF @StatusDefault = 'NA' --Gema, 20081107 : cek @StatusDefault  
            --   Begin     
            --    Set @PaymentAllocationJournal = 'PROVBANKNA'      
            --   End  
            --   Else  
            --   Begin  
            --    Set @PaymentAllocationJournal = 'PROVEXPWO'   
            --   End       
            -- End      
            --End      

            ELSE IF @Counter = 23
            BEGIN
                IF @Provision < 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal 
                END;
            END;

            ELSE IF @Counter = 24
            BEGIN
                IF @Provision <> 0 ---Raug, FMF-3195 30 Nov 2021
                BEGIN
                    IF @Provision < 0
                    BEGIN
                        SET @AmountJournal = -1 * @Provision;
                        SET @PostJournal = 'C';
                    END;
                    ---Raug, FMF-3195 30 Nov 2021 : Supaya handle PSAK Plus minus
                    ELSE IF @Provision > 0
                    BEGIN
                        SET @AmountJournal = @Provision;
                        SET @PostJournal = 'D';
                    END;
                    ---End Raug  

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'PROVBANKNA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;

            --�������� ARIF ����  END  ���������������������������������������������������������������������������������������������������������������    

            --Gema, 20081107 : Add Journal AdminFee -----------------------------------  
            /*Rubianto 20100413*/
            --Else If @Counter = 25      
            --Begin      
            -- If @AdminFee < 0      
            -- Begin      
            --   Set @AmountJournal = -1 * @AdminFee      
            --   Set @PostJournal = 'D'      
            --   Set @PaymentAllocationJournal = 'ADMFEEAMZ'      
            -- End      
            --End    

            --Else If @Counter = 26   
            --Begin      
            -- If @AdminFee < 0      
            -- Begin      
            --   Set @AmountJournal = -1 * @AdminFee     
            --   Set @PostJournal = 'C'      

            --      IF @StatusDefault = 'NA' --Gema, 20081107 : cek @StatusDefault  
            --   Begin     
            --    Set @PaymentAllocationJournal = 'ADMFEENA'      
            --   End  
            --   Else  
            --   Begin  
            --    Set @PaymentAllocationJournal = 'ADMFEEWO'   
            --   End       
            -- End      
            --End    
            ELSE IF @Counter = 25
            BEGIN
                IF @AdminFee < 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal     
                END;
            END;

            ELSE IF @Counter = 26
            BEGIN
                IF @AdminFee <> 0 ---Raug, FMF-3195 30 Nov 2021
                BEGIN
                    IF @AdminFee < 0
                    BEGIN
                        SET @AmountJournal = -1 * @AdminFee;
                        SET @PostJournal = 'C';
                    END;
                    ---Raug, FMF-3195 30 Nov 2021 : Supaya handle PSAK plus minus
                    ELSE IF @AdminFee > 0
                    BEGIN
                        SET @AmountJournal = @AdminFee;
                        SET @PostJournal = 'D';
                    END;
                    ---End Raug

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'ADMFEENA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;
            --Deferred Insurance Income
            ELSE IF @Counter = 27
            BEGIN
                SET @AmountJournal = @DeferredInsurance;
                SET @PostJournal = 'D';

                IF @DeferredInsurance > 0
                BEGIN
                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'DEFINSURNA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
                ELSE
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;

            END;

            ELSE IF @Counter = 28
            BEGIN
                SET @AmountJournal = @DeferredInsurance;
                SET @PostJournal = 'C';

                IF @DeferredInsurance > 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal 
                END;
                ELSE
                BEGIN
                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'INSREXPNA';
                        SET @AmountJournal = -1 * @DeferredInsurance;
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;
            --Insurance Refund											

            ELSE IF @Counter = 29
            BEGIN
                IF @InsuranceIncome < 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;
            END;
            ELSE IF @Counter = 30
            BEGIN
                ---Raug, FMF-3195 30 Nov 2021 : Perbaiki supaya handle PSAK plus minus 
                --IF @InsuranceIncome < 0
                IF @InsuranceIncome <> 0
                ---End Raug
                BEGIN
                    ---Raug, FMF-3195 30 Nov 2021 : Perbaiki supaya handle PSAK plus minus 
                    IF @InsuranceIncome < 0
                    BEGIN
                        SET @AmountJournal = -1 * @InsuranceIncome;
                        SET @PostJournal = 'C';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = @InsuranceIncome;
                        SET @PostJournal = 'D';
                    END;
                    ---End Raug

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'INSRRFDNA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;
            --Other Refund
            ELSE IF @Counter = 31
            BEGIN
                IF @OtherRefund < 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;
            END;

            ELSE IF @Counter = 32
            BEGIN
                IF @OtherRefund <> 0 ---Raug, FMF-3195 30 Nov 2021    
                BEGIN
                    IF @OtherRefund < 0
                    BEGIN
                        SET @AmountJournal = -1 * @OtherRefund;
                        SET @PostJournal = 'C';
                    END;
                    ---Raug, FMF-3195 30 Nov 2021    
                    ELSE IF @OtherRefund > 0
                    BEGIN
                        SET @AmountJournal = @OtherRefund;
                        SET @PostJournal = 'D';
                    END;
                    ---End Raug

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'COMOTHNA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;
            --AdmFee
            ELSE IF @Counter = 33
            BEGIN
                SET @AmountJournal = @AdmFee;
                SET @PostJournal = 'D';

                IF @AdmFee > 0
                BEGIN
                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'ADMNFEENA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;

            ELSE
            --Niko 7 Juli 2021 FMF-2863
            -- IF @Counter = 34
            --BEGIN
            --SET @AmountJournal = @AdmFee
            --SET @PostJournal = 'C'
            --IF @AdmFee > 0
            --BEGIN
            --SET @AmountJournal = 0 --WO tidak membentuk jurnal
            --END
            -- END

            IF @Counter = 34
            BEGIN
                SET @AmountJournal = @AdmFee * -1;
                SET @PostJournal = 'C';
                IF @AdmFee < 0
                BEGIN
                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'ADMNFEENA';
                    END;
                END;
                ELSE
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;
            END;

            --End Niko 7 Juli 2021 FMF-2863


            --ProvisionFee
            ELSE IF @Counter = 35
            BEGIN
                ---Raug, FMF-3195 30 Nov 2021
                IF @ProvisionFee <> 0
                BEGIN
                    --SET @AmountJournal = @ProvisionFee      
                    --SET @PostJournal = 'D'     

                    IF @ProvisionFee > 0
                    BEGIN
                        SET @AmountJournal = @ProvisionFee;
                        SET @PostJournal = 'D';
                    END;
                    ---Raug, FMF-3195 30 Nov 2021
                    ELSE IF @ProvisionFee < 0
                    BEGIN
                        SET @AmountJournal = ABS(@ProvisionFee);
                        SET @PostJournal = 'C';
                    END;
                    ---End Raug

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'PRVFEENA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;

            ELSE IF @Counter = 36
            BEGIN
                SET @AmountJournal = @ProvisionFee;
                SET @PostJournal = 'C';

                IF @ProvisionFee > 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;
            END;

            --OtherFee
            ELSE IF @Counter = 37
            BEGIN
                ---Raug, FMF-3195 30 Nov 2021  
                IF @OtherFee <> 0
                BEGIN

                    --SET @AmountJournal = @OtherFee      
                    --SET @PostJournal = 'D'     

                    IF @OtherFee > 0
                    BEGIN
                        SET @AmountJournal = @OtherFee;
                        SET @PostJournal = 'D';
                    END;
                    ---Raug, FMF-3195 30 Nov 2021  
                    ELSE IF @OtherFee < 0
                    BEGIN
                        SET @AmountJournal = ABS(@OtherFee);
                        SET @PostJournal = 'C';
                    END;

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'OTHFEENA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;

            ELSE IF @Counter = 38
            BEGIN
                SET @AmountJournal = @OtherFee;
                SET @PostJournal = 'C';

                IF @OtherFee > 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;
            END;

            --SurveyFee
            ELSE IF @Counter = 39
            BEGIN
                IF @SurveyFee <> 0 ---Raug, FMF-3195 30 Nov 2021
                BEGIN
                    --SET @AmountJournal = @SurveyFee      
                    --SET @PostJournal = 'D'   
                    IF @SurveyFee > 0
                    BEGIN
                        SET @AmountJournal = @SurveyFee;
                        SET @PostJournal = 'D';
                    END;
                    ---Raug, FMF-3195 30 Nov 2021
                    ELSE IF @SurveyFee < 0
                    BEGIN
                        SET @AmountJournal = ABS(@SurveyFee);
                        SET @PostJournal = 'C';
                    END;
                    ---End Raug

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'SVYFEENA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            END;

            ELSE IF @Counter = 40
            BEGIN

                SET @AmountJournal = @SurveyFee;
                SET @PostJournal = 'C';

                IF @SurveyFee > 0
                BEGIN
                    SET @AmountJournal = 0; --WO tidak membentuk jurnal
                END;

            END;

            /*Rubianto End*/
            --- Chris 15 May 2009 ---
            ---Tendi 07 may 2009-----Tambahan OtherINC---------------------

            ELSE
            --Dessy remark 27012014 (FMF-1337), pindahkan di urutan terakhir
            --If @Counter = 41 
            --   BEGIN

            --      declare @Rounded Numeric(17, 2),
            --         @Debit Amount,
            --         @Credit Amount,
            --         @CustomerName varchar(50)

            --      select   @Rounded = Rounded
            --      from     Currency with ( nolock )
            --      where    CurrencyID = @CurrencyID      

            --      select   @CustomerName = Customer.Name
            --      from     Agreement with ( nolock )
            --      inner join Customer with ( nolock )
            --               on Agreement.CustomerID = Customer.CustomerID
            --      where    Agreement.BranchID = @BranchID
            --               and Agreement.ApplicationID = @ApplicationID  

            --      select   @Debit = sum(Amount) + @AmountReceive
            --      from     #TempTable
            --      where    Post = 'D'
            --      select   @Credit = sum(Amount)
            --      from     #TempTable
            --      where    Post = 'C'
            --      Set @PaymentAllocationJournal = 'OTHERINC'      


            --      if ( @Debit - @Credit ) >= 0 
            --         begin      
            --            Set @PostJournal = 'C'  
            --            Set @AmountJournal = @Debit - @Credit
            --         end     
            --      else 
            --         begin      
            --            Set @PostJournal = 'D' 
            --            Set @AmountJournal = -1 * ( @Debit - @Credit )
            --         end        

            --      Set @Refdesc = Rtrim(Ltrim(rtrim(@AgreementNo)) + '#' + ltrim(@CustomerName))      
            --      if ( @AmountJournal > @Rounded ) 
            --         begin      
            --            set @AmountJournal = 0      
            --         end    
            --   END
            --Else 
            --end Dessy remark 27012014 (FMF-1337)
            IF @Counter = 41 --42  --Dessy 27012014 (FMF-1337), ubah counter 42 -> 41
            BEGIN
                IF @costofSurvey < 0
                BEGIN

                    SET @AmountJournal = 0; --WO tidak membentuk jurnal 
                END;
            END;

            ELSE IF @Counter = 42 --43 --Dessy 27012014 (FMF-1337), ubah counter 43 -> 42
            BEGIN
                IF @costofSurvey < 0
                BEGIN
                    SET @RefDesc = 'INVSELLRCV' + RTRIM(@ReferenceNo);
                    SET @AmountJournal = -1 * @costofSurvey;
                    SET @PostJournal = 'C';

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'CSTSVY1NA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;

                --Begin Niko, 7 Juli 2021 FMF-2863
                IF @costofSurvey > 0
                BEGIN
                    SET @RefDesc = 'INVSELLRCV' + RTRIM(@ReferenceNo);
                    SET @AmountJournal = @costofSurvey;
                    SET @PostJournal = 'D';

                    IF @StatusDefault = 'NA'
                    BEGIN
                        SET @PaymentAllocationJournal = 'CSTSVY1NA';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0; --WO tidak membentuk jurnal
                    END;
                END;
            --End Niko FMF-2863  
            END;

            --Dessy add 27012014 (FMF-1337), pindah ke sini, dan ganti @Counter dari 41 ke 43                                                                                  
            ELSE IF @Counter = 43
            BEGIN

                DECLARE @Rounded NUMERIC(17, 2),
                        @Debit Amount,
                        @Credit Amount,
                        @CustomerName VARCHAR(50);

                SELECT @Rounded = Rounded
                FROM Currency WITH (NOLOCK)
                WHERE CurrencyID = @CurrencyID;

                SELECT @CustomerName = Customer.Name
                FROM Agreement WITH (NOLOCK)
                    INNER JOIN Customer WITH (NOLOCK)
                        ON Agreement.CustomerID = Customer.CustomerID
                WHERE Agreement.BranchID = @BranchID
                      AND Agreement.ApplicationID = @ApplicationID;

                SELECT @Debit = SUM(Amount) + @AmountReceive
                FROM #TempTable
                WHERE Post = 'D';
                SELECT @Credit = SUM(Amount)
                FROM #TempTable
                WHERE Post = 'C';
                SET @PaymentAllocationJournal = 'OTHERINC';


                IF (@Debit - @Credit) >= 0
                BEGIN
                    SET @PostJournal = 'C';
                    SET @AmountJournal = @Debit - @Credit;
                END;
                ELSE
                BEGIN
                    SET @PostJournal = 'D';
                    SET @AmountJournal = -1 * (@Debit - @Credit);
                END;

                SET @RefDesc = RTRIM(LTRIM(RTRIM(@AgreementNo)) + '#' + LTRIM(@CustomerName));
                IF (@AmountJournal > @Rounded)
                BEGIN
                    SET @AmountJournal = 0;
                END;
            END;
            --End Dessy add 27012014 (FMF-1337)     
            --Add Fuji,16 Mei 2018 (FMF-1649)
            ELSE IF @Counter = 44
            BEGIN
                IF @RepoFeeBankPortion > 0
                BEGIN
                    SET @AmountJournal = @RepoFeeBankPortion;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'REPOFEE';
                END;
            END;
            ELSE IF @Counter = 45
            BEGIN
                IF @CalOSPrincipalAmount > 0
                BEGIN
                    SET @AmountJournal = @CalOSPrincipalAmount;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'OTHERINCWO';
                END;
            END;
            ELSE IF @Counter = 46
            BEGIN
                IF @PrepaidBNK > 0
                BEGIN
                    SET @AmountJournal = @PrepaidBNK;
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'PREPAIDBNK';
                END;
            END;
            --end fuji	

            --Add Sugiono FMF-1782
            ELSE IF @Counter = 47
            BEGIN
                SET @RefDesc = 'INVSELLRCV' + RTRIM(@ReferenceNo);
                IF @IsPaymentHierarchy = 1
                BEGIN
                    SET @AmountJournal = @ExecutionCostBankPortion; --@ExecutionCost --edit fuji,07 nov 2019 (fmf-1782 UAT)
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'EXECOST';
                END;
                ELSE
                    SET @AmountJournal = 0;
            END;
            --End Sugiono		

            --Vincenza FMF-2847 03082021

            ELSE IF @Counter = 48
            BEGIN
                SET @RefDesc = 'INVSELLRCV' + RTRIM(@ReferenceNo);
                IF @FlagAssetTypeID = 1
                BEGIN
                    IF @RepoAmount < 0
                    BEGIN
                        SET @AmountJournal = ABS(@RepoAmount);
                        SET @PostJournal = 'C';
                        SET @PaymentAllocationJournal = 'PREPAID';
                    END;
                    ELSE
                    BEGIN
                        SET @AmountJournal = 0;
                    END;
                END;
                ELSE
                    SET @AmountJournal = 0;
            END;
            ELSE IF @Counter = 49
            BEGIN
                SET @RefDesc = 'INVSELLRCV' + RTRIM(@ReferenceNo);
                IF @FlagAssetTypeID = 1
                BEGIN
                    IF @RepoAmount > 0
                    BEGIN
                        SET @AmountJournal = @RepoAmount;
                        SET @PostJournal = 'D';
                        SET @PaymentAllocationJournal = 'REPOLOSS';
                    END;
                    ELSE
                        SET @AmountJournal = 0;
                END;
                ELSE
                BEGIN
                    SET @AmountJournal = 0;
                END;
            END;
            --end Vincenza
            -- PMK41
            IF @Counter = 50
            BEGIN
                SET @RefDesc = 'AP Tax Asset Selling' + RTRIM(@ReferenceNo);
                IF ISNULL(@PPN, 0) > 0
                BEGIN
                    SET @AmountJournal = ABS(@PPN);
                    SET @PostJournal = 'C';
                    SET @PaymentAllocationJournal = 'APTAXAS';
                END;
                ELSE
                BEGIN
                    SET @AmountJournal = 0;
                END;
            END;



            IF @AmountJournal > 0
            BEGIN
                INSERT INTO #TempTable
                (
                    PaymentAllocationID,
                    Post,
                    Amount,
                    RefDesc,
                    VoucherDesc
                )
                VALUES
                (@PaymentAllocationJournal, @PostJournal, @AmountJournal, @RefDesc, '');


                IF @@error <> 0
                BEGIN
                    GOTO ExitSP;
                END;
            END;
            SET @AmountJournal = 0;
            SET @Counter = @Counter + 1;
        END;

        --------Tambahan OtherINC---------------------
        -----

        --End Gema, 20081107 -------------------------------------------------------   

        /* 
  If @AmountJournal > 0       
  Begin      
   Insert Into #TempTable (PaymentAllocationID, Post, Amount,       
     RefDesc, VoucherDesc)      
      
   Values(@PaymentAllocationJournal, @PostJournal, @AmountJournal, @Refdesc, '')      
   If @@error <>  0       
   Begin      
    Goto ExitSP      
   End       
  end      
  Set @AmountJournal = 0      
  Set @Counter = @Counter + 1      
 End      
    */
        IF @IsLastAssetSold = '1'
        BEGIN
            DECLARE @ProductType CHAR(2); --Gema 9 Agustus 2007 : Untuk mendapatkan ProductType          

            SELECT @ProductType = ProductType
            FROM Agreement WITH (NOLOCK)
            WHERE BranchID = @BranchID
                  AND ApplicationID = @ApplicationID;

            --GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG          
            -------------------------------------------------------------------------------              
            -- Journal --              
            -- u/Leasing              
            -- Gema 8 Agustus 2007 : RESIDUNPL dan SECDEPNPL dan insert ke Payment History              
            -- Nilai diambil dari tbl Agreement.DownPayment              
            -------------------------------------------------------------------------------              
            -- Dewi 01022013 added begin
            IF @StatusDefault = 'NA'
            BEGIN
                -- Dewi 01022013 added end
                IF @ProductType = 'LS'
                BEGIN

                    IF @Downpayment > 0
                    BEGIN

                        INSERT INTO #TempTable
                        (
                            PaymentAllocationID,
                            Post,
                            Amount,
                            RefDesc,
                            VoucherDesc
                        )
                        VALUES
                        ('SECDEPNPL', 'D', @Downpayment, @AgreementNo, '');
                        IF @@error <> 0
                            GOTO ExitSP;

                        INSERT INTO #TempTable
                        (
                            PaymentAllocationID,
                            Post,
                            Amount,
                            RefDesc,
                            VoucherDesc
                        )
                        VALUES
                        ('RESIDUNPL', 'C', @Downpayment, @AgreementNo, '');
                        IF @@error <> 0
                            GOTO ExitSP;

                    END;
                END;
            END;
        END;
        --debug chandra     
        --SELECT  *
        --FROM    #Temptable   
        --end debug

        EXECUTE @Error = spProcessUpdateCashBank @BranchID,
                                                 @BankAccountID,
                                                 @LoginID,
                                                 @BusinessDate,
                                                 @WOP,
                                                 @AmountReceive,
                                                 @CurrencyID,
                                                 @OpeningSequence OUTPUT;
        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;
        --notes FMF-5229 untuk PREPAID dan REPOFEE
        --Vincenza FMF-2934 23082021
        IF EXISTS
        (
            SELECT ''
            FROM #TempTable WITH (NOLOCK)
            WHERE PaymentAllocationID IN ( 'REPOPNL', 'REPOLOSS', 'PREPAID' )
        )
        BEGIN
            DELETE #TempTable
            --WHERE PaymentAllocationID IN ( 'INTERESTWO', 'LCINSTALWO' );
            WHERE PaymentAllocationID IN ( 'INTERESTWO' ); --changed by Reyvano FMF-5229 : take out where cond untuk pay alloc LCINSTALWO agar tetap terbentuk jurnalnya
        END;

        DECLARE @PrpAmt NUMERIC(17, 2),
                @RepoWoAmt NUMERIC(17, 2),
                @RepoAmountPrp NUMERIC(17, 2);

        SET @RepoAmountPrp = @RepoAmount;

        SELECT @PrpAmt = ISNULL(Amount, 0)
        FROM #TempTable WITH (NOLOCK)
        WHERE PaymentAllocationID IN ( 'PREPAID' );

        SELECT @RepoWoAmt = ISNULL(Amount, 0)
        FROM #TempTable WITH (NOLOCK)
        WHERE PaymentAllocationID IN ( 'REPOFEEWO' );

        IF @PrpAmt = @RepoWoAmt
        BEGIN
            DELETE #TempTable
            WHERE PaymentAllocationID IN ( 'PREPAID', 'REPOFEEWO' );
            SET @RepoAmountPrp = 0;
        END;

        IF @PrpAmt > @RepoWoAmt
        BEGIN
            DELETE #TempTable
            WHERE PaymentAllocationID IN ( 'REPOFEEWO' );
            SET @RepoAmountPrp = @PrpAmt - @RepoWoAmt;
            UPDATE #TempTable
            SET Amount = @RepoAmountPrp
            WHERE PaymentAllocationID IN ( 'PREPAID' );
        END;

        IF @PrpAmt < @RepoWoAmt
        BEGIN
            DELETE #TempTable
            WHERE PaymentAllocationID IN ( 'PREPAID' );
            SET @RepoAmountPrp = 0;
            UPDATE #TempTable
            SET Amount = @RepoWoAmt - @PrpAmt
            WHERE PaymentAllocationID IN ( 'REPOFEEWO' );
        END;

        --end Vincenza


        --added by Reyvano FMF-5229 : buat proses pembuatan alokasi baru untuk pendapatan
        DECLARE @AmtPrepaidISL NUMERIC(17, 2);
        DECLARE @TotalTunggakanTerutang NUMERIC(17, 2);
        DECLARE @SelisihLebihAtauKurang NUMERIC(17, 2);
        --Added by Reyvano GAP FMF-5229 : 18 Des 2024
        DECLARE @LCInstallmentCalculation NUMERIC(17, 2);
        DECLARE @LCInsuranceCalculation NUMERIC(17, 2);
        --ended by Reyvano GAP FMF-5229

		--Added by Aurellie : FMF-5310
		SET @AmtPrepaidISL = 0
		SET @TotalTunggakanTerutang = 0 
		SET @SelisihLebihAtauKurang = 0  
		--Ended by Aurellie : FMF-5310

        SELECT @AmtPrepaidISL = Amount
        FROM #TempTable WITH (NOLOCK)
        WHERE PaymentAllocationID = 'PREPAID'
              AND Post = 'C';

        --Added by Reyvano GAP FMF-5229 18 Des 2024
        SELECT @LCInstallmentCalculation
            = (CASE
                   WHEN (AGR.LCInstallment - AGR.LCInstallmentPaid - AGR.LCInstallmentWaived)
                        + dbo.FnCalculationForLCInstallment(@ApplicationID, @BusinessDate) < 0 THEN
                       0
                   ELSE
            (AGR.LCInstallment - AGR.LCInstallmentPaid - AGR.LCInstallmentWaived)
            + dbo.FnCalculationForLCInstallment(@ApplicationID, @BusinessDate)
               END
              ),
               @LCInsuranceCalculation
                   = (CASE
                          WHEN CEILING((AGR.LCInsurance - AGR.LCInsurancePaid - AGR.LCInsuranceWaived) * 1.0
                                       / @CurrencyRounded
                                      ) * @CurrencyRounded
                               + dbo.FnCalculationForLCInsurance(@ApplicationID, @BusinessDate) < 0 THEN
                              0
                          ELSE
                              CEILING((AGR.LCInsurance - AGR.LCInsurancePaid - AGR.LCInsuranceWaived) * 1.0
                                      / @CurrencyRounded
                                     ) * @CurrencyRounded
                              + dbo.FnCalculationForLCInsurance(@ApplicationID, @BusinessDate)
                      END
                     )
        FROM dbo.Agreement AGR WITH (NOLOCK)
        --WHERE AGR.BranchID = @BranchID
		WHERE AGR.BranchID = @BranchAgreement --Added by Aurellie : FMF-5310
              AND AGR.ApplicationID = @ApplicationID;
        --ended by Reyvano GAP FMF-5229

        --Added by Reyvano FMF-5229 19 Des 2024 : ambil nilai OS STNK
        DECLARE @STNKCost AS NUMERIC(17, 2);
		SET @STNKCost = 0 --Added by Aurellie : FMF-5310

        SELECT @STNKCost = (STNKFee + AgentFeeToCustomer + OtherFee + AdminFee) - STNKFeePaid
        FROM dbo.STNKRequest WITH (NOLOCK)
        WHERE ApplicationID = @ApplicationID
              AND STNKStatus = 'RCV';
        --ended by Reyvano FMF-5229


        SELECT @TotalTunggakanTerutang
            = ISNULL(AGR.OutstandingPrincipal,0) + ISNULL(AGR.OutstandingInterest,0)  --Added by Aurellie : FMF-5310
              --Added by Reyvano GAP FMF-5229 : 18 Des 2024
              + @LCInstallmentCalculation + @OSInsuranceDueAloc + @LCInsuranceCalculation + @OSRepossessFeeAloc
              --ended by Reyvano GAP FMF-5229
              --+ ISNULL(STNKR.STNKFee, 0),
              + @STNKCost, --changed by Reyvano FMF-5229 19 Des 2024 : ubah jadi nilai OS STNK
               --@SelisihLebihAtauKurang = (ESH.DPP) - @TotalTunggakanTerutang --Remark Aurellie : FMF-5310
			   --Added by Aurellie : FMF-5310
			   @SelisihLebihAtauKurang = ISNULL(ESH.DPP,0) - 
										 (ISNULL(AGR.OutstandingPrincipal,0) + ISNULL(AGR.OutstandingInterest,0)
										 + @LCInstallmentCalculation + @OSInsuranceDueAloc + @LCInsuranceCalculation + @OSRepossessFeeAloc
										 + @STNKCost) 
										 --Ended by Aurellie : FMF-5310

        FROM Agreement AGR WITH (NOLOCK)
            LEFT JOIN dbo.AgreementAsset AGA WITH (NOLOCK)
                ON AGA.BranchID = AGR.BranchID
                   AND AGA.ApplicationID = AGR.ApplicationID
            LEFT JOIN dbo.ExInvSellingDetail ESD WITH (NOLOCK)
                ON ESD.BranchId = AGR.BranchID
                   AND ESD.ApplicationId = AGR.ApplicationID
            LEFT JOIN dbo.ExInvSellingHeader ESH WITH (NOLOCK)
                ON ESH.BranchId = ESD.BranchId
                   AND ESH.RequestNo = ESD.RequestNo
            LEFT JOIN dbo.STNKRequest STNKR WITH (NOLOCK)
                ON STNKR.BranchId = AGA.BranchID
                   AND STNKR.ApplicationID = AGA.ApplicationID
                   AND STNKR.AssetSeqNo = AGA.AssetSeqNo
        --WHERE AGR.BranchID = @BranchID
		WHERE AGR.BranchID = @BranchAgreement --Added by Aurellie : FMF-5310
              AND AGR.ApplicationID = @ApplicationID;
        -----------------------------------------------------------------------------------------------
        --Added by Reyvano GAP FMF-5229 : 18 Des 2024
        UPDATE dbo.ExInvSellingHeader
        SET OSLCInstallmentToCust = @LCInstallmentCalculation,
            OSLCInsuranceToCust = @LCInsuranceCalculation
        --WHERE BranchId = @BranchID
		WHERE BranchId = @BranchAgreement  --Added by Aurellie : FMF-5310
              AND RequestNo = @RequestNo;
        --ended by Reyvano GAP FMF-5229
        -----------------------------------------------------------------------------------------------
        IF EXISTS
        (
            SELECT ''
            FROM #TempTable WITH (NOLOCK)
            WHERE PaymentAllocationID = 'PREPAID'
                  AND Post = 'C'
        )
        BEGIN
            IF @SelisihLebihAtauKurang > 0
            BEGIN
                ---------------------------
                SET @CounterOtherInc = 1;
                WHILE @CounterOtherInc <= 2
                BEGIN
                    IF @CounterOtherInc = 1
                    BEGIN
                        IF @SelisihLebihAtauKurang > 0
                        BEGIN
                            UPDATE #TempTable
                            SET Amount = @SelisihLebihAtauKurang
                            WHERE PaymentAllocationID = 'PREPAID'
                                  AND Post = 'C';
                        END;
                    END;
                    ELSE IF @CounterOtherInc = 2
                    BEGIN
                        SET @PaymentAllocationJournal = 'REPOPNL';
                        SET @PostJournal = 'C';
                        SET @AmountJournal = @AmtPrepaidISL - @SelisihLebihAtauKurang;
                    END;
                    IF @AmountJournal > 0
                    BEGIN
                        INSERT INTO #TempTable
                        (
                            PaymentAllocationID,
                            Post,
                            Amount,
                            RefDesc,
                            VoucherDesc
                        )
                        VALUES
                        (@PaymentAllocationJournal, @PostJournal, @AmountJournal, @RefDesc, '');
                        IF @@error <> 0
                        BEGIN
                            GOTO ExitSP;
                        END;
                    END;
                    SET @AmountJournal = 0;
                    SET @CounterOtherInc = @CounterOtherInc + 1;
                END;
            END;
            ELSE
            BEGIN
                UPDATE #TempTable
                SET PaymentAllocationID = 'REPOPNL'
                WHERE PaymentAllocationID = 'PREPAID'
                      AND Post = 'C';
            ---------------------------
            END;

        END;

        --ended by Reyvano FMF-5229
        -------------------------------------------------------------------------------

        EXECUTE @Error = spProcessCreateJournal @CompanyId,
                                                @BranchID,
                                                @TransactionID,
                                                @BusinessDate,
                                                @ValueDate,
                                                @ReferenceNo,
                                                @ApplicationID,
                                                'R',
                                                @BankAccountID,
                                                @AmountReceive,
                                                @CurrencyID,
                                                @Rate,
                                                1,
                                                @JournalCode OUTPUT;

        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;

        ---Silvia, 24 Maret 2020 [FMF-2140] : Update COA PrepaidBNK disini
        DECLARE @FundingCoyID VARCHAR(20),
                @COAPrepaidBNK CHAR(25);

        SELECT @FundingCoyID = FundingCoyID
        FROM Agreement WITH (NOLOCK)
        WHERE BranchID = @BranchAgreement
              AND ApplicationID = @ApplicationID;

        SELECT @COAPrepaidBNK = [dbo].[FnGetCoaChanneling](@BranchAgreement, @FundingCoyID, 'PREPAIDBNK');

        UPDATE GLJournalD
        SET CoaId = @COAPrepaidBNK
        WHERE Tr_Nomor = @JournalCode
              AND PaymentAllocationID = 'PREPAIDBNK';

        IF @@error <> 0
            GOTO ExitSP;
        ---End Silvia [FMF-2140]




        SELECT *
        FROM GLJournalD
        WHERE Tr_Nomor = @JournalCode;

        EXECUTE @Error = spProcessCreateCashBankTransactions @BranchID,
                                                             @ProcessID,
                                                             @BusinessDate,
                                                             @ValueDate,
                                                             @OpeningSequence,
                                                             @LoginID,
                                                             @WOP,
                                                             @ReceivedFrom,
                                                             @ReferenceNo,
                                                             @JournalCode,
                                                             @ApplicationID,
                                                             'R',
                                                             @BankAccountID,
                                                             @AmountReceive,
                                                             @Notes,
                                                             @CurrencyID,
                                                             '',
                                                             NULL,
                                                             1,
                                                             @VoucherNo OUTPUT;
        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;

        -- Yovita 18 Okt 2007: Add Update #TempTable dari ARNA jadi INSTALLRCV pd saat Create Payment History  
        IF EXISTS (SELECT '' FROM #TempTable WHERE PaymentAllocationID = 'ARNA')
        BEGIN
            UPDATE #TempTable
            SET PaymentAllocationID = 'INSTALLRCV'
            WHERE PaymentAllocationID IN ( 'ARNA', 'CRTWORCV' );
        END;
        /*Rubianto, 20100414*/

        /*Rubianto End*/

        EXECUTE @Error = spProcessCreatePaymentHistory
            --Raug 2 Juni 2021
            --@BranchAgreement,
            @BranchID,
            --End Raug FMF-2725
            @ApplicationID,
            @BusinessDate,
            @ValueDate,
            @BankID,
            '-',
            0,
            0,
            @ReferenceNo,
            @ReceivedFrom,
            @WOP,
            @ProcessID,
            @AmountReceive,
            @JournalCode,
            @BankAccountID,
            @HistorySequenceNo OUTPUT,
            @ReceiptNoFormControl;
        IF @Error > 0
        BEGIN
            GOTO ExitSP;
        END;

        ---Jason, 2 September 2022 [FMF-3744] : Perbaikan cara update LCAmount di PaymentHistoryDetail dan LateCharges di InstallmentSchedule saat ISL terkait perubahan CR FMF-2934 yang mengubah cara hitung LC sampai dengan NA Date
        DECLARE @TempLCISL AS TABLE
        (
            BranchID CHAR(3),
            ApplicationID VARCHAR(20),
            HistorySequenceNo INT,
            InsSeqNo INT,
            LCDays INT,
            LCAmount NUMERIC(17, 2)
        );

        INSERT INTO @TempLCISL
        SELECT BranchId,
               ApplicationID,
               HistorySequenceNo,
               InsSeqNo,
               --Edit Vita N 16 Okt 2024 (FMF-5185) : tambah case when, untuk kontrak interval LC, set LCDays dan LCAmount ke 0
               LCDays = CASE
                            WHEN @IsIntervalLCScheme = 0 THEN
                                dbo.FnCalcReportLCDays(PHD.BranchId, PHD.ApplicationID, PHD.InsSeqNo, @NADate)
                            ELSE
                                0
                        END,
               LCAmount = CASE
                              WHEN @IsIntervalLCScheme = 0 THEN
                                  dbo.FnCalcReportLCInstallment(PHD.BranchId, PHD.ApplicationID, PHD.InsSeqNo, @NADate)
                              ELSE
                                  0
                          END
        --End edit Vita
        FROM PaymentHistoryDetail PHD WITH (NOLOCK)
        WHERE BranchId = @BranchAgreement
              AND ApplicationID = @ApplicationID
              AND HistorySequenceNo = @HistorySequenceNo
              AND InsSeqNo <> 0
              AND PaymentAllocationID = 'INSTALLRCV';
        ---End Jason [FMF-3744]

        EXECUTE @Error = spProcessInstallmentAllocation @BranchAgreement,
                                                        @ApplicationID,
                                                        @ARNA, --Rendi 18 des 2015 [FMF-1464] ganti @AmountReceive menjadi @ARNA,
                                                        @ValueDate,
                                                        0;

        ---Jason, 2 September 2022 [FMF-3744] : Perbaikan cara update LCAmount di PaymentHistoryDetail dan LateCharges di InstallmentSchedule saat ISL terkait perubahan CR FMF-2934 yang mengubah cara hitung LC sampai dengan NA Date		
        UPDATE PaymentHistoryDetail
        SET LCDays = TEMP.LCDays,
            LCAmount = TEMP.LCAmount
        FROM PaymentHistoryDetail PHD WITH (NOLOCK)
            INNER JOIN @TempLCISL TEMP
                ON PHD.BranchId = TEMP.BranchID
                   AND PHD.ApplicationID = TEMP.ApplicationID
                   AND PHD.HistorySequenceNo = TEMP.HistorySequenceNo
                   AND PHD.InsSeqNo = TEMP.InsSeqNo
        WHERE PHD.BranchId = @BranchAgreement
              AND PHD.ApplicationID = @ApplicationID
              AND PHD.HistorySequenceNo = @HistorySequenceNo
              AND PHD.InsSeqNo <> 0
              AND PHD.PaymentAllocationID = 'INSTALLRCV';

        UPDATE InstallmentSchedule
        SET LateCharges = ISNULL(PHD.TotalLC, 0)
        FROM InstallmentSchedule ISC WITH (NOLOCK)
            LEFT JOIN
            (
                SELECT BranchId,
                       ApplicationID,
                       InsSeqNo,
                       SUM(LCAmount) TotalLC
                FROM PaymentHistoryDetail WITH (NOLOCK)
                WHERE PaymentAllocationID = 'INSTALLRCV'
                GROUP BY BranchId,
                         ApplicationID,
                         InsSeqNo
            ) PHD
                ON ISC.BranchId = PHD.BranchId
                   AND ISC.ApplicationID = PHD.ApplicationID
                   AND ISC.InsSeqNo = PHD.InsSeqNo
        WHERE ISC.BranchId = @BranchAgreement
              AND ISC.ApplicationID = @ApplicationID;
        ---End Jason [FMF-3744]

        --Vincenza FMF-2934 27092021  agar LCInstallment tidak gerak
        UPDATE Agreement
        SET LCInstallment = ISNULL(@OSLCInstallment + @LCInstallmentCurrent, 0) + LCInstallmentPaid
                            + LCInstallmentWaived
        WHERE BranchID = @BranchAgreement
              AND ApplicationID = @ApplicationID;
        IF @Error <> 0
        BEGIN
            GOTO ExitSP;
        END;

        SELECT @OSInstallmentDueAfter = InstallmentDue - InstallmentDuePaid - InstallmentDueWaived
        FROM Agreement
        WHERE BranchID = @BranchAgreement
              AND ApplicationID = @ApplicationID;

        SET @InstallmentAloc = @OSInstallmentDueBefore - @OSInstallmentDueAfter;

        IF @IsLastAssetSold = '1'
        BEGIN
            IF @OSInstallmentDueAfter > 0
            BEGIN
                SET @InstallmentWaived = @OSInstallmentDueAfter;
            END;

        END;


        IF @OSInsuranceDueAloc > 0
           OR @LCInsuranceAloc > 0
        BEGIN
            EXECUTE @Error = spProcessInsuranceAllocation @BranchAgreement,
                                                          @ApplicationID,
                                                          @OSInsuranceDueAloc,
                                                          @ValueDate,
                                                          @LCInsuranceAloc;
            IF @Error <> 0
            BEGIN
                GOTO ExitSP;
            END;
        END;

        -- Yovita Oct 3 2007: Tambahin sp untuk allocation Amount Inc Recognize       
        -- To ARIF: rif di spRemedialAccrualAllocation harus kamu enhance untuk pengakuan DiffRate, Incentive sama Provision Expense :)  sudaaaaaaaahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh ^^    

        IF @EarnAmountAloc > 0
           OR @DiffRate <> 0
           OR @Provision <> 0
           OR @Incentive <> 0
           OR @AdminFee <> 0 -- Add by Gema, 20081112 : Bukan hanya lihat eci     
           --Budiman, add [FMF-1731] 13 Nov 2018  tambah komponen PSAK lainnya
           OR @OtherRefund <> 0
           OR @OtherFee <> 0
           OR @AdmFee <> 0
           OR @ProvisionFee <> 0
           OR @SurveyFee <> 0
           OR @costofSurvey <> 0
           OR @DeferredInsurance <> 0
           OR @InsuranceIncome <> 0
        --End Budiman

        BEGIN
            EXECUTE @Error = spRemedialAccrualAllocation @ApplicationID,
                                                         @ValueDate,
                                                         @EarnAmountAloc,
                                                         @DiffRate,
                                                         @Provision,
                                                         @Incentive,
                                                         @AdminFee,
                                                         --Budiman, add [FMF-1731] 13 Nov 2018  tambah komponen PSAK lainnya
                                                         @DeferredInsurance,
                                                         @OtherRefund,
                                                         @AdmFee,
                                                         @ProvisionFee,
                                                         @OtherFee,
                                                         @SurveyFee,
                                                         @costofSurvey,
                                                         @InsuranceIncome,
                                                         --End Budiman
                                                         0;
            IF @Error <> 0
            BEGIN
                GOTO ExitSP;
            END;
        END;

        --Johnson, March 23 2006      

        /*      
 If @OSRepossessFeeAloc > 0       
 Begin      
  Execute @Error = spProcessReposessionFee @branchagreement, @applicationid, @Valuedate, @OSRepossessFeeAloc      
  If @Error > 0       
  Begin      
   Goto ExitSP      
  End       
 End      
       
 If @ReposessWaived  <>  0       
  Begin      
   Exec @Error = spProcessReposessionWaived @branchagreement, @applicationid, @ReposessWaived      
   If @Error <>  0       
   Begin      
    Goto ExitSP      
   End       
  End      
 */



        /*      
 If @InstallmentWaived  > 0       
  Begin      
   Exec @Error = spProcessInstallmentWaived @branchagreement, @applicationid, @InstallmentWaived      
   If @Error <>  0       
   Begin      
    Goto ExitSP      
   End       
  End      
 */

        IF @InstallmentWaived > 0
        BEGIN
            EXEC @Error = spProcessInstallmentEarnWaived @BranchAgreement,
                                                         @ApplicationID,
                                                         @EarnWaived;
            IF @Error <> 0
            BEGIN
                GOTO ExitSP;
            END;
        END;


        /*      
 Update InsuranceAsset Set       
  PaidDate = @Valuedate, FlagInsStatus = 'T'       
 where  BranchId = @BranchAgreement and applicationid = @applicationid and      
  PremiumAmountByCust - PaidAmountByCust  -  WaivedAmountByCust >0       
 If @@error <> 0       
 Begin      
  Goto ExitSP      
 End        
 Update insuranceAsset Set      
  PaidAmountByCust = PremiumAmountByCust -  WaivedAmountByCust      
 where  BranchId = @BranchAgreement and applicationid = @applicationid       
 If @@error <> 0       
 Begin      
  Goto ExitSP      
 End        
 */

        /*       
 Update insuranceAsset Set      
  FlagInsStatus = 'T'       
 where  BranchId = @BranchAgreement and applicationid = @applicationid       
 If @@error <> 0       
 Begin      
  Goto ExitSP      
 End        
 */
        UPDATE AssetRepossessionOrder
        SET CollectionExpensePaid = QRY.CollectionExpense - QRY.CollectionExpenseWaived,
            RepossesionStatus = 'P',
            SoldJournalNo = @JournalCode,
            VoucherNo = @VoucherNo,
            PaidDate = @ValueDate,
            PaidAmount = @AmountReceive,
            SellingAmount = @AmountReceive
        FROM
        (
            SELECT AssetRepossessionOrder.BranchId,
                   AssetRepossessionOrder.ApplicationId,
                   AssetRepossessionOrder.AssetSeqNo,
                   AssetRepossessionOrder.RepossesSeqNo,
                   AssetRepossessionOrder.CollectionExpense,
                   AssetRepossessionOrder.CollectionExpenseWaived
            FROM AssetRepossessionOrder
                INNER JOIN
                (
                    SELECT BranchId,
                           ApplicationId,
                           AssetSeqNo,
                           MAX(RepossesSeqNo) AS MaxRepossesSeqNo
                    FROM AssetRepossessionOrder WITH (NOLOCK)
                    WHERE BranchId = @BranchAgreement
                          AND ApplicationId = @ApplicationID
                          AND AssetSeqNo = @AssetSeqNo
                    GROUP BY BranchId,
                             ApplicationId,
                             AssetSeqNo
                ) QARO
                    ON QARO.BranchId = AssetRepossessionOrder.BranchId
                       AND QARO.ApplicationId = AssetRepossessionOrder.ApplicationId
                       AND QARO.AssetSeqNo = AssetRepossessionOrder.AssetSeqNo
                       AND QARO.MaxRepossesSeqNo = AssetRepossessionOrder.RepossesSeqNo
            WHERE AssetRepossessionOrder.BranchId = @BranchAgreement
                  AND AssetRepossessionOrder.ApplicationId = @ApplicationID
                  AND AssetRepossessionOrder.AssetSeqNo = @AssetSeqNo
        ) QRY
        WHERE AssetRepossessionOrder.BranchId = QRY.BranchId
              AND AssetRepossessionOrder.ApplicationId = QRY.ApplicationId
              AND AssetRepossessionOrder.AssetSeqNo = QRY.AssetSeqNo
              AND AssetRepossessionOrder.RepossesSeqNo = QRY.RepossesSeqNo;

        IF @@error <> 0
        BEGIN
            GOTO ExitSP;
        END;

        UPDATE AgreementAsset
        SET AssetStatus =
            ---Raug 26 November 2021 FMF-3182
            --'RRD'
            (CASE
                 WHEN @AssetTypeID = '4' THEN
                     'RLS'
                 WHEN @IsFactoring = 1 THEN
                     'RLS'
                 ELSE
                     'RRD'
             END
            ),
            AssetDocStatus = (CASE
                                  WHEN @AssetTypeID = '4' THEN
                                      'R'
                                  WHEN @IsFactoring = 1 THEN
                                      'R'
                                  ELSE
                                      AssetDocStatus
                              END
                             )
        ---End Raug FMF-3182
        WHERE BranchID = @BranchAgreement
              AND ApplicationID = @ApplicationID
              AND AssetSeqNo = @AssetSeqNo;
        IF @@error <> 0
        BEGIN
            GOTO ExitSP;
        END;
        UPDATE Agreement
        SET --InstallmentDuePaid = InstallmentDuePaid + @AmountReceive, (Sudah Di spProcessInstallmentAllocation)      
            InstallmentDueWaived = InstallmentDueWaived + @InstallmentWaived,
                                                             --LCInstallmentPaid = LCInstallmentPaid
                                                             --+ @LCInstallmentAloc - @LCInstallmentWaived ,--@InsuranceWaived,      
                                                             --LCInstallmentWaived = LCInstallmentWaived
                                                             --+ @LCInstallmentWaived ,--@InsuranceWaived,
                                                             --Vincenza FMF-2934       
            LCInstallmentPaid = LCInstallmentPaid + @LCInstallmentWaived,
            LCInstallmentWaived = LCInstallmentWaived + @LCInstallmentAloc - @LCInstallmentWaived,
                                                             --end
                                                             --InsuranceDuePaid = InsuranceDuePaid + @OSInsuranceDueAloc - @InsuranceWaived, (Sudah Di spProcessInsuranceAllocation)      
            InsuranceDueWaived = InsuranceDueWaived + @InsuranceWaived,
            LCInsurancePaid = LCInsurancePaid + @LCInsuranceAloc - @LCInsuranceWaived,
            LCInsuranceWaived = LCInsuranceWaived + @LCInsuranceWaived,

                                                             --Johnson, March 23 2006      
            CollectionExpensePaid = CollectionExpensePaid + @OSRepossessFeeAloc - @ReposessWaived,
            CollectionExpenseWaived = CollectionExpenseWaived + @ReposessWaived,
            PDCBounceFeePaid = PDCBounceFeePaid + @OSPDCBounceFeeAloc - @PDCBounceWaived,
            PDCBounceFeeWaived = PDCBounceFeeWaived + @PDCBounceWaived,
            ContractPrepaidAmount = ContractPrepaidAmount + @PrepaidAloc,
            NAPaid = NAPaid + @NAAmountAloc - @NAWaived - (CASE
                                                               WHEN @StatusDefault = 'NA' THEN
                                                                   @InstallmentAloc
                                                               ELSE
                                                                   0
                                                           END
                                                          ), -- di kurang nilai yang diupdate di spProcessInstallmentAllocation,      
            NAWaived = NAWaived + @NAWaived,
            WOPaid = WOPaid + @WOAmountAloc - @WOWaived - (CASE
                                                               WHEN @StatusDefault = 'WO' THEN
                                                                   @InstallmentAloc
                                                               ELSE
                                                                   0
                                                           END
                                                          ), -- di kurang nilai yang diupdate di spProcessInstallmentAllocation,      
            WOWaived = WOWaived + @WOWaived
        WHERE BranchID = @BranchAgreement
              AND ApplicationID = @ApplicationID;
        IF @@error <> 0
        BEGIN
            GOTO ExitSP;
        END;


        IF @IsLastAssetSold = '1'
        BEGIN

            --add Jason 15 Agustus 2022 [FMF-3705]
            IF EXISTS
            (
                SELECT ''
                FROM STNKRequest
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID
                      AND STNKStatus = 'REQ'
            )
            BEGIN
                RAISERROR('Contract is still on STNK Request. Please process the STNK Request first !', 16, 1);
                GOTO ExitSP;
            END;
            --end Jason [FMF-3705]

            DECLARE @TotalInstallmentAmount Amount;

            SELECT @TotalInstallmentAmount = SUM(InstallmentAmount)
            FROM InstallmentSchedule
            WHERE BranchId = @BranchAgreement
                  AND ApplicationID = @ApplicationID;

            -- Yovita Mar 22 2006 : CHange Where Cond For Updating PaidDate On Tbl InstallmentSchedule       
            UPDATE InstallmentSchedule
            SET PaidDate = @ValueDate
            WHERE BranchId = @BranchAgreement
                  AND ApplicationID = @ApplicationID
                  AND InstallmentAmount - PaidAmount - WaivedAmount > 0;

            UPDATE InstallmentSchedule
            SET WaivedAmount = InstallmentAmount - PaidAmount
            WHERE BranchId = @BranchAgreement
                  AND ApplicationID = @ApplicationID;
            --=========================================================================================================      

            UPDATE Agreement
            SET InstallmentDue = ISNULL(@TotalInstallmentAmount, 0),
                InstallmentDueWaived = ISNULL(@TotalInstallmentAmount, 0) - InstallmentDuePaid,
                OutstandingPrincipal = 0,
                OutstandingInterest = 0,
                OutstandingPrincipalUndue = 0,
                OutstandingInterestUndue = 0,
                NextInstallmentNumber = '999',
                NextInstallmentDueNumber = '999',
                --    NextInstallmentNumber = NumOfInstallment + 1,      
                NextInstallmentDate = MaturityDate,
                --    NextInstallmentDueNumber = NumOfInstallment + 1,      
                NextInstallmentDueDate = MaturityDate,
                ---Raug 26 November 2021 FMF-3182
                --ContractStatus = 'RRD' ,
                ContractStatus = (CASE
                                      WHEN @AssetTypeID = '4' THEN
                                          'EXP'
                                      WHEN @AssetTypeID = '10' THEN
                                          'EXP'
                                      WHEN @IsFactoring = 1 THEN
                                          'EXP'
                                      ELSE
                                          'RRD'
                                  END
                                 ),
                ---End Raug FMF-3182
                RRDDate = @ValueDate,
                PrepaidHoldStatus = 'NM',
                --add Jason FMF-3473
                DtmUpd = GETDATE()
            --End Jason
            WHERE BranchID = @BranchAgreement
                  AND ApplicationID = @ApplicationID;

        END;
    /*      
 Update Agreement Set       
   InsuranceDuePaid = InsuranceDue-InsuranceDueWaived,      
   InstallmentDuePaid = InstallmentDue - InstallmentDueWaived,      
   LCInstallmentPaid=LCInstallment-LCInstallmentWaived,      
   PDCBounceFeePaid=PDCBounceFee-PDCBounceFeeWaived,       
   LCInsurancePaid=LCInsurance-LCInsuranceWaived,       
   OutstandingPrincipal = 0,      
   OutstandingInterest = 0,      
   OutstandingPrincipalUndue = 0,      
   OutstandingInterestUndue = 0,      
   PrepaidHoldStatus = 'NM'      
  Where branchId = @BranchAgreement and ApplicationID = @ApplicationID      
  If @@error <> 0       
Begin      
   Goto ExitSP      
  End       
 */




    END;

    --Vincenza FMF-2847 03082021
    IF @IsLastAssetSold = '1'
    BEGIN
        IF @FlagAssetTypeID = 1
        BEGIN
            IF @RepoAmount > 0
            BEGIN

                --add Jason 15 Agustus 2022 [FMF-3705]
                IF EXISTS
                (
                    SELECT ''
                    FROM STNKRequest
                    WHERE BranchId = @BranchAgreement
                          AND ApplicationID = @ApplicationID
                          AND STNKStatus = 'REQ'
                )
                BEGIN
                    RAISERROR('Contract is still on STNK Request. Please process the STNK Request first !', 16, 1);
                    GOTO ExitSP;
                END;
                --end Jason [FMF-3705]

                UPDATE Agreement
                SET --DefaultStatus = 'WO', FMF-3221
                    DefaultStatus = 'DF',
                    --ContractStatus = 'ICP', FMF-3221
                    ContractStatus = (CASE
                                          WHEN @AssetTypeID = '4' THEN
                                              'EXP'
                                          WHEN @AssetTypeID = '10' THEN
                                              'EXP'
                                          WHEN @IsFactoring = 1 THEN
                                              'EXP'
                                          ELSE
                                              'RRD'
                                      END
                                     ),
                    WOAmount = @RepoAmount,
                    --OutstandingPrincipal = 0, FMF-3221
                    OutstandingPrincipal = @RepoAmount,
                    OutstandingInterest = 0,
                    --Add Jason FMF-3473
                    DtmUpd = GETDATE()
                --end Jason
                WHERE BranchID = @BranchAgreement
                      AND ApplicationID = @ApplicationID;
                IF @@Error <> 0
                    GOTO exitsp;
                DECLARE @RequestNANo VARCHAR(20),
                        @NALastPayment DATETIME,
                        @NAPastDueDays INT,
                        @NATotalAmount NUMERIC(17, 2);
                SELECT @RequestNANo = RequestNANo,
                       @NALastPayment = LastPayment,
                       @NAPastDueDays = PastDueDays,
                       @NATotalAmount = NATotalAmount
                FROM NonAccrual WITH (NOLOCK)
                WHERE BranchId = @BranchAgreement
                      AND ApplicationID = @ApplicationID;

                IF @StatusDefault = 'NA'
                BEGIN
                    INSERT INTO WriteOff
                    (
                        [BranchId],
                        [ApplicationId],
                        [RequestWONo],
                        [RequestNANo],
                        [RequestDate],
                        [CurrencyID],
                        [LastPayment],
                        [PastDueDays],
                        [WOTotalAmount],
                        [OSPrincipleAmount],
                        [OSInterestAmount],
                        [OSInstallmentDue],
                        [OSInsuranceDue],
                        [OSLCInstallment],
                        [RepossessionFee],
                        [OSLCInsurance],
                        [AccruedInterest],
                        [OSNAAmount],
                        [OSPDCBounceFee],
                        [OSDiffRateAmount],
                        [OSIncentiveAmount],
                        [OSProvisionAmount],
                        [WOTotalAmountSelfPortion],
                        [OSPrincipleAmountSelfPortion],
                        [OSInterestAmountSelfPortion],
                        [OSInstallmentDueSelfPortion],
                        [JournalNo],
                        [Notes],
                        [ApprovalStatus],
                        [StatusDate],
                        [ReasonTypeId],
                        [ReasonID],
                        [ApprovalNo],
                        [RequestBy],
                        [OptionType],
                        [UsrUpd],
                        [DtmUpd],
                        [OSAdminFeeAmount],
                        [OSInsuranceIncomeAmount],
                        [OSDeferredInsurIncAmount],
                        [OSOtherRefundAmount],
                        [OSAdmFeeAmount],
                        [OSProvisionFeeAmount],
                        [OSOtherFeeAmount],
                        [OSSurveyFeeAmount],
                        [OSCostOfSurveyAmount]
                    )
                    VALUES
                    (   @BranchAgreement, @ApplicationID, '-', @RequestNANo, @BusinessDate, 'IDR', @NALastPayment,
                        @NAPastDueDays, @RepoAmount, 0, 0, 0, 0, 0, 0, 0, 0, @NATotalAmount, 0, 0, 0, 0, 0, 0, 0, 0,
                        @JournalCode, --Journal ISL
                        '-', 'A', @BusinessDate, 'WROFF', 'RSN2', '-', '-', 'ADA', SYSTEM_USER, GETDATE(), 0, 0, 0, 0,
                        0, 0, 0, 0, 0);
                    IF @@Error <> 0
                        GOTO exitsp;
                END;
                IF @StatusDefault = 'WO'
                BEGIN
                    UPDATE WriteOff
                    SET RequestWONo = '-',
                        RequestDate = @BusinessDate,
                        LastPayment = @NALastPayment,
                        PastDueDays = @NAPastDueDays,
                        WOTotalAmount = @RepoAmount,
                        WOTotalAmountSelfPortion = 0,
                        OSNAAmount = @NATotalAmount,
                        JournalNo = @JournalCode,
                        ReasonTypeId = 'WROFF',
                        ReasonID = 'RSN2',
                        UsrUpd = SYSTEM_USER,
                        DtmUpd = GETDATE()
                    WHERE BranchId = @BranchAgreement
                          AND ApplicationId = @ApplicationID;
                END;

                --FMF-3221
                DECLARE @ApprvNo VARCHAR(50),
                        @DFReqNo VARCHAR(20);
                EXEC @Error = spGetNoTransaction @BranchAgreement,
                                                 @BusinessDate,
                                                 'DF',
                                                 @DFReqNo OUTPUT;
                IF @Error <> 0
                    GOTO exitsp;

                SET @ApprvNo
                    = 'DF__' + RIGHT(LTRIM(STR(YEAR(@ValueDate))), 2) + RIGHT(00 + LTRIM(STR(MONTH(@ValueDate))), 2)
                      + RIGHT(00 + LTRIM(STR(DAY(@ValueDate))), 2) + LTRIM(STR(DATEPART(hh, GETDATE())))
                      + LTRIM(STR(DATEPART(n, GETDATE()))) + LTRIM(STR(DATEPART(s, GETDATE()))) + 'WO__'
                      + @ApplicationID;

                INSERT INTO DebtForgiveness
                (
                    [BranchID],
                    [ApplicationID],
                    [DFRequestNO],
                    [WORequestNo],
                    [DebtForgivenessDate],
                    [PastDueDays],
                    [LastPaymentDate],
                    [DFTotalAmount],
                    [OSWOAmount],
                    [OSPrincipleAmount],
                    [OSInterestAmount],
                    [InstallmentDue],
                    [InsuranceDue],
                    [OutstandingLCInstallment],
                    [OutstandingLCInsurance],
                    [LCInstallmentCurrent],
                    [LCInsuranceCurrent],
                    [Notes],
                    [ApprovalStatus],
                    [ReasonTypeId],
                    [ReasonID],
                    [ApprovalNo],
                    [RequestBy],
                    [UsrUpd],
                    [DtmUpd]
                )
                VALUES
                (@BranchAgreement, @ApplicationID, @DFReqNo, '-', @ValueDate, @NAPastDueDays, @NALastPayment,
                 @RepoAmount, @RepoAmount, @RepoAmount, 0, 0, 0, 0, 0, 0, 0, '', 'A', 'NOACR', 'RSN5', @ApprvNo,
                 SYSTEM_USER, SYSTEM_USER, GETDATE());

            --end FMF-3221

            END;
            IF @RepoAmount < 0
            BEGIN
                UPDATE Agreement
                --SET ContractPrepaidAmount = ABS(@RepoAmountPrp),--Changed by Reyvano FMF-5229 : hapus proses update ke contractPrepaidAmount
                SET OutstandingPrincipal = 0,
                    OutstandingInterest = 0
                WHERE BranchID = @BranchAgreement
                      AND ApplicationID = @ApplicationID;
                --Added by Reyvano FMF-5229 : tambahin proses update ke contract prepaid amount jika selisih rpt dan dengan pendapatan ISL > 0
                IF @SelisihLebihAtauKurang > 0
                BEGIN
                    UPDATE dbo.Agreement
                    SET ContractPrepaidAmount = @SelisihLebihAtauKurang
                    WHERE BranchID = @BranchAgreement
                          AND ApplicationID = @ApplicationID;
                END;
                --ended by Reyvano FMF-5229
                IF @@Error <> 0
                    GOTO exitsp;
            END;
        END;
    END;
    --end Vincenza

    --Arie, 24 09 2010
    DECLARE @CGId CHAR(3),
            @seqNo INT,
            @CollectorID VARCHAR(12);

    SELECT @CGId = CGId,
           @CollectorID = CollectorID
    FROM AssetRepossessionOrder WITH (NOLOCK)
    WHERE BranchId = @BranchAgreement
          AND ApplicationId = @ApplicationID
          AND AssetSeqNo = @AssetSeqNo;

    SELECT @seqNo = ISNULL(MAX(SeqNo), 0) + 1
    FROM CollEventHistory
    WHERE ApplicationId = @ApplicationID;

    INSERT INTO CollEventHistory
    (
        BranchId,
        ApplicationId,
        CGId,
        SeqNo,
        EventDate,
        Description,
        CollectorId
    )
    VALUES
    (   @BranchAgreement, --@BranchID, Ruth. 23 Maret 2011
        @ApplicationID, @CGId, @seqNo, @BusinessDate, 'Inventory Selling Receive', @CollectorID);
    --Arie, 24 09 2010

    --Begin Restu FMF-1725 2 November 2018
    IF
    (
        SELECT PaidAmount
        FROM dbo.AssetRepossessionOrder WITH (NOLOCK)
        WHERE ApplicationId = @ApplicationID
              AND BranchId = @BranchAgreement
              AND AssetSeqNo = @AssetSeqNo
              AND RepossesSeqNo = @RepossesSeqNO
    ) <> @AmountReceive
    BEGIN
        RAISERROR('Paid Amount of this asset is invalid, please contact Administrator/IT', 16, 1);
        GOTO exitsp;
    END;
--End Restu FMF-1725 2 November 2018

END;

--Raug 29 Desember 2021 FMF-3267
IF @IsLastAssetSold = '1'
BEGIN
    ---Raug 21 Desc 2021 FMF-3246 : tambah menjalankan spMoveToExpTable jika elektronik, KTA, atau isfactoring
    IF @AssetTypeID = '4'
       OR @AssetTypeID = '10'
       OR @IsFactoring = 1
    BEGIN
        EXEC spMoveToExpTable @BranchID, @ApplicationID, @strerror;
        IF @strerror <> ''
        BEGIN
            GOTO exitsp;
        END;
    END;
---Raug FMF-3246   
END;
--Raug 29 Desember 2021 FMF-3267


--Budiman FMF-1754, 21 Desember 2018 tambah validasi untuk kontrak yang masih di pledge, maka kontrak tidak boleh dilakukan selling receive
IF EXISTS
(
    SELECT ''
    FROM Agreement WITH (NOLOCK)
    WHERE ApplicationID = @ApplicationID
          AND BranchID = @BranchAgreement
          AND FundingCoyID IS NOT NULL
          AND FundingCoyID <> ''
          AND FundingCoyID <> '-'
          AND @IsPaymentHierarchy = 0
) --Aditia 20052019
BEGIN
    RAISERROR('Contract is being pledged! Please BuyBack First', 16, 1);
    GOTO exitsp;
END;
--End Budiman


COMMIT TRANSACTION InventorySellingReceive;
--Harry
IF OBJECT_ID('#TempTable') IS NOT NULL
    DROP TABLE #TempTable;
--Drop Table #TempTable      
RETURN @Error;


Exitsp:
BEGIN
    ROLLBACK TRANSACTION InventorySellingReceive;
    --Harry 
    IF OBJECT_ID('#TempTable') IS NOT NULL
        DROP TABLE #TempTable;
    --   Drop Table #TempTable      
    RETURN @Error;
END;


