USE [FMFDB];
GO
/****** Object:  StoredProcedure [dbo].[spPostingOnlinePaymentIndomart]    Script Date: 6/21/2024 10:41:11 AM ******/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO


/* 
	Created by Arie, 30 09 2010Select * 
	Arie, 15 11 2010 : Menambahkan @ValueDate
bEGIN TRANSACTION 
EXEC spPostingOnlinePayment_1
EXEC spPostingOnlinePayment
rOLLBACK tRANSACTION

	Modified By :
					- Raug 3 Nov 2021 [FMF-3104] : Tambah kondisi ambil Max HistorySequence untuk Reversal OLP, jika IsCorrection nya 1 dan CorrectionHistSequence nya 0
					- Vincenza FMF-2816 13072021 PaymentPointCustomerWO
					- Vincenza FMF-3720 23082022 
					- Sugiono 06 Desember 2023 : FMF-4688 CLONE - Tidak Dapat Lanjut di menu Agreement Allocation : penyesuaian untuk get @HistorySequenceNo untuk kontrak EXP
					- Bisma 21 Juni 2024  FMF-5087 : Tambah lemparan parameter @ApplicationIDAgrExp 


*/     
ALTER PROCEDURE [dbo].[spPostingOnlinePaymentIndomart]
AS
    SET NOCOUNT ON;
    BEGIN TRANSACTION PostingOnlinePayment;  

    SAVE TRANSACTION PostingOnlinePayment;  
    
    DECLARE @AgreementNo VARCHAR(20) ,
        @InsSeqNo INT ,
        @InsSeqNoSchedule INT ,
        @ReferenceNo VARCHAR(20) ,
        @PmtTotalAmt Amount ,
        @PaymentMethod CHAR(7) ,
        @OPStep CHAR(3) ,
        @Error VARCHAR(500) ,
        @ApplicationID VARCHAR(20) ,
        @HistorySequenceNo INT ,
        @ValueDate DATETIME ,
        @ContractStatus VARCHAR(3);    
    

    DECLARE @TableOnlinePayment TABLE
        (
          SeqNo INT IDENTITY
                    PRIMARY KEY ,
          AgreementNo VARCHAR(20) ,
          InsSeqNo INT ,
          ReferenceNo VARCHAR(20) ,
          TransactionDate DATETIME ,
          PaymentAmount NUMERIC(17, 2) ,
          PaymentMethod CHAR(7) ,
          OPStep CHAR(3)
        );  

    INSERT  INTO @TableOnlinePayment
            ( AgreementNo ,
              InsSeqNo ,
              ReferenceNo ,
              PaymentAmount ,
              PaymentMethod ,
              OPStep ,
              TransactionDate 
            )
            --Vincenza FMF-2816 13072021
			--SELECT  --top 500
			--        AgreementNo,
   --                 InsSeqNo,
   --                 ReferenceNo,
   --                 PaymentAmount,
   --                 'INDOMRT' PaymentMethod,
   --                 OPStep,
   --                 TransactionDate
   --         FROM    OLPDB.dbo.OnlinePaymentTransactionIndoMart WITH ( NOLOCK )
   --         WHERE   IsPosted = 0
   --                 AND InProcess = 0
   --                 AND CreatedBy = 'OPA'																			 
			--ORDER BY ReferenceNo, OPStep
            SELECT TOP 500
                    opt.AgreementNo ,
                    opt.InsSeqNo ,
                    opt.ReferenceNo ,
                    opt.PaymentAmount ,
                    'INDOMRT' PaymentMethod ,
                    opt.OPStep ,
                    opt.TransactionDate
            FROM    OLPDB.dbo.OnlinePaymentTransactionIndoMart opt WITH ( NOLOCK )
                    LEFT JOIN OLPDB.dbo.PaymentPointCustomerWO ppcw WITH ( NOLOCK ) ON opt.AgreementNo = ppcw.AgreementNo
            WHERE   IsPosted = 0
                    AND InProcess = 0
                    AND CreatedBy = 'OPA'
                    AND opt.AgreementNo NOT IN (
                    SELECT  AgreementNo
                    FROM    OLPDB.dbo.PaymentPointCustomerWO WITH ( NOLOCK ) )
            ORDER BY opt.DtmUpd; -- ReferenceNo, OPStep
			--end Vincenza

--and transactiondate>='2/20/2013'

--and journalno='-'
            --ORDER BY ReferenceNo,
            --        DtmUpd ASC

--SELECT  *
--FROM    @TableOnlinePayment
    
    IF @@Error > 0
        BEGIN  
            GOTO ExitSP;  
        END; 

    DECLARE @CounterAging INT ,
        @LoopAging INT;  
    SET @CounterAging = 1;  
    SELECT  @LoopAging = COUNT(SeqNo)
    FROM    @TableOnlinePayment;  

    DECLARE @BranchAgreement VARCHAR(3);    
   

--PRINT 'mau masuk'

    WHILE @CounterAging <= @LoopAging
        BEGIN  
        --PRINT 'masuk'
        
            SELECT  @AgreementNo = AgreementNo ,
                    @ReferenceNo = ReferenceNo ,
                    @InsSeqNo = InsSeqNo ,
                    @PmtTotalAmt = PaymentAmount ,
                    @PaymentMethod = PaymentMethod ,
                    @OPStep = OPStep ,
                    @ValueDate = TransactionDate
            FROM    @TableOnlinePayment
            WHERE   SeqNo = @CounterAging;
        
        --SELECT  contractstatus
        --FROM    agreement
        --WHERE   agreementno = @AgreementNo
            SELECT  @BranchAgreement = BranchID ,
                    @ApplicationID = ApplicationID ,
                    @ContractStatus = ContractStatus
            FROM    Agreement WITH ( NOLOCK )
            WHERE   AgreementNo = @AgreementNo;

            SELECT  @InsSeqNoSchedule = InsSeqNo
            FROM    ( SELECT    BranchId ,
                                ApplicationID ,
                                MIN(InsSeqNo) AS InsSeqNo
                      FROM      dbo.InstallmentSchedule WITH ( NOLOCK )
                      WHERE     BranchId = @BranchAgreement
                                AND ApplicationID = @ApplicationID
                                AND InstallmentAmount - PaidAmount
                                - WaivedAmount > 0
                      GROUP BY  BranchId ,
                                ApplicationID
                      UNION
                      SELECT    BranchId ,
                                ApplicationID ,
                                MIN(InsSeqNo) AS InsSeqNo
                      FROM      dbo.InstallmentScheduleEXP WITH ( NOLOCK )
                      WHERE     BranchId = @BranchAgreement
                                AND ApplicationID = @ApplicationID
                                AND InstallmentAmount - PaidAmount
                                - WaivedAmount > 0
                      GROUP BY  BranchId ,
                                ApplicationID
                    ) ISS
                    INNER JOIN dbo.Agreement A WITH ( NOLOCK ) ON A.BranchID = ISS.BranchId
                                                              AND A.ApplicationID = ISS.ApplicationID
            WHERE   A.BranchID = @BranchAgreement
                    AND A.ApplicationID = @ApplicationID
                    AND A.ContractStatus NOT IN ( 'CAN', 'RJC' );
                   

		  --DueDate,
    --                                    InstallmentAmount,
    --                                    PaidAmount,
    --                                    WaivedAmount,
    --                                    PaidDate,
    --                                    LateCharges,
    --                                    PrincipalAmount,
    --                                    InterestAmount,
    --                                    OutstandingPrincipal,
    --                                    OutstandingInterest,
    --                                    AmountIncRecognize,
    --                                    LastIncRecognize,
    --                                    DiffRateAmount,
    --                                    OutStandingDiffRateAmount,
    --                                    DiffRateRecognize,
    --                                    Incentive,
    --                                    OSIncentive,
    --                                    IncentiveRecognize,
    --                                    InsuranceIncomeAmount,
    --                                    OutStandingInsuranceIncomeAmount,
    --                                    InsuranceIncomeRecognize,
    --                                    Provision,
    --                                    OSProvision,
    --                                    ProvisionRecognize,
    --                                    IsSMSSent YesNo,
    --                                    ReceiptNo TransactionNo,
    --                                    ReceiptDate,
    --                                    CollectionFee,
    --                                    CollectionFeePaid,
    --                                    CollectionFeeWaived,
    --                                    UsrUpd UsrUpd,
    --                                    DtmUpd DtmUpd,
    --                                    FundingCoyPortion,
    --                                    SpreadAmount,
    --                                    SpreadRecognize,
    --                                    LastSpreadRecognize,
    --                                    AdminFee,
    --                                    OSAdminFee,
    --                                    AdminFeeRecognize,
    --                                    DeferredInsurIncAmount,
    --                                    OutstandingDeferredInsurIncAmount,
    --                                    DeferredInsurIncRecognize,
    --                                    OtherRefundAmount,
    --                                    OutStandingOtherRefundAmount,
    --                                    OtherRefundRecognize,
    --                                    AdmFeeAmount,
    --                                    OutStandingAdmFeeAmount,
    --                                    AdmFeeRecognize,
    --                                    ProvisionFeeAmount,
    --                                    OutStandingProvisionFeeAmount,
    --                                    ProvisionFeeRecognize,
    --                                    OtherFeeAmount,
    --                                    OutStandingOtherFeeAmount,
    --                                    OtherFeeRecognize,
    --                                    SurveyFeeAmount,
    --                                    OutStandingSurveyFeeAmount,
    --                                    SurveyFeeRecognize,
    --                                    IncomeNet,
    --                                    OSPrincipleNet,
    --                                    GrossYieldAcct,
    --                                    CostOfSurveyFeeAmount,
    --                                    OutStandingCostOfSurveyAmount,
    --                                    CostOfSurveyRecognize
        --SELECT  @InsSeqNoSchedule


            IF @OPStep = 'PAY'
                BEGIN 
                    IF ( SELECT InProcess
                         FROM   OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                WITH ( NOLOCK )
                         WHERE  ReferenceNo = @ReferenceNo
                                AND OPStep = @OPStep
                       ) = 0
                        BEGIN
                        --Remark by Nahar(20122010), atas permintaan user, jika ada double payment, maka diperbolehkan, tetapi direversal saat process reconcile 			
                            --IF @InsSeqNo = @InsSeqNoSchedule 
                            --    BEGIN 
                            UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                            SET     InProcess = 1
                            WHERE   ReferenceNo = @ReferenceNo
                                    AND OPStep = @OPStep;
					
                            EXEC @Error = spOnlinePayment_1_Indomart @BranchAgreement,
                                @ApplicationID, -- @AgreementNo,
                                @ReferenceNo, @PmtTotalAmt, @ValueDate,
                                @PaymentMethod, 'OPA'; 
				
                            IF @@Error <> 0
                                BEGIN
                                    UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                    SET     ErrorDescription = 'exec spOnlinePaymentIndomart '
                                            + @AgreementNo + ', '
                                            + @ReferenceNo + ', '
                                            + @PmtTotalAmt + ', '
                                            + @PmtTotalAmt + ', ' + 'OPA'
                                    WHERE   ReferenceNo = @ReferenceNo
                                            AND OPStep = @OPStep;
                                END;
                                --END 
                        END;
                END;
            ELSE
                BEGIN 
                --SELECT  InProcess
                --FROM    OLPDB.dbo.OnlinePaymentTransactionIndoMart WITH ( NOLOCK )
                --WHERE   ReferenceNo = @ReferenceNo
                --        AND OPStep = @OPStep 
                    IF ( SELECT InProcess
                         FROM   OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                WITH ( NOLOCK )
                         WHERE  ReferenceNo = @ReferenceNo
                                AND OPStep = @OPStep
                       ) = 0
                        BEGIN 			
				
                            SELECT  @HistorySequenceNo = HistorySequenceNo
                            FROM    ( SELECT    MAX(HistorySequenceNo) AS HistorySequenceNo
                                      FROM      PaymentHistoryHeader PHH WITH ( NOLOCK )
                                      WHERE     PHH.BranchId = @BranchAgreement
                                                AND PHH.ApplicationID = @ApplicationID
                                                AND EXISTS ( SELECT
                                                              1
                                                             FROM
                                                              Agreement WITH ( NOLOCK )
                                                             WHERE
                                                              BranchID = PHH.BranchId
                                                              AND ApplicationID = PHH.ApplicationID
                                                              AND ContractStatus NOT IN (
                                                              'CAN', 'RJC',
                                                              'EXP' ) )
										---Raug 3 Nov 2021 [FMF-3104] : Tambah kondisi jika IsCorrection nya 1 dan CorrectionHistSequence nya 0
                                                AND IsCorrection = 1
                                                AND CorrectionHistSequence = 0
										---End Raug 3 Nov 2021 [FMF-3104]
                                      UNION
                                      SELECT    MAX(PHH.HistorySequenceNo) AS HistorySequenceNo
                                      FROM      PaymentHistoryHeaderEXP PHH
                                                WITH ( NOLOCK ) --Sugiono 06 Desember 2023 : kontrak electronic
                                                INNER JOIN dbo.Agreement Agr
                                                WITH ( NOLOCK ) ON Agr.BranchID = PHH.BranchId
                                                              AND Agr.ApplicationID = PHH.ApplicationID
                                                INNER JOIN dbo.ProductOffering PO
                                                WITH ( NOLOCK ) ON PO.BranchID = Agr.BranchID
                                                              AND PO.ProductID = Agr.ProductID
                                                              AND PO.ProductOfferingID = Agr.ProductOfferingID
                                                INNER JOIN dbo.AssetType AT
                                                WITH ( NOLOCK ) ON AT.AssetTypeID = PO.AssetTypeID
								--End Sugiono
                                      WHERE     PHH.BranchId = @BranchAgreement
                                                AND PHH.ApplicationID = @ApplicationID
                                                AND EXISTS ( SELECT
                                                              1
                                                             FROM
                                                              Agreement WITH ( NOLOCK )
                                                             WHERE
                                                              BranchID = PHH.BranchId
                                                              AND ApplicationID = PHH.ApplicationID
                                                              AND ContractStatus NOT IN (
                                                              'CAN', 'RJC' ) )--, 'EXP' )) --Sugiono 06 Desember 2023 : FMF-4688 Exclude EXP karena disini statusnya EXP
										---Raug 3 Nov 2021 [FMF-3104] : Tambah kondisi jika IsCorrection nya 1 dan CorrectionHistSequence nya 0
                                                AND PHH.IsCorrection = 0 --Sugiono 06 Desember 2023 : FMF-4688 ubah iscorrection 0 karena untuk histseqno EXP di table phhExp iscorrectionnya 0
                                                AND PHH.CorrectionHistSequence = 0
										---End Raug 3 Nov 2021 [FMF-3104]
                                                AND ( PO.AssetTypeID IN ( '4',
                                                              '10' )
                                                      OR AT.isFactoring = 1
                                                    ) --Sugiono 06 Desember 2023 : kontrak electronic
                                    ) AS qry;

							--Sugiono 06 Desember 2023 : tidak bisa lakukan reversal bisa di cek di errordesc nya
                            IF @HistorySequenceNo IS NULL
                                BEGIN
                                    UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                    SET     ErrorDescription = 'Cannot Payment Reversal, '
                                            + @AgreementNo + ', '
                                            + @ReferenceNo + ', ' + 'OPA'
                                            + ', ' + @OPStep
                                    WHERE   ReferenceNo = @ReferenceNo
                                            AND OPStep = @OPStep;
                                END;
							--END Sugiono

                            --FROM    ( SELECT    A.ApplicationID,
                            --                    PHH.HistorySequenceNo
                            --          FROM      Agreement A WITH ( NOLOCK )
                            --                    INNER JOIN ( SELECT BranchId,
                            --                                        ApplicationID,
                            --                                        MAX(HistorySequenceNo) AS HistorySequenceNo
                            --                                 FROM   PaymentHistoryHeader WITH ( NOLOCK )
                            --                                 GROUP BY BranchID,
                            --                                        ApplicationID
                            --                               ) PHH ON A.BranchID = PHH.BranchId
                            --                                        AND A.ApplicationID = PHH.ApplicationID
                            --                    INNER JOIN PaymentHistoryHeader PHH2
                            --                    WITH ( NOLOCK ) ON PHH.BranchId = PHH2.BranchId
                            --                                       AND PHH.ApplicationID = PHH2.ApplicationID
                            --                                       AND PHH.HistorySequenceNo = PHH2.HistorySequenceNo
                            --          WHERE       BranchID = @BranchAgreement And ApplicationID = @ApplicationID -- AgreementNo = @AgreementNo
                            --                    AND contractstatus NOT IN (
                            --                    'CAN', 'RJC', 'EXP' )
                            --          UNION
                            --          SELECT    A.ApplicationID,
                            --                    PHH.HistorySequenceNo
                            --          FROM      Agreement A WITH ( NOLOCK )
                            --                    INNER JOIN ( SELECT BranchId,
                            --                                        ApplicationID,
                            --                                        MAX(HistorySequenceNo) AS HistorySequenceNo
                            --                                 FROM   PaymentHistoryHeaderExp WITH ( NOLOCK )
                            --                                 GROUP BY BranchID,
                            --                                        ApplicationID
                            --                               ) PHH ON A.BranchID = PHH.BranchId
                            --                                        AND A.ApplicationID = PHH.ApplicationID
                            --                    INNER JOIN PaymentHistoryHeaderExp PHH2
                            --                    WITH ( NOLOCK ) ON PHH.BranchId = PHH2.BranchId
                            --                                       AND PHH.ApplicationID = PHH2.ApplicationID
                            --                                       AND PHH.HistorySequenceNo = PHH2.HistorySequenceNo
                            --          WHERE     BranchID = @BranchAgreement And ApplicationID = @ApplicationID -- AgreementNo = @AgreementNo
                            --                    AND contractstatus = 'EXP'
                               
                            IF EXISTS ( SELECT  1
                                        FROM    PaymentHistoryHeader WITH ( NOLOCK )
                                        WHERE   BranchId = @BranchAgreement
                                                AND ApplicationID = @ApplicationID
                                                AND HistorySequenceNo = @HistorySequenceNo
                                                AND IsCorrection = 1
                                                AND CorrectionHistSequence = 0 )
                                BEGIN 
                                    UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                    SET     InProcess = 1
                                    WHERE   ReferenceNo = @ReferenceNo
                                            AND OPStep = @OPStep;
                                        
                                --PRINT 'masuk slaen EXP'
					
                                    EXEC spOnlineReversalIndoMart @AgreementNo,
                                        @ReferenceNo, 'OPA'; 
					
                                    IF @@Error <> 0
                                        BEGIN
                                            UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                            SET     ErrorDescription = 'exec spOnlineReversalIndoMart '
                                                    + @AgreementNo + ', '
                                                    + @ReferenceNo + ', '
                                                    + 'OPA'
                                            WHERE   ReferenceNo = @ReferenceNo
                                                    AND OPStep = @OPStep;
                                        END;
                                END; 
                            ELSE
                                BEGIN
                                    IF EXISTS ( SELECT  1
                                                FROM    PaymentHistoryHeaderEXP
                                                        WITH ( NOLOCK )
                                                WHERE   BranchId = @BranchAgreement
                                                        AND ApplicationID = @ApplicationID
                                                        AND HistorySequenceNo = @HistorySequenceNo
                                                        AND IsCorrection = 0
                                                        AND CorrectionHistSequence = 0 )
                                        BEGIN
                                            --PRINT 'masuk EXP'
                                            UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                            SET     InProcess = 1
                                            WHERE   ReferenceNo = @ReferenceNo
                                                    AND OPStep = @OPStep;
					

					
                                            EXEC spOnlineReversalIndoMart @AgreementNo,
                                                @ReferenceNo, 'OPA'; 
                                            IF @@Error <> 0
                                                BEGIN
                                                    UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                                    SET     ErrorDescription = 'exec spOnlineReversalIndoMart '
                                                            + @AgreementNo
                                                            + ', '
                                                            + @ReferenceNo
                                                            + ', ' + 'OPA'
                                                    WHERE   ReferenceNo = @ReferenceNo
                                                            AND OPStep = @OPStep;
                                                END;
                                        END;
                                    ELSE
                                        BEGIN
                                            IF @ContractStatus = 'RRD'
                                                BEGIN
                                                --PRINT 'masuk RRD'
                                                    UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                                    SET     InProcess = 1
                                                    WHERE   ReferenceNo = @ReferenceNo
                                                            AND OPStep = @OPStep;
					
                                                    EXEC spOnlineReversalIndoMart @AgreementNo,
                                                        @ReferenceNo, 'OPA'; 
                                            
                                                --SELECT  contractstatus
                                                --FROM    agreement
                                                --WHERE   agreementno = @AgreementNo
					
                                                    IF @@Error <> 0
                                                        BEGIN
                                                            UPDATE
                                                              OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                                            SET
                                                              ErrorDescription = 'exec spOnlineReversalIndoMart '
                                                              + @AgreementNo
                                                              + ', '
                                                              + @ReferenceNo
                                                              + ', ' + 'OPA'
                                                            WHERE
                                                              ReferenceNo = @ReferenceNo
                                                              AND OPStep = @OPStep;
                                                        END;					   	
                                                END;
                                        END;
                                END;
                        END;
			
                END; 
                
                
            DECLARE @RealValuedate DATETIME;
			
            SELECT TOP 1
                    @RealValuedate = valuedate
            FROM    OLPDB.dbo.OnlinePaymentTransactionIndoMart WITH ( NOLOCK )
            WHERE   referenceno = @ReferenceNo
                    AND agreementno = @AgreementNo
            ORDER BY valuedate ASC;
			
            IF @RealValuedate IS NULL
                UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                SET     valuedate = @ValueDate
                WHERE   agreementno = @AgreementNo
                        AND referenceno = @ReferenceNo;
            ELSE
                UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                SET     valuedate = @RealValuedate
                WHERE   agreementno = @AgreementNo
                        AND referenceno = @ReferenceNo; 

            SET @CounterAging = @CounterAging + 1;  
        END;  
				
	--Buat untuk yang PaymentPointCustomerWO Vincenza FMF-2816 13072021
    DELETE  FROM @TableOnlinePayment;
    INSERT  INTO @TableOnlinePayment
            ( AgreementNo ,
              InsSeqNo ,
              ReferenceNo ,
              PaymentAmount ,
              PaymentMethod ,
              OPStep ,
              TransactionDate 
            )
            SELECT  -- top 200
                    opt.AgreementNo ,
                    opt.InsSeqNo ,
                    opt.ReferenceNo ,
                    opt.PaymentAmount ,
                    'INDOMRT' AS PaymentMethod ,
                    opt.OPStep ,
                    opt.TransactionDate
            FROM    OLPDB.dbo.OnlinePaymentTransactionIndoMart opt WITH ( NOLOCK )
                    INNER JOIN OLPDB.dbo.PaymentPointCustomerWO ppcw WITH ( NOLOCK ) ON opt.AgreementNo = ppcw.AgreementNo
                                                              AND opt.InsSeqNo = ppcw.InsSeqNo
            WHERE   IsPosted = 0
                    AND InProcess = 0
                    AND CreatedBy = 'OPA'
            ORDER BY ReferenceNo ,
                    OPStep;

    DECLARE @CounterAgingWO INT ,
        @LoopAgingWO INT ,
        @BranchHO CHAR(3) ,
        @BankAccountID VARCHAR(10) ,
        @CollectorAgent VARCHAR(100) ,
        @businessdate DATETIME ,
        @WOP VARCHAR(7) ,
        @CurrencyID CHAR(3) ,
        @TransactionsNo VARCHAR(20) ,
        @LoginID CHAR(10) ,
        @TrxFeeSchemeID VARCHAR(20) ,
        @Name VARCHAR(50) ,
        @ApplicationIDForEXP VARCHAR(20) ,
        @BranchIDForAgrExp CHAR(3) ,
        @TransactionFee NUMERIC(17, 2);
    DECLARE @SequenceNo AS INT;
	--Vincenza FMF-3720 23082022
    DECLARE @JournalNo VARCHAR(20);

    SELECT  @BranchHO = '999' ,
            @LoginID = 'CSHOLP' ,
            @WOP = 'BA';

    SET @CounterAgingWO = @CounterAging; 
	
    SELECT  @LoopAgingWO = ISNULL(COUNT(SeqNo), 0)
    FROM    @TableOnlinePayment;
	
	--Vincenza FMF-3720 23082022 
	--set @LoopAgingWO = @LoopAgingWO + @CounterAging
    SET @LoopAgingWO = @LoopAgingWO + @CounterAging - 1;

    WHILE @CounterAgingWO <= @LoopAgingWO
        BEGIN
		--Vincenza FMF-3720 23082022
            SET @AgreementNo = '';
            SET @ReferenceNo = '';
            SET @InsSeqNo = 0;
            SET @PmtTotalAmt = 0;
            SET @PaymentMethod = '';
            SET @OPStep = '';
            SET @ValueDate = '';

            SELECT  @AgreementNo = ISNULL(AgreementNo, '') ,
                    @ReferenceNo = ISNULL(ReferenceNo, '') ,
                    @InsSeqNo = ISNULL(InsSeqNo, 0) ,
                    @PmtTotalAmt = ISNULL(PaymentAmount, 0) ,
                    @PaymentMethod = ISNULL(PaymentMethod, '') ,
                    @OPStep = ISNULL(OPStep, '') ,
                    @ValueDate = ISNULL(TransactionDate, '')
            FROM    @TableOnlinePayment
            WHERE   SeqNo = @CounterAgingWO;

            IF @OPStep = 'PAY'
                BEGIN
                    IF ( SELECT InProcess
                         FROM   OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                WITH ( NOLOCK )
                         WHERE  ReferenceNo = @ReferenceNo
                                AND OPStep = @OPStep
                       ) = 0
                        BEGIN
                            UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                            SET     InProcess = 1
                            WHERE   ReferenceNo = @ReferenceNo
                                    AND OPStep = @OPStep;

                            SELECT  @businessdate = BDCurrent
                            FROM    SystemControlCoy WITH ( NOLOCK );

                            SELECT  @BankAccountID = BankAccountID
                            FROM    tblTransactionFee WITH ( NOLOCK )
                            WHERE   CAID = @PaymentMethod;

                            SELECT  @TrxFeeSchemeID = TrxFeeSchemeID ,
                                    @CurrencyID = CurrencyID ,
                                    @Name = Customer.Name ,
                                    @ApplicationIDForEXP = ApplicationID ,
                                    @BranchIDForAgrExp = BranchID
                            FROM    dbo.Agreement WITH ( NOLOCK )
                                    INNER JOIN Customer WITH ( NOLOCK ) ON Agreement.CustomerID = Customer.CustomerID
                            WHERE   AgreementNo = @AgreementNo;

                            SELECT  @TransactionFee = txfeeD.TransactionFee ,
                                    @CollectorAgent = txfeeH.[Description]
                            FROM    dbo.TransactionFeeSchemeDetail txfeeD WITH ( NOLOCK )
                                    INNER JOIN dbo.TransactionFeeScheme txfeeH
                                    WITH ( NOLOCK ) ON txfeeH.TrxFeeSchemeID = txfeeD.TrxFeeSchemeID
                            WHERE   txfeeD.CAID = @PaymentMethod
                                    AND txfeeH.TrxFeeSchemeID = @TrxFeeSchemeID;
							
                            EXEC spOtherTransactionsHeaderSaveExpired @BranchHO,
                                @businessdate, @ValueDate, @WOP,
                                @BankAccountID, @CurrencyID, @PmtTotalAmt, 1,
                                '', 'R', @ReferenceNo, @TransactionsNo OUTPUT,
                                '', @businessdate, @LoginID, @Name, '',
                                @ApplicationIDForEXP, @BranchIDForAgrExp;

                            DECLARE @AmountReceiveWO Amount ,
                                @NotesInstallmentReceiveWO VARCHAR(100) ,
                                @NotesTransactionFee VARCHAR(100);
                            SET @AmountReceiveWO = @PmtTotalAmt
                                - @TransactionFee;
                            SET @NotesInstallmentReceiveWO = 'Installment Receive WO - '
                                + @AgreementNo;
                            SET @NotesTransactionFee = 'Other Income Payment Transaction Fee - '
                                + @ReferenceNo;

                            IF @AmountReceiveWO <> 0
                                BEGIN
                                    EXEC spOtherTransactionsDetailSaveExpired @TransactionsNo = @TransactionsNo,
                                        @BranchID = @BranchIDForAgrExp,
                                        @DepartmentID = '000',
                                        @PaymentAllocationID = 'OTHPAY',
                                        @AmountReceive = @AmountReceiveWO,
                                        @Notes = @NotesInstallmentReceiveWO,
                                        @FlagTransactions = 'R'
										,@ApplicationIDAgrExp = @ApplicationIDForEXP --21 Juni 2024 Bisma FMF-5087 : Tambah lemparan parameter @ApplicationIDAgrExp 


                                END;

                            IF @TransactionFee <> 0
                                BEGIN
                                    EXEC spOtherTransactionsDetailSaveExpired @TransactionsNo = @TransactionsNo,
                                        @BranchID = @BranchIDForAgrExp,
                                        @DepartmentID = '000',
                                        @PaymentAllocationID = 'OTHINCPAY',
                                        @AmountReceive = @TransactionFee,
                                        @Notes = @NotesTransactionFee,
                                        @FlagTransactions = 'R'
										,@ApplicationIDAgrExp = @ApplicationIDForEXP --21 Juni 2024 Bisma FMF-5087 : Tambah lemparan parameter @ApplicationIDAgrExp 


                                END;

                            EXEC spOtherReceiveTransactionsExpired @TransactionsNo,
                                @LoginID;

					--Vincenza FMF-3720 23082022
                            SELECT  @JournalNo = ISNULL(JournalNo, '')
                            FROM    OtherReceiveHeaderExpired WITH ( NOLOCK )
                            WHERE   TransactionsNo = @TransactionsNo; 

                            UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                            SET     JournalNo = @JournalNo ,
                                    IsPosted = 1 ,
                                    DtmUpd = GETDATE() ,
                                    UsrUpd = SYSTEM_USER
                            WHERE   ReferenceNo = @ReferenceNo
                                    AND OPStep = 'PAY';

                            UPDATE  OLPDB.dbo.PaymentPointCustomerWO
                            SET     isPaid = 1 ,
                                    DtmUpd = GETDATE()
                            WHERE   BranchID = @BranchIDForAgrExp
                                    AND AgreementNo = @AgreementNo
                                    AND InsSeqNo = @InsSeqNo; 

                        END;
                END;
            ELSE
                BEGIN
                    IF ( SELECT InProcess
                         FROM   OLPDB.dbo.OnlinePaymentTransactionIndoMart
                                WITH ( NOLOCK )
                         WHERE  ReferenceNo = @ReferenceNo
                                AND OPStep = @OPStep
                       ) = 0
                        BEGIN
                            UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                            SET     InProcess = 1
                            WHERE   ReferenceNo = @ReferenceNo
                                    AND OPStep = @OPStep;

                            SELECT  @businessdate = BDCurrent
                            FROM    SystemControlCoy WITH ( NOLOCK );

                            SELECT  @BankAccountID = BankAccountID
                            FROM    tblTransactionFee WITH ( NOLOCK )
                            WHERE   CAID = @PaymentMethod;

                            SELECT  @TrxFeeSchemeID = TrxFeeSchemeID ,
                                    @CurrencyID = CurrencyID ,
                                    @Name = Customer.Name ,
                                    @ApplicationIDForEXP = ApplicationID ,
                                    @BranchIDForAgrExp = BranchID
                            FROM    dbo.Agreement WITH ( NOLOCK )
                                    INNER JOIN Customer WITH ( NOLOCK ) ON Agreement.CustomerID = Customer.CustomerID
                            WHERE   AgreementNo = @AgreementNo;

                            SELECT  @TransactionFee = txfeeD.TransactionFee ,
                                    @CollectorAgent = txfeeH.[Description]
                            FROM    dbo.TransactionFeeSchemeDetail txfeeD WITH ( NOLOCK )
                                    INNER JOIN dbo.TransactionFeeScheme txfeeH
                                    WITH ( NOLOCK ) ON txfeeH.TrxFeeSchemeID = txfeeD.TrxFeeSchemeID
                            WHERE   txfeeD.CAID = @PaymentMethod
                                    AND txfeeH.TrxFeeSchemeID = @TrxFeeSchemeID;

                            EXEC spOtherTransactionsHeaderSave @BranchHO,
                                @businessdate, @ValueDate, @WOP,
                                @BankAccountID, @CurrencyID, @PmtTotalAmt, 1,
                                '', 'D', @AgreementNo, @TransactionsNo OUTPUT,
                                'None', @businessdate, @LoginID, @Name, '';

                            INSERT  INTO OtherDisburseHeaderExpired
                                    ( TransactionsNo ,
                                      BranchID ,
                                      BusinessDate ,
                                      ValueDate ,
                                      WOP ,
                                      BankAccountID ,
                                      AmountReceive ,
                                      CurrencyId ,
                                      CurrencyRate ,
                                      Notes ,
                                      BGNo ,
                                      BGDueDate ,
                                      UsrUpd ,
                                      dtmUpd ,
                                      ReferenceNo ,
                                      LoginID ,
                                      JournalNo ,
                                      VoucherNo ,
                                      ProcessFlag ,
                                      ReceiveFrom ,
                                      ApplicationID
                                    )
                            VALUES  ( @TransactionsNo ,
                                      @BranchHO ,
                                      @businessdate ,
                                      @ValueDate ,
                                      @WOP ,
                                      @BankAccountID ,
                                      @PmtTotalAmt ,
                                      @CurrencyID ,
                                      1 ,
                                      '' ,
                                      'None' ,
                                      @businessdate ,
                                      SYSTEM_USER ,
                                      GETDATE() ,
                                      @ReferenceNo ,
                                      @LoginID ,
                                      @TransactionsNo ,
                                      '' ,
                                      0 ,
                                      @Name ,
                                      @ApplicationIDForEXP
                                    );

                            DECLARE @AmountReceiveWORev Amount ,
                                @NotesInstallmentReceiveWORev VARCHAR(100) ,
                                @NotesTransactionFeeRev VARCHAR(100);
                            SET @AmountReceiveWORev = @PmtTotalAmt
                                - @TransactionFee;
                            SET @NotesInstallmentReceiveWORev = 'Installment Receive WO - '
                                + @AgreementNo;
                            SET @NotesTransactionFeeRev = 'Other Income Payment Transaction Fee - '
                                + @ReferenceNo;
					
                            IF @AmountReceiveWORev <> 0
                                BEGIN
                                    EXEC spOtherTransactionsDetailSave @TransactionsNo = @TransactionsNo,
                                        @BranchID = @BranchIDForAgrExp,
                                        @DepartmentID = '000',
                                        @PaymentAllocationID = 'OTHPAY',
                                        @AmountReceive = @AmountReceiveWORev,
                                        @Notes = @NotesInstallmentReceiveWORev,
                                        @FlagTransactions = 'D';

                                    SELECT  @SequenceNo = ISNULL(MAX(SequenceNo),
                                                              0) + 1
                                    FROM    OtherDisburseDetailExpired WITH ( NOLOCK )
                                    WHERE   TransactionsNo = @TransactionsNo;

                                    INSERT  INTO OtherDisburseDetailExpired
                                            ( TransactionsNo ,
                                              BranchID ,
                                              DepartmentID ,
                                              PaymentAllocationID ,
                                              SequenceNo ,
                                              AmountReceive ,
                                              Notes ,
                                              UsrUpd ,
                                              dtmUpd
						                    )
                                    VALUES  ( @TransactionsNo ,
                                              @BranchIDForAgrExp ,
                                              '000' ,
                                              'OTHPAY' ,
                                              @SequenceNo ,
                                              @AmountReceiveWORev ,
                                              @NotesInstallmentReceiveWORev ,
                                              SYSTEM_USER ,
                                              GETDATE()
                                            );
                                END;

                            IF @TransactionFee <> 0
                                BEGIN
                                    EXEC spOtherTransactionsDetailSave @TransactionsNo = @TransactionsNo,
                                        @BranchID = @BranchIDForAgrExp,
                                        @DepartmentID = '000',
                                        @PaymentAllocationID = 'OTHINCPAY',
                                        @AmountReceive = @TransactionFee,
                                        @Notes = @NotesTransactionFeeRev,
                                        @FlagTransactions = 'D';

                                    INSERT  INTO OtherDisburseDetailExpired
                                            ( TransactionsNo ,
                                              BranchID ,
                                              DepartmentID ,
                                              PaymentAllocationID ,
                                              SequenceNo ,
                                              AmountReceive ,
                                              Notes ,
                                              UsrUpd ,
                                              dtmUpd
						                    )
                                    VALUES  ( @TransactionsNo ,
                                              @BranchIDForAgrExp ,
                                              '000' ,
                                              'OTHINCPAY' ,
                                              @SequenceNo ,
                                              @AmountReceiveWORev ,
                                              @NotesTransactionFeeRev ,
                                              SYSTEM_USER ,
                                              GETDATE()
                                            );
                                END;
                            EXEC spOtherDisburseTransactionsExpired @TransactionsNo,
                                @LoginID;

					--Vincenza FMF-3720 23082022
                            SELECT  @JournalNo = ISNULL(JournalNo, '')
                            FROM    OtherDisburseHeaderExpired WITH ( NOLOCK )
                            WHERE   TransactionsNo = @TransactionsNo; 

                            UPDATE  OLPDB.dbo.OnlinePaymentTransactionIndoMart
                            SET     JournalNo = @JournalNo ,
                                    InstallmentPaid = 0 ,
                                    LCPaid = 0 ,
                                    PrepaidPaid = 0 ,
                                    IsPosted = 1 ,
                                    DtmUpd = GETDATE() ,
                                    UsrUpd = SYSTEM_USER
                            WHERE   ReferenceNo = @ReferenceNo
                                    AND OPStep = 'REV';

                            UPDATE  OLPDB.dbo.PaymentPointCustomerWO
                            SET     isPaid = 0 ,
                                    DtmUpd = GETDATE()
                            WHERE   BranchID = @BranchIDForAgrExp
                                    AND AgreementNo = @AgreementNo
                                    AND InsSeqNo = @InsSeqNo; 

                        END;
                END;

            SET @CounterAgingWO = @CounterAgingWO + 1;
        END;
	--end Vincenza FMF-2816

    COMMIT TRANSACTION PostingOnlinePayment;   
	
    RETURN;  

    ExitSP:  
    BEGIN  
        ROLLBACK TRANSACTION PostingOnlinePayment;  
	
        RETURN;  
    END;  
