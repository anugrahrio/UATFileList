﻿/* 
  
Modification         	:	RINA 2/12/2019 tambah @PostFIX untuk update header  
							- Jason, 20 September 2022 [FMF-3776] : Perubahan header : 
																		024 Mobil : 024/BUSINESSBANKING/XII/2018 
																		024 MOTOR : 024/BUSINESSBANKING/XII/2018MT  
																		024 WG AR : 024/BUSINESSBANKING/XII/2018WGAR 
							- Jason, 12 Desember 2022 [FMF-3987]: Perubahan sesuai dengan permintaan client 
																		header : 
																		024/BUSINESSBANKING/XI/2018-WG   untuk white goods 
																		024/BUSINESSBANKING/XI/2018-MB   untuk mobil 
																		024/BUSINESSBANKING/XI/2018-MT   untuk motor 
							- Restu, 21 Feb 23 [FMF-3987] : Ubah cara ambil header balik lagi ambil dari contractname, karena sesuai kesepakatan user akan setting dari menu fundingcontract 
							- Niko 27 Mar 23 [FMF-4243] : Tambah beberapa perubahan isi textfile sesuai request user 
							- Restu, 10/10/23 [FMF-4656] : NomorIdentitasPasangan (kolom 16) Ubah kondisi jika ada angka 0 tetap dimunculkan 
							- Bisma 21 November 2023 FMF-4279 : Penambahan Kondisi untuk WR dan Set nilai 0
 
 */ 
 
  
 
alter Procedure [dbo].[spGenerateTextFileSLIKBTPN] 
@FundingCoyID varchar(20), 
@FundingContract varchar(20), 
@FundingBatchID varchar(20) 
AS 
Declare @WhereBy varchar(1000) 
DECLARE @Record INT 
DECLARE @FundingContractName VARCHAR(50) 
Declare @postFix varchar(2) 
 
IF @FundingBatchID ='All' 
	Set @WhereBy='WHERE Agreement.FundingCoyID='''+@FundingCoyID+''' 
	And Agreement.FundingContractID='''+@FundingContract+'''' 
Else 
	Set @WhereBy='WHERE Agreement.FundingCoyID='''+@FundingCoyID+''' 
	And Agreement.FundingContractID='''+@FundingContract+''' And Agreement.FundingBatchID='''+@FundingBatchID+'''' 
 
Create Table #Temp 
	( 
	NoPin CHAR(17), 
	KodeSifatKreditPembiayaan CHAR(1), 
	KodeJenisKreditPembiayaan CHAR(2), 
	KodeSkimPembiayaan CHAR(2), 
	BaruPerpanjangan CHAR(2), 
	KodeJenisPenggunaan CHAR(1), 
	KodeOrientasiPenggunaan CHAR(1), 
	TakeoverDari CHAR(6), 
	Email CHAR(150), 
	HP CHAR(15), 
	AlamatTempatBekerja CHAR(300), 
	PenghasilanKotorPerTahun CHAR(12), 
	KodeSumberPenghasilan CHAR(1), 
	JumlahTanggungan CHAR(2), 
	NamaPasangan CHAR(150), 
	NomorIdentitasPasangan CHAR(16), 
	TanggalLahirPasangan CHAR(10), 
	PerjanjianPisahHarta CHAR(1), 
	KodeBidangUsahaTempatBekerja CHAR(6), 
	KodeGolonganDebitur CHAR(4), 
	KodeBentukBadanUsaha CHAR(2), 
	GoPublic CHAR(1), 
	PeringkatRatingDebitur CHAR(6), 
	LembagaPemeringkatRating CHAR(2), 
	TanggalPemeringkat CHAR(10), 
	NamaGroupDebitur CHAR(150), 
	KodeAenisAgunan CHAR(3), 
	KodeJenisPengikatan CHAR(2), 
	TanggalPengikatan CHAR(10), 
	NamaPemilikAgunan CHAR(150), 
	AlamatAgunan CHAR(300), 
	StatusKreditJoint CHAR(1), 
	KodeDatiLokasiAgunan CHAR(4), 
	Diasuransikan CHAR(1) 
	) 
	 
	---Add Jason 12 Desember 2022 [FMF-3987] : 
	DECLARE @FlagWG BIT 
	DECLARE @FlagMB BIT 
	DECLARE @FlagMT BIT 

	-- Bisma 21 November 2023 FMF-4279 : Add Set 0
	SET @FlagWG=0
	SET @FlagMB=0
	SET @FlagMT=0
	--End Bisma


	SELECT	@FlagWG = CASE WHEN @FundingContract LIKE '%WG%' OR @FundingContract LIKE '%WR%' THEN 1 ELSE 0 END  --Bisma 21 November 2023 FMF-4279  Add WR 
	SELECT	@FlagMB = CASE WHEN @FundingContract LIKE '%MOBIL%' THEN 1 ELSE 0 END 
	SELECT	@FlagMT = CASE WHEN @FundingContract LIKE '%MOTOR%' THEN 1 ELSE 0 END 
	---End Jason [FMF-3987]	 
	  
 
	EXEC('Insert Into #Temp  
	SELECT  
	RTRIM(Agreement.AgreementNo) NoPin, 
/* 
1 : Kredit yang Direstrukturisasi 
2 : Pengambilalihan Kredit 
3 : Kredit Subordinasi 
9 : Lainnya 
*/ 
	''4'' KodeSifatKreditPembiayaan, 
/* 
05 : Kredit yang diberikan 
10 : Kredit dalam rangka pembiayaan bersama (Sindikasi) 
20 : Kredit kepada pihak ketiga melalui lembaga lain secara channeling 
26 : Kredit kepada UMKM melalui lembaga lain secara executing 
27 : Kredit kepada Non-UMKM melalui lembaga lain secara executing 
45 : Surat berharga dengan Note Purchase Agreement (NPA) 
*/ 
	''10'' KodeJenisKreditPembiayaan, 
/* 
00 : Konvensional 
01 : Piutang Murabahah 
02 : Piutang Istishna 
03 : Piutang Salam 
04 : Qard 
05 : Mudharabah 
06 : Musyarakah 
07 : Ijarah 
08 : Mudharabah Muqayyadah 
09 : Ijarah Muntahiya Bitamlik 
99 : Skim/Akad Lainnya 
*/ 
	''00'' KodeSkimPembiayaan, 
/*0=baru, 1=perpanjang sekali, 2=perpanjang kedua, dst*/ 
	''0'' BaruPerpanjangan, 
/*1=Modal Kerja, 2=Investasi, 3=Konsumsi*/ 
	CASE WHEN Agreement.PurposeOfFinancingID=''PMK'' THEN ''1'' ELSE ''3'' END KodeJenisPenggunaan, 
/*1=Export, 2=Import, 3=Lainnya*/ 
	''3'' KodeOrientasiPenggunaan, 
	'''' TakeoverDari, 
	CASE WHEN PersonalCustomer.Email IS NULL OR PersonalCustomer.Email = '' ''  OR PersonalCustomer.Email = ''-'' OR PersonalCustomer.Email = '''' THEN ''NA'' 
	ELSE PersonalCustomer.Email END AS Email, /*Niko FMF-4243 kalau kosong, spasi, strip default isi NA*/ 
	LEFT(ISNULL(PersonalCustomer.MobilePhone,''''),15) HP, 
	LEFT(RTRIM(REPLACE(REPLACE(REPLACE(ISNULL(PersonalCustomer.CompanyAddress,''''),CHAR(9),'' ''),CHAR(10),'' ''),CHAR(13),'' '')) + '' '' + RTRIM(ISNULL(PersonalCustomer.CompanyKelurahan,''''))  + '' '' + RTRIM(ISNULL(PersonalCustomer.CompanyKecamatan,''''
))  + '' '' + RTRIM(ISNULL(PersonalCustomer.CompanyCity,''''))  + '' '' + RTRIM(ISNULL(PersonalCustomer.CompanyZipCode,'''')),300) AlamatTempatBekerja, 
	FORMAT((ISNULL(PersonalCustomer.MonthlyFixedIncome,0)+ISNULL(PersonalCustomer.MonthlyvariableIncome,0))*12,''0'')  PenghasilanKotorPerTahun, 
/*1=Gaji, 2=Usaha, 3=Lainnya*/ 
	CASE WHEN RTRIM(PersonalCustomer.ProfessionID) IN (''PRO'',''WRST'') THEN ''2'' ELSE ''1'' END KodeSumberPenghasilan, 
	FORMAT(PersonalCustomer.NumOfDependence,''0'') JumlahTanggungan, 
	ISNULL(Family.Name,'''') NamaPasangan, 
	CASE  
		/* Restu FMF-4656 Ubah kondisi jika ada angka 0 tetap dimunculkan 
        WHEN LEN(LEFT(ISNULL(Family.IDNumber,''''),16)) < 15 OR LEFT(ISNULL(Family.IDNumber,''''),16) LIKE ''%0%'' OR LEFT(ISNULL(Family.IDNumber,''''),16) LIKE ''%-%'' 
		*/ 
 
		WHEN LEN(LEFT(ISNULL(Family.IDNumber,''''),16)) < 15 OR LEFT(ISNULL(Family.IDNumber,''''),16) LIKE ''%-%'' 
 
        THEN '' '' 
        ELSE LEFT(ISNULL(Family.IDNumber,''''),16)  
    END AS NomorIdentitasPasangan, /*Niko FMF-4243 kalau kurang dari 15 digit atau ada angka 0 atau ada symbol -, maka default isi kosong.*/ 
	CONVERT(CHAR(10), ISNULL(Family.BirthDate,''''), 103) TanggalLahirPasangan, 
/*Y/T, default=T*/ 
	''T'' PerjanjianPisahHarta, 
	IndustryType.LBPPCode KodeBidangUsahaTempatBekerja,  
	''9000'' KodeGolonganDebitur, 
/* 
01 : Badan Usaha Unit Desa (BUUD) 
02 : Commanditer Venotschap (CV) 
03 : Debitur Kelompok 
04 : Ekspedisi Muatan Kapal Laut (EMKL) 
05 : FIRMA 
06 : Gabungan Koperasi 
07 : Induk Koperasi 
08 : Koperasi 
09 : Koperasi Unit Desa 
10 : Limited 
11 : Maskapai Andil Indonesia 
12 : Namloose Venotschaap 
13 : Perusahaan Daerah 
14 : Persero 
15 : Persekutuan Perdata 
16 : Perusahaan Umum 
17 : Primer Koperasi 
18 : Perseroan Terbatas 
19 : Pusat Koperasi 
20 : Pusat Koperasi Unit Desa 
21 : Usaha Dagang 
22 : Unit Dagang Kredit Pedesaan 
23 : Yayasan	23 
99 : Lainnya Badan Usaha 
*/ 
	'''' KodeBentukBadanUsaha, 
/*Y=Ya, T=Tidak*/ 
	'''' GoPublic, 
	'''' PeringkatRatingDebitur, 
/* 
10 : MOODY`S 
11 : STANDARD AND POOR`S 
12 : FITCH RATING 
13 : PEFINDO 
14 : ICRA INDONESIA 
15 : FITCH INDONESIA 
99 : LAINNYA 
*/ 
	'''' LembagaPemeringkatRating, 
	'''' TanggalPemeringkat, 
	'''' NamaGroupDebitur, 
	--CASE WHEN Product.AssetTypeID=''4'' THEN ''250'' ELSE ''189'' END  
	--Add Jason 8 Desember 2022, FMF-3987 
	--'''' KodeJenisAgunan, 
	CASE WHEN '+ @FlagWG + ' = 1 THEN ''250''  
	WHEN '+ @FlagMB + ' = 1 THEN ''189''  
	WHEN '+ @FlagMT + ' = 1 THEN ''189''  END AS KodeJenisAgunan,-- Edit jason default value jadi 189 bukan kosong 
	--End Jason 
/* 
01 : Hak Tanggungan 
02 : Gadai 
03 : Fiduciare Eigendom Overdracht (FEO) 
04 : Surat Kuasa Membebankan Hak Tanggungan (SKMHT) 
05 : Cessie	 
06 : Belum Diikat 
99 : Lainnya 
*/ 
	--CASE WHEN Product.AssetTypeID=''4'' THEN ''99'' ELSE ''04'' END  
	--Add Jason 8 Desember 2022, FMF-3987 
	--'''' KodeJenisPengikatan, 
	CASE WHEN '+ @FlagWG + ' = 1 THEN ''99''  
	WHEN '+ @FlagMT + ' = 1 THEN ''03''  
	WHEN '+ @FlagMB + ' = 1 THEN ''03''  END AS KodeJenisPengikatan,-- Edit jason default value jadi 03 bukan kosong 
	--'''' TanggalPengikatan, 
	convert(char(10), FundingAgreement.EffectiveDate, 103) TanggalPengikatan,-- Edit jason hilangin else (Default Value), 19 Januari ilangin select, 23 Januari ubah jadi CHAR(10) dari varchar 
	--RTRIM(AgreementAsset.OwnerAsset) NamaPemilikAgunan, 
	CASE WHEN '+ @FlagWG + ' = 1 THEN ''NA'' ELSE RTRIM(AgreementAsset.OwnerAsset) END AS NamaPemilikAgunan, 
	--End Jason 
	CASE WHEN Agreement.FundingContractID LIKE ''%WG%'' OR FundingContractID LIKE ''%WR%'' THEN ''0'' ELSE /*Niko FMF-4243 kalau fundingcontract WG/Elektronik, diisi hardcode 0, Bisma 21 November 2023 FMF-4279 : Penambahan Kondisi untuk WR */ 
	LEFT(RTRIM(REPLACE(REPLACE(REPLACE(AgreementAsset.OwnerAddress,CHAR(9),'' ''),CHAR(10),'' ''),CHAR(13),'' '')) + '' '' + RTRIM(AgreementAsset.OwnerKelurahan)  + '' '' + RTRIM(AgreementAsset.OwnerKecamatan)  + '' '' + RTRIM(AgreementAsset.OwnerCity)  + ''
 '' + RTRIM(AgreementAsset.OwnerZipCode),300) END AS AlamatAgunan, 
	--Add Jason 8 Desember 2022, FMF-3987 
	--'''' StatusKreditJoint, 
	''N'' StatusKreditJoint,-- Edit jason hilangin else (Default Value) 
	--End Jason 
	CASE 
		WHEN LEFT(PersonalCustomer.LegalZipCode, 2) = ''00'' THEN  
			CASE Agreement.BranchID 
				WHEN ''400'' THEN ''0198'' 
				WHEN ''401'' THEN ''0292'' 
				WHEN ''403'' THEN ''0395'' 
				WHEN ''404'' THEN ''0394'' 
				WHEN ''405'' THEN ''0108'' 
				WHEN ''406'' THEN ''0393'' 
				WHEN ''407'' THEN ''0292'' 
				WHEN ''408'' THEN ''0106'' 
				WHEN ''409'' THEN ''0108'' 
				WHEN ''410'' THEN ''0108'' 
				WHEN ''411'' THEN ''0292'' 
				WHEN ''413'' THEN ''0202'' 
				WHEN ''414'' THEN ''0392'' 
				WHEN ''415'' THEN ''0204'' 
				WHEN ''417'' THEN ''0395'' 
				WHEN ''418'' THEN ''0395'' 
				WHEN ''420'' THEN ''0394'' 
				WHEN ''421'' THEN ''0392'' 
				WHEN ''422'' THEN ''0394'' 
				WHEN ''426'' THEN ''0191'' 
				WHEN ''427'' THEN ''0116'' 
				WHEN ''428'' THEN ''0113'' 
				WHEN ''429'' THEN ''0196'' 
				WHEN ''430'' THEN ''0193'' 
				WHEN ''431'' THEN ''0106'' 
				WHEN ''432'' THEN ''0103'' 
				WHEN ''433'' THEN ''0112'' 
				WHEN ''434'' THEN ''0114'' 
				WHEN ''435'' THEN ''0121'' 
				WHEN ''436'' THEN ''0111'' 
				WHEN ''437'' THEN ''0117'' 
				WHEN ''438'' THEN ''0110'' 
				WHEN ''440'' THEN ''0106'' 
				WHEN ''441'' THEN ''0118'' 
				WHEN ''442'' THEN ''0111'' 
				WHEN ''451'' THEN ''0991'' 
				WHEN ''452'' THEN ''0591'' 
				WHEN ''453'' THEN ''0994'' 
				WHEN ''454'' THEN ''0996'' 
				WHEN ''455'' THEN ''0915'' 
				WHEN ''456'' THEN ''0913'' 
				WHEN ''457'' THEN ''0915'' 
				WHEN ''458'' THEN ''0923'' 
				WHEN ''459'' THEN ''0909'' 
				WHEN ''460'' THEN ''0918'' 
				WHEN ''476'' THEN ''1291'' 
				WHEN ''477'' THEN ''1292'' 
				WHEN ''478'' THEN ''1202'' 
				WHEN ''479'' THEN ''1201'' 
				WHEN ''480'' THEN ''1213'' 
				WHEN ''481'' THEN ''1217'' 
				WHEN ''482'' THEN ''1298'' 
				WHEN ''485'' THEN ''1296'' 
				WHEN ''486'' THEN ''1296'' 
				WHEN ''488'' THEN ''1291'' 
				WHEN ''501'' THEN ''7291'' 
				WHEN ''502'' THEN ''7201'' 
				WHEN ''503'' THEN ''7203'' 
				WHEN ''518'' THEN ''5492'' 
				WHEN ''519'' THEN ''5491'' 
				WHEN ''520'' THEN ''5491'' 
				WHEN ''521'' THEN ''5493'' 
				WHEN ''522'' THEN ''5494'' 
				WHEN ''535'' THEN ''5191'' 
				WHEN ''536'' THEN ''5192'' 
				WHEN ''537'' THEN ''5102'' 
				WHEN ''538'' THEN ''5110'' 
				WHEN ''539'' THEN ''5108'' 
				WHEN ''540'' THEN ''5109'' 
				WHEN ''552'' THEN ''6191'' 
				WHEN ''553'' THEN ''6102'' 
				WHEN ''554'' THEN ''6192'' 
				WHEN ''555'' THEN ''6105'' 
				WHEN ''556'' THEN ''6193'' 
				WHEN ''557'' THEN ''6111'' 
				WHEN ''559'' THEN ''6191'' 
				WHEN ''561'' THEN ''6106'' 
				WHEN ''577'' THEN ''5892'' 
				WHEN ''578'' THEN ''5802'' 
				WHEN ''579'' THEN ''5803'' 
				WHEN ''580'' THEN ''5801'' 
				WHEN ''594'' THEN ''3107'' 
				WHEN ''611'' THEN ''6291'' 
				WHEN ''612'' THEN ''6301'' 
				WHEN ''613'' THEN ''6293'' 
				WHEN ''621'' THEN ''3396'' 
				WHEN ''622'' THEN ''3301'' 
				WHEN ''623'' THEN ''3392'' 
				WHEN ''624'' THEN ''3302'' 
				WHEN ''625'' THEN ''3393'' 
				WHEN ''646'' THEN ''3591'' 
				WHEN ''647'' THEN ''3892'' 
				WHEN ''649'' THEN ''3891'' 
				WHEN ''650'' THEN ''3502'' 
				WHEN ''652'' THEN ''3501'' 
				WHEN ''653'' THEN ''3591'' 
				WHEN ''663'' THEN ''5391'' 
				WHEN ''664'' THEN ''5392'' 
				WHEN ''680'' THEN ''3991'' 
				WHEN ''681'' THEN ''3992'' 
				WHEN ''697'' THEN ''3691'' 
				WHEN ''698'' THEN ''3608'' 
				WHEN ''699'' THEN ''3694'' 
				WHEN ''701'' THEN ''3791'' 
				WHEN ''702'' THEN ''3609'' 
				WHEN ''703'' THEN ''3606'' 
				WHEN ''704'' THEN ''2391'' 
				WHEN ''707'' THEN ''3691'' 
				WHEN ''714'' THEN ''6991'' 
				WHEN ''715'' THEN ''6990'' 
				WHEN ''731'' THEN ''6091'' 
				WHEN ''732'' THEN ''6005'' 
				WHEN ''748'' THEN ''3492'' 
				WHEN ''749'' THEN ''3491'' 
				WHEN ''765'' THEN ''7191'' 
				WHEN ''766'' THEN ''7105'' 
				WHEN ''767'' THEN ''7401'' 
				WHEN ''782'' THEN ''8191'' 
				WHEN ''783'' THEN ''8390'' 
				WHEN ''799'' THEN ''6491'' 
				WHEN ''902'' THEN ''0204'' 
				WHEN ''903'' THEN ''0395'' 
				WHEN ''905'' THEN ''0202'' 
				WHEN ''906'' THEN ''0108'' 
				WHEN ''907'' THEN ''0102'' 
				WHEN ''908'' THEN ''0395'' 
				WHEN ''909'' THEN ''0392'' 
				WHEN ''910'' THEN ''0394'' 
				WHEN ''911'' THEN ''0293'' 
				WHEN ''912'' THEN ''0394'' 
				WHEN ''913'' THEN ''0204'' 
				WHEN ''914'' THEN ''0102'' 
				WHEN ''915'' THEN ''0102'' 
			END  
		WHEN LEFT(PersonalCustomer.LegalZipCode, 2) <> ''00'' THEN  
		isnull( 
		isnull( 
		( 
			SELECT TOP 1 
				CASE  
					WHEN Code1 <> '''' THEN LEFT(Code1, 4) 
				END  
			FROM DATI2 WITH (NOLOCK) WHERE Description LIKE ''%'' + RTrim(PersonalCustomer.LegalCity) + ''%'' and Code2 = LEFT(PersonalCustomer.LegalZipCode, 2) and right(rtrim(Description),7) <> ''lainnya'' 
		) 
		,( 
			SELECT TOP 1 
				CASE  
					WHEN Code1 <> '''' THEN LEFT(Code1, 4) 
				END  
			FROM DATI2 WITH (NOLOCK) WHERE Description LIKE ''%lainnya%'' and Code2 = LEFT(PersonalCustomer.LegalZipCode, 2) 
		)) 
		,''9999'') 
		ELSE 
			CASE Agreement.BranchID 
				WHEN ''400'' THEN ''0198'' 
				WHEN ''401'' THEN ''0292'' 
				WHEN ''403'' THEN ''0395'' 
				WHEN ''404'' THEN ''0394'' 
				WHEN ''405'' THEN ''0108'' 
				WHEN ''406'' THEN ''0393'' 
				WHEN ''407'' THEN ''0292'' 
				WHEN ''408'' THEN ''0106'' 
				WHEN ''409'' THEN ''0108'' 
				WHEN ''410'' THEN ''0108'' 
				WHEN ''411'' THEN ''0292'' 
				WHEN ''413'' THEN ''0202'' 
				WHEN ''414'' THEN ''0392'' 
				WHEN ''415'' THEN ''0204'' 
				WHEN ''417'' THEN ''0395'' 
				WHEN ''418'' THEN ''0395'' 
				WHEN ''420'' THEN ''0394'' 
				WHEN ''421'' THEN ''0392'' 
				WHEN ''422'' THEN ''0394'' 
				WHEN ''426'' THEN ''0191'' 
				WHEN ''427'' THEN ''0116'' 
				WHEN ''428'' THEN ''0113'' 
				WHEN ''429'' THEN ''0196'' 
				WHEN ''430'' THEN ''0193'' 
				WHEN ''431'' THEN ''0106'' 
				WHEN ''432'' THEN ''0103'' 
				WHEN ''433'' THEN ''0112'' 
				WHEN ''434'' THEN ''0114'' 
				WHEN ''435'' THEN ''0121'' 
				WHEN ''436'' THEN ''0111'' 
				WHEN ''437'' THEN ''0117'' 
				WHEN ''438'' THEN ''0110'' 
				WHEN ''440'' THEN ''0106'' 
				WHEN ''441'' THEN ''0118'' 
				WHEN ''442'' THEN ''0111'' 
				WHEN ''451'' THEN ''0991'' 
				WHEN ''452'' THEN ''0591'' 
				WHEN ''453'' THEN ''0994'' 
				WHEN ''454'' THEN ''0996'' 
				WHEN ''455'' THEN ''0915'' 
				WHEN ''456'' THEN ''0913'' 
				WHEN ''457'' THEN ''0915'' 
				WHEN ''458'' THEN ''0923'' 
				WHEN ''459'' THEN ''0909'' 
				WHEN ''460'' THEN ''0918'' 
				WHEN ''476'' THEN ''1291'' 
				WHEN ''477'' THEN ''1292'' 
				WHEN ''478'' THEN ''1202'' 
				WHEN ''479'' THEN ''1201'' 
				WHEN ''480'' THEN ''1213'' 
				WHEN ''481'' THEN ''1217'' 
				WHEN ''482'' THEN ''1298'' 
				WHEN ''485'' THEN ''1296'' 
				WHEN ''486'' THEN ''1296'' 
				WHEN ''488'' THEN ''1291'' 
				WHEN ''501'' THEN ''7291'' 
				WHEN ''502'' THEN ''7201'' 
				WHEN ''503'' THEN ''7203'' 
				WHEN ''518'' THEN ''5492'' 
				WHEN ''519'' THEN ''5491'' 
				WHEN ''520'' THEN ''5491'' 
				WHEN ''521'' THEN ''5493'' 
				WHEN ''522'' THEN ''5494'' 
				WHEN ''535'' THEN ''5191'' 
				WHEN ''536'' THEN ''5192'' 
				WHEN ''537'' THEN ''5102'' 
				WHEN ''538'' THEN ''5110'' 
				WHEN ''539'' THEN ''5108'' 
				WHEN ''540'' THEN ''5109'' 
				WHEN ''552'' THEN ''6191'' 
				WHEN ''553'' THEN ''6102'' 
				WHEN ''554'' THEN ''6192'' 
				WHEN ''555'' THEN ''6105'' 
				WHEN ''556'' THEN ''6193'' 
				WHEN ''557'' THEN ''6111'' 
				WHEN ''559'' THEN ''6191'' 
				WHEN ''561'' THEN ''6106'' 
				WHEN ''577'' THEN ''5892'' 
				WHEN ''578'' THEN ''5802'' 
				WHEN ''579'' THEN ''5803'' 
				WHEN ''580'' THEN ''5801'' 
				WHEN ''594'' THEN ''3107'' 
				WHEN ''611'' THEN ''6291'' 
				WHEN ''612'' THEN ''6301'' 
				WHEN ''613'' THEN ''6293'' 
				WHEN ''621'' THEN ''3396'' 
				WHEN ''622'' THEN ''3301'' 
				WHEN ''623'' THEN ''3392'' 
				WHEN ''624'' THEN ''3302'' 
				WHEN ''625'' THEN ''3393'' 
				WHEN ''646'' THEN ''3591'' 
				WHEN ''647'' THEN ''3892'' 
				WHEN ''649'' THEN ''3891'' 
				WHEN ''650'' THEN ''3502'' 
				WHEN ''652'' THEN ''3501'' 
				WHEN ''653'' THEN ''3591'' 
				WHEN ''663'' THEN ''5391'' 
				WHEN ''664'' THEN ''5392'' 
				WHEN ''680'' THEN ''3991'' 
				WHEN ''681'' THEN ''3992'' 
				WHEN ''697'' THEN ''3691'' 
				WHEN ''698'' THEN ''3608'' 
				WHEN ''699'' THEN ''3694'' 
				WHEN ''701'' THEN ''3791'' 
				WHEN ''702'' THEN ''3609'' 
				WHEN ''703'' THEN ''3606'' 
				WHEN ''704'' THEN ''2391'' 
				WHEN ''707'' THEN ''3691'' 
				WHEN ''714'' THEN ''6991'' 
				WHEN ''715'' THEN ''6990'' 
				WHEN ''731'' THEN ''6091'' 
				WHEN ''732'' THEN ''6005'' 
				WHEN ''748'' THEN ''3492'' 
				WHEN ''749'' THEN ''3491'' 
				WHEN ''765'' THEN ''7191'' 
				WHEN ''766'' THEN ''7105'' 
				WHEN ''767'' THEN ''7401'' 
				WHEN ''782'' THEN ''8191'' 
				WHEN ''783'' THEN ''8390'' 
				WHEN ''799'' THEN ''6491'' 
				WHEN ''902'' THEN ''0204'' 
				WHEN ''903'' THEN ''0395'' 
				WHEN ''905'' THEN ''0202'' 
				WHEN ''906'' THEN ''0108'' 
				WHEN ''907'' THEN ''0102'' 
				WHEN ''908'' THEN ''0395'' 
				WHEN ''909'' THEN ''0392'' 
				WHEN ''910'' THEN ''0394'' 
				WHEN ''911'' THEN ''0293'' 
				WHEN ''912'' THEN ''0394'' 
				WHEN ''913'' THEN ''0204'' 
				WHEN ''914'' THEN ''0102'' 
				WHEN ''915'' THEN ''0102'' 
			END  
	END KodeDatiLokasiAgunan, 
	CASE WHEN Agreement.InsAssetPremium > 0 THEN ''Y'' ELSE ''T'' END Diasuransikan 
	FROM FundingAgreement WITH (NOLOCK) 
	INNER JOIN Agreement WITH (NOLOCK) ON Agreement.BranchID=FundingAgreement.BranchID AND Agreement.ApplicationID=FundingAgreement.ApplicationID 
	INNER JOIN Product WITH (NOLOCK) ON Agreement.ProductID=Product.ProductID  
	INNER JOIN Customer WITH (NOLOCK) ON Agreement.CustomerID=Customer.CustomerID 
	INNER JOIN PersonalCustomer WITH (NOLOCK) ON Agreement.CustomerID=PersonalCustomer.CustomerID 
	INNER JOIN IndustryType WITH (NOLOCK) ON PersonalCustomer.IndustryTypeID=IndustryType.IndustryTypeID 
	INNER JOIN AgreementAsset WITH (NOLOCK) ON Agreement.BranchID=AgreementAsset.BranchID AND Agreement.ApplicationID=AgreementAsset.ApplicationID AND AgreementAsset.AssetSeqNo=1 
	LEFT OUTER JOIN Family WITH (NOLOCK)  ON Family.CustomerID=PersonalCustomer.CustomerID AND Family.FamilyRelation=''SP'' 
	'+@WhereBy+'') 
	SELECT @Record=COUNT(*) FROM #Temp 
		--SELECT @FundingContractName=LEFT(ContractName,3) FROM FundingContract WITH (NOLOCK) WHERE FundingContractNo=@FundingContract AND FundingCoyID=@FundingCoyID  
	/* 
	SELECT @FundingContractName=LEFT(ContractName,3), @postFix=case when ContractName like '%MOBIL%' then 'MB' when ContractName like '%MOTOR%' then 'MT' else 'WG' end   
	FROM FundingContract WITH (NOLOCK) WHERE FundingContractNo=@FundingContract AND FundingCoyID=@FundingCoyID 
	*/ 
 
	--Begin Remarked by Restu FMF-3987 21 Feb 23, ubah jadi ambil dari contractname saja 
	--SELECT @FundingContractName= 
	--CASE WHEN FundingContractNo='024 MOBIL' THEN '024/BUSINESSBANKING/XII/2018' -- Edited by Jason 20 September 2022 [FMF-3776] 
	--	WHEN FundingContractNo='024 MOTOR' THEN '024/BUSINESSBANKING/XII/2018MT' -- Edited by Jason 20 September 2022 [FMF-3776] 
	--	WHEN FundingContractNo='024 WG AD' THEN '024BUSINESSBANKINGXII2018WGAD' 
	--	WHEN FundingContractNo='024 WG AR' THEN '024/BUSINESSBANKING/XII/2018WGAR' -- Edited by Jason 20 September 2022 [FMF-3776] 
	--	WHEN FundingContractNo='024 WHITE GOODS' THEN '024BUSINESSBANKINGXII2019WGAR' 
	--	WHEN FundingContractNo='024 WHITE GOODS ADV' THEN '024/BUSINESSBANKING/XI/2018WG' 
	--	WHEN FundingContractNo='024 BSBSC MOBIL' THEN '024/BSBSC/X/2022MB' --Added Jason 9 Desember 2022 FMF-3987 
	--	WHEN FundingContractNo='024 BSBSC MOTOR' THEN '024/BSBSC/X/2022MT'--Added Jason 9 Desember 2022 FMF-3987 
	--	WHEN FundingContractNo='024 BSBSC WG ADV' THEN '024/BSBSC/X/2022WGAD'--Added Jason 9 Desember 2022 FMF-3987 
	--	WHEN FundingContractNo='024 BSBSC WG ARR' THEN '024/BSBSC/X/2022WGAR'--Added Jason 9 Desember 2022 FMF-3987 
	--ELSE ContractName END 
	--FROM FundingContract WITH (NOLOCK) WHERE FundingContractNo=@FundingContract AND FundingCoyID=@FundingCoyID 
 
	SELECT @FundingContractName = LTRIM(RTRIM(ContractName)) 
	FROM FundingContract WITH (NOLOCK) WHERE FundingContractNo=@FundingContract AND FundingCoyID=@FundingCoyID 
	--End Restu FMF-3987  
 
	Insert Into #tempDua (textFile) 
--SELECT 'FMF|31|' + RIGHT(REPLACE(CONVERT(VARCHAR(8), GETDATE(), 112)+CONVERT(VARCHAR(8),GETDATE(), 114), ':',''),12)  + '|' + RTRIM(@FundingContractName)+'/BUSINESSBANKING/XII/2018'+@postFix 
SELECT 'FMF|31|' + RIGHT(REPLACE(CONVERT(VARCHAR(8), GETDATE(), 112)+CONVERT(VARCHAR(8),GETDATE(), 114), ':',''),12)  + '|' + RTRIM(@FundingContractName) 
Insert Into #tempDua (textFile) 
Select 
	RTRIM(NoPin) + '|' +  
	RTRIM(KodeSifatKreditPembiayaan) + '|' +  
	RTRIM(KodeJenisKreditPembiayaan) + '|' +  
	RTRIM(KodeSkimPembiayaan) + '|' +  
	RTRIM(BaruPerpanjangan) + '|' +  
	RTRIM(KodeJenisPenggunaan) + '|' +  
	RTRIM(KodeOrientasiPenggunaan) + '|' +  
	RTRIM(TakeoverDari) + '|' +  
	RTRIM(Email) + '|' +  
	RTRIM(HP) + '|' +  
	RTRIM(AlamatTempatBekerja) + '|' +  
	RTRIM(PenghasilanKotorPerTahun) + '|' +  
	RTRIM(KodeSumberPenghasilan) + '|' +  
	RTRIM(JumlahTanggungan) + '|' +  
	RTRIM(NamaPasangan) + '|' +  
	RTRIM(NomorIdentitasPasangan) + '|' +  
	RTRIM(TanggalLahirPasangan) + '|' +  
	RTRIM(PerjanjianPisahHarta) + '|' +  
	RTRIM(KodeBidangUsahaTempatBekerja) + '|' +  
	RTRIM(KodeGolonganDebitur) + '|' +  
	RTRIM(KodeBentukBadanUsaha) + '|' +  
	RTRIM(GoPublic) + '|' +  
	RTRIM(PeringkatRatingDebitur) + '|' +  
	RTRIM(LembagaPemeringkatRating) + '|' +  
	RTRIM(TanggalPemeringkat) + '|' +  
	RTRIM(NamaGroupDebitur) + '|' +  
	RTRIM(KodeAenisAgunan) + '|' +  
	RTRIM(KodeJenisPengikatan) + '|' +  
	RTRIM(TanggalPengikatan) + '|' +  
	RTRIM(NamaPemilikAgunan) + '|' +  
	RTRIM(AlamatAgunan) + '|' +  
	RTRIM(StatusKreditJoint) + '|' +  
	RTRIM(KodeDatiLokasiAgunan) + '|' + 
	RTRIM(Diasuransikan)  
From #Temp ORDER BY NoPin 
 
Insert Into #tempDua (textFile) 
SELECT 'FMF|' + RTRIM(CONVERT(VARCHAR(5),@Record)) + '|0'
