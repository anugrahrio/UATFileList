Petunjuk Deploy

A. Deploy DATABASE
1. Buka script yang ada pada folder ...\BATCH-FMF-489\DEPLOY\DATABASE\FMFDB dan lakukan review terlebih dahulu. 
Jika sudah ok, maka jalankan script seperti biasa pada database FMFDB.

2. Script yang dijalankan dengan urutan sebagai berikut:
	1. spSaveBPKBExtendCostPaymentReceive.sql
